package su.nightexpress.divineitems;

import java.io.File;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;
import su.nightexpress.divineitems.api.DivineItemsAPI;
import su.nightexpress.divineitems.cmds.MainCommand;
import su.nightexpress.divineitems.config.Config;
import su.nightexpress.divineitems.config.ConfigManager;
import su.nightexpress.divineitems.gui.GUIManager;
import su.nightexpress.divineitems.hooks.HookManager;
import su.nightexpress.divineitems.libs.glowapi.GlowPlugin;
import su.nightexpress.divineitems.libs.packetlistener.PacketListenerPlugin;
import su.nightexpress.divineitems.listeners.DamageListener;
import su.nightexpress.divineitems.listeners.GlobalListener;
import su.nightexpress.divineitems.modules.ModuleManager;
import su.nightexpress.divineitems.modules.tiers.resources.Resources;
import su.nightexpress.divineitems.nms.NMS;
import su.nightexpress.divineitems.nms.VersionUtils;
import su.nightexpress.divineitems.tasks.TaskManager;
import su.nightexpress.divineitems.utils.Spells;

public class DivineItems extends JavaPlugin {
   public static DivineItems instance;
   public DivineItemsAPI diapi;
   private MainCommand cmds;
   private ConfigManager cm;
   private ModuleManager mm;
   private HookManager hm;
   private GUIManager gui;
   private PluginManager pm;
   private TaskManager tasks;
   private VersionUtils vu;
   private PacketListenerPlugin plp;
   private GlowPlugin gp;

   public void onEnable() {
      instance = this;
      this.pm = this.getServer().getPluginManager();
      this.sendStatus();
      this.vu = new VersionUtils();
      if (!this.vu.setup()) {
         this.getServer().getConsoleSender().sendMessage("§7> §fServer version: §cUnsupported! Disabling...");
         this.pm.disablePlugin(this);
      } else {
         this.makeBackup();
         this.plp = new PacketListenerPlugin(this);
         this.plp.setup();
         this.gp = new GlowPlugin(this);
         this.gp.setup();
         this.cmds = new MainCommand(this);
         this.getCommand("divineitems").setExecutor(this.cmds);
         this.tasks = new TaskManager(this);
         this.cm = new ConfigManager(this);
         this.cm.setup();
         this.mm = new ModuleManager(this);
         this.hm = new HookManager(this);
         this.gui = new GUIManager(this);
         this.hm.setup();
         Resources.setup();
         this.gui.setup();
         this.mm.initialize();
         this.pm.registerEvents(new DamageListener(this), this);
         this.pm.registerEvents(new GlobalListener(), this);
         this.tasks.start();
         Spells.startPjEfTask();
      }
   }

   public void onDisable() {
      this.hm.disable();
      this.tasks.stop();
      this.gp.disable();
      this.getServer().getScheduler().cancelTasks(this);
      Resources.clear();
      instance = null;
   }

   public void reloadFull() {
      Resources.clear();
      this.hm.disable();
      this.tasks.stop();
      this.getServer().getScheduler().cancelTasks(this);
      this.mm.disable();
      Resources.setup();
      this.cm.setup();
      this.hm.setup();
      this.gui.setup();
      this.mm.initialize();
      this.tasks.start();
   }

   public void reloadCfg() {
      Resources.clear();
      this.cm.setup();
      Resources.setup();
      this.mm.cfgrel();
      this.gui.setup();
   }

   public NMS getNMS() {
      return this.vu.getNMS();
   }

   private void sendStatus() {
      this.getServer().getConsoleSender().sendMessage("§2---------[ §aPlugin Initializing §2]---------");
      this.getServer().getConsoleSender().sendMessage("§7> §fPlugin name: §a" + this.getName());
      this.getServer().getConsoleSender().sendMessage("§7> §fAuthor: §a" + (String)this.getDescription().getAuthors().get(0));
      this.getServer().getConsoleSender().sendMessage("§7> §fVersion: §a" + this.getDescription().getVersion());
   }

   public void makeBackup() {
      File var1 = new File(this.getDataFolder(), "config.yml");
      if (var1.exists()) {
         YamlConfiguration var2 = YamlConfiguration.loadConfiguration(var1);
         if (!var2.getString("cfg_version").equalsIgnoreCase("3.0.0")) {
            this.getServer().getConsoleSender().sendMessage("[§aDivineItems§7] §c================================");
            this.getServer().getConsoleSender().sendMessage("[§aDivineItems§7] §e    DIVINE   ITEMS  RPG  3.0 ");
            this.getServer().getConsoleSender().sendMessage("[§aDivineItems§7] §f     Preparing to update...");
            this.getServer().getConsoleSender().sendMessage("[§aDivineItems§7] §f    Don't worry, you won't");
            this.getServer().getConsoleSender().sendMessage("[§aDivineItems§7] §f      lose anything.");
            this.getServer().getConsoleSender().sendMessage("[§aDivineItems§7] §c================================");
            File var3 = new File(this.getDataFolder().getParentFile(), "DivineItemsRPG");
            var3.renameTo(new File(this.getDataFolder().getParentFile(), "DivineItemsRPG_Backup"));
            this.getServer().getConsoleSender().sendMessage("[§aDivineItems§7] §c================================");
            this.getServer().getConsoleSender().sendMessage("[§aDivineItems§7] §fUpdate finished. ");
            this.getServer().getConsoleSender().sendMessage("[§aDivineItems§7] §fOld configs were moved to");
            this.getServer().getConsoleSender().sendMessage("[§aDivineItems§7] §fDivineItemsRPG_Backup");
            this.getServer().getConsoleSender().sendMessage("[§aDivineItems§7] ");
            this.getServer().getConsoleSender().sendMessage("[§aDivineItems§7] §fPlease, check the configuration changes");
            this.getServer().getConsoleSender().sendMessage("[§aDivineItems§7] §fBefore using your old settings.");
            this.getServer().getConsoleSender().sendMessage("[§aDivineItems§7] §c================================");
         }
      }
   }

   public static DivineItems getInstance() {
      return instance;
   }

   public DivineItemsAPI getAPI() {
      return this.diapi;
   }

   public Config getCFG() {
      return this.cm.getCFG();
   }

   public MainCommand getCommander() {
      return this.cmds;
   }

   public ConfigManager getCM() {
      return this.cm;
   }

   public ModuleManager getMM() {
      return this.mm;
   }

   public HookManager getHM() {
      return this.hm;
   }

   public GUIManager getGUIManager() {
      return this.gui;
   }

   public PluginManager getPluginManager() {
      return this.pm;
   }

   public GlowPlugin getGlowLib() {
      return this.gp;
   }

   public TaskManager getTM() {
      return this.tasks;
   }

   public VersionUtils getVU() {
      return this.vu;
   }
}
