package su.nightexpress.divineitems;

import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.plugin.Plugin;

public abstract class DivineListener<P extends Plugin> implements Listener {
   public final P plugin;

   public DivineListener(P var1) {
      this.plugin = var1;
   }

   public void registerListeners() {
      this.plugin.getServer().getPluginManager().registerEvents(this, this.plugin);
   }

   public void unregisterListeners() {
      HandlerList.unregisterAll(this);
   }
}
