package su.nightexpress.divineitems;

public enum DivinePerms {
   REPAIR_ANVL("divineitems.repair.anvil");

   private String node;

   private DivinePerms(String var3) {
      this.node = var3;
   }

   public String node() {
      return this.node;
   }
}
