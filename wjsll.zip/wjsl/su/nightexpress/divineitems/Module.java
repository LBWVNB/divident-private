package su.nightexpress.divineitems;

import org.bukkit.event.Listener;

public interface Module extends Listener {
   String name();

   String version();

   boolean isDropable();

   boolean isResolvable();

   boolean isActive();

   void loadConfig();

   void enable();

   void unload();

   void reload();
}
