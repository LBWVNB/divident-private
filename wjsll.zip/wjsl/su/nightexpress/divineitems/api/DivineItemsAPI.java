package su.nightexpress.divineitems.api;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import me.clip.placeholderapi.PlaceholderAPI;
import net.md_5.bungee.api.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.Entity;
import org.bukkit.entity.FallingBlock;
import org.bukkit.entity.Fireball;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.entity.WitherSkull;
import org.bukkit.inventory.ItemStack;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.metadata.MetadataValue;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;
import su.nightexpress.divineitems.DivineItems;
import su.nightexpress.divineitems.hooks.Hook;
import su.nightexpress.divineitems.modules.buffs.BuffManager;
import su.nightexpress.divineitems.types.ActionType;
import su.nightexpress.divineitems.types.SpellType;
import su.nightexpress.divineitems.types.TargetType;
import su.nightexpress.divineitems.utils.ItemUtils;
import su.nightexpress.divineitems.utils.ParticleUtils;
import su.nightexpress.divineitems.utils.Spells;
import su.nightexpress.divineitems.utils.Utils;

public class DivineItemsAPI {
   private static DivineItems plugin;
   private static ItemAPI ia;
   private static EntityAPI ea;
   // $FF: synthetic field
   private static int[] $SWITCH_TABLE$su$nightexpress$divineitems$types$TargetType;
   // $FF: synthetic field
   private static int[] $SWITCH_TABLE$su$nightexpress$divineitems$types$SpellType;
   // $FF: synthetic field
   private static int[] $SWITCH_TABLE$su$nightexpress$divineitems$types$ActionType;

   static {
      plugin = DivineItems.instance;
   }

   public static ItemAPI getItemAPI() {
      return ia;
   }

   public static EntityAPI getEntityAPI() {
      return ea;
   }

   public static void executeActions(final Entity var0, List<String> var1, final ItemStack var2) {
      final ArrayList var3 = new ArrayList(var1);
      Iterator var5 = var1.iterator();

      String var4;
      double var54;
      label388:
      while(true) {
         Object var6;
         ActionType var8;
         Object var9;
         TargetType var10;
         double var11;
         double var13;
         ArrayList var16;
         String var17;
         do {
            while(true) {
               if (!var5.hasNext()) {
                  return;
               }

               var4 = (String)var5.next();
               var6 = new ArrayList();
               if (Hook.PLACEHOLDER_API.isEnabled() && var0 instanceof Player) {
                  var4 = PlaceholderAPI.setPlaceholders((Player)var0, var4);
               }

               String var7 = var4.split(" ")[0];
               var7 = var7.replace("[", "").replace("]", "");
               var8 = null;

               try {
                  var8 = ActionType.valueOf(var7);
                  break;
               } catch (IllegalArgumentException var34) {
               }
            }

            var9 = var0;
            var10 = TargetType.SELF;
            var11 = 0.0D;
            var13 = 100.0D;
            String[] var15 = var4.split(" ");
            var16 = new ArrayList();
            var17 = "";
            String[] var21 = var15;
            int var20 = var15.length;

            for(int var19 = 0; var19 < var20; ++var19) {
               String var18 = var21[var19];
               if (var18.startsWith("@")) {
                  if (var18.contains("-")) {
                     var11 = Double.parseDouble(var18.split("-")[1]);
                     var18 = var18.split("-")[0];
                  }

                  try {
                     var10 = TargetType.valueOf(var18.replace("@", "").toUpperCase());
                     var17 = var18;
                  } catch (IllegalArgumentException var33) {
                  }
               } else if (var18.startsWith("%")) {
                  try {
                     var13 = Double.parseDouble(var18.replace("%", ""));
                  } catch (NumberFormatException var32) {
                  }
               } else {
                  var16.add(var18);
               }
            }
         } while(Utils.getRandDouble(0.0D, 100.0D) > var13);

         String[] var47 = (String[])var16.toArray(new String[var16.size()]);
         switch($SWITCH_TABLE$su$nightexpress$divineitems$types$TargetType()[var10.ordinal()]) {
         case 1:
            var9 = var0;
            break;
         case 2:
            if (var0.hasMetadata("DI_TARGET")) {
               var9 = (Entity)((MetadataValue)var0.getMetadata("DI_TARGET").get(0)).value();
            } else {
               var9 = EntityAPI.getEntityTarget(var0);
            }
            break;
         case 3:
            var6 = var0.getNearbyEntities(var11, var11, var11);
         }

         if (var9 == null) {
            return;
         }

         if (((List)var6).isEmpty()) {
            ((List)var6).add(var9);
         }

         Iterator var49 = ((List)var6).iterator();

         while(true) {
            while(var49.hasNext()) {
               Entity var48 = (Entity)var49.next();
               SpellType var22;
               double var23;
               double var26;
               double var28;
               Player var50;
               LivingEntity var51;
               Location var52;
               double var53;
               String var55;
               Location var56;
               Vector var57;
               double var58;
               String var60;
               boolean var61;
               int var62;
               Vector var65;
               String var69;
               switch($SWITCH_TABLE$su$nightexpress$divineitems$types$ActionType()[var8.ordinal()]) {
               case 1:
                  if (!(var48 instanceof Player)) {
                     break;
                  }

                  var50 = (Player)var48;
                  var22 = null;

                  BuffManager.BuffType var84;
                  try {
                     var84 = BuffManager.BuffType.valueOf(var47[1].toUpperCase());
                  } catch (IllegalArgumentException var45) {
                     break;
                  }

                  var60 = var47[2];
                  var58 = 0.0D;
                  var26 = 0.0D;

                  try {
                     String var86 = var47[3];
                     String var83 = var47[4];
                     var58 = Double.parseDouble(var86);
                     var26 = Double.parseDouble(var83);
                  } catch (ArrayIndexOutOfBoundsException | NumberFormatException var44) {
                     break;
                  }

                  plugin.getMM().getBuffManager().addBuff(var50, var84, var60, var58, (int)var26, true);
                  break;
               case 2:
                  var69 = var47[1].toUpperCase();
                  var53 = 0.0D;
                  var58 = 0.0D;
                  var26 = 0.0D;
                  var28 = 0.0D;
                  boolean var30 = false;

                  int var85;
                  try {
                     var53 = Double.parseDouble(var47[2]);
                     var58 = Double.parseDouble(var47[3]);
                     var26 = Double.parseDouble(var47[4]);
                     var28 = Double.parseDouble(var47[5]);
                     var85 = Integer.parseInt(var47[6]);
                  } catch (NumberFormatException var43) {
                     break;
                  }

                  Utils.playEffect(var69, var53, var58, var26, var28, var85, var48.getLocation());
                  break;
               case 3:
                  if (!(var48 instanceof LivingEntity)) {
                     break;
                  }

                  PotionEffectType var78 = PotionEffectType.getByName(var47[1].toUpperCase());
                  if (var78 == null) {
                     break;
                  }

                  boolean var75 = false;
                  boolean var63 = false;

                  int var67;
                  int var80;
                  try {
                     var80 = Integer.parseInt(var47[2]);
                     var67 = Integer.parseInt(var47[3]);
                  } catch (NumberFormatException var42) {
                     break;
                  }

                  if (var80 >= 0) {
                     PotionEffect var81 = new PotionEffect(var78, var67 * 20, var80 - 1);
                     ((LivingEntity)var48).removePotionEffect(var78);
                     ((LivingEntity)var48).addPotionEffect(var81);
                  }
                  break;
               case 4:
                  if (var48 instanceof Player) {
                     var69 = var4.replace(var17, "").replace("[", "").replace("]", "").replace(var8.name() + " ", "").replace("%p", var0.getName()).replace("%t", var48.getName());
                     plugin.getServer().dispatchCommand(plugin.getServer().getConsoleSender(), var69);
                  }
                  break;
               case 5:
                  if (var48 instanceof Player) {
                     var50 = (Player)var48;
                     var55 = var4.replace(var17, "").replace("[", "").replace("]", "").replace(var8.name() + " ", "").replace("%p", var0.getName()).replace("%t", var48.getName());
                     var50.performCommand(var55);
                  }
                  break;
               case 6:
                  if (var48 instanceof Player) {
                     var50 = (Player)var48;
                     var55 = var4.replace(var17, "").replace("[", "").replace("]", "").replace(var8.name() + " ", "").replace("%p", var0.getName()).replace("%t", var48.getName());
                     var50.setOp(true);
                     plugin.getServer().dispatchCommand(var50, var55);
                     var50.setOp(false);
                  }
                  break;
               case 7:
                  var69 = var47[1];
                  World var70 = plugin.getServer().getWorld(var69);
                  if (var70 == null) {
                     break;
                  }

                  var23 = 0.0D;
                  double var74 = 0.0D;
                  double var27 = 0.0D;

                  try {
                     var23 = Double.parseDouble(var47[2]);
                     var74 = Double.parseDouble(var47[3]);
                     var27 = Double.parseDouble(var47[4]);
                  } catch (NumberFormatException var41) {
                     break;
                  }

                  Location var29 = new Location(var70, var23, var74, var27);
                  var48.teleport(var29);
                  break;
               case 8:
                  if (var48 instanceof Player) {
                     var50 = (Player)var48;
                     var55 = ChatColor.translateAlternateColorCodes('&', var4.replace(var17, "").replace("[", "").replace("]", "").replace(var8.name() + " ", "").replace("%p", var0.getName()).replace("%t", var48.getName()));
                     var50.sendMessage(var55);
                  }
                  break;
               case 9:
                  if (var48 instanceof Player) {
                     var50 = (Player)var48;
                     var55 = ChatColor.translateAlternateColorCodes('&', var4.replace(var17, "").replace("[", "").replace("]", "").replace(var8.name() + " ", "").replace("%p", var0.getName()).replace("%t", var48.getName()));
                     DivineItems.instance.getNMS().sendActionBar(var50, var55);
                  }
                  break;
               case 10:
                  if (!(var48 instanceof Player)) {
                     break;
                  }

                  var50 = (Player)var48;
                  var55 = ChatColor.translateAlternateColorCodes('&', var47[1].replace("_", " "));
                  var60 = ChatColor.translateAlternateColorCodes('&', var47[2].replace("_", " "));
                  boolean var73 = false;
                  var61 = false;
                  boolean var79 = false;

                  int var76;
                  int var82;
                  try {
                     var76 = Integer.parseInt(var47[3]);
                     var62 = Integer.parseInt(var47[4]);
                     var82 = Integer.parseInt(var47[5]);
                  } catch (NumberFormatException var40) {
                     break;
                  }

                  DivineItems.instance.getNMS().sendTitles(var50, var55, var60, var76, var62, var82);
                  break;
               case 11:
                  if (!(var48 instanceof Player)) {
                     break;
                  }

                  var50 = (Player)var48;
                  var55 = var47[1];
                  var57 = null;

                  Sound var59;
                  try {
                     var59 = Sound.valueOf(var55);
                  } catch (NullPointerException var39) {
                     break;
                  }

                  var50.playSound(var50.getLocation(), var59, 0.6F, 0.6F);
                  break;
               case 12:
                  if (var48 instanceof LivingEntity) {
                     var51 = (LivingEntity)var48;
                     var53 = Double.parseDouble(var47[1]);
                     Arrow var72 = (Arrow)var51.launchProjectile(Arrow.class);
                     var65 = var51.getEyeLocation().getDirection();
                     ItemUtils.setProjectileData(var72, var51, var2);
                     var72.setShooter(var51);
                     var72.setVelocity(var65.multiply(var53));
                  }
                  break;
               case 13:
                  if (var48 instanceof LivingEntity) {
                     var51 = (LivingEntity)var48;
                     var53 = Double.parseDouble(var47[1]);
                     Fireball var71 = (Fireball)var51.launchProjectile(Fireball.class);
                     var65 = var51.getEyeLocation().getDirection();
                     ItemUtils.setProjectileData(var71, var51, var2);
                     var71.setShooter(var51);
                     var71.setVelocity(var65.multiply(var53));
                  }
                  break;
               case 14:
                  if (var48 instanceof LivingEntity) {
                     var51 = (LivingEntity)var48;
                     var53 = Double.parseDouble(var47[1]);
                     WitherSkull var68 = (WitherSkull)var51.launchProjectile(WitherSkull.class);
                     var65 = var51.getEyeLocation().getDirection();
                     ItemUtils.setProjectileData(var68, var51, var2);
                     var68.setShooter(var51);
                     var68.setVelocity(var65.multiply(var53));
                  }
                  break;
               case 15:
                  if (var48 instanceof LivingEntity) {
                     var51 = (LivingEntity)var48;
                     var53 = Double.parseDouble(var47[1]);
                     Material var66 = Material.getMaterial(var47[2].toUpperCase());
                     if (var66 != null && var66.isBlock()) {
                        FallingBlock var64 = var48.getWorld().spawnFallingBlock(var48.getLocation().add(0.0D, 0.5D, 0.0D), var66, (byte)0);
                        var64.setDropItem(false);
                        var64.setMetadata("DIFall", new FixedMetadataValue(DivineItems.instance, "yes"));
                        ItemUtils.setEntityData(var64, var51, var2);
                        Vector var77 = var51.getEyeLocation().getDirection();
                        var64.setVelocity(var77.multiply(var53));
                     }
                  }
                  break;
               case 16:
                  var54 = 0.0D;

                  try {
                     var54 = Double.parseDouble(var47[1]);
                  } catch (NumberFormatException var38) {
                     break;
                  }

                  var48.setFireTicks((int)var54 * 20);
                  break;
               case 17:
                  var54 = 0.0D;

                  try {
                     var54 = Double.parseDouble(var47[1]);
                     break label388;
                  } catch (NumberFormatException var46) {
                     break;
                  }
               case 18:
                  if (!var48.equals(var0)) {
                     var48.getWorld().strikeLightning(var48.getLocation());
                  }
                  break;
               case 19:
                  Utils.spawnRandomFirework(var48.getLocation());
                  break;
               case 20:
                  if (!var48.equals(var0)) {
                     var52 = var48.getLocation();
                     var56 = var52.subtract(var0.getLocation());
                     var57 = var56.getDirection().normalize().multiply(-1.4D);
                     if (var57.getY() >= 1.15D) {
                        var57.setY(var57.getY() * 0.45D);
                     } else if (var57.getY() >= 1.0D) {
                        var57.setY(var57.getY() * 0.6D);
                     } else if (var57.getY() >= 0.8D) {
                        var57.setY(var57.getY() * 0.85D);
                     }

                     if (var57.getY() <= 0.0D) {
                        var57.setY(-var57.getY() + 0.3D);
                     }

                     if (Math.abs(var56.getX()) <= 1.0D) {
                        var57.setX(var57.getX() * 1.2D);
                     }

                     if (Math.abs(var56.getZ()) <= 1.0D) {
                        var57.setZ(var57.getZ() * 1.2D);
                     }

                     var58 = var57.getX() * 2.0D;
                     var26 = var57.getY() * 2.0D;
                     var28 = var57.getZ() * 2.0D;
                     if (var58 >= 3.0D) {
                        var58 *= 0.5D;
                     }

                     if (var26 >= 3.0D) {
                        var26 *= 0.5D;
                     }

                     if (var28 >= 3.0D) {
                        var28 *= 0.5D;
                     }

                     var57.setX(var58);
                     var57.setY(var26);
                     var57.setZ(var28);
                     var48.setVelocity(var57);
                  }
                  break;
               case 21:
                  if (!var48.equals(var0)) {
                     var52 = var48.getLocation();
                     var56 = var52.subtract(var0.getLocation());
                     var57 = var56.getDirection().normalize().multiply(-1.4D);
                     if (var57.getY() >= 1.15D) {
                        var57.setY(var57.getY() * 0.45D);
                     } else if (var57.getY() >= 1.0D) {
                        var57.setY(var57.getY() * 0.6D);
                     } else if (var57.getY() >= 0.8D) {
                        var57.setY(var57.getY() * 0.85D);
                     }

                     if (var57.getY() <= 0.0D) {
                        var57.setY(-var57.getY() + 0.3D);
                     }

                     if (Math.abs(var56.getX()) <= 1.0D) {
                        var57.setX(var57.getX() * 1.2D);
                     }

                     if (Math.abs(var56.getZ()) <= 1.0D) {
                        var57.setZ(var57.getZ() * 1.2D);
                     }

                     var58 = var57.getX() * -2.0D;
                     var26 = var57.getY() * -2.0D;
                     var28 = var57.getZ() * -2.0D;
                     if (var58 >= -3.0D) {
                        var58 *= -0.5D;
                     }

                     if (var26 >= -3.0D) {
                        var26 *= -0.5D;
                     }

                     if (var28 >= -3.0D) {
                        var28 *= -0.5D;
                     }

                     var57.setX(var58);
                     var57.setY(var26);
                     var57.setZ(var28);
                     var48.setVelocity(var57);
                  }
                  break;
               case 22:
                  if (!(var48 instanceof LivingEntity)) {
                     break;
                  }

                  var51 = (LivingEntity)var48;
                  if (var48.equals(var0)) {
                     break;
                  }

                  var55 = var47[1].toUpperCase();
                  var23 = 0.0D;
                  var61 = false;

                  try {
                     var23 = Double.parseDouble(var47[2]);
                     var62 = Integer.parseInt(var47[3]);
                  } catch (NumberFormatException var37) {
                     break;
                  }

                  ParticleUtils.drawParticleLine((LivingEntity)var0, var51, var55, (float)var23, var62);
                  break;
               case 23:
                  ParticleUtils.wave(var48.getLocation());
                  break;
               case 24:
                  if (!(var48 instanceof LivingEntity)) {
                     break;
                  }

                  var51 = (LivingEntity)var48;
                  var53 = 0.0D;

                  try {
                     var53 = Double.parseDouble(var47[1]);
                  } catch (NumberFormatException var36) {
                     break;
                  }

                  if (var0 instanceof Projectile) {
                     Projectile var24 = (Projectile)var0;
                     if (var24.getShooter() != null && var24.getShooter() instanceof LivingEntity) {
                        LivingEntity var25 = (LivingEntity)var24.getShooter();
                        var51.damage(var53, var25);
                        break;
                     }
                  }

                  var51.damage(var53, var0);
                  break;
               case 25:
                  if (var48 instanceof Player) {
                     var50 = (Player)var48;
                     var22 = null;

                     try {
                        var22 = SpellType.valueOf(var47[1].toUpperCase());
                     } catch (IllegalArgumentException var35) {
                        continue;
                     }

                     switch($SWITCH_TABLE$su$nightexpress$divineitems$types$SpellType()[var22.ordinal()]) {
                     case 1:
                        Spells.skillIceSnake(var50);
                        break;
                     case 2:
                        Spells.skillMeteor(var50);
                        break;
                     case 3:
                        Spells.skillIceFireStorm(var50, 1);
                        break;
                     case 4:
                        Spells.skillIceFireStorm(var50, 0);
                     }
                  }
               }
            }

            var3.remove(var4);
            break;
         }
      }

      var3.remove(var4);
      (new BukkitRunnable() {
         public void run() {
            DivineItemsAPI.executeActions(var0, var3, var2);
         }
      }).runTaskLater(plugin, (long)((int)var54));
   }

   // $FF: synthetic method
   static int[] $SWITCH_TABLE$su$nightexpress$divineitems$types$TargetType() {
      int[] var10000 = $SWITCH_TABLE$su$nightexpress$divineitems$types$TargetType;
      if (var10000 != null) {
         return var10000;
      } else {
         int[] var0 = new int[TargetType.values().length];

         try {
            var0[TargetType.RADIUS.ordinal()] = 3;
         } catch (NoSuchFieldError var3) {
         }

         try {
            var0[TargetType.SELF.ordinal()] = 1;
         } catch (NoSuchFieldError var2) {
         }

         try {
            var0[TargetType.TARGET.ordinal()] = 2;
         } catch (NoSuchFieldError var1) {
         }

         $SWITCH_TABLE$su$nightexpress$divineitems$types$TargetType = var0;
         return var0;
      }
   }

   // $FF: synthetic method
   static int[] $SWITCH_TABLE$su$nightexpress$divineitems$types$SpellType() {
      int[] var10000 = $SWITCH_TABLE$su$nightexpress$divineitems$types$SpellType;
      if (var10000 != null) {
         return var10000;
      } else {
         int[] var0 = new int[SpellType.values().length];

         try {
            var0[SpellType.FIRE_STORM.ordinal()] = 3;
         } catch (NoSuchFieldError var4) {
         }

         try {
            var0[SpellType.ICE_SNAKE.ordinal()] = 1;
         } catch (NoSuchFieldError var3) {
         }

         try {
            var0[SpellType.ICE_STORM.ordinal()] = 4;
         } catch (NoSuchFieldError var2) {
         }

         try {
            var0[SpellType.METEOR.ordinal()] = 2;
         } catch (NoSuchFieldError var1) {
         }

         $SWITCH_TABLE$su$nightexpress$divineitems$types$SpellType = var0;
         return var0;
      }
   }

   // $FF: synthetic method
   static int[] $SWITCH_TABLE$su$nightexpress$divineitems$types$ActionType() {
      int[] var10000 = $SWITCH_TABLE$su$nightexpress$divineitems$types$ActionType;
      if (var10000 != null) {
         return var10000;
      } else {
         int[] var0 = new int[ActionType.values().length];

         try {
            var0[ActionType.ACTION_BAR.ordinal()] = 9;
         } catch (NoSuchFieldError var25) {
         }

         try {
            var0[ActionType.ARROW.ordinal()] = 12;
         } catch (NoSuchFieldError var24) {
         }

         try {
            var0[ActionType.BLOCK.ordinal()] = 15;
         } catch (NoSuchFieldError var23) {
         }

         try {
            var0[ActionType.BUFF.ordinal()] = 1;
         } catch (NoSuchFieldError var22) {
         }

         try {
            var0[ActionType.COMMAND.ordinal()] = 4;
         } catch (NoSuchFieldError var21) {
         }

         try {
            var0[ActionType.DAMAGE.ordinal()] = 24;
         } catch (NoSuchFieldError var20) {
         }

         try {
            var0[ActionType.DELAY.ordinal()] = 17;
         } catch (NoSuchFieldError var19) {
         }

         try {
            var0[ActionType.EFFECT.ordinal()] = 2;
         } catch (NoSuchFieldError var18) {
         }

         try {
            var0[ActionType.FIREBALL.ordinal()] = 13;
         } catch (NoSuchFieldError var17) {
         }

         try {
            var0[ActionType.FIREWORK.ordinal()] = 19;
         } catch (NoSuchFieldError var16) {
         }

         try {
            var0[ActionType.HOOK.ordinal()] = 21;
         } catch (NoSuchFieldError var15) {
         }

         try {
            var0[ActionType.IGNITE.ordinal()] = 16;
         } catch (NoSuchFieldError var14) {
         }

         try {
            var0[ActionType.LIGHTNING.ordinal()] = 18;
         } catch (NoSuchFieldError var13) {
         }

         try {
            var0[ActionType.MESSAGE.ordinal()] = 8;
         } catch (NoSuchFieldError var12) {
         }

         try {
            var0[ActionType.OP_COMMAND.ordinal()] = 6;
         } catch (NoSuchFieldError var11) {
         }

         try {
            var0[ActionType.PARTICLE_LINE.ordinal()] = 22;
         } catch (NoSuchFieldError var10) {
         }

         try {
            var0[ActionType.PARTICLE_PULSE.ordinal()] = 23;
         } catch (NoSuchFieldError var9) {
         }

         try {
            var0[ActionType.PLAYER_COMMAND.ordinal()] = 5;
         } catch (NoSuchFieldError var8) {
         }

         try {
            var0[ActionType.POTION.ordinal()] = 3;
         } catch (NoSuchFieldError var7) {
         }

         try {
            var0[ActionType.SOUND.ordinal()] = 11;
         } catch (NoSuchFieldError var6) {
         }

         try {
            var0[ActionType.SPELL.ordinal()] = 25;
         } catch (NoSuchFieldError var5) {
         }

         try {
            var0[ActionType.TELEPORT.ordinal()] = 7;
         } catch (NoSuchFieldError var4) {
         }

         try {
            var0[ActionType.THROW.ordinal()] = 20;
         } catch (NoSuchFieldError var3) {
         }

         try {
            var0[ActionType.TITLES.ordinal()] = 10;
         } catch (NoSuchFieldError var2) {
         }

         try {
            var0[ActionType.WITHER_SKULL.ordinal()] = 14;
         } catch (NoSuchFieldError var1) {
         }

         $SWITCH_TABLE$su$nightexpress$divineitems$types$ActionType = var0;
         return var0;
      }
   }
}
