package su.nightexpress.divineitems.api;

import cn.mcdcs.legendcore.api.attribute.AttributeManagerAPI;
import java.util.Iterator;
import java.util.List;
import net.md_5.bungee.api.ChatColor;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Creeper;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.Vector;
import su.nightexpress.divineitems.DivineItems;
import su.nightexpress.divineitems.attributes.ItemStat;
import su.nightexpress.divineitems.hooks.Hook;
import su.nightexpress.divineitems.modules.buffs.BuffManager;
import su.nightexpress.divineitems.modules.sets.SetManager;
import su.nightexpress.divineitems.utils.ItemUtils;

public class EntityAPI {
   private static DivineItems plugin;

   public static LivingEntity getEntityTarget(Entity entity) {
      return getEntityTargetByRange(entity, (double)plugin.getCM().getCFG().getMaxTargetDistance());
   }

   public static LivingEntity getEntityTargetByRange(Entity entity, double d) {
      LivingEntity livingEntity = null;
      Location location = entity.getLocation();
      if (entity instanceof LivingEntity) {
         location = ((LivingEntity)entity).getEyeLocation();
      }

      Vector vector = location.getDirection();

      for(int n = 0; (double)n < d; ++n) {
         Location location2 = location.add(vector);
         if (location2.getBlock() != null && location2.getBlock().getType() != Material.AIR) {
            break;
         }

         Entity[] entityArray = location2.getChunk().getEntities();
         int n2 = entityArray.length;

         for(int n3 = 0; n3 < n2; ++n3) {
            Entity entity2 = entityArray[n3];
            if (entity2 instanceof LivingEntity && !(entity2 instanceof ArmorStand) && entity2.getWorld().equals(location2.getWorld()) && !(entity2.getLocation().distance(location2) > 1.5D) && (!Hook.WORLD_GUARD.isEnabled() || plugin.getHM().getWorldGuard().canFights(entity2, entity)) && (!Hook.CITIZENS.isEnabled() || !plugin.getHM().getCitizens().isNPC(entity2)) && !entity2.equals(entity)) {
               return (LivingEntity)entity2;
            }
         }
      }

      return (LivingEntity)livingEntity;
   }

   public static double getEnchantedDefense(Entity entity, LivingEntity livingEntity) {
      double d = 0.0D;
      ItemStack[] itemStackArray;
      int n;
      int n3;
      ItemStack itemStack;
      if (entity instanceof Creeper) {
         itemStackArray = getEquipment(livingEntity, true);
         n = itemStackArray.length;

         for(n3 = 0; n3 < n; ++n3) {
            itemStack = itemStackArray[n3];
            if (itemStack != null && itemStack.getType() != Material.AIR && itemStack.containsEnchantment(Enchantment.PROTECTION_EXPLOSIONS)) {
               d += (double)(itemStack.getEnchantmentLevel(Enchantment.PROTECTION_EXPLOSIONS) * 2);
            }
         }
      } else if (entity instanceof Projectile) {
         itemStackArray = getEquipment(livingEntity, true);
         n = itemStackArray.length;

         for(n3 = 0; n3 < n; ++n3) {
            itemStack = itemStackArray[n3];
            if (itemStack != null && itemStack.getType() != Material.AIR && itemStack.containsEnchantment(Enchantment.PROTECTION_PROJECTILE)) {
               d += (double)(itemStack.getEnchantmentLevel(Enchantment.PROTECTION_PROJECTILE) * 2);
            }
         }
      } else {
         itemStackArray = getEquipment(livingEntity, true);
         n = itemStackArray.length;

         for(n3 = 0; n3 < n; ++n3) {
            itemStack = itemStackArray[n3];
            if (itemStack != null && itemStack.getType() != Material.AIR && itemStack.containsEnchantment(Enchantment.PROTECTION_ENVIRONMENTAL)) {
               d += (double)itemStack.getEnchantmentLevel(Enchantment.PROTECTION_ENVIRONMENTAL);
            }
         }
      }

      return d;
   }

   public static double getPvPEDamage(LivingEntity livingEntity, LivingEntity livingEntity2) {
      double d = 0.0D;
      if (livingEntity2 instanceof Player) {
         d = livingEntity instanceof Player ? getItemStat(livingEntity2, ItemStat.PVP_DAMAGE) : getItemStat(livingEntity2, ItemStat.PVE_DAMAGE);
      }

      return d;
   }

   public static double getItemStat(LivingEntity livingEntity, ItemStat itemStat) {
      if (!(livingEntity instanceof Player) && !plugin.getCM().getCFG().allowAttributesToMobs()) {
         return -1.0D;
      } else {
         double d = 0.0D;
         double d2 = getBase(livingEntity, itemStat);
         double d3 = getBonus(livingEntity, itemStat);
         if (livingEntity instanceof Player) {
            Player player = (Player)livingEntity;
            d3 += plugin.getMM().getBuffManager().getBuff(player, BuffManager.BuffType.ITEM_STAT, itemStat.name());
         }

         if (itemStat.isPercent()) {
            d = d2 + d3;
         } else {
            if (d2 == 0.0D && d3 != 0.0D) {
               d2 = 1.0D;
            }

            d = d2 * (1.0D + d3 / 100.0D);
         }

         if (itemStat.getCapability() >= 0.0D && d > itemStat.getCapability()) {
            d = itemStat.getCapability();
         }

         return d;
      }
   }

   public static double getBase(LivingEntity livingEntity, ItemStat itemStat) {
      String string = plugin.getCM().getCFG().getAttributeFormat();
      String string2 = string.replace("%att_value%", itemStat.getValue()).replace("%att_name%", itemStat.getName()).replace("%att_prefix%", itemStat.getPrefix());
      double d = 0.0D;
      if (!plugin.getCM().getCFG().allowAttributesToMobs() && !(livingEntity instanceof Player)) {
         return d;
      } else {
         if (plugin.getMM().getSetManager().isActive()) {
            Iterator var6 = plugin.getMM().getSetManager().getSets().iterator();

            while(var6.hasNext()) {
               SetManager.ItemSet itemSet = (SetManager.ItemSet)var6.next();
               if (plugin.getMM().getSetManager().getSetAttributes(livingEntity, itemSet, false).containsKey(itemStat)) {
                  d += (Double)plugin.getMM().getSetManager().getSetAttributes(livingEntity, itemSet, false).get(itemStat);
               }
            }
         }

         ItemStack[] itemStackArray = getEquipment(livingEntity, false);
         int n = itemStackArray.length;

         for(int n2 = 0; n2 < n; ++n2) {
            ItemStack itemSet = itemStackArray[n2];
            if (itemSet != null && itemSet.hasItemMeta() && itemSet.getItemMeta().hasLore()) {
               List list = itemSet.getItemMeta().getLore();
               Iterator var11 = list.iterator();

               while(var11.hasNext()) {
                  String string3 = (String)var11.next();
                  if (string3.startsWith(string2)) {
                     String string4 = ChatColor.stripColor(string3.replace(string2, "").replace(plugin.getCM().getCFG().getStrPercent(), "").replace(plugin.getCM().getCFG().getStrModifier(), ""));
                     if (!string4.isEmpty()) {
                        double d2 = Double.parseDouble(string4);
                        d += d2;
                     }
                     break;
                  }
               }

               if (plugin.getMM().getGemManager().getItemGemStats(itemSet, false).containsKey(itemStat)) {
                  d += (Double)plugin.getMM().getGemManager().getItemGemStats(itemSet, false).get(itemStat);
               }
            }
         }

         return d;
      }
   }

   public static double getBonus(LivingEntity livingEntity, ItemStat itemStat) {
      String string = plugin.getCM().getCFG().getAttributeFormat();
      String string2 = string.replace("%att_value%", itemStat.getValue()).replace("%att_name%", itemStat.getName()).replace("%att_prefix%", itemStat.getBonus());
      double d = 0.0D;
      if (!plugin.getCM().getCFG().allowAttributesToMobs() && !(livingEntity instanceof Player)) {
         return d;
      } else {
         if (plugin.getMM().getSetManager().isActive()) {
            Iterator var6 = plugin.getMM().getSetManager().getSets().iterator();

            while(var6.hasNext()) {
               SetManager.ItemSet itemSet = (SetManager.ItemSet)var6.next();
               if (plugin.getMM().getSetManager().getSetAttributes(livingEntity, itemSet, true).containsKey(itemStat)) {
                  d += (Double)plugin.getMM().getSetManager().getSetAttributes(livingEntity, itemSet, true).get(itemStat);
               }
            }
         }

         ItemStack[] itemStackArray = getEquipment(livingEntity, false);
         int n = itemStackArray.length;

         for(int n2 = 0; n2 < n; ++n2) {
            ItemStack itemSet = itemStackArray[n2];
            if (itemSet != null && itemSet.hasItemMeta() && itemSet.getItemMeta().hasLore()) {
               if (plugin.getMM().getGemManager().getItemGemStats(itemSet, true).containsKey(itemStat)) {
                  d += (Double)plugin.getMM().getGemManager().getItemGemStats(itemSet, true).get(itemStat);
               }

               List list = itemSet.getItemMeta().getLore();
               Iterator var11 = list.iterator();

               while(var11.hasNext()) {
                  String string3 = (String)var11.next();
                  if (string3.startsWith(string2)) {
                     String string4 = ChatColor.stripColor(string3.replace(string2, "").replace(plugin.getCM().getCFG().getStrPercent(), "").replace(plugin.getCM().getCFG().getStrModifier(), ""));
                     double d2 = 0.0D;

                     try {
                        d2 = Double.parseDouble(string4);
                     } catch (NumberFormatException var17) {
                        Bukkit.getConsoleSender().sendMessage("[DivineItems] Unable to get bonus stats from string: " + string4);
                     }

                     d += d2;
                     break;
                  }
               }
            }
         }

         return d;
      }
   }

   public static ItemStack[] getEquipment(LivingEntity livingEntity, boolean bl) {
      try {
         return AttributeManagerAPI.getInstance().getDivineItemsRPGItems(livingEntity);
      } catch (Throwable var5) {
         if (livingEntity instanceof Player && Hook.RPG_INVENTORY.isEnabled()) {
            Player player = (Player)livingEntity;
            return plugin.getHM().getRPGInventory().getEquip(player);
         } else {
            ItemStack[] itemStackArray = new ItemStack[6];
            if (livingEntity != null && livingEntity.getEquipment() != null) {
               for(int n = 2; n < 6; ++n) {
                  itemStackArray[n] = livingEntity.getEquipment().getArmorContents()[n - 2];
               }

               if (livingEntity.getEquipment().getItemInOffHand() != null && (plugin.getCM().getCFG().allowAttributesToOffHand() || livingEntity.getEquipment().getItemInOffHand().getType() == Material.SHIELD)) {
                  itemStackArray[1] = livingEntity.getEquipment().getItemInOffHand();
               }

               if (livingEntity.getEquipment().getItemInMainHand() != null && !ItemUtils.isArmor(livingEntity.getEquipment().getItemInMainHand())) {
                  itemStackArray[0] = bl ? new ItemStack(Material.AIR) : livingEntity.getEquipment().getItemInMainHand();
               }
            }

            return itemStackArray;
         }
      }
   }

   public static void checkForLegitItems(Player player) {
      int n = 0;
      ItemStack[] itemStackArray;
      ItemStack[] itemStackArray2 = itemStackArray = player.getInventory().getArmorContents();
      int n2 = itemStackArray.length;

      for(int n3 = 0; n3 < n2; ++n3) {
         ItemStack itemStack = itemStackArray2[n3];
         if (itemStack != null && !ItemAPI.canUse(itemStack, player)) {
            if (n == 2) {
               player.getInventory().setChestplate((ItemStack)null);
            } else if (n == 1) {
               player.getInventory().setLeggings((ItemStack)null);
            } else if (n == 0) {
               player.getInventory().setBoots((ItemStack)null);
            } else {
               player.getInventory().setHelmet((ItemStack)null);
            }

            if (player.getInventory().firstEmpty() != -1) {
               player.getInventory().addItem(new ItemStack[]{itemStack});
            } else {
               player.getWorld().dropItem(player.getLocation(), itemStack).setPickupDelay(40);
            }
         }

         ++n;
      }

   }

   static {
      plugin = DivineItems.instance;
   }
}
