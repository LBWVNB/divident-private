package su.nightexpress.divineitems.api;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import net.md_5.bungee.api.ChatColor;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.WordUtils;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.LeatherArmorMeta;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.inventory.meta.SpawnEggMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import su.nightexpress.divineitems.DivineItems;
import su.nightexpress.divineitems.api.events.DivineItemDamageEvent;
import su.nightexpress.divineitems.attributes.ItemStat;
import su.nightexpress.divineitems.config.Lang;
import su.nightexpress.divineitems.modules.ability.AbilityManager;
import su.nightexpress.divineitems.modules.buffs.BuffManager;
import su.nightexpress.divineitems.modules.enchant.EnchantManager;
import su.nightexpress.divineitems.modules.scrolls.ScrollManager;
import su.nightexpress.divineitems.modules.tiers.TierManager;
import su.nightexpress.divineitems.nbt.NBTItem;
import su.nightexpress.divineitems.nms.NBTAttribute;
import su.nightexpress.divineitems.types.AmmoType;
import su.nightexpress.divineitems.types.ArmorType;
import su.nightexpress.divineitems.types.DamageType;
import su.nightexpress.divineitems.types.SlotType;
import su.nightexpress.divineitems.utils.ItemUtils;
import su.nightexpress.divineitems.utils.Utils;

public class ItemAPI {
   private static DivineItems plugin;
   private static Random r;
   // $FF: synthetic field
   private static int[] $SWITCH_TABLE$org$bukkit$Material;
   // $FF: synthetic field
   private static int[] $SWITCH_TABLE$su$nightexpress$divineitems$attributes$ItemStat;

   static {
      plugin = DivineItems.instance;
      r = new Random();
   }

   public static boolean hasOwner(ItemStack var0) {
      return plugin.getMM().getSoulboundManager().hasOwner(var0);
   }

   public static boolean isOwner(ItemStack var0, Player var1) {
      return plugin.getMM().getSoulboundManager().isOwner(var0, var1);
   }

   public static String getOwner(ItemStack var0) {
      return plugin.getMM().getSoulboundManager().getOwner(var0);
   }

   public static ItemStack setOwner(ItemStack var0, Player var1) {
      return plugin.getMM().getSoulboundManager().setOwner(var0, var1);
   }

   public static boolean isUntradeable(ItemStack var0) {
      return plugin.getMM().getSoulboundManager().isUntradeable(var0);
   }

   public static boolean isSoulboundRequired(ItemStack var0) {
      return plugin.getMM().getSoulboundManager().isSoulboundRequired(var0);
   }

   public static boolean isSoulBinded(ItemStack var0) {
      return plugin.getMM().getSoulboundManager().isSoulBinded(var0);
   }

   public static boolean isLevelRequired(ItemStack var0) {
      if (var0 != null && var0.hasItemMeta() && var0.getItemMeta().hasLore()) {
         ItemMeta var1 = var0.getItemMeta();
         List var2 = var1.getLore();
         String[] var3 = plugin.getCFG().getStrLevel().split("%n");
         String var4 = null;
         if (var3[0] != null) {
            var4 = var3[0];
         }

         String var5 = null;
         if (var3.length == 2 && var3[1] != null) {
            var5 = var3[1];
         }

         Iterator var7 = var2.iterator();

         String var6;
         do {
            if (!var7.hasNext()) {
               return false;
            }

            var6 = (String)var7.next();
         } while((var4 == null || !var6.contains(var4)) && (var5 == null || !var6.contains(var5)));

         return true;
      } else {
         return false;
      }
   }

   public static boolean isClassRequired(ItemStack var0) {
      if (var0 != null && var0.hasItemMeta() && var0.getItemMeta().hasLore()) {
         ItemMeta var1 = var0.getItemMeta();
         List var2 = var1.getLore();
         Iterator var4 = var2.iterator();

         while(var4.hasNext()) {
            String var3 = (String)var4.next();
            if (var3.startsWith(plugin.getCFG().getStrClass())) {
               return true;
            }
         }

         return false;
      } else {
         return false;
      }
   }

   public static boolean isAllowedPlayerClass(ItemStack var0, Player var1) {
      if (var0 != null && var0.hasItemMeta() && var0.getItemMeta().hasLore()) {
         ItemMeta var2 = var0.getItemMeta();
         List var3 = var2.getLore();
         Iterator var5 = var3.iterator();

         while(true) {
            String var4;
            do {
               if (!var5.hasNext()) {
                  return false;
               }

               var4 = (String)var5.next();
            } while(!var4.startsWith(plugin.getCFG().getStrClass()));

            String var6 = var4.replace(plugin.getCFG().getStrClass(), "");
            String[] var7 = var6.split(plugin.getCFG().getStrClassSeparator());

            for(int var8 = 0; var8 < var7.length; ++var8) {
               String var9 = plugin.getHM().getClassesHook().getPlayerClass(var1);
               if (ChatColor.stripColor(var9).equalsIgnoreCase(ChatColor.stripColor(var7[var8]))) {
                  return true;
               }
            }
         }
      } else {
         return true;
      }
   }

   public static boolean canUse(ItemStack var0, Player var1) {
      if (var0 != null && var0.hasItemMeta() && var0.getItemMeta().hasLore()) {
         if (getDurability(var0, 0) == 0 && !plugin.getCFG().breakItems()) {
            var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_BrokenItem.toMsg());
            return false;
         } else if (isClassRequired(var0) && !isAllowedPlayerClass(var0, var1)) {
            if (var1.hasPermission("divineitems.bypass.class")) {
               return true;
            } else {
               var1.sendMessage(Lang.Prefix.toMsg() + Lang.Restrictions_Class.toMsg().replace("%s", plugin.getHM().getClassesHook().getPlayerClass(var1)));
               return false;
            }
         } else if (isLevelRequired(var0) && getLevelRequired(var0) > plugin.getHM().getLevelsHook().getPlayerLevel(var1)) {
            if (var1.hasPermission("divineitems.bypass.level")) {
               return true;
            } else {
               var1.sendMessage(Lang.Prefix.toMsg() + Lang.Restrictions_Level.toMsg().replace("%s", "" + plugin.getHM().getLevelsHook().getPlayerLevel(var1)));
               return false;
            }
         } else {
            if (plugin.getMM().getSoulboundManager().isActive()) {
               if (plugin.getMM().getSoulboundManager().isSoulboundRequired(var0)) {
                  if (var1.hasPermission("divineitems.bypass.soulbound")) {
                     return true;
                  }

                  var1.sendMessage(Lang.Prefix.toMsg() + Lang.Restrictions_Usage.toMsg());
                  return false;
               }

               if (plugin.getMM().getSoulboundManager().isSoulBinded(var0) || plugin.getMM().getSoulboundManager().hasOwner(var0)) {
                  if (var1.hasPermission("divineitems.bypass.owner")) {
                     return true;
                  }

                  if (!plugin.getMM().getSoulboundManager().isOwner(var0, var1)) {
                     var1.sendMessage(Lang.Prefix.toMsg() + Lang.Restrictions_NotOwner.toMsg());
                     return false;
                  }
               }
            }

            if (plugin.getMM().getIdentifyManager().isActive() && plugin.getMM().getIdentifyManager().isUnidentified(var0)) {
               var1.sendMessage(Lang.Prefix.toMsg() + Lang.Identify_NoEquip.toMsg());
               return false;
            } else {
               return true;
            }
         }
      } else {
         return true;
      }
   }

   public static boolean hasAttribute(ItemStack var0, ItemStat var1) {
      if (var0 != null && var0.hasItemMeta() && var0.getItemMeta().hasLore()) {
         String var2 = plugin.getCFG().getAttributeFormat();
         String var3 = var2.replace("%att_value%", var1.getValue()).replace("%att_name%", var1.getName()).replace("%att_prefix%", var1.getPrefix());
         Iterator var5 = var0.getItemMeta().getLore().iterator();

         while(var5.hasNext()) {
            String var4 = (String)var5.next();
            if (var4.startsWith(var3)) {
               return true;
            }
         }

         return false;
      } else {
         return false;
      }
   }

   public static int getLevelRequired(ItemStack var0) {
      if (var0 != null && var0.hasItemMeta() && var0.getItemMeta().hasLore()) {
         int var1 = -1;
         ItemMeta var2 = var0.getItemMeta();
         List var3 = var2.getLore();
         String[] var4 = plugin.getCFG().getStrLevel().split("%n");
         String var5 = "";
         if (var4[0] != null) {
            var5 = var4[0];
         }

         String var6 = "";
         if (var4.length == 2 && var4[1] != null) {
            var6 = var4[1];
         }

         if (var5.equals("") && var6.equals("")) {
            return var1;
         } else {
            Iterator var8 = var3.iterator();

            while(var8.hasNext()) {
               String var7 = (String)var8.next();
               if (var7.contains(var5) && var7.contains(var6)) {
                  var7 = ChatColor.stripColor(var7.replace(var5, "").replace(var6, "").trim().replaceAll("\\s+", ""));

                  try {
                     var1 = Integer.parseInt(var7);
                  } catch (NumberFormatException var10) {
                     Bukkit.getConsoleSender().sendMessage("[DivineItems] Unable to get level from string: " + var7);
                  }
                  break;
               }
            }

            return var1;
         }
      } else {
         return -1;
      }
   }

   public static int getDurability(ItemStack var0, int var1) {
      int var2 = -1;
      if (var0 != null && var0.hasItemMeta() && var0.getItemMeta().hasLore()) {
         String var3 = plugin.getCFG().getAttributeFormat();
         ItemStat var4 = ItemStat.DURABILITY;
         String var5 = var3.replace("%att_value%", var4.getValue()).replace("%att_name%", var4.getName()).replace("%att_prefix%", var4.getPrefix());
         ItemStat var6 = ItemStat.DURABILITY_UNBREAK;
         String var7 = var3.replace("%att_value%", var6.getValue()).replace("%att_name%", var6.getName()).replace("%att_prefix%", var6.getPrefix());
         Iterator var9 = var0.getItemMeta().getLore().iterator();

         while(var9.hasNext()) {
            String var8 = (String)var9.next();
            if (var8.startsWith(var7) && var8.endsWith(var6.getValue())) {
               return -999;
            }

            if (var8.startsWith(var5)) {
               String var10 = ChatColor.stripColor(var8.replace(var5, ""));

               try {
                  var2 = Integer.parseInt(var10.split(ChatColor.stripColor(plugin.getCFG().getStrDurabilitySeparator()))[var1]);
               } catch (NumberFormatException var12) {
                  Bukkit.getConsoleSender().sendMessage("[DivineItems] Unable to get durability from string: " + var10);
               }
               break;
            }
         }

         return var2;
      } else {
         return var2;
      }
   }

   private static double getDamageFromString(String var0, int var1) {
      double var2 = 0.0D;
      String[] var4 = var0.split(plugin.getCFG().getStrDamageSeparator());
      if (var4.length <= 1 && var1 > 0) {
         return var2;
      } else {
         try {
            var2 = Double.parseDouble(ChatColor.stripColor(var4[var1].replace(plugin.getCFG().getStrPercent(), "")));
         } catch (NumberFormatException var6) {
         }

         return var2;
      }
   }

   public static double getItemTotalDamageMinMax(ItemStack var0, int var1) {
      double var2 = getDefaultDamage(var0);
      if (var0 != null && var0.hasItemMeta() && var0.getItemMeta().hasLore()) {
         Iterator var5 = plugin.getCFG().getDamageTypes().values().iterator();

         while(true) {
            while(var5.hasNext()) {
               DamageType var4 = (DamageType)var5.next();
               String var6 = plugin.getCFG().getDamageTypeFormat();
               String var7 = var6.replace("%type_value%", var4.getValue()).replace("%type_name%", var4.getName()).replace("%type_prefix%", var4.getPrefix());
               List var8 = var0.getItemMeta().getLore();
               Iterator var10 = var8.iterator();

               while(var10.hasNext()) {
                  String var9 = (String)var10.next();
                  if (var9.startsWith(var7)) {
                     String var11 = var9.replace(var7, "");
                     var2 += getDamageFromString(var11, var1);
                     break;
                  }
               }
            }

            return var2;
         }
      } else {
         return var2;
      }
   }

   public static double getItemTotalDamage(ItemStack var0) {
      double var1 = getDefaultDamage(var0);
      if (var0 != null && var0.hasItemMeta() && var0.getItemMeta().hasLore()) {
         double var3 = getItemTotalDamageMinMax(var0, 0);
         double var5 = getItemTotalDamageMinMax(var0, 1);
         return Utils.getRandDouble(var3, var5);
      } else {
         return var1;
      }
   }

   public static double getItemDamageMinMax(String var0, ItemStack var1, int var2) {
      double var3 = 0.0D;
      if (var1 != null && var1.hasItemMeta() && var1.getItemMeta().hasLore()) {
         DamageType var5 = (DamageType)plugin.getCFG().getDamageTypes().get(var0.toLowerCase());
         if (var5 != null) {
            String var6 = plugin.getCFG().getDamageTypeFormat();
            String var7 = var6.replace("%type_value%", var5.getValue()).replace("%type_name%", var5.getName()).replace("%type_prefix%", var5.getPrefix());
            List var8 = var1.getItemMeta().getLore();
            Iterator var10 = var8.iterator();

            while(var10.hasNext()) {
               String var9 = (String)var10.next();
               if (var9.startsWith(var7)) {
                  String var11 = var9.replace(var7, "");
                  return getDamageFromString(var11, var2);
               }
            }
         }

         if (var3 == 0.0D && var5.isDefault()) {
            var3 = getDefaultDamage(var1);
         }

         return var3;
      } else {
         return var3;
      }
   }

   public static boolean hasDamageType(String var0, ItemStack var1) {
      DamageType var2 = (DamageType)plugin.getCFG().getDamageTypes().get(var0.toLowerCase());
      if (var1 != null && var1.hasItemMeta() && var1.getItemMeta().hasLore()) {
         if (var2 != null) {
            String var3 = plugin.getCFG().getDamageTypeFormat();
            String var4 = var3.replace("%type_value%", var2.getValue()).replace("%type_name%", var2.getName()).replace("%type_prefix%", var2.getPrefix());
            List var5 = var1.getItemMeta().getLore();
            Iterator var7 = var5.iterator();

            while(var7.hasNext()) {
               String var6 = (String)var7.next();
               if (var6.startsWith(var4)) {
                  return true;
               }
            }
         }

         return false;
      } else {
         return false;
      }
   }

   public static double getItemDamage(String var0, ItemStack var1) {
      DamageType var2 = (DamageType)plugin.getCFG().getDamageTypes().get(var0.toLowerCase());
      double var3 = 0.0D;
      if (var2.isDefault()) {
         var3 = getDefaultDamage(var1);
      }

      if (var1 != null && var1.hasItemMeta() && var1.getItemMeta().hasLore()) {
         if (hasDamageType(var0, var1)) {
            double var5 = getItemDamageMinMax(var0, var1, 0);
            double var7 = getItemDamageMinMax(var0, var1, 1);
            if (var7 == 0.0D) {
               var7 = var5;
            }

            var3 = Utils.getRandDouble(var5, var7);
         }

         return var3;
      } else {
         return var3;
      }
   }

   public static double getAttribute(ItemStack var0, ItemStat var1) {
      double var2 = 0.0D;
      double var4 = getBase(var0, var1);
      double var6 = getBonus(var0, var1);
      if (var4 == 0.0D && var6 != 0.0D && var1 == ItemStat.RANGE) {
         var4 = 3.0D;
      }

      if (var1.isPercent()) {
         var2 = var4 + var6;
      } else {
         if (var4 == 0.0D && var6 != 0.0D) {
            var4 = 1.0D;
         }

         var2 = var4 * (1.0D + var6 / 100.0D);
      }

      if (var2 > var1.getCapability()) {
         var2 = var1.getCapability();
      }

      return var2;
   }

   public static double getBase(ItemStack var0, ItemStat var1) {
      String var2 = plugin.getCFG().getAttributeFormat();
      String var3 = var2.replace("%att_value%", var1.getValue()).replace("%att_name%", var1.getName()).replace("%att_prefix%", var1.getPrefix());
      double var4 = 0.0D;
      if (var0 != null && var0.hasItemMeta() && var0.getItemMeta().hasLore()) {
         if (plugin.getMM().getGemManager().getItemGemStats(var0, false).containsKey(var1)) {
            var4 += (Double)plugin.getMM().getGemManager().getItemGemStats(var0, false).get(var1);
         }

         List var6 = var0.getItemMeta().getLore();
         Iterator var8 = var6.iterator();

         while(var8.hasNext()) {
            String var7 = (String)var8.next();
            if (var7.startsWith(var3)) {
               String var9 = ChatColor.stripColor(var7.replace(var3, "").replace(plugin.getCFG().getStrPercent(), "").replace(plugin.getCFG().getStrModifier(), ""));
               double var10 = Double.parseDouble(var9);
               var4 += var10;
               break;
            }
         }

         return var4;
      } else {
         return var4;
      }
   }

   public static double getBonus(ItemStack var0, ItemStat var1) {
      String var2 = plugin.getCFG().getAttributeFormat();
      String var3 = var2.replace("%att_value%", var1.getValue()).replace("%att_name%", var1.getName()).replace("%att_prefix%", var1.getBonus());
      double var4 = 0.0D;
      if (var0 != null && var0.hasItemMeta() && var0.getItemMeta().hasLore()) {
         if (plugin.getMM().getGemManager().getItemGemStats(var0, true).containsKey(var1)) {
            var4 += (Double)plugin.getMM().getGemManager().getItemGemStats(var0, true).get(var1);
         }

         List var6 = var0.getItemMeta().getLore();
         Iterator var8 = var6.iterator();

         while(var8.hasNext()) {
            String var7 = (String)var8.next();
            if (var7.startsWith(var3)) {
               String var9 = ChatColor.stripColor(var7.replace(var3, "").replace(plugin.getCFG().getStrPercent(), "").replace(plugin.getCFG().getStrModifier(), ""));
               double var10 = 0.0D;

               try {
                  var10 = Double.parseDouble(var9);
               } catch (NumberFormatException var13) {
                  Bukkit.getConsoleSender().sendMessage("[DivineItems] Unable to get bonus stats from string: " + var9);
               }

               var4 += var10;
               break;
            }
         }

         return var4;
      } else {
         return var4;
      }
   }

   public static double getFinalDamageByType(String var0, LivingEntity var1) {
      DamageType var2 = plugin.getCFG().getDamageTypeById(var0);
      double var3 = 0.0D;
      if (var2 == null) {
         return var3;
      } else {
         Block var5 = var1.getLocation().getBlock();
         String var6 = var5.getBiome().name();
         ItemStack[] var10;
         int var9 = (var10 = EntityAPI.getEquipment(var1, false)).length;

         for(int var8 = 0; var8 < var9; ++var8) {
            ItemStack var7 = var10[var8];
            if (hasDamageType(var2.getId(), var7) || var2.isDefault()) {
               if (var3 == 0.0D) {
                  var3 = getItemDamageMinMax(var2.getId(), var7, 1);
               }

               if (plugin.getMM().getGemManager().isActive()) {
                  HashMap var11 = plugin.getMM().getGemManager().getItemGemDamages(var7, false);
                  if (var11.containsKey(var2)) {
                     var3 += (Double)var11.get(var2);
                  }

                  HashMap var12 = plugin.getMM().getGemManager().getItemGemDamages(var7, true);
                  if (var12.containsKey(var2)) {
                     var3 *= 1.0D + (Double)var12.get(var2) / 100.0D;
                  }
               }

               var3 *= var2.getDamageModifierByBiome(var6);
            }
         }

         return var3;
      }
   }

   public static HashMap<DamageType, Double> getDamageTypes(LivingEntity var0) {
      HashMap var1 = new HashMap();
      Block var2 = var0.getLocation().getBlock();
      String var3 = var2.getBiome().name();
      ItemStack[] var7;
      int var6 = (var7 = EntityAPI.getEquipment(var0, false)).length;

      label65:
      for(int var5 = 0; var5 < var6; ++var5) {
         ItemStack var4 = var7[var5];
         if (var4 != null && var4.hasItemMeta()) {
            Iterator var9 = plugin.getCFG().getDamageTypes().values().iterator();

            while(true) {
               DamageType var8;
               do {
                  if (!var9.hasNext()) {
                     continue label65;
                  }

                  var8 = (DamageType)var9.next();
               } while(!hasDamageType(var8.getId(), var4) && !var8.isDefault());

               double var10 = getItemDamage(var8.getId(), var4);
               if (plugin.getMM().getGemManager().isActive()) {
                  HashMap var12 = plugin.getMM().getGemManager().getItemGemDamages(var4, false);
                  if (var12.containsKey(var8)) {
                     var10 += (Double)var12.get(var8);
                  }

                  HashMap var13 = plugin.getMM().getGemManager().getItemGemDamages(var4, true);
                  if (var13.containsKey(var8)) {
                     var10 *= 1.0D + (Double)var13.get(var8) / 100.0D;
                  }
               }

               if (plugin.getMM().getBuffManager().isActive()) {
                  Iterator var16 = plugin.getMM().getBuffManager().getEntityBuffs(var0).iterator();

                  while(var16.hasNext()) {
                     BuffManager.Buff var14 = (BuffManager.Buff)var16.next();
                     if (var14.getType() == BuffManager.BuffType.DAMAGE && var14.getValue().equalsIgnoreCase(var8.getId())) {
                        var10 *= 1.0D + var14.getModifier() / 100.0D;
                        break;
                     }
                  }
               }

               var10 *= var8.getDamageModifierByBiome(var3);
               if (var1.containsKey(var8)) {
                  double var15 = (Double)var1.get(var8);
                  var10 += var15;
               }

               var1.put(var8, var10);
            }
         }
      }

      return var1;
   }

   public static HashMap<ArmorType, Double> getDefenseTypes(LivingEntity var0) {
      HashMap var1 = new HashMap();
      ItemStack[] var5;
      int var4 = (var5 = EntityAPI.getEquipment(var0, true)).length;

      label96:
      for(int var3 = 0; var3 < var4; ++var3) {
         ItemStack var2 = var5[var3];
         if (var2 != null && var2.hasItemMeta() && var2.getItemMeta().hasLore()) {
            ItemMeta var6 = var2.getItemMeta();
            List var7 = var6.getLore();
            String var8 = plugin.getCFG().getArmorTypeFormat();
            Iterator var10 = plugin.getCFG().getArmorTypes().values().iterator();

            while(true) {
               while(true) {
                  if (!var10.hasNext()) {
                     continue label96;
                  }

                  ArmorType var9 = (ArmorType)var10.next();
                  String var11 = var8.replace("%type_prefix%", var9.getPrefix()).replace("%type_name%", var9.getName()).replace("%type_value%", var9.getValue());
                  Iterator var13 = var7.iterator();

                  while(var13.hasNext()) {
                     String var12 = (String)var13.next();
                     if (var12.startsWith(var11)) {
                        String var14 = ChatColor.stripColor(var12.replace(plugin.getCFG().getStrPercent(), "").replace(var11, ""));
                        double var15 = Double.parseDouble(var14);
                        if (plugin.getMM().getGemManager().isActive()) {
                           HashMap var17 = plugin.getMM().getGemManager().getItemGemArmors(var2, false);
                           if (var17.containsKey(var9)) {
                              var15 += (Double)var17.get(var9);
                           }

                           HashMap var18 = plugin.getMM().getGemManager().getItemGemArmors(var2, true);
                           if (var18.containsKey(var9)) {
                              var15 *= 1.0D + (Double)var18.get(var9) / 100.0D;
                           }
                        }

                        if (plugin.getMM().getBuffManager().isActive()) {
                           Iterator var26 = plugin.getMM().getBuffManager().getEntityBuffs(var0).iterator();

                           while(var26.hasNext()) {
                              BuffManager.Buff var24 = (BuffManager.Buff)var26.next();
                              if (var24.getType() == BuffManager.BuffType.DEFENSE && var24.getValue().equalsIgnoreCase(var9.getId())) {
                                 var15 *= 1.0D + var24.getModifier() / 100.0D;
                                 break;
                              }
                           }
                        }

                        if (var1.containsKey(var9)) {
                           double var25 = (Double)var1.get(var9);
                           var15 += var25;
                        }

                        var1.put(var9, var15);
                        break;
                     }
                  }
               }
            }
         }
      }

      if (var1.isEmpty()) {
         Iterator var20 = plugin.getCFG().getDamageTypes().values().iterator();

         while(true) {
            DamageType var19;
            do {
               if (!var20.hasNext()) {
                  return var1;
               }

               var19 = (DamageType)var20.next();
            } while(!var19.isDefault());

            double var21 = getDefaultDefense(var0);
            Iterator var23 = plugin.getCFG().getArmorTypes().values().iterator();

            while(var23.hasNext()) {
               ArmorType var22 = (ArmorType)var23.next();
               if (var22.getBlockDamageTypes().contains(var19.getId())) {
                  var1.put(var22, var21);
               }
            }
         }
      } else {
         return var1;
      }
   }

   public static double getDefaultDamage(ItemStack var0) {
      if (var0 != null && var0.getType() != Material.AIR && !ItemUtils.isArmor(var0)) {
         double var1 = 1.0D;
         if (var0.getType() != Material.DIAMOND_SWORD && var0.getType() != Material.GOLD_AXE && var0.getType() != Material.WOOD_AXE) {
            if (var0.getType() != Material.DIAMOND_AXE && var0.getType() != Material.IRON_AXE && var0.getType() != Material.STONE_AXE && !var0.getType().name().equals("TRIDENT")) {
               if (var0.getType() != Material.DIAMOND_PICKAXE && var0.getType() != Material.DIAMOND_SPADE && var0.getType() != Material.STONE_SWORD) {
                  if (var0.getType() == Material.IRON_SWORD) {
                     var1 = 6.0D;
                  } else if (var0.getType() != Material.IRON_PICKAXE && var0.getType() != Material.IRON_SPADE && var0.getType() != Material.GOLD_SWORD && var0.getType() != Material.WOOD_SWORD) {
                     if (var0.getType() != Material.STONE_PICKAXE && var0.getType() != Material.STONE_SPADE) {
                        if (var0.getType() == Material.GOLD_PICKAXE || var0.getType() == Material.GOLD_SPADE || var0.getType() == Material.WOOD_PICKAXE || var0.getType() == Material.WOOD_SPADE) {
                           var1 = 2.0D;
                        }
                     } else {
                        var1 = 3.0D;
                     }
                  } else {
                     var1 = 4.0D;
                  }
               } else {
                  var1 = 5.0D;
               }
            } else {
               var1 = 9.0D;
            }
         } else {
            var1 = 7.0D;
         }

         return var1;
      } else {
         return 0.0D;
      }
   }

   public static double getDefaultDefense(ItemStack var0) {
      if (var0 == null) {
         return 0.0D;
      } else if (var0.getType() != Material.LEATHER_LEGGINGS && var0.getType() != Material.CHAINMAIL_HELMET && var0.getType() != Material.IRON_HELMET && var0.getType() != Material.IRON_BOOTS && var0.getType() != Material.GOLD_HELMET) {
         if (var0.getType() != Material.LEATHER_CHESTPLATE && var0.getType() != Material.DIAMOND_HELMET && var0.getType() != Material.DIAMOND_BOOTS && var0.getType() != Material.GOLD_LEGGINGS) {
            if (var0.getType() == Material.CHAINMAIL_LEGGINGS) {
               return 4.0D;
            } else if (var0.getType() != Material.CHAINMAIL_CHESTPLATE && var0.getType() != Material.IRON_LEGGINGS && var0.getType() != Material.GOLD_CHESTPLATE) {
               if (var0.getType() != Material.IRON_CHESTPLATE && var0.getType() != Material.DIAMOND_LEGGINGS) {
                  return var0.getType() == Material.DIAMOND_CHESTPLATE ? 8.0D : 0.0D;
               } else {
                  return 6.0D;
               }
            } else {
               return 5.0D;
            }
         } else {
            return 3.0D;
         }
      } else {
         return 2.0D;
      }
   }

   public static double getDefaultToughness(ItemStack var0) {
      if (var0 != null && ItemUtils.isArmor(var0)) {
         return var0.getType().name().startsWith("DIAMOND_") ? 2.0D : 0.0D;
      } else {
         return 0.0D;
      }
   }

   public static double getDefaultDefense(LivingEntity var0) {
      double var1 = 0.0D;
      ItemStack[] var6;
      int var5 = (var6 = EntityAPI.getEquipment(var0, true)).length;

      for(int var4 = 0; var4 < var5; ++var4) {
         ItemStack var3 = var6[var4];
         if (var3 != null) {
            if (var3.getType() != Material.LEATHER_LEGGINGS && var3.getType() != Material.CHAINMAIL_HELMET && var3.getType() != Material.IRON_HELMET && var3.getType() != Material.IRON_BOOTS && var3.getType() != Material.GOLD_HELMET) {
               if (var3.getType() != Material.LEATHER_CHESTPLATE && var3.getType() != Material.DIAMOND_HELMET && var3.getType() != Material.DIAMOND_BOOTS && var3.getType() != Material.GOLD_LEGGINGS) {
                  if (var3.getType() == Material.CHAINMAIL_LEGGINGS) {
                     var1 += 4.0D;
                  } else if (var3.getType() != Material.CHAINMAIL_CHESTPLATE && var3.getType() != Material.IRON_LEGGINGS && var3.getType() != Material.GOLD_CHESTPLATE) {
                     if (var3.getType() != Material.IRON_CHESTPLATE && var3.getType() != Material.DIAMOND_LEGGINGS) {
                        if (var3.getType() == Material.DIAMOND_CHESTPLATE) {
                           var1 += 8.0D;
                        }
                     } else {
                        var1 += 6.0D;
                     }
                  } else {
                     var1 += 5.0D;
                  }
               } else {
                  var1 += 3.0D;
               }
            } else {
               var1 += 2.0D;
            }
         }
      }

      return var1;
   }

   public static double getDefaultAttackSpeed(ItemStack var0) {
      if (var0 == null) {
         return -0.5D;
      } else {
         double var1 = -0.5D;
         switch($SWITCH_TABLE$org$bukkit$Material()[var0.getType().ordinal()]) {
         case 255:
         case 268:
         case 272:
         case 276:
         case 278:
         case 283:
         case 285:
         case 289:
         case 293:
            var1 = 3.0D;
            break;
         case 256:
         case 269:
         case 273:
         case 277:
         case 284:
            var1 = 2.8D;
            break;
         case 257:
         case 270:
         case 274:
            var1 = 3.2D;
            break;
         case 258:
         case 259:
         case 260:
         case 261:
         case 262:
         case 263:
         case 264:
         case 265:
         case 279:
         case 280:
         case 281:
         case 286:
         case 287:
         case 288:
         default:
            var1 = -0.5D;
            break;
         case 266:
         case 267:
         case 271:
         case 275:
         case 282:
            var1 = 2.4D;
            break;
         case 290:
            var1 = 2.0D;
            break;
         case 291:
            var1 = 1.0D;
            break;
         case 292:
            var1 = 0.0D;
         }

         return var1;
      }
   }

   public static ItemStack setAmmoType(ItemStack var0, AmmoType var1, int var2) {
      if (!var1.isEnabled()) {
         return var0;
      } else if (var0.getType() != Material.BOW) {
         return var0;
      } else {
         String var3 = plugin.getCFG().getAmmoTypeFormat();
         String var4 = var3.replace("%type_name%", var1.getName()).replace("%type_prefix%", var1.getPrefix());
         boolean var5 = false;
         ItemMeta var6 = var0.getItemMeta();
         Object var7 = var6.getLore();
         if (var7 == null) {
            var7 = new ArrayList();
         }

         Iterator var9 = ((List)var7).iterator();

         while(var9.hasNext()) {
            String var8 = (String)var9.next();
            if (var8.startsWith(var4)) {
               int var10 = ((List)var7).indexOf(var8);
               ((List)var7).remove(var10);
               break;
            }
         }

         if (var2 >= 0 && var2 < ((List)var7).size()) {
            ((List)var7).add(var2, var4);
         } else {
            ((List)var7).add(var4);
         }

         var6.setLore((List)var7);
         var0.setItemMeta(var6);
         return var0;
      }
   }

   public static AmmoType getAmmoType(ItemStack var0) {
      AmmoType var1 = AmmoType.ARROW;
      if (var0 != null && var0.hasItemMeta()) {
         String var2 = plugin.getCFG().getAmmoTypeFormat();
         AmmoType[] var6;
         int var5 = (var6 = AmmoType.values()).length;

         for(int var4 = 0; var4 < var5; ++var4) {
            AmmoType var3 = var6[var4];
            String var7 = var2.replace("%type_name%", var3.getName()).replace("%type_prefix%", var3.getPrefix());
            ItemMeta var8 = var0.getItemMeta();
            List var9 = var8.getLore();
            if (var9 == null || var9.isEmpty()) {
               return var1;
            }

            Iterator var11 = var9.iterator();

            while(var11.hasNext()) {
               String var10 = (String)var11.next();
               if (var10.equals(var7)) {
                  return var3;
               }
            }
         }

         return var1;
      } else {
         return var1;
      }
   }

   public static ItemStack setDurability(ItemStack var0, int var1, int var2) {
      if (var1 > var2) {
         var1 = var2;
      }

      String var3 = plugin.getCFG().getAttributeFormat();
      ItemStat var4 = ItemStat.DURABILITY;
      String var5 = var3.replace("%att_value%", var4.getValue()).replace("%att_name%", var4.getName()).replace("%att_prefix%", var4.getPrefix());
      ItemMeta var6 = var0.getItemMeta();
      List var7 = var6.getLore();
      Iterator var9 = var7.iterator();

      while(var9.hasNext()) {
         String var8 = (String)var9.next();
         if (var8.startsWith(var5)) {
            int var10 = var7.indexOf(var8);
            var7.remove(var10);
            var7.add(var10, var5 + var1 + plugin.getCFG().getStrDurabilitySeparator() + var4.getValue() + var2);
            var6.setLore(var7);
            var0.setItemMeta(var6);
            break;
         }
      }

      return var0;
   }

   public static ItemStack setFinalDurability(ItemStack var0, Entity var1, int var2) {
      if (var1 instanceof Player) {
         Player var3 = (Player)var1;
         if (getDurability(var0, 0) > 0) {
            DivineItemDamageEvent var4 = new DivineItemDamageEvent(var0, var3);
            plugin.getPluginManager().callEvent(var4);
            if (var4.isCancelled()) {
               return var0;
            }

            var0 = reduceDurability(var0, var2);
            if (getDurability(var0, 0) <= 0 && plugin.getCFG().breakItems()) {
               var0.setAmount(0);
               var3.playSound(var3.getLocation(), Sound.BLOCK_ANVIL_PLACE, 0.5F, 0.5F);
            }
         }
      }

      return var0;
   }

   public static ItemStack reduceDurability(ItemStack var0, int var1) {
      int var3;
      if (var0.containsEnchantment(Enchantment.DURABILITY)) {
         var3 = var0.getEnchantmentLevel(Enchantment.DURABILITY);
         if (r.nextInt(200) <= var3 * 10) {
            return var0;
         }
      }

      var3 = getDurability(var0, 0);
      if (var3 == -999) {
         return var0;
      } else {
         int var4 = getDurability(var0, 1);
         ItemStack var2 = setDurability(var0, var3 - var1, var4);
         return var2;
      }
   }

   public static ItemStack getItemByModule(String var0, String var1, int var2) {
      ItemStack var3 = new ItemStack(Material.AIR);
      String var4 = WordUtils.capitalizeFully(var1.replace("_", " ")).split(":")[0];
      switch(var4.hashCode()) {
      case -1850668115:
         if (var4.equals("Repair")) {
            var3 = plugin.getMM().getRepairManager().getGem().getItemGem(var2);
         }
         break;
      case -947662255:
         if (var4.equals("Custom Items")) {
            var3 = plugin.getMM().getCustomItemsManager().getCustomItem(var0);
         }
         break;
      case -790637179:
         if (var4.equals("Magic Dust")) {
            if (plugin.getMM().getMagicDustManager().getDustById(var0) == null) {
               return var3;
            }

            var3 = plugin.getMM().getMagicDustManager().getDustById(var0).create(var2);
         }
         break;
      case -703624410:
         if (var4.equals("Scrolls")) {
            ScrollManager.Scroll var8 = plugin.getMM().getScrollManager().getScrollById(var0);
            if (var8 == null) {
               return var3;
            }

            var3 = var8.create(var2);
         }
         break;
      case -632618200:
         if (var4.equals("Abilities")) {
            if (plugin.getMM().getAbilityManager().getAbilityById(var0) == null) {
               return var3;
            }

            var3 = plugin.getMM().getAbilityManager().getAbilityById(var0).create(var2);
         }
         break;
      case -71118036:
         if (var4.equals("Identify")) {
            String[] var7 = var1.split(":");
            if (var7[1].equalsIgnoreCase("tome")) {
               if (plugin.getMM().getIdentifyManager().getTomeById(var0) == null) {
                  return var3;
               }

               var3 = plugin.getMM().getIdentifyManager().getTomeById(var0).create();
            } else {
               if (plugin.getMM().getIdentifyManager().getItemById(var0) == null) {
                  return var3;
               }

               var3 = plugin.getMM().getIdentifyManager().getItemById(var0).create(var2);
            }
         }
         break;
      case 2215716:
         if (var4.equals("Gems")) {
            if (plugin.getMM().getGemManager().getGemById(var0) == null) {
               return var3;
            }

            var3 = plugin.getMM().getGemManager().getGemById(var0).create(var2);
         }
         break;
      case 79323225:
         if (var4.equals("Runes")) {
            if (plugin.getMM().getRuneManager().getRuneById(var0) == null) {
               return var3;
            }

            var3 = plugin.getMM().getRuneManager().getRuneById(var0).create(var2);
         }
         break;
      case 80804529:
         if (var4.equals("Tiers")) {
            TierManager.Tier var6 = plugin.getMM().getTierManager().getTierById(var0);
            if (var6 == null) {
               return var3;
            }

            var3 = var6.create(var2, (Material)null);
         }
         break;
      case 1769317210:
         if (var4.equals("Enchants")) {
            if (var0.equalsIgnoreCase("random")) {
               var3 = plugin.getMM().getEnchantManager().getRandomEnchant().create(var2);
            } else {
               var3 = plugin.getMM().getEnchantManager().getEnchantByType(EnchantManager.EnchantType.valueOf(var0.toUpperCase())).create(var2);
            }
         }
         break;
      case 1809054010:
         if (var4.equals("Abyss Dust")) {
            if (plugin.getMM().getAbyssDustManager().getDustById(var0) == null) {
               return var3;
            }

            var3 = plugin.getMM().getAbyssDustManager().getDustById(var0).create();
         }
      }

      return var3;
   }

   public static ItemStack setUntradeable(ItemStack var0, String var1, int var2) {
      ItemMeta var3 = var0.getItemMeta();
      Object var4 = var3.getLore();
      if (var4 == null) {
         var4 = new ArrayList();
      }

      String var5 = plugin.getMM().getSoulboundManager().getUntradeString();
      if (var1.contains("true")) {
         if (var2 > 0 && ((List)var4).size() > var2) {
            ((List)var4).add(var2, var5);
         } else {
            ((List)var4).add(var5);
         }
      } else if (var1.contains("false")) {
         Iterator var7 = ((List)var4).iterator();

         while(var7.hasNext()) {
            String var6 = (String)var7.next();
            if (var6.equals(var5)) {
               ((List)var4).remove(var6);
               break;
            }
         }
      }

      var3.setLore((List)var4);
      var0.setItemMeta(var3);
      return var0;
   }

   public static ItemStack setLevelRequired(ItemStack var0, int var1, int var2) {
      ItemMeta var3 = var0.getItemMeta();
      Object var4 = var3.getLore();
      if (var4 == null) {
         var4 = new ArrayList();
      }

      int var5 = 0;
      String[] var6 = plugin.getCFG().getStrLevel().split("%n");
      Iterator var8 = ((List)var4).iterator();

      String var7;
      while(var8.hasNext()) {
         var7 = (String)var8.next();
         if (var6.length == 1 && var7.contains(var6[0]) || var6.length == 2 && (var7.contains(var6[0]) || var7.contains(var6[1]))) {
            var5 = ((List)var4).indexOf(var7);
            ((List)var4).remove(var7);
            break;
         }
      }

      if (var2 > 0) {
         var5 = var2;
      }

      var7 = plugin.getCFG().getStrLevel().replace("%n", String.valueOf(var1));
      if (var5 >= 0 && var5 < ((List)var4).size()) {
         ((List)var4).add(var5, var7);
      } else {
         ((List)var4).add(var7);
      }

      var3.setLore((List)var4);
      var0.setItemMeta(var3);
      return var0;
   }

   public static ItemStack setClassRequired(ItemStack var0, String var1, int var2) {
      ItemMeta var3 = var0.getItemMeta();
      Object var4 = var3.getLore();
      if (var4 == null) {
         var4 = new ArrayList();
      }

      int var5 = 0;
      String var6 = plugin.getCFG().getStrClass();
      Iterator var8 = ((List)var4).iterator();

      String var7;
      while(var8.hasNext()) {
         var7 = (String)var8.next();
         if (var7.contains(var6)) {
            var5 = ((List)var4).indexOf(var7);
            ((List)var4).remove(var7);
            break;
         }
      }

      if (var2 > 0) {
         var5 = var2;
      }

      var7 = plugin.getCFG().getStrClass() + plugin.getCFG().getStrClassColor() + var1.replace(",", plugin.getCFG().getStrClassSeparator());
      if (var5 >= 0 && var5 < ((List)var4).size()) {
         ((List)var4).add(var5, var7);
      } else {
         ((List)var4).add(var7);
      }

      var3.setLore((List)var4);
      var0.setItemMeta(var3);
      return var0;
   }

   public static ItemStack setSoulboundRequired(ItemStack var0, String var1, int var2) {
      ItemMeta var3 = var0.getItemMeta();
      if (var3 == null) {
         return var0;
      } else {
         Object var4 = var3.getLore();
         if (var4 == null) {
            var4 = new ArrayList();
         }

         String var5 = plugin.getMM().getSoulboundManager().getSoulString();
         Iterator var7 = ((List)var4).iterator();

         while(var7.hasNext()) {
            String var6 = (String)var7.next();
            if (var6.equals(var5)) {
               ((List)var4).remove(var6);
               break;
            }
         }

         if (var1.contains("true")) {
            if (var2 > 0 && var2 < ((List)var4).size()) {
               ((List)var4).add(var2, var5);
            } else {
               ((List)var4).add(var5);
            }
         }

         var3.setLore((List)var4);
         var0.setItemMeta(var3);
         return var0;
      }
   }

   public static ItemStack addAttribute(ItemStack var0, ItemStat var1, boolean var2, String var3, String var4, int var5) {
      ItemMeta var6 = var0.getItemMeta();
      Object var7 = var6.getLore();
      if (var7 == null) {
         var7 = new ArrayList();
      }

      String var8 = plugin.getCFG().getAttributeFormat();
      String var9 = var8.replace("%att_value%", var1.getValue()).replace("%att_name%", var1.getName()).replace("%att_prefix%", var1.getPrefix());
      if (var2) {
         var9 = var8.replace("%att_value%", var1.getValue()).replace("%att_name%", var1.getName()).replace("%att_prefix%", var1.getBonus());
      }

      int var10 = -1;
      Iterator var12 = ((List)var7).iterator();

      while(var12.hasNext()) {
         String var11 = (String)var12.next();
         if (var11.startsWith(var9)) {
            var10 = ((List)var7).indexOf(var11);
            ((List)var7).remove(var11);
            break;
         }
      }

      if (var5 > 0) {
         var10 = var5;
      }

      if (var10 >= ((List)var7).size()) {
         var10 = -1;
      }

      double var21;
      switch($SWITCH_TABLE$su$nightexpress$divineitems$attributes$ItemStat()[var1.ordinal()]) {
      case 15:
         if (!var2) {
            var21 = -1.0D;

            try {
               var21 = Double.parseDouble(var3);
            } catch (NumberFormatException var17) {
               return var0;
            }

            var0 = removeAttribute(var0, ItemStat.DURABILITY_UNBREAK);
            var7 = var0.getItemMeta().getLore();
            if (var7 == null) {
               var7 = new ArrayList();
            }

            if (var21 > 0.0D) {
               int var22 = (int)var21;
               if (var10 >= 0 && var10 < ((List)var7).size()) {
                  ((List)var7).add(var10, var9 + var22 + plugin.getCFG().getStrDurabilitySeparator() + var1.getValue() + var22);
               } else {
                  ((List)var7).add(var9 + var22 + plugin.getCFG().getStrDurabilitySeparator() + var1.getValue() + var22);
               }
            }
         }
         break;
      case 16:
         if (!var2) {
            var0 = removeAttribute(var0, ItemStat.DURABILITY);
            var7 = var0.getItemMeta().getLore();
            if (var7 == null) {
               var7 = new ArrayList();
            }

            var21 = -1.0D;

            try {
               var21 = Double.parseDouble(var3);
            } catch (NumberFormatException var16) {
               return var0;
            }

            if (var21 > 0.0D) {
               if (var10 >= 0 && var10 < ((List)var7).size()) {
                  ((List)var7).add(var10, var9);
               } else {
                  ((List)var7).add(var9);
               }
            }

            var0.getItemMeta().spigot().setUnbreakable(true);
         }
         break;
      case 17:
         var21 = -1.0D;

         try {
            var21 = Double.parseDouble(var3) + getAttribute(var0, var1);
         } catch (NumberFormatException var18) {
            return var0;
         }

         if (var2) {
            if (var21 >= 0.0D) {
               var3 = plugin.getCFG().getStrPositive() + var3 + plugin.getCFG().getStrPercent();
            }

            if (var21 < 0.0D) {
               var3 = plugin.getCFG().getStrNegative() + var3 + plugin.getCFG().getStrPercent();
            }

            if (var10 >= 0 && var10 < ((List)var7).size()) {
               ((List)var7).add(var10, var9 + var3);
            } else {
               ((List)var7).add(var9 + var3);
            }
         } else if (var21 > 0.0D) {
            if (var10 >= 0 && var10 < ((List)var7).size()) {
               ((List)var7).add(var10, var9 + ChatColor.stripColor(plugin.getCFG().getStrPositive()) + var3 + plugin.getCFG().getStrPercent());
            } else {
               ((List)var7).add(var9 + ChatColor.stripColor(plugin.getCFG().getStrPositive()) + var3 + plugin.getCFG().getStrPercent());
            }
         }

         if (var1.getCapability() > 0.0D && var21 > var1.getCapability()) {
            var21 = var1.getCapability();
         }

         var0 = new ItemStack(plugin.getNMS().setNBTAtt(var0, NBTAttribute.movementSpeed, var21));
         if (!ItemUtils.isArmor(var0)) {
            var0 = plugin.getNMS().setNBTAtt(var0, NBTAttribute.attackDamage, getDefaultDamage(var0));
         } else {
            var0 = plugin.getNMS().setNBTAtt(var0, NBTAttribute.armor, getDefaultDefense(var0));
            var0 = plugin.getNMS().setNBTAtt(var0, NBTAttribute.armorToughness, getDefaultToughness(var0));
         }

         var6 = var0.getItemMeta();
         break;
      case 18:
      case 20:
      default:
         var21 = -1.0D;

         try {
            var21 = Double.parseDouble(var3);
         } catch (NumberFormatException var15) {
            return var0;
         }

         if (var1 != ItemStat.RANGE || var0.getType() != Material.BOW && !(var21 <= 0.0D)) {
            if (var1.isPercent() && !var2) {
               var3 = var3 + plugin.getCFG().getStrPercent();
            }

            if (var1 == ItemStat.CRITICAL_DAMAGE && !var2) {
               var3 = var3 + plugin.getCFG().getStrModifier();
            }

            if (var2) {
               if (var21 > 0.0D) {
                  var3 = plugin.getCFG().getStrPositive() + var3 + plugin.getCFG().getStrPercent();
               }

               if (var21 < 0.0D) {
                  var3 = plugin.getCFG().getStrNegative() + var3 + plugin.getCFG().getStrPercent();
               }
            } else if (var1.isPlus() && var21 > 0.0D) {
               var3 = ChatColor.stripColor(plugin.getCFG().getStrPositive()) + var3;
            }

            if (var10 >= 0 && var10 < ((List)var7).size()) {
               ((List)var7).add(var10, var9 + var3);
            } else {
               ((List)var7).add(var9 + var3);
            }
         }
         break;
      case 19:
         if (ItemUtils.isWeapon(var0)) {
            var21 = -1.0D;

            try {
               var21 = Double.parseDouble(var3) + getAttribute(var0, var1);
            } catch (NumberFormatException var20) {
               return var0;
            }

            if (var2) {
               if (var21 >= 0.0D) {
                  var3 = plugin.getCFG().getStrPositive() + var3 + plugin.getCFG().getStrPercent();
               }

               if (var21 < 0.0D) {
                  var3 = plugin.getCFG().getStrNegative() + var3 + plugin.getCFG().getStrPercent();
               }

               if (var10 >= 0 && var10 < ((List)var7).size()) {
                  ((List)var7).add(var10, var9 + var3);
               } else {
                  ((List)var7).add(var9 + var3);
               }
            } else if (var21 > 0.0D) {
               if (var10 >= 0 && var10 < ((List)var7).size()) {
                  ((List)var7).add(var10, var9 + ChatColor.stripColor(plugin.getCFG().getStrPositive()) + var3 + plugin.getCFG().getStrPercent());
               } else {
                  ((List)var7).add(var9 + ChatColor.stripColor(plugin.getCFG().getStrPositive()) + var3 + plugin.getCFG().getStrPercent());
               }
            }

            if (var1.getCapability() > 0.0D && var21 > var1.getCapability()) {
               var21 = var1.getCapability();
            }

            var0 = plugin.getNMS().setNBTAtt(var0, NBTAttribute.attackSpeed, var21 / 1000.0D);
            var0 = plugin.getNMS().setNBTAtt(var0, NBTAttribute.attackDamage, getDefaultDamage(var0));
            var6 = var0.getItemMeta();
         }
         break;
      case 21:
         var21 = -1.0D;

         try {
            var21 = Double.parseDouble(var3);
         } catch (NumberFormatException var19) {
            return var0;
         }

         double var13 = getAttribute(var0, var1);
         if (var2) {
            if (var13 <= 0.0D) {
               var21 = 0.0D;
            } else {
               var21 = var13 * (1.0D + var21 / 100.0D);
            }

            if (var21 >= 0.0D) {
               var3 = plugin.getCFG().getStrPositive() + var3 + plugin.getCFG().getStrPercent();
            }

            if (var21 < 0.0D) {
               var3 = plugin.getCFG().getStrNegative() + var3 + plugin.getCFG().getStrPercent();
            }

            if (var10 >= 0 && var10 < ((List)var7).size()) {
               ((List)var7).add(var10, var9 + var3);
            } else {
               ((List)var7).add(var9 + var3);
            }
         } else {
            var21 += var13;
            if (var21 > 0.0D) {
               if (var10 >= 0 && var10 < ((List)var7).size()) {
                  ((List)var7).add(var10, var9 + ChatColor.stripColor(plugin.getCFG().getStrPositive()) + var3);
               } else {
                  ((List)var7).add(var9 + ChatColor.stripColor(plugin.getCFG().getStrPositive()) + var3);
               }
            }
         }

         if (var1.getCapability() > 0.0D && var21 > var1.getCapability()) {
            var21 = var1.getCapability();
         }

         var0 = plugin.getNMS().setNBTAtt(var0, NBTAttribute.maxHealth, var21);
         if (!ItemUtils.isArmor(var0)) {
            var0 = plugin.getNMS().setNBTAtt(var0, NBTAttribute.attackDamage, getDefaultDamage(var0));
         } else {
            var0 = plugin.getNMS().setNBTAtt(var0, NBTAttribute.armor, getDefaultDefense(var0));
            var0 = plugin.getNMS().setNBTAtt(var0, NBTAttribute.armorToughness, getDefaultToughness(var0));
         }

         var6 = var0.getItemMeta();
      }

      var6.setLore((List)var7);
      var0.setItemMeta(var6);
      return var0;
   }

   public static ItemStack removeAttribute(ItemStack var0, ItemStat var1) {
      if (var0 != null && var0.hasItemMeta() && var0.getItemMeta().hasLore()) {
         String var2 = plugin.getCFG().getAttributeFormat();
         String var3 = var2.replace("%att_value%", var1.getValue()).replace("%att_name%", var1.getName()).replace("%att_prefix%", var1.getPrefix());
         ItemMeta var4 = var0.getItemMeta();
         List var5 = var4.getLore();
         Iterator var7 = var5.iterator();

         while(var7.hasNext()) {
            String var6 = (String)var7.next();
            if (var6.startsWith(var3)) {
               var5.remove(var6);
               break;
            }
         }

         var4.setLore(var5);
         var0.setItemMeta(var4);
         return var0;
      } else {
         return var0;
      }
   }

   public static ItemStack addNBTTag(ItemStack var0, String var1, String var2) {
      NBTItem var3 = new NBTItem(var0);
      if (StringUtils.isNumeric(var2)) {
         if (Double.valueOf(var2) != null) {
            var3.setDouble(var1, Double.parseDouble(var2));
         } else if (Integer.valueOf(var2) != null) {
            var3.setInteger(var1, Integer.parseInt(var2));
         }
      } else if (!var2.equals("true") && !var2.equals("false")) {
         var3.setString(var1, var2);
      } else {
         boolean var4 = Boolean.valueOf(var2);
         var3.setBoolean(var1, var4);
      }

      return var3.getItem();
   }

   public static ItemStack delNBTTag(ItemStack var0, String var1) {
      NBTItem var2 = new NBTItem(var0);
      var2.removeKey(var1);
      return var2.getItem();
   }

   public static ItemStack addDamageType(ItemStack var0, DamageType var1, double var2, double var4, int var6) {
      String var7 = plugin.getCFG().getDamageTypeFormat();
      String var8 = var7.replace("%type_value%", var1.getValue()).replace("%type_name%", var1.getName()).replace("%type_prefix%", var1.getPrefix());
      boolean var9 = false;
      ItemMeta var10 = var0.getItemMeta();
      Object var11 = var10.getLore();
      if (var11 == null) {
         var11 = new ArrayList();
      }

      Iterator var13 = ((List)var11).iterator();

      String var12;
      while(var13.hasNext()) {
         var12 = (String)var13.next();
         if (var12.startsWith(var8)) {
            int var14 = ((List)var11).indexOf(var12);
            ((List)var11).remove(var14);
            break;
         }
      }

      var12 = var8 + Math.min(var2, var4) + plugin.getCFG().getStrDamageSeparator() + var1.getValue() + Math.max(var2, var4);
      if (var6 >= 0 && var6 < ((List)var11).size()) {
         ((List)var11).add(var6, var12);
      } else {
         ((List)var11).add(var12);
      }

      var10.setLore((List)var11);
      var0.setItemMeta(var10);
      return var0;
   }

   public static ItemStack addDefenseType(ItemStack var0, ArmorType var1, double var2, int var4) {
      var2 = Utils.round3(var2);
      String var5 = plugin.getCFG().getArmorTypeFormat();
      String var6 = var5.replace("%type_value%", var1.getValue()).replace("%type_name%", var1.getName()).replace("%type_prefix%", var1.getPrefix());
      boolean var7 = false;
      ItemMeta var8 = var0.getItemMeta();
      Object var9 = var8.getLore();
      if (var9 == null) {
         var9 = new ArrayList();
      }

      Iterator var11 = ((List)var9).iterator();

      String var10;
      while(var11.hasNext()) {
         var10 = (String)var11.next();
         if (var10.startsWith(var6)) {
            int var12 = ((List)var9).indexOf(var10);
            ((List)var9).remove(var12);
            break;
         }
      }

      if (var1.isPercent()) {
         var10 = var6 + plugin.getCFG().getStrPositive() + var2 + plugin.getCFG().getStrPercent();
      } else {
         var10 = var6 + var2;
      }

      if (var4 >= 0 && var4 < ((List)var9).size()) {
         ((List)var9).add(var4, var10);
      } else {
         ((List)var9).add(var10);
      }

      var8.setLore((List)var9);
      var0.setItemMeta(var8);
      return var0;
   }

   public static ItemStack addAbility(ItemStack var0, String var1, int var2, String var3, boolean var4, int var5, int var6) {
      ItemMeta var7 = var0.getItemMeta();
      Object var8 = var7.getLore();
      if (var8 == null) {
         var8 = new ArrayList();
      }

      AbilityManager.Ability var9 = plugin.getMM().getAbilityManager().getAbilityById(var1);
      String var10 = plugin.getMM().getAbilityManager().getSettings().getLeftClick();
      if (var3.equalsIgnoreCase("RIGHT")) {
         var10 = plugin.getMM().getAbilityManager().getSettings().getRightClick();
      }

      String var11 = "";
      if (var4) {
         var11 = plugin.getMM().getAbilityManager().getSettings().getShiftClick() + " ";
      }

      String var12 = plugin.getMM().getAbilityManager().getSettings().getCD().replace("%s", String.valueOf(var5));
      String var13 = plugin.getMM().getAbilityManager().getSettings().getFilledSlot() + var9.getName().replace("%level%", String.valueOf(var2)).replace("%rlevel%", Utils.IntegerToRomanNumeral(var2)) + " " + var11 + var10 + " " + var12;
      Iterator var15 = ((List)var8).iterator();

      while(var15.hasNext()) {
         String var14 = (String)var15.next();
         if (var14.contains(var9.getName().replace("%rlevel%", "").replace("%level%", "").trim())) {
            ((List)var8).remove(var14);
            break;
         }
      }

      if (var6 > 0) {
         ((List)var8).add(var6, var13);
      } else {
         ((List)var8).add(var13);
      }

      var7.setLore((List)var8);
      var0.setItemMeta(var7);
      NBTItem var16 = new NBTItem(var0);
      var16.setString("ABILITY_" + plugin.getMM().getAbilityManager().getItemAbsAmount(var0), var9.getIdName().toLowerCase() + ":" + var2 + ":" + var5 + ":" + var3.toUpperCase() + ":" + var4);
      return var16.getItem();
   }

   public static ItemStack addDivineSlot(ItemStack var0, SlotType var1, int var2) {
      ItemMeta var3 = var0.getItemMeta();
      Object var4 = var3.getLore();
      if (var4 == null) {
         var4 = new ArrayList();
      }

      String var5 = var1.getEmpty();
      if (var2 >= 0 && var2 < ((List)var4).size()) {
         ((List)var4).add(var2, var5);
      } else {
         ((List)var4).add(var5);
      }

      var3.setLore((List)var4);
      var0.setItemMeta(var3);
      return var0;
   }

   public static ItemStack addFlag(ItemStack var0, ItemFlag var1) {
      ItemMeta var2 = var0.getItemMeta();
      var2.addItemFlags(new ItemFlag[]{var1});
      var0.setItemMeta(var2);
      return var0;
   }

   public static ItemStack delFlag(ItemStack var0, ItemFlag var1) {
      ItemMeta var2 = var0.getItemMeta();
      var2.removeItemFlags(new ItemFlag[]{var1});
      var0.setItemMeta(var2);
      return var0;
   }

   public static ItemStack setName(ItemStack var0, String var1) {
      ItemMeta var2 = var0.getItemMeta();
      var2.setDisplayName(ChatColor.translateAlternateColorCodes('&', var1.trim()));
      var0.setItemMeta(var2);
      return var0;
   }

   public static ItemStack addLoreLine(ItemStack var0, String var1, int var2) {
      ItemMeta var3 = var0.getItemMeta();
      Object var4 = var3.getLore();
      if (var4 == null) {
         var4 = new ArrayList();
      }

      if (var2 > 0 && var2 < ((List)var4).size()) {
         ((List)var4).add(var2, ChatColor.translateAlternateColorCodes('&', var1));
      } else {
         ((List)var4).add(ChatColor.translateAlternateColorCodes('&', var1));
      }

      var3.setLore((List)var4);
      var0.setItemMeta(var3);
      return var0;
   }

   public static ItemStack delLoreLine(ItemStack var0, int var1) {
      ItemMeta var2 = var0.getItemMeta();
      List var3 = var2.getLore();
      if (var3 == null) {
         return var0;
      } else {
         if (var1 >= var3.size() || var1 < 0) {
            var1 = var3.size() - 1;
         }

         var3.remove(var1);
         var2.setLore(var3);
         var0.setItemMeta(var2);
         return var0;
      }
   }

   public static ItemStack delLoreLine(ItemStack var0, String var1) {
      ItemMeta var2 = var0.getItemMeta();
      List var3 = var2.getLore();
      if (var3 == null) {
         return var0;
      } else if (!var3.contains(var1)) {
         return var0;
      } else {
         int var4 = var3.indexOf(var1);
         var3.remove(var4);
         var2.setLore(var3);
         var0.setItemMeta(var2);
         return var0;
      }
   }

   public static ItemStack clearLore(ItemStack var0) {
      ItemMeta var1 = var0.getItemMeta();
      List var2 = var1.getLore();
      if (var2 == null) {
         return var0;
      } else {
         var1.setLore(new ArrayList());
         var0.setItemMeta(var1);
         return var0;
      }
   }

   public static ItemStack enchant(ItemStack var0, Enchantment var1, int var2) {
      if (var2 <= 0) {
         var0.removeEnchantment(var1);
      } else {
         var0.addUnsafeEnchantment(var1, var2);
      }

      return var0;
   }

   public static ItemStack addPotionEffect(ItemStack var0, PotionEffectType var1, int var2, int var3, boolean var4, boolean var5, boolean var6) {
      PotionMeta var7 = (PotionMeta)var0.getItemMeta();
      --var2;
      if (var2 < 0) {
         var7.removeCustomEffect(var1);
      } else {
         var7.addCustomEffect(new PotionEffect(var1, var3 * 20, var2, var4, var5), true);
      }

      var0.setItemMeta(var7);
      return var0;
   }

   public static ItemStack addPotionEffect(ItemStack var0, PotionEffectType var1, int var2, int var3, boolean var4, boolean var5, Color var6) {
      PotionMeta var7 = (PotionMeta)var0.getItemMeta();
      --var2;
      if (var2 < 0) {
         var7.removeCustomEffect(var1);
      } else {
         var7.addCustomEffect(new PotionEffect(var1, var3 * 20, var2, var4, var5, var6), true);
      }

      var0.setItemMeta(var7);
      return var0;
   }

   public static ItemStack setEggType(ItemStack var0, EntityType var1) {
      SpawnEggMeta var2 = (SpawnEggMeta)var0.getItemMeta();
      var2.setSpawnedType(var1);
      var0.setItemMeta(var2);
      return var0;
   }

   public static ItemStack setLeatherColor(ItemStack var0, Color var1) {
      LeatherArmorMeta var2 = (LeatherArmorMeta)var0.getItemMeta();
      var2.setColor(var1);
      var0.setItemMeta(var2);
      return var0;
   }

   // $FF: synthetic method
   static int[] $SWITCH_TABLE$org$bukkit$Material() {
      int[] var10000 = $SWITCH_TABLE$org$bukkit$Material;
      if (var10000 != null) {
         return var10000;
      } else {
         int[] var0 = new int[Material.values().length];

         try {
            var0[Material.ACACIA_DOOR.ordinal()] = 197;
         } catch (NoSuchFieldError var463) {
         }

         try {
            var0[Material.ACACIA_DOOR_ITEM.ordinal()] = 429;
         } catch (NoSuchFieldError var462) {
         }

         try {
            var0[Material.ACACIA_FENCE.ordinal()] = 193;
         } catch (NoSuchFieldError var461) {
         }

         try {
            var0[Material.ACACIA_FENCE_GATE.ordinal()] = 188;
         } catch (NoSuchFieldError var460) {
         }

         try {
            var0[Material.ACACIA_STAIRS.ordinal()] = 164;
         } catch (NoSuchFieldError var459) {
         }

         try {
            var0[Material.ACTIVATOR_RAIL.ordinal()] = 158;
         } catch (NoSuchFieldError var458) {
         }

         try {
            var0[Material.AIR.ordinal()] = 1;
         } catch (NoSuchFieldError var457) {
         }

         try {
            var0[Material.ANVIL.ordinal()] = 146;
         } catch (NoSuchFieldError var456) {
         }

         try {
            var0[Material.APPLE.ordinal()] = 259;
         } catch (NoSuchFieldError var455) {
         }

         try {
            var0[Material.ARMOR_STAND.ordinal()] = 415;
         } catch (NoSuchFieldError var454) {
         }

         try {
            var0[Material.ARROW.ordinal()] = 261;
         } catch (NoSuchFieldError var453) {
         }

         try {
            var0[Material.BAKED_POTATO.ordinal()] = 392;
         } catch (NoSuchFieldError var452) {
         }

         try {
            var0[Material.BANNER.ordinal()] = 424;
         } catch (NoSuchFieldError var451) {
         }

         try {
            var0[Material.BARRIER.ordinal()] = 167;
         } catch (NoSuchFieldError var450) {
         }

         try {
            var0[Material.BEACON.ordinal()] = 139;
         } catch (NoSuchFieldError var449) {
         }

         try {
            var0[Material.BED.ordinal()] = 354;
         } catch (NoSuchFieldError var448) {
         }

         try {
            var0[Material.BEDROCK.ordinal()] = 8;
         } catch (NoSuchFieldError var447) {
         }

         try {
            var0[Material.BED_BLOCK.ordinal()] = 27;
         } catch (NoSuchFieldError var446) {
         }

         try {
            var0[Material.BEETROOT.ordinal()] = 433;
         } catch (NoSuchFieldError var445) {
         }

         try {
            var0[Material.BEETROOT_BLOCK.ordinal()] = 208;
         } catch (NoSuchFieldError var444) {
         }

         try {
            var0[Material.BEETROOT_SEEDS.ordinal()] = 434;
         } catch (NoSuchFieldError var443) {
         }

         try {
            var0[Material.BEETROOT_SOUP.ordinal()] = 435;
         } catch (NoSuchFieldError var442) {
         }

         try {
            var0[Material.BIRCH_DOOR.ordinal()] = 195;
         } catch (NoSuchFieldError var441) {
         }

         try {
            var0[Material.BIRCH_DOOR_ITEM.ordinal()] = 427;
         } catch (NoSuchFieldError var440) {
         }

         try {
            var0[Material.BIRCH_FENCE.ordinal()] = 190;
         } catch (NoSuchFieldError var439) {
         }

         try {
            var0[Material.BIRCH_FENCE_GATE.ordinal()] = 185;
         } catch (NoSuchFieldError var438) {
         }

         try {
            var0[Material.BIRCH_WOOD_STAIRS.ordinal()] = 136;
         } catch (NoSuchFieldError var437) {
         }

         try {
            var0[Material.BLACK_GLAZED_TERRACOTTA.ordinal()] = 251;
         } catch (NoSuchFieldError var436) {
         }

         try {
            var0[Material.BLACK_SHULKER_BOX.ordinal()] = 235;
         } catch (NoSuchFieldError var435) {
         }

         try {
            var0[Material.BLAZE_POWDER.ordinal()] = 376;
         } catch (NoSuchFieldError var434) {
         }

         try {
            var0[Material.BLAZE_ROD.ordinal()] = 368;
         } catch (NoSuchFieldError var433) {
         }

         try {
            var0[Material.BLUE_GLAZED_TERRACOTTA.ordinal()] = 247;
         } catch (NoSuchFieldError var432) {
         }

         try {
            var0[Material.BLUE_SHULKER_BOX.ordinal()] = 231;
         } catch (NoSuchFieldError var431) {
         }

         try {
            var0[Material.BOAT.ordinal()] = 332;
         } catch (NoSuchFieldError var430) {
         }

         try {
            var0[Material.BOAT_ACACIA.ordinal()] = 446;
         } catch (NoSuchFieldError var429) {
         }

         try {
            var0[Material.BOAT_BIRCH.ordinal()] = 444;
         } catch (NoSuchFieldError var428) {
         }

         try {
            var0[Material.BOAT_DARK_OAK.ordinal()] = 447;
         } catch (NoSuchFieldError var427) {
         }

         try {
            var0[Material.BOAT_JUNGLE.ordinal()] = 445;
         } catch (NoSuchFieldError var426) {
         }

         try {
            var0[Material.BOAT_SPRUCE.ordinal()] = 443;
         } catch (NoSuchFieldError var425) {
         }

         try {
            var0[Material.BONE.ordinal()] = 351;
         } catch (NoSuchFieldError var424) {
         }

         try {
            var0[Material.BONE_BLOCK.ordinal()] = 217;
         } catch (NoSuchFieldError var423) {
         }

         try {
            var0[Material.BOOK.ordinal()] = 339;
         } catch (NoSuchFieldError var422) {
         }

         try {
            var0[Material.BOOKSHELF.ordinal()] = 48;
         } catch (NoSuchFieldError var421) {
         }

         try {
            var0[Material.BOOK_AND_QUILL.ordinal()] = 385;
         } catch (NoSuchFieldError var420) {
         }

         try {
            var0[Material.BOW.ordinal()] = 260;
         } catch (NoSuchFieldError var419) {
         }

         try {
            var0[Material.BOWL.ordinal()] = 280;
         } catch (NoSuchFieldError var418) {
         }

         try {
            var0[Material.BREAD.ordinal()] = 296;
         } catch (NoSuchFieldError var417) {
         }

         try {
            var0[Material.BREWING_STAND.ordinal()] = 118;
         } catch (NoSuchFieldError var416) {
         }

         try {
            var0[Material.BREWING_STAND_ITEM.ordinal()] = 378;
         } catch (NoSuchFieldError var415) {
         }

         try {
            var0[Material.BRICK.ordinal()] = 46;
         } catch (NoSuchFieldError var414) {
         }

         try {
            var0[Material.BRICK_STAIRS.ordinal()] = 109;
         } catch (NoSuchFieldError var413) {
         }

         try {
            var0[Material.BROWN_GLAZED_TERRACOTTA.ordinal()] = 248;
         } catch (NoSuchFieldError var412) {
         }

         try {
            var0[Material.BROWN_MUSHROOM.ordinal()] = 40;
         } catch (NoSuchFieldError var411) {
         }

         try {
            var0[Material.BROWN_SHULKER_BOX.ordinal()] = 232;
         } catch (NoSuchFieldError var410) {
         }

         try {
            var0[Material.BUCKET.ordinal()] = 324;
         } catch (NoSuchFieldError var409) {
         }

         try {
            var0[Material.BURNING_FURNACE.ordinal()] = 63;
         } catch (NoSuchFieldError var408) {
         }

         try {
            var0[Material.CACTUS.ordinal()] = 82;
         } catch (NoSuchFieldError var407) {
         }

         try {
            var0[Material.CAKE.ordinal()] = 353;
         } catch (NoSuchFieldError var406) {
         }

         try {
            var0[Material.CAKE_BLOCK.ordinal()] = 93;
         } catch (NoSuchFieldError var405) {
         }

         try {
            var0[Material.CARPET.ordinal()] = 172;
         } catch (NoSuchFieldError var404) {
         }

         try {
            var0[Material.CARROT.ordinal()] = 142;
         } catch (NoSuchFieldError var403) {
         }

         try {
            var0[Material.CARROT_ITEM.ordinal()] = 390;
         } catch (NoSuchFieldError var402) {
         }

         try {
            var0[Material.CARROT_STICK.ordinal()] = 397;
         } catch (NoSuchFieldError var401) {
         }

         try {
            var0[Material.CAULDRON.ordinal()] = 119;
         } catch (NoSuchFieldError var400) {
         }

         try {
            var0[Material.CAULDRON_ITEM.ordinal()] = 379;
         } catch (NoSuchFieldError var399) {
         }

         try {
            var0[Material.CHAINMAIL_BOOTS.ordinal()] = 304;
         } catch (NoSuchFieldError var398) {
         }

         try {
            var0[Material.CHAINMAIL_CHESTPLATE.ordinal()] = 302;
         } catch (NoSuchFieldError var397) {
         }

         try {
            var0[Material.CHAINMAIL_HELMET.ordinal()] = 301;
         } catch (NoSuchFieldError var396) {
         }

         try {
            var0[Material.CHAINMAIL_LEGGINGS.ordinal()] = 303;
         } catch (NoSuchFieldError var395) {
         }

         try {
            var0[Material.CHEST.ordinal()] = 55;
         } catch (NoSuchFieldError var394) {
         }

         try {
            var0[Material.CHORUS_FLOWER.ordinal()] = 201;
         } catch (NoSuchFieldError var393) {
         }

         try {
            var0[Material.CHORUS_FRUIT.ordinal()] = 431;
         } catch (NoSuchFieldError var392) {
         }

         try {
            var0[Material.CHORUS_FRUIT_POPPED.ordinal()] = 432;
         } catch (NoSuchFieldError var391) {
         }

         try {
            var0[Material.CHORUS_PLANT.ordinal()] = 200;
         } catch (NoSuchFieldError var390) {
         }

         try {
            var0[Material.CLAY.ordinal()] = 83;
         } catch (NoSuchFieldError var389) {
         }

         try {
            var0[Material.CLAY_BALL.ordinal()] = 336;
         } catch (NoSuchFieldError var388) {
         }

         try {
            var0[Material.CLAY_BRICK.ordinal()] = 335;
         } catch (NoSuchFieldError var387) {
         }

         try {
            var0[Material.COAL.ordinal()] = 262;
         } catch (NoSuchFieldError var386) {
         }

         try {
            var0[Material.COAL_BLOCK.ordinal()] = 174;
         } catch (NoSuchFieldError var385) {
         }

         try {
            var0[Material.COAL_ORE.ordinal()] = 17;
         } catch (NoSuchFieldError var384) {
         }

         try {
            var0[Material.COBBLESTONE.ordinal()] = 5;
         } catch (NoSuchFieldError var383) {
         }

         try {
            var0[Material.COBBLESTONE_STAIRS.ordinal()] = 68;
         } catch (NoSuchFieldError var382) {
         }

         try {
            var0[Material.COBBLE_WALL.ordinal()] = 140;
         } catch (NoSuchFieldError var381) {
         }

         try {
            var0[Material.COCOA.ordinal()] = 128;
         } catch (NoSuchFieldError var380) {
         }

         try {
            var0[Material.COMMAND.ordinal()] = 138;
         } catch (NoSuchFieldError var379) {
         }

         try {
            var0[Material.COMMAND_CHAIN.ordinal()] = 212;
         } catch (NoSuchFieldError var378) {
         }

         try {
            var0[Material.COMMAND_MINECART.ordinal()] = 421;
         } catch (NoSuchFieldError var377) {
         }

         try {
            var0[Material.COMMAND_REPEATING.ordinal()] = 211;
         } catch (NoSuchFieldError var376) {
         }

         try {
            var0[Material.COMPASS.ordinal()] = 344;
         } catch (NoSuchFieldError var375) {
         }

         try {
            var0[Material.CONCRETE.ordinal()] = 252;
         } catch (NoSuchFieldError var374) {
         }

         try {
            var0[Material.CONCRETE_POWDER.ordinal()] = 253;
         } catch (NoSuchFieldError var373) {
         }

         try {
            var0[Material.COOKED_BEEF.ordinal()] = 363;
         } catch (NoSuchFieldError var372) {
         }

         try {
            var0[Material.COOKED_CHICKEN.ordinal()] = 365;
         } catch (NoSuchFieldError var371) {
         }

         try {
            var0[Material.COOKED_FISH.ordinal()] = 349;
         } catch (NoSuchFieldError var370) {
         }

         try {
            var0[Material.COOKED_MUTTON.ordinal()] = 423;
         } catch (NoSuchFieldError var369) {
         }

         try {
            var0[Material.COOKED_RABBIT.ordinal()] = 411;
         } catch (NoSuchFieldError var368) {
         }

         try {
            var0[Material.COOKIE.ordinal()] = 356;
         } catch (NoSuchFieldError var367) {
         }

         try {
            var0[Material.CROPS.ordinal()] = 60;
         } catch (NoSuchFieldError var366) {
         }

         try {
            var0[Material.CYAN_GLAZED_TERRACOTTA.ordinal()] = 245;
         } catch (NoSuchFieldError var365) {
         }

         try {
            var0[Material.CYAN_SHULKER_BOX.ordinal()] = 229;
         } catch (NoSuchFieldError var364) {
         }

         try {
            var0[Material.DARK_OAK_DOOR.ordinal()] = 198;
         } catch (NoSuchFieldError var363) {
         }

         try {
            var0[Material.DARK_OAK_DOOR_ITEM.ordinal()] = 430;
         } catch (NoSuchFieldError var362) {
         }

         try {
            var0[Material.DARK_OAK_FENCE.ordinal()] = 192;
         } catch (NoSuchFieldError var361) {
         }

         try {
            var0[Material.DARK_OAK_FENCE_GATE.ordinal()] = 187;
         } catch (NoSuchFieldError var360) {
         }

         try {
            var0[Material.DARK_OAK_STAIRS.ordinal()] = 165;
         } catch (NoSuchFieldError var359) {
         }

         try {
            var0[Material.DAYLIGHT_DETECTOR.ordinal()] = 152;
         } catch (NoSuchFieldError var358) {
         }

         try {
            var0[Material.DAYLIGHT_DETECTOR_INVERTED.ordinal()] = 179;
         } catch (NoSuchFieldError var357) {
         }

         try {
            var0[Material.DEAD_BUSH.ordinal()] = 33;
         } catch (NoSuchFieldError var356) {
         }

         try {
            var0[Material.DETECTOR_RAIL.ordinal()] = 29;
         } catch (NoSuchFieldError var355) {
         }

         try {
            var0[Material.DIAMOND.ordinal()] = 263;
         } catch (NoSuchFieldError var354) {
         }

         try {
            var0[Material.DIAMOND_AXE.ordinal()] = 278;
         } catch (NoSuchFieldError var353) {
         }

         try {
            var0[Material.DIAMOND_BARDING.ordinal()] = 418;
         } catch (NoSuchFieldError var352) {
         }

         try {
            var0[Material.DIAMOND_BLOCK.ordinal()] = 58;
         } catch (NoSuchFieldError var351) {
         }

         try {
            var0[Material.DIAMOND_BOOTS.ordinal()] = 312;
         } catch (NoSuchFieldError var350) {
         }

         try {
            var0[Material.DIAMOND_CHESTPLATE.ordinal()] = 310;
         } catch (NoSuchFieldError var349) {
         }

         try {
            var0[Material.DIAMOND_HELMET.ordinal()] = 309;
         } catch (NoSuchFieldError var348) {
         }

         try {
            var0[Material.DIAMOND_HOE.ordinal()] = 292;
         } catch (NoSuchFieldError var347) {
         }

         try {
            var0[Material.DIAMOND_LEGGINGS.ordinal()] = 311;
         } catch (NoSuchFieldError var346) {
         }

         try {
            var0[Material.DIAMOND_ORE.ordinal()] = 57;
         } catch (NoSuchFieldError var345) {
         }

         try {
            var0[Material.DIAMOND_PICKAXE.ordinal()] = 277;
         } catch (NoSuchFieldError var344) {
         }

         try {
            var0[Material.DIAMOND_SPADE.ordinal()] = 276;
         } catch (NoSuchFieldError var343) {
         }

         try {
            var0[Material.DIAMOND_SWORD.ordinal()] = 275;
         } catch (NoSuchFieldError var342) {
         }

         try {
            var0[Material.DIODE.ordinal()] = 355;
         } catch (NoSuchFieldError var341) {
         }

         try {
            var0[Material.DIODE_BLOCK_OFF.ordinal()] = 94;
         } catch (NoSuchFieldError var340) {
         }

         try {
            var0[Material.DIODE_BLOCK_ON.ordinal()] = 95;
         } catch (NoSuchFieldError var339) {
         }

         try {
            var0[Material.DIRT.ordinal()] = 4;
         } catch (NoSuchFieldError var338) {
         }

         try {
            var0[Material.DISPENSER.ordinal()] = 24;
         } catch (NoSuchFieldError var337) {
         }

         try {
            var0[Material.DOUBLE_PLANT.ordinal()] = 176;
         } catch (NoSuchFieldError var336) {
         }

         try {
            var0[Material.DOUBLE_STEP.ordinal()] = 44;
         } catch (NoSuchFieldError var335) {
         }

         try {
            var0[Material.DOUBLE_STONE_SLAB2.ordinal()] = 182;
         } catch (NoSuchFieldError var334) {
         }

         try {
            var0[Material.DRAGONS_BREATH.ordinal()] = 436;
         } catch (NoSuchFieldError var333) {
         }

         try {
            var0[Material.DRAGON_EGG.ordinal()] = 123;
         } catch (NoSuchFieldError var332) {
         }

         try {
            var0[Material.DROPPER.ordinal()] = 159;
         } catch (NoSuchFieldError var331) {
         }

         try {
            var0[Material.EGG.ordinal()] = 343;
         } catch (NoSuchFieldError var330) {
         }

         try {
            var0[Material.ELYTRA.ordinal()] = 442;
         } catch (NoSuchFieldError var329) {
         }

         try {
            var0[Material.EMERALD.ordinal()] = 387;
         } catch (NoSuchFieldError var328) {
         }

         try {
            var0[Material.EMERALD_BLOCK.ordinal()] = 134;
         } catch (NoSuchFieldError var327) {
         }

         try {
            var0[Material.EMERALD_ORE.ordinal()] = 130;
         } catch (NoSuchFieldError var326) {
         }

         try {
            var0[Material.EMPTY_MAP.ordinal()] = 394;
         } catch (NoSuchFieldError var325) {
         }

         try {
            var0[Material.ENCHANTED_BOOK.ordinal()] = 402;
         } catch (NoSuchFieldError var324) {
         }

         try {
            var0[Material.ENCHANTMENT_TABLE.ordinal()] = 117;
         } catch (NoSuchFieldError var323) {
         }

         try {
            var0[Material.ENDER_CHEST.ordinal()] = 131;
         } catch (NoSuchFieldError var322) {
         }

         try {
            var0[Material.ENDER_PEARL.ordinal()] = 367;
         } catch (NoSuchFieldError var321) {
         }

         try {
            var0[Material.ENDER_PORTAL.ordinal()] = 120;
         } catch (NoSuchFieldError var320) {
         }

         try {
            var0[Material.ENDER_PORTAL_FRAME.ordinal()] = 121;
         } catch (NoSuchFieldError var319) {
         }

         try {
            var0[Material.ENDER_STONE.ordinal()] = 122;
         } catch (NoSuchFieldError var318) {
         }

         try {
            var0[Material.END_BRICKS.ordinal()] = 207;
         } catch (NoSuchFieldError var317) {
         }

         try {
            var0[Material.END_CRYSTAL.ordinal()] = 425;
         } catch (NoSuchFieldError var316) {
         }

         try {
            var0[Material.END_GATEWAY.ordinal()] = 210;
         } catch (NoSuchFieldError var315) {
         }

         try {
            var0[Material.END_ROD.ordinal()] = 199;
         } catch (NoSuchFieldError var314) {
         }

         try {
            var0[Material.EXPLOSIVE_MINECART.ordinal()] = 406;
         } catch (NoSuchFieldError var313) {
         }

         try {
            var0[Material.EXP_BOTTLE.ordinal()] = 383;
         } catch (NoSuchFieldError var312) {
         }

         try {
            var0[Material.EYE_OF_ENDER.ordinal()] = 380;
         } catch (NoSuchFieldError var311) {
         }

         try {
            var0[Material.FEATHER.ordinal()] = 287;
         } catch (NoSuchFieldError var310) {
         }

         try {
            var0[Material.FENCE.ordinal()] = 86;
         } catch (NoSuchFieldError var309) {
         }

         try {
            var0[Material.FENCE_GATE.ordinal()] = 108;
         } catch (NoSuchFieldError var308) {
         }

         try {
            var0[Material.FERMENTED_SPIDER_EYE.ordinal()] = 375;
         } catch (NoSuchFieldError var307) {
         }

         try {
            var0[Material.FIRE.ordinal()] = 52;
         } catch (NoSuchFieldError var306) {
         }

         try {
            var0[Material.FIREBALL.ordinal()] = 384;
         } catch (NoSuchFieldError var305) {
         }

         try {
            var0[Material.FIREWORK.ordinal()] = 400;
         } catch (NoSuchFieldError var304) {
         }

         try {
            var0[Material.FIREWORK_CHARGE.ordinal()] = 401;
         } catch (NoSuchFieldError var303) {
         }

         try {
            var0[Material.FISHING_ROD.ordinal()] = 345;
         } catch (NoSuchFieldError var302) {
         }

         try {
            var0[Material.FLINT.ordinal()] = 317;
         } catch (NoSuchFieldError var301) {
         }

         try {
            var0[Material.FLINT_AND_STEEL.ordinal()] = 258;
         } catch (NoSuchFieldError var300) {
         }

         try {
            var0[Material.FLOWER_POT.ordinal()] = 141;
         } catch (NoSuchFieldError var299) {
         }

         try {
            var0[Material.FLOWER_POT_ITEM.ordinal()] = 389;
         } catch (NoSuchFieldError var298) {
         }

         try {
            var0[Material.FROSTED_ICE.ordinal()] = 213;
         } catch (NoSuchFieldError var297) {
         }

         try {
            var0[Material.FURNACE.ordinal()] = 62;
         } catch (NoSuchFieldError var296) {
         }

         try {
            var0[Material.GHAST_TEAR.ordinal()] = 369;
         } catch (NoSuchFieldError var295) {
         }

         try {
            var0[Material.GLASS.ordinal()] = 21;
         } catch (NoSuchFieldError var294) {
         }

         try {
            var0[Material.GLASS_BOTTLE.ordinal()] = 373;
         } catch (NoSuchFieldError var293) {
         }

         try {
            var0[Material.GLOWING_REDSTONE_ORE.ordinal()] = 75;
         } catch (NoSuchFieldError var292) {
         }

         try {
            var0[Material.GLOWSTONE.ordinal()] = 90;
         } catch (NoSuchFieldError var291) {
         }

         try {
            var0[Material.GLOWSTONE_DUST.ordinal()] = 347;
         } catch (NoSuchFieldError var290) {
         }

         try {
            var0[Material.GOLDEN_APPLE.ordinal()] = 321;
         } catch (NoSuchFieldError var289) {
         }

         try {
            var0[Material.GOLDEN_CARROT.ordinal()] = 395;
         } catch (NoSuchFieldError var288) {
         }

         try {
            var0[Material.GOLD_AXE.ordinal()] = 285;
         } catch (NoSuchFieldError var287) {
         }

         try {
            var0[Material.GOLD_BARDING.ordinal()] = 417;
         } catch (NoSuchFieldError var286) {
         }

         try {
            var0[Material.GOLD_BLOCK.ordinal()] = 42;
         } catch (NoSuchFieldError var285) {
         }

         try {
            var0[Material.GOLD_BOOTS.ordinal()] = 316;
         } catch (NoSuchFieldError var284) {
         }

         try {
            var0[Material.GOLD_CHESTPLATE.ordinal()] = 314;
         } catch (NoSuchFieldError var283) {
         }

         try {
            var0[Material.GOLD_HELMET.ordinal()] = 313;
         } catch (NoSuchFieldError var282) {
         }

         try {
            var0[Material.GOLD_HOE.ordinal()] = 293;
         } catch (NoSuchFieldError var281) {
         }

         try {
            var0[Material.GOLD_INGOT.ordinal()] = 265;
         } catch (NoSuchFieldError var280) {
         }

         try {
            var0[Material.GOLD_LEGGINGS.ordinal()] = 315;
         } catch (NoSuchFieldError var279) {
         }

         try {
            var0[Material.GOLD_NUGGET.ordinal()] = 370;
         } catch (NoSuchFieldError var278) {
         }

         try {
            var0[Material.GOLD_ORE.ordinal()] = 15;
         } catch (NoSuchFieldError var277) {
         }

         try {
            var0[Material.GOLD_PICKAXE.ordinal()] = 284;
         } catch (NoSuchFieldError var276) {
         }

         try {
            var0[Material.GOLD_PLATE.ordinal()] = 148;
         } catch (NoSuchFieldError var275) {
         }

         try {
            var0[Material.GOLD_RECORD.ordinal()] = 452;
         } catch (NoSuchFieldError var274) {
         }

         try {
            var0[Material.GOLD_SPADE.ordinal()] = 283;
         } catch (NoSuchFieldError var273) {
         }

         try {
            var0[Material.GOLD_SWORD.ordinal()] = 282;
         } catch (NoSuchFieldError var272) {
         }

         try {
            var0[Material.GRASS.ordinal()] = 3;
         } catch (NoSuchFieldError var271) {
         }

         try {
            var0[Material.GRASS_PATH.ordinal()] = 209;
         } catch (NoSuchFieldError var270) {
         }

         try {
            var0[Material.GRAVEL.ordinal()] = 14;
         } catch (NoSuchFieldError var269) {
         }

         try {
            var0[Material.GRAY_GLAZED_TERRACOTTA.ordinal()] = 243;
         } catch (NoSuchFieldError var268) {
         }

         try {
            var0[Material.GRAY_SHULKER_BOX.ordinal()] = 227;
         } catch (NoSuchFieldError var267) {
         }

         try {
            var0[Material.GREEN_GLAZED_TERRACOTTA.ordinal()] = 249;
         } catch (NoSuchFieldError var266) {
         }

         try {
            var0[Material.GREEN_RECORD.ordinal()] = 453;
         } catch (NoSuchFieldError var265) {
         }

         try {
            var0[Material.GREEN_SHULKER_BOX.ordinal()] = 233;
         } catch (NoSuchFieldError var264) {
         }

         try {
            var0[Material.GRILLED_PORK.ordinal()] = 319;
         } catch (NoSuchFieldError var263) {
         }

         try {
            var0[Material.HARD_CLAY.ordinal()] = 173;
         } catch (NoSuchFieldError var262) {
         }

         try {
            var0[Material.HAY_BLOCK.ordinal()] = 171;
         } catch (NoSuchFieldError var261) {
         }

         try {
            var0[Material.HOPPER.ordinal()] = 155;
         } catch (NoSuchFieldError var260) {
         }

         try {
            var0[Material.HOPPER_MINECART.ordinal()] = 407;
         } catch (NoSuchFieldError var259) {
         }

         try {
            var0[Material.HUGE_MUSHROOM_1.ordinal()] = 100;
         } catch (NoSuchFieldError var258) {
         }

         try {
            var0[Material.HUGE_MUSHROOM_2.ordinal()] = 101;
         } catch (NoSuchFieldError var257) {
         }

         try {
            var0[Material.ICE.ordinal()] = 80;
         } catch (NoSuchFieldError var256) {
         }

         try {
            var0[Material.INK_SACK.ordinal()] = 350;
         } catch (NoSuchFieldError var255) {
         }

         try {
            var0[Material.IRON_AXE.ordinal()] = 257;
         } catch (NoSuchFieldError var254) {
         }

         try {
            var0[Material.IRON_BARDING.ordinal()] = 416;
         } catch (NoSuchFieldError var253) {
         }

         try {
            var0[Material.IRON_BLOCK.ordinal()] = 43;
         } catch (NoSuchFieldError var252) {
         }

         try {
            var0[Material.IRON_BOOTS.ordinal()] = 308;
         } catch (NoSuchFieldError var251) {
         }

         try {
            var0[Material.IRON_CHESTPLATE.ordinal()] = 306;
         } catch (NoSuchFieldError var250) {
         }

         try {
            var0[Material.IRON_DOOR.ordinal()] = 329;
         } catch (NoSuchFieldError var249) {
         }

         try {
            var0[Material.IRON_DOOR_BLOCK.ordinal()] = 72;
         } catch (NoSuchFieldError var248) {
         }

         try {
            var0[Material.IRON_FENCE.ordinal()] = 102;
         } catch (NoSuchFieldError var247) {
         }

         try {
            var0[Material.IRON_HELMET.ordinal()] = 305;
         } catch (NoSuchFieldError var246) {
         }

         try {
            var0[Material.IRON_HOE.ordinal()] = 291;
         } catch (NoSuchFieldError var245) {
         }

         try {
            var0[Material.IRON_INGOT.ordinal()] = 264;
         } catch (NoSuchFieldError var244) {
         }

         try {
            var0[Material.IRON_LEGGINGS.ordinal()] = 307;
         } catch (NoSuchFieldError var243) {
         }

         try {
            var0[Material.IRON_NUGGET.ordinal()] = 450;
         } catch (NoSuchFieldError var242) {
         }

         try {
            var0[Material.IRON_ORE.ordinal()] = 16;
         } catch (NoSuchFieldError var241) {
         }

         try {
            var0[Material.IRON_PICKAXE.ordinal()] = 256;
         } catch (NoSuchFieldError var240) {
         }

         try {
            var0[Material.IRON_PLATE.ordinal()] = 149;
         } catch (NoSuchFieldError var239) {
         }

         try {
            var0[Material.IRON_SPADE.ordinal()] = 255;
         } catch (NoSuchFieldError var238) {
         }

         try {
            var0[Material.IRON_SWORD.ordinal()] = 266;
         } catch (NoSuchFieldError var237) {
         }

         try {
            var0[Material.IRON_TRAPDOOR.ordinal()] = 168;
         } catch (NoSuchFieldError var236) {
         }

         try {
            var0[Material.ITEM_FRAME.ordinal()] = 388;
         } catch (NoSuchFieldError var235) {
         }

         try {
            var0[Material.JACK_O_LANTERN.ordinal()] = 92;
         } catch (NoSuchFieldError var234) {
         }

         try {
            var0[Material.JUKEBOX.ordinal()] = 85;
         } catch (NoSuchFieldError var233) {
         }

         try {
            var0[Material.JUNGLE_DOOR.ordinal()] = 196;
         } catch (NoSuchFieldError var232) {
         }

         try {
            var0[Material.JUNGLE_DOOR_ITEM.ordinal()] = 428;
         } catch (NoSuchFieldError var231) {
         }

         try {
            var0[Material.JUNGLE_FENCE.ordinal()] = 191;
         } catch (NoSuchFieldError var230) {
         }

         try {
            var0[Material.JUNGLE_FENCE_GATE.ordinal()] = 186;
         } catch (NoSuchFieldError var229) {
         }

         try {
            var0[Material.JUNGLE_WOOD_STAIRS.ordinal()] = 137;
         } catch (NoSuchFieldError var228) {
         }

         try {
            var0[Material.KNOWLEDGE_BOOK.ordinal()] = 451;
         } catch (NoSuchFieldError var227) {
         }

         try {
            var0[Material.LADDER.ordinal()] = 66;
         } catch (NoSuchFieldError var226) {
         }

         try {
            var0[Material.LAPIS_BLOCK.ordinal()] = 23;
         } catch (NoSuchFieldError var225) {
         }

         try {
            var0[Material.LAPIS_ORE.ordinal()] = 22;
         } catch (NoSuchFieldError var224) {
         }

         try {
            var0[Material.LAVA.ordinal()] = 11;
         } catch (NoSuchFieldError var223) {
         }

         try {
            var0[Material.LAVA_BUCKET.ordinal()] = 326;
         } catch (NoSuchFieldError var222) {
         }

         try {
            var0[Material.LEASH.ordinal()] = 419;
         } catch (NoSuchFieldError var221) {
         }

         try {
            var0[Material.LEATHER.ordinal()] = 333;
         } catch (NoSuchFieldError var220) {
         }

         try {
            var0[Material.LEATHER_BOOTS.ordinal()] = 300;
         } catch (NoSuchFieldError var219) {
         }

         try {
            var0[Material.LEATHER_CHESTPLATE.ordinal()] = 298;
         } catch (NoSuchFieldError var218) {
         }

         try {
            var0[Material.LEATHER_HELMET.ordinal()] = 297;
         } catch (NoSuchFieldError var217) {
         }

         try {
            var0[Material.LEATHER_LEGGINGS.ordinal()] = 299;
         } catch (NoSuchFieldError var216) {
         }

         try {
            var0[Material.LEAVES.ordinal()] = 19;
         } catch (NoSuchFieldError var215) {
         }

         try {
            var0[Material.LEAVES_2.ordinal()] = 162;
         } catch (NoSuchFieldError var214) {
         }

         try {
            var0[Material.LEVER.ordinal()] = 70;
         } catch (NoSuchFieldError var213) {
         }

         try {
            var0[Material.LIGHT_BLUE_GLAZED_TERRACOTTA.ordinal()] = 239;
         } catch (NoSuchFieldError var212) {
         }

         try {
            var0[Material.LIGHT_BLUE_SHULKER_BOX.ordinal()] = 223;
         } catch (NoSuchFieldError var211) {
         }

         try {
            var0[Material.LIME_GLAZED_TERRACOTTA.ordinal()] = 241;
         } catch (NoSuchFieldError var210) {
         }

         try {
            var0[Material.LIME_SHULKER_BOX.ordinal()] = 225;
         } catch (NoSuchFieldError var209) {
         }

         try {
            var0[Material.LINGERING_POTION.ordinal()] = 440;
         } catch (NoSuchFieldError var208) {
         }

         try {
            var0[Material.LOG.ordinal()] = 18;
         } catch (NoSuchFieldError var207) {
         }

         try {
            var0[Material.LOG_2.ordinal()] = 163;
         } catch (NoSuchFieldError var206) {
         }

         try {
            var0[Material.LONG_GRASS.ordinal()] = 32;
         } catch (NoSuchFieldError var205) {
         }

         try {
            var0[Material.MAGENTA_GLAZED_TERRACOTTA.ordinal()] = 238;
         } catch (NoSuchFieldError var204) {
         }

         try {
            var0[Material.MAGENTA_SHULKER_BOX.ordinal()] = 222;
         } catch (NoSuchFieldError var203) {
         }

         try {
            var0[Material.MAGMA.ordinal()] = 214;
         } catch (NoSuchFieldError var202) {
         }

         try {
            var0[Material.MAGMA_CREAM.ordinal()] = 377;
         } catch (NoSuchFieldError var201) {
         }

         try {
            var0[Material.MAP.ordinal()] = 357;
         } catch (NoSuchFieldError var200) {
         }

         try {
            var0[Material.MELON.ordinal()] = 359;
         } catch (NoSuchFieldError var199) {
         }

         try {
            var0[Material.MELON_BLOCK.ordinal()] = 104;
         } catch (NoSuchFieldError var198) {
         }

         try {
            var0[Material.MELON_SEEDS.ordinal()] = 361;
         } catch (NoSuchFieldError var197) {
         }

         try {
            var0[Material.MELON_STEM.ordinal()] = 106;
         } catch (NoSuchFieldError var196) {
         }

         try {
            var0[Material.MILK_BUCKET.ordinal()] = 334;
         } catch (NoSuchFieldError var195) {
         }

         try {
            var0[Material.MINECART.ordinal()] = 327;
         } catch (NoSuchFieldError var194) {
         }

         try {
            var0[Material.MOB_SPAWNER.ordinal()] = 53;
         } catch (NoSuchFieldError var193) {
         }

         try {
            var0[Material.MONSTER_EGG.ordinal()] = 382;
         } catch (NoSuchFieldError var192) {
         }

         try {
            var0[Material.MONSTER_EGGS.ordinal()] = 98;
         } catch (NoSuchFieldError var191) {
         }

         try {
            var0[Material.MOSSY_COBBLESTONE.ordinal()] = 49;
         } catch (NoSuchFieldError var190) {
         }

         try {
            var0[Material.MUSHROOM_SOUP.ordinal()] = 281;
         } catch (NoSuchFieldError var189) {
         }

         try {
            var0[Material.MUTTON.ordinal()] = 422;
         } catch (NoSuchFieldError var188) {
         }

         try {
            var0[Material.MYCEL.ordinal()] = 111;
         } catch (NoSuchFieldError var187) {
         }

         try {
            var0[Material.NAME_TAG.ordinal()] = 420;
         } catch (NoSuchFieldError var186) {
         }

         try {
            var0[Material.NETHERRACK.ordinal()] = 88;
         } catch (NoSuchFieldError var185) {
         }

         try {
            var0[Material.NETHER_BRICK.ordinal()] = 113;
         } catch (NoSuchFieldError var184) {
         }

         try {
            var0[Material.NETHER_BRICK_ITEM.ordinal()] = 404;
         } catch (NoSuchFieldError var183) {
         }

         try {
            var0[Material.NETHER_BRICK_STAIRS.ordinal()] = 115;
         } catch (NoSuchFieldError var182) {
         }

         try {
            var0[Material.NETHER_FENCE.ordinal()] = 114;
         } catch (NoSuchFieldError var181) {
         }

         try {
            var0[Material.NETHER_STALK.ordinal()] = 371;
         } catch (NoSuchFieldError var180) {
         }

         try {
            var0[Material.NETHER_STAR.ordinal()] = 398;
         } catch (NoSuchFieldError var179) {
         }

         try {
            var0[Material.NETHER_WARTS.ordinal()] = 116;
         } catch (NoSuchFieldError var178) {
         }

         try {
            var0[Material.NETHER_WART_BLOCK.ordinal()] = 215;
         } catch (NoSuchFieldError var177) {
         }

         try {
            var0[Material.NOTE_BLOCK.ordinal()] = 26;
         } catch (NoSuchFieldError var176) {
         }

         try {
            var0[Material.OBSERVER.ordinal()] = 219;
         } catch (NoSuchFieldError var175) {
         }

         try {
            var0[Material.OBSIDIAN.ordinal()] = 50;
         } catch (NoSuchFieldError var174) {
         }

         try {
            var0[Material.ORANGE_GLAZED_TERRACOTTA.ordinal()] = 237;
         } catch (NoSuchFieldError var173) {
         }

         try {
            var0[Material.ORANGE_SHULKER_BOX.ordinal()] = 221;
         } catch (NoSuchFieldError var172) {
         }

         try {
            var0[Material.PACKED_ICE.ordinal()] = 175;
         } catch (NoSuchFieldError var171) {
         }

         try {
            var0[Material.PAINTING.ordinal()] = 320;
         } catch (NoSuchFieldError var170) {
         }

         try {
            var0[Material.PAPER.ordinal()] = 338;
         } catch (NoSuchFieldError var169) {
         }

         try {
            var0[Material.PINK_GLAZED_TERRACOTTA.ordinal()] = 242;
         } catch (NoSuchFieldError var168) {
         }

         try {
            var0[Material.PINK_SHULKER_BOX.ordinal()] = 226;
         } catch (NoSuchFieldError var167) {
         }

         try {
            var0[Material.PISTON_BASE.ordinal()] = 34;
         } catch (NoSuchFieldError var166) {
         }

         try {
            var0[Material.PISTON_EXTENSION.ordinal()] = 35;
         } catch (NoSuchFieldError var165) {
         }

         try {
            var0[Material.PISTON_MOVING_PIECE.ordinal()] = 37;
         } catch (NoSuchFieldError var164) {
         }

         try {
            var0[Material.PISTON_STICKY_BASE.ordinal()] = 30;
         } catch (NoSuchFieldError var163) {
         }

         try {
            var0[Material.POISONOUS_POTATO.ordinal()] = 393;
         } catch (NoSuchFieldError var162) {
         }

         try {
            var0[Material.PORK.ordinal()] = 318;
         } catch (NoSuchFieldError var161) {
         }

         try {
            var0[Material.PORTAL.ordinal()] = 91;
         } catch (NoSuchFieldError var160) {
         }

         try {
            var0[Material.POTATO.ordinal()] = 143;
         } catch (NoSuchFieldError var159) {
         }

         try {
            var0[Material.POTATO_ITEM.ordinal()] = 391;
         } catch (NoSuchFieldError var158) {
         }

         try {
            var0[Material.POTION.ordinal()] = 372;
         } catch (NoSuchFieldError var157) {
         }

         try {
            var0[Material.POWERED_MINECART.ordinal()] = 342;
         } catch (NoSuchFieldError var156) {
         }

         try {
            var0[Material.POWERED_RAIL.ordinal()] = 28;
         } catch (NoSuchFieldError var155) {
         }

         try {
            var0[Material.PRISMARINE.ordinal()] = 169;
         } catch (NoSuchFieldError var154) {
         }

         try {
            var0[Material.PRISMARINE_CRYSTALS.ordinal()] = 409;
         } catch (NoSuchFieldError var153) {
         }

         try {
            var0[Material.PRISMARINE_SHARD.ordinal()] = 408;
         } catch (NoSuchFieldError var152) {
         }

         try {
            var0[Material.PUMPKIN.ordinal()] = 87;
         } catch (NoSuchFieldError var151) {
         }

         try {
            var0[Material.PUMPKIN_PIE.ordinal()] = 399;
         } catch (NoSuchFieldError var150) {
         }

         try {
            var0[Material.PUMPKIN_SEEDS.ordinal()] = 360;
         } catch (NoSuchFieldError var149) {
         }

         try {
            var0[Material.PUMPKIN_STEM.ordinal()] = 105;
         } catch (NoSuchFieldError var148) {
         }

         try {
            var0[Material.PURPLE_GLAZED_TERRACOTTA.ordinal()] = 246;
         } catch (NoSuchFieldError var147) {
         }

         try {
            var0[Material.PURPLE_SHULKER_BOX.ordinal()] = 230;
         } catch (NoSuchFieldError var146) {
         }

         try {
            var0[Material.PURPUR_BLOCK.ordinal()] = 202;
         } catch (NoSuchFieldError var145) {
         }

         try {
            var0[Material.PURPUR_DOUBLE_SLAB.ordinal()] = 205;
         } catch (NoSuchFieldError var144) {
         }

         try {
            var0[Material.PURPUR_PILLAR.ordinal()] = 203;
         } catch (NoSuchFieldError var143) {
         }

         try {
            var0[Material.PURPUR_SLAB.ordinal()] = 206;
         } catch (NoSuchFieldError var142) {
         }

         try {
            var0[Material.PURPUR_STAIRS.ordinal()] = 204;
         } catch (NoSuchFieldError var141) {
         }

         try {
            var0[Material.QUARTZ.ordinal()] = 405;
         } catch (NoSuchFieldError var140) {
         }

         try {
            var0[Material.QUARTZ_BLOCK.ordinal()] = 156;
         } catch (NoSuchFieldError var139) {
         }

         try {
            var0[Material.QUARTZ_ORE.ordinal()] = 154;
         } catch (NoSuchFieldError var138) {
         }

         try {
            var0[Material.QUARTZ_STAIRS.ordinal()] = 157;
         } catch (NoSuchFieldError var137) {
         }

         try {
            var0[Material.RABBIT.ordinal()] = 410;
         } catch (NoSuchFieldError var136) {
         }

         try {
            var0[Material.RABBIT_FOOT.ordinal()] = 413;
         } catch (NoSuchFieldError var135) {
         }

         try {
            var0[Material.RABBIT_HIDE.ordinal()] = 414;
         } catch (NoSuchFieldError var134) {
         }

         try {
            var0[Material.RABBIT_STEW.ordinal()] = 412;
         } catch (NoSuchFieldError var133) {
         }

         try {
            var0[Material.RAILS.ordinal()] = 67;
         } catch (NoSuchFieldError var132) {
         }

         try {
            var0[Material.RAW_BEEF.ordinal()] = 362;
         } catch (NoSuchFieldError var131) {
         }

         try {
            var0[Material.RAW_CHICKEN.ordinal()] = 364;
         } catch (NoSuchFieldError var130) {
         }

         try {
            var0[Material.RAW_FISH.ordinal()] = 348;
         } catch (NoSuchFieldError var129) {
         }

         try {
            var0[Material.RECORD_10.ordinal()] = 461;
         } catch (NoSuchFieldError var128) {
         }

         try {
            var0[Material.RECORD_11.ordinal()] = 462;
         } catch (NoSuchFieldError var127) {
         }

         try {
            var0[Material.RECORD_12.ordinal()] = 463;
         } catch (NoSuchFieldError var126) {
         }

         try {
            var0[Material.RECORD_3.ordinal()] = 454;
         } catch (NoSuchFieldError var125) {
         }

         try {
            var0[Material.RECORD_4.ordinal()] = 455;
         } catch (NoSuchFieldError var124) {
         }

         try {
            var0[Material.RECORD_5.ordinal()] = 456;
         } catch (NoSuchFieldError var123) {
         }

         try {
            var0[Material.RECORD_6.ordinal()] = 457;
         } catch (NoSuchFieldError var122) {
         }

         try {
            var0[Material.RECORD_7.ordinal()] = 458;
         } catch (NoSuchFieldError var121) {
         }

         try {
            var0[Material.RECORD_8.ordinal()] = 459;
         } catch (NoSuchFieldError var120) {
         }

         try {
            var0[Material.RECORD_9.ordinal()] = 460;
         } catch (NoSuchFieldError var119) {
         }

         try {
            var0[Material.REDSTONE.ordinal()] = 330;
         } catch (NoSuchFieldError var118) {
         }

         try {
            var0[Material.REDSTONE_BLOCK.ordinal()] = 153;
         } catch (NoSuchFieldError var117) {
         }

         try {
            var0[Material.REDSTONE_COMPARATOR.ordinal()] = 403;
         } catch (NoSuchFieldError var116) {
         }

         try {
            var0[Material.REDSTONE_COMPARATOR_OFF.ordinal()] = 150;
         } catch (NoSuchFieldError var115) {
         }

         try {
            var0[Material.REDSTONE_COMPARATOR_ON.ordinal()] = 151;
         } catch (NoSuchFieldError var114) {
         }

         try {
            var0[Material.REDSTONE_LAMP_OFF.ordinal()] = 124;
         } catch (NoSuchFieldError var113) {
         }

         try {
            var0[Material.REDSTONE_LAMP_ON.ordinal()] = 125;
         } catch (NoSuchFieldError var112) {
         }

         try {
            var0[Material.REDSTONE_ORE.ordinal()] = 74;
         } catch (NoSuchFieldError var111) {
         }

         try {
            var0[Material.REDSTONE_TORCH_OFF.ordinal()] = 76;
         } catch (NoSuchFieldError var110) {
         }

         try {
            var0[Material.REDSTONE_TORCH_ON.ordinal()] = 77;
         } catch (NoSuchFieldError var109) {
         }

         try {
            var0[Material.REDSTONE_WIRE.ordinal()] = 56;
         } catch (NoSuchFieldError var108) {
         }

         try {
            var0[Material.RED_GLAZED_TERRACOTTA.ordinal()] = 250;
         } catch (NoSuchFieldError var107) {
         }

         try {
            var0[Material.RED_MUSHROOM.ordinal()] = 41;
         } catch (NoSuchFieldError var106) {
         }

         try {
            var0[Material.RED_NETHER_BRICK.ordinal()] = 216;
         } catch (NoSuchFieldError var105) {
         }

         try {
            var0[Material.RED_ROSE.ordinal()] = 39;
         } catch (NoSuchFieldError var104) {
         }

         try {
            var0[Material.RED_SANDSTONE.ordinal()] = 180;
         } catch (NoSuchFieldError var103) {
         }

         try {
            var0[Material.RED_SANDSTONE_STAIRS.ordinal()] = 181;
         } catch (NoSuchFieldError var102) {
         }

         try {
            var0[Material.RED_SHULKER_BOX.ordinal()] = 234;
         } catch (NoSuchFieldError var101) {
         }

         try {
            var0[Material.ROTTEN_FLESH.ordinal()] = 366;
         } catch (NoSuchFieldError var100) {
         }

         try {
            var0[Material.SADDLE.ordinal()] = 328;
         } catch (NoSuchFieldError var99) {
         }

         try {
            var0[Material.SAND.ordinal()] = 13;
         } catch (NoSuchFieldError var98) {
         }

         try {
            var0[Material.SANDSTONE.ordinal()] = 25;
         } catch (NoSuchFieldError var97) {
         }

         try {
            var0[Material.SANDSTONE_STAIRS.ordinal()] = 129;
         } catch (NoSuchFieldError var96) {
         }

         try {
            var0[Material.SAPLING.ordinal()] = 7;
         } catch (NoSuchFieldError var95) {
         }

         try {
            var0[Material.SEA_LANTERN.ordinal()] = 170;
         } catch (NoSuchFieldError var94) {
         }

         try {
            var0[Material.SEEDS.ordinal()] = 294;
         } catch (NoSuchFieldError var93) {
         }

         try {
            var0[Material.SHEARS.ordinal()] = 358;
         } catch (NoSuchFieldError var92) {
         }

         try {
            var0[Material.SHIELD.ordinal()] = 441;
         } catch (NoSuchFieldError var91) {
         }

         try {
            var0[Material.SHULKER_SHELL.ordinal()] = 449;
         } catch (NoSuchFieldError var90) {
         }

         try {
            var0[Material.SIGN.ordinal()] = 322;
         } catch (NoSuchFieldError var89) {
         }

         try {
            var0[Material.SIGN_POST.ordinal()] = 64;
         } catch (NoSuchFieldError var88) {
         }

         try {
            var0[Material.SILVER_GLAZED_TERRACOTTA.ordinal()] = 244;
         } catch (NoSuchFieldError var87) {
         }

         try {
            var0[Material.SILVER_SHULKER_BOX.ordinal()] = 228;
         } catch (NoSuchFieldError var86) {
         }

         try {
            var0[Material.SKULL.ordinal()] = 145;
         } catch (NoSuchFieldError var85) {
         }

         try {
            var0[Material.SKULL_ITEM.ordinal()] = 396;
         } catch (NoSuchFieldError var84) {
         }

         try {
            var0[Material.SLIME_BALL.ordinal()] = 340;
         } catch (NoSuchFieldError var83) {
         }

         try {
            var0[Material.SLIME_BLOCK.ordinal()] = 166;
         } catch (NoSuchFieldError var82) {
         }

         try {
            var0[Material.SMOOTH_BRICK.ordinal()] = 99;
         } catch (NoSuchFieldError var81) {
         }

         try {
            var0[Material.SMOOTH_STAIRS.ordinal()] = 110;
         } catch (NoSuchFieldError var80) {
         }

         try {
            var0[Material.SNOW.ordinal()] = 79;
         } catch (NoSuchFieldError var79) {
         }

         try {
            var0[Material.SNOW_BALL.ordinal()] = 331;
         } catch (NoSuchFieldError var78) {
         }

         try {
            var0[Material.SNOW_BLOCK.ordinal()] = 81;
         } catch (NoSuchFieldError var77) {
         }

         try {
            var0[Material.SOIL.ordinal()] = 61;
         } catch (NoSuchFieldError var76) {
         }

         try {
            var0[Material.SOUL_SAND.ordinal()] = 89;
         } catch (NoSuchFieldError var75) {
         }

         try {
            var0[Material.SPECKLED_MELON.ordinal()] = 381;
         } catch (NoSuchFieldError var74) {
         }

         try {
            var0[Material.SPECTRAL_ARROW.ordinal()] = 438;
         } catch (NoSuchFieldError var73) {
         }

         try {
            var0[Material.SPIDER_EYE.ordinal()] = 374;
         } catch (NoSuchFieldError var72) {
         }

         try {
            var0[Material.SPLASH_POTION.ordinal()] = 437;
         } catch (NoSuchFieldError var71) {
         }

         try {
            var0[Material.SPONGE.ordinal()] = 20;
         } catch (NoSuchFieldError var70) {
         }

         try {
            var0[Material.SPRUCE_DOOR.ordinal()] = 194;
         } catch (NoSuchFieldError var69) {
         }

         try {
            var0[Material.SPRUCE_DOOR_ITEM.ordinal()] = 426;
         } catch (NoSuchFieldError var68) {
         }

         try {
            var0[Material.SPRUCE_FENCE.ordinal()] = 189;
         } catch (NoSuchFieldError var67) {
         }

         try {
            var0[Material.SPRUCE_FENCE_GATE.ordinal()] = 184;
         } catch (NoSuchFieldError var66) {
         }

         try {
            var0[Material.SPRUCE_WOOD_STAIRS.ordinal()] = 135;
         } catch (NoSuchFieldError var65) {
         }

         try {
            var0[Material.STAINED_CLAY.ordinal()] = 160;
         } catch (NoSuchFieldError var64) {
         }

         try {
            var0[Material.STAINED_GLASS.ordinal()] = 96;
         } catch (NoSuchFieldError var63) {
         }

         try {
            var0[Material.STAINED_GLASS_PANE.ordinal()] = 161;
         } catch (NoSuchFieldError var62) {
         }

         try {
            var0[Material.STANDING_BANNER.ordinal()] = 177;
         } catch (NoSuchFieldError var61) {
         }

         try {
            var0[Material.STATIONARY_LAVA.ordinal()] = 12;
         } catch (NoSuchFieldError var60) {
         }

         try {
            var0[Material.STATIONARY_WATER.ordinal()] = 10;
         } catch (NoSuchFieldError var59) {
         }

         try {
            var0[Material.STEP.ordinal()] = 45;
         } catch (NoSuchFieldError var58) {
         }

         try {
            var0[Material.STICK.ordinal()] = 279;
         } catch (NoSuchFieldError var57) {
         }

         try {
            var0[Material.STONE.ordinal()] = 2;
         } catch (NoSuchFieldError var56) {
         }

         try {
            var0[Material.STONE_AXE.ordinal()] = 274;
         } catch (NoSuchFieldError var55) {
         }

         try {
            var0[Material.STONE_BUTTON.ordinal()] = 78;
         } catch (NoSuchFieldError var54) {
         }

         try {
            var0[Material.STONE_HOE.ordinal()] = 290;
         } catch (NoSuchFieldError var53) {
         }

         try {
            var0[Material.STONE_PICKAXE.ordinal()] = 273;
         } catch (NoSuchFieldError var52) {
         }

         try {
            var0[Material.STONE_PLATE.ordinal()] = 71;
         } catch (NoSuchFieldError var51) {
         }

         try {
            var0[Material.STONE_SLAB2.ordinal()] = 183;
         } catch (NoSuchFieldError var50) {
         }

         try {
            var0[Material.STONE_SPADE.ordinal()] = 272;
         } catch (NoSuchFieldError var49) {
         }

         try {
            var0[Material.STONE_SWORD.ordinal()] = 271;
         } catch (NoSuchFieldError var48) {
         }

         try {
            var0[Material.STORAGE_MINECART.ordinal()] = 341;
         } catch (NoSuchFieldError var47) {
         }

         try {
            var0[Material.STRING.ordinal()] = 286;
         } catch (NoSuchFieldError var46) {
         }

         try {
            var0[Material.STRUCTURE_BLOCK.ordinal()] = 254;
         } catch (NoSuchFieldError var45) {
         }

         try {
            var0[Material.STRUCTURE_VOID.ordinal()] = 218;
         } catch (NoSuchFieldError var44) {
         }

         try {
            var0[Material.SUGAR.ordinal()] = 352;
         } catch (NoSuchFieldError var43) {
         }

         try {
            var0[Material.SUGAR_CANE.ordinal()] = 337;
         } catch (NoSuchFieldError var42) {
         }

         try {
            var0[Material.SUGAR_CANE_BLOCK.ordinal()] = 84;
         } catch (NoSuchFieldError var41) {
         }

         try {
            var0[Material.SULPHUR.ordinal()] = 288;
         } catch (NoSuchFieldError var40) {
         }

         try {
            var0[Material.THIN_GLASS.ordinal()] = 103;
         } catch (NoSuchFieldError var39) {
         }

         try {
            var0[Material.TIPPED_ARROW.ordinal()] = 439;
         } catch (NoSuchFieldError var38) {
         }

         try {
            var0[Material.TNT.ordinal()] = 47;
         } catch (NoSuchFieldError var37) {
         }

         try {
            var0[Material.TORCH.ordinal()] = 51;
         } catch (NoSuchFieldError var36) {
         }

         try {
            var0[Material.TOTEM.ordinal()] = 448;
         } catch (NoSuchFieldError var35) {
         }

         try {
            var0[Material.TRAPPED_CHEST.ordinal()] = 147;
         } catch (NoSuchFieldError var34) {
         }

         try {
            var0[Material.TRAP_DOOR.ordinal()] = 97;
         } catch (NoSuchFieldError var33) {
         }

         try {
            var0[Material.TRIPWIRE.ordinal()] = 133;
         } catch (NoSuchFieldError var32) {
         }

         try {
            var0[Material.TRIPWIRE_HOOK.ordinal()] = 132;
         } catch (NoSuchFieldError var31) {
         }

         try {
            var0[Material.VINE.ordinal()] = 107;
         } catch (NoSuchFieldError var30) {
         }

         try {
            var0[Material.WALL_BANNER.ordinal()] = 178;
         } catch (NoSuchFieldError var29) {
         }

         try {
            var0[Material.WALL_SIGN.ordinal()] = 69;
         } catch (NoSuchFieldError var28) {
         }

         try {
            var0[Material.WATCH.ordinal()] = 346;
         } catch (NoSuchFieldError var27) {
         }

         try {
            var0[Material.WATER.ordinal()] = 9;
         } catch (NoSuchFieldError var26) {
         }

         try {
            var0[Material.WATER_BUCKET.ordinal()] = 325;
         } catch (NoSuchFieldError var25) {
         }

         try {
            var0[Material.WATER_LILY.ordinal()] = 112;
         } catch (NoSuchFieldError var24) {
         }

         try {
            var0[Material.WEB.ordinal()] = 31;
         } catch (NoSuchFieldError var23) {
         }

         try {
            var0[Material.WHEAT.ordinal()] = 295;
         } catch (NoSuchFieldError var22) {
         }

         try {
            var0[Material.WHITE_GLAZED_TERRACOTTA.ordinal()] = 236;
         } catch (NoSuchFieldError var21) {
         }

         try {
            var0[Material.WHITE_SHULKER_BOX.ordinal()] = 220;
         } catch (NoSuchFieldError var20) {
         }

         try {
            var0[Material.WOOD.ordinal()] = 6;
         } catch (NoSuchFieldError var19) {
         }

         try {
            var0[Material.WOODEN_DOOR.ordinal()] = 65;
         } catch (NoSuchFieldError var18) {
         }

         try {
            var0[Material.WOOD_AXE.ordinal()] = 270;
         } catch (NoSuchFieldError var17) {
         }

         try {
            var0[Material.WOOD_BUTTON.ordinal()] = 144;
         } catch (NoSuchFieldError var16) {
         }

         try {
            var0[Material.WOOD_DOOR.ordinal()] = 323;
         } catch (NoSuchFieldError var15) {
         }

         try {
            var0[Material.WOOD_DOUBLE_STEP.ordinal()] = 126;
         } catch (NoSuchFieldError var14) {
         }

         try {
            var0[Material.WOOD_HOE.ordinal()] = 289;
         } catch (NoSuchFieldError var13) {
         }

         try {
            var0[Material.WOOD_PICKAXE.ordinal()] = 269;
         } catch (NoSuchFieldError var12) {
         }

         try {
            var0[Material.WOOD_PLATE.ordinal()] = 73;
         } catch (NoSuchFieldError var11) {
         }

         try {
            var0[Material.WOOD_SPADE.ordinal()] = 268;
         } catch (NoSuchFieldError var10) {
         }

         try {
            var0[Material.WOOD_STAIRS.ordinal()] = 54;
         } catch (NoSuchFieldError var9) {
         }

         try {
            var0[Material.WOOD_STEP.ordinal()] = 127;
         } catch (NoSuchFieldError var8) {
         }

         try {
            var0[Material.WOOD_SWORD.ordinal()] = 267;
         } catch (NoSuchFieldError var7) {
         }

         try {
            var0[Material.WOOL.ordinal()] = 36;
         } catch (NoSuchFieldError var6) {
         }

         try {
            var0[Material.WORKBENCH.ordinal()] = 59;
         } catch (NoSuchFieldError var5) {
         }

         try {
            var0[Material.WRITTEN_BOOK.ordinal()] = 386;
         } catch (NoSuchFieldError var4) {
         }

         try {
            var0[Material.YELLOW_FLOWER.ordinal()] = 38;
         } catch (NoSuchFieldError var3) {
         }

         try {
            var0[Material.YELLOW_GLAZED_TERRACOTTA.ordinal()] = 240;
         } catch (NoSuchFieldError var2) {
         }

         try {
            var0[Material.YELLOW_SHULKER_BOX.ordinal()] = 224;
         } catch (NoSuchFieldError var1) {
         }

         $SWITCH_TABLE$org$bukkit$Material = var0;
         return var0;
      }
   }

   // $FF: synthetic method
   static int[] $SWITCH_TABLE$su$nightexpress$divineitems$attributes$ItemStat() {
      int[] var10000 = $SWITCH_TABLE$su$nightexpress$divineitems$attributes$ItemStat;
      if (var10000 != null) {
         return var10000;
      } else {
         int[] var0 = new int[ItemStat.values().length];

         try {
            var0[ItemStat.ACCURACY_RATE.ordinal()] = 6;
         } catch (NoSuchFieldError var24) {
         }

         try {
            var0[ItemStat.AOE_DAMAGE.ordinal()] = 2;
         } catch (NoSuchFieldError var23) {
         }

         try {
            var0[ItemStat.ATTACK_SPEED.ordinal()] = 19;
         } catch (NoSuchFieldError var22) {
         }

         try {
            var0[ItemStat.BLEED_RATE.ordinal()] = 22;
         } catch (NoSuchFieldError var21) {
         }

         try {
            var0[ItemStat.BLOCK_DAMAGE.ordinal()] = 8;
         } catch (NoSuchFieldError var20) {
         }

         try {
            var0[ItemStat.BLOCK_RATE.ordinal()] = 7;
         } catch (NoSuchFieldError var19) {
         }

         try {
            var0[ItemStat.BURN_RATE.ordinal()] = 10;
         } catch (NoSuchFieldError var18) {
         }

         try {
            var0[ItemStat.CRITICAL_DAMAGE.ordinal()] = 14;
         } catch (NoSuchFieldError var17) {
         }

         try {
            var0[ItemStat.CRITICAL_RATE.ordinal()] = 13;
         } catch (NoSuchFieldError var16) {
         }

         try {
            var0[ItemStat.DIRECT_DAMAGE.ordinal()] = 1;
         } catch (NoSuchFieldError var15) {
         }

         try {
            var0[ItemStat.DISARM_RATE.ordinal()] = 23;
         } catch (NoSuchFieldError var14) {
         }

         try {
            var0[ItemStat.DODGE_RATE.ordinal()] = 5;
         } catch (NoSuchFieldError var13) {
         }

         try {
            var0[ItemStat.DURABILITY.ordinal()] = 15;
         } catch (NoSuchFieldError var12) {
         }

         try {
            var0[ItemStat.DURABILITY_UNBREAK.ordinal()] = 16;
         } catch (NoSuchFieldError var11) {
         }

         try {
            var0[ItemStat.LOOT_RATE.ordinal()] = 9;
         } catch (NoSuchFieldError var10) {
         }

         try {
            var0[ItemStat.MAX_HEALTH.ordinal()] = 21;
         } catch (NoSuchFieldError var9) {
         }

         try {
            var0[ItemStat.MOVEMENT_SPEED.ordinal()] = 17;
         } catch (NoSuchFieldError var8) {
         }

         try {
            var0[ItemStat.PENETRATION.ordinal()] = 18;
         } catch (NoSuchFieldError var7) {
         }

         try {
            var0[ItemStat.PVE_DAMAGE.ordinal()] = 4;
         } catch (NoSuchFieldError var6) {
         }

         try {
            var0[ItemStat.PVE_DEFENSE.ordinal()] = 12;
         } catch (NoSuchFieldError var5) {
         }

         try {
            var0[ItemStat.PVP_DAMAGE.ordinal()] = 3;
         } catch (NoSuchFieldError var4) {
         }

         try {
            var0[ItemStat.PVP_DEFENSE.ordinal()] = 11;
         } catch (NoSuchFieldError var3) {
         }

         try {
            var0[ItemStat.RANGE.ordinal()] = 24;
         } catch (NoSuchFieldError var2) {
         }

         try {
            var0[ItemStat.VAMPIRISM.ordinal()] = 20;
         } catch (NoSuchFieldError var1) {
         }

         $SWITCH_TABLE$su$nightexpress$divineitems$attributes$ItemStat = var0;
         return var0;
      }
   }
}
