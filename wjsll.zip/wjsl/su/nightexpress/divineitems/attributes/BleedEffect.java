package su.nightexpress.divineitems.attributes;

public class BleedEffect {
   private int time;
   private double dmg;

   public BleedEffect(int var1, double var2) {
      this.setTime(var1);
      this.setDamage(var2);
   }

   public int getTime() {
      return this.time;
   }

   public void setTime(int var1) {
      this.time = var1;
   }

   public double getDamage() {
      return this.dmg;
   }

   public void setDamage(double var1) {
      this.dmg = var1;
   }
}
