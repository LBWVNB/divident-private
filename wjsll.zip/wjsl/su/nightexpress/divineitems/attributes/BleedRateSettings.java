package su.nightexpress.divineitems.attributes;

public class BleedRateSettings extends StatSettings {
   private int time;
   private String formula;
   private String effect;

   public BleedRateSettings(ItemStat var1, int var2, String var3, String var4) {
      super(var1);
      this.setTime(var2);
      this.setFormula(var3);
      this.setEffect(var4);
   }

   public int getTime() {
      return this.time;
   }

   public void setTime(int var1) {
      this.time = var1;
   }

   public String getFormula() {
      return this.formula;
   }

   public void setFormula(String var1) {
      this.formula = var1;
   }

   public String getEffect() {
      return this.effect;
   }

   public void setEffect(String var1) {
      this.effect = var1;
   }
}
