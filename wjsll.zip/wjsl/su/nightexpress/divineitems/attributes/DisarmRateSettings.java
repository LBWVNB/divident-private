package su.nightexpress.divineitems.attributes;

public class DisarmRateSettings extends StatSettings {
   private String effect;
   private String msg_dam;
   private String msg_zertva;

   public DisarmRateSettings(ItemStat var1, String var2, String var3, String var4) {
      super(var1);
      this.effect = var2;
      this.msg_dam = var3;
      this.msg_zertva = var4;
   }

   public String getEffect() {
      return this.effect;
   }

   public String getMsgToDamager() {
      return this.msg_dam;
   }

   public String getMsgToEntity() {
      return this.msg_zertva;
   }
}
