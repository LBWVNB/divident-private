package su.nightexpress.divineitems.attributes;

import net.md_5.bungee.api.ChatColor;

public enum ItemStat {
   DIRECT_DAMAGE("Direct Damage", "&f▸", "&f", "&6⏏&f", 100.0D, ItemStat.ItemType.WEAPON, true, false, (StatSettings)null),
   AOE_DAMAGE("AoE Damage", "&3▸", "&f", "&6⏏&f", -1.0D, ItemStat.ItemType.WEAPON, true, false, (StatSettings)null),
   PVP_DAMAGE("PvP Damage", "&b▸", "&f", "&6⏏&f", -1.0D, ItemStat.ItemType.WEAPON, true, true, (StatSettings)null),
   PVE_DAMAGE("PvE Damage", "&b▸", "&f", "&6⏏&f", -1.0D, ItemStat.ItemType.WEAPON, true, true, (StatSettings)null),
   DODGE_RATE("Dodge Rate", "&6▸", "&f", "&6⏏&f", -1.0D, ItemStat.ItemType.ARMOR, true, true, (StatSettings)null),
   ACCURACY_RATE("Accuracy Rate", "&6▸", "&f", "&6⏏&f", -1.0D, ItemStat.ItemType.WEAPON, true, true, (StatSettings)null),
   BLOCK_RATE("Block Rate", "&6▸", "&f", "&6⏏&f", -1.0D, ItemStat.ItemType.ARMOR, true, true, (StatSettings)null),
   BLOCK_DAMAGE("Block Damage", "&6▸", "&f", "&6⏏&f", -1.0D, ItemStat.ItemType.ARMOR, true, true, (StatSettings)null),
   LOOT_RATE("Loot Rate", "&e▸", "&f", "&6⏏&f", 250.0D, ItemStat.ItemType.BOTH, true, true, (StatSettings)null),
   BURN_RATE("Chance to Burn", "&c▸", "&f", "&6⏏&f", 100.0D, ItemStat.ItemType.WEAPON, true, false, (StatSettings)null),
   PVP_DEFENSE("PvP Defense", "&b▸", "&f", "&6⏏&f", -1.0D, ItemStat.ItemType.ARMOR, true, true, (StatSettings)null),
   PVE_DEFENSE("PvE Defense", "&b▸", "&f", "&6⏏&f", -1.0D, ItemStat.ItemType.ARMOR, true, true, (StatSettings)null),
   CRITICAL_RATE("Critical Rate", "&e▸", "&f", "&6⏏&f", 75.0D, ItemStat.ItemType.WEAPON, true, true, (StatSettings)null),
   CRITICAL_DAMAGE("Critical Damage", "&e▸", "&f", "&6⏏&f", 3.0D, ItemStat.ItemType.WEAPON, false, false, (StatSettings)null),
   DURABILITY("Durability", "&f▸", "&f", "&6⏏&f", -1.0D, ItemStat.ItemType.BOTH, false, false, (StatSettings)null),
   DURABILITY_UNBREAK("Unbreakable", "&f▸", "&f", "&6⏏&f", -1.0D, ItemStat.ItemType.BOTH, false, false, (StatSettings)null),
   MOVEMENT_SPEED("Movement speed", "&3▸", "&f", "&6⏏&f", -1.0D, ItemStat.ItemType.BOTH, true, true, (StatSettings)null),
   PENETRATION("Armor Penetration", "&c▸", "&f", "&6⏏&f", 45.0D, ItemStat.ItemType.WEAPON, true, true, (StatSettings)null),
   ATTACK_SPEED("Attack Speed", "&3▸", "&f", "&6⏏&f", -1.0D, ItemStat.ItemType.WEAPON, true, true, (StatSettings)null),
   VAMPIRISM("Vampirism", "&c▸", "&f", "&6⏏&f", 45.0D, ItemStat.ItemType.WEAPON, true, true, (StatSettings)null),
   MAX_HEALTH("Max Health", "&3▸", "&f", "&6⏏&f", 30.0D, ItemStat.ItemType.BOTH, false, true, (StatSettings)null),
   BLEED_RATE("Chance to Open Wounds", "&c▸", "&f", "&6⏏&f", 75.0D, ItemStat.ItemType.WEAPON, true, true, (StatSettings)null),
   DISARM_RATE("Chance to Disarm", "&c▸", "&f", "&6⏏&f", 25.0D, ItemStat.ItemType.WEAPON, true, true, (StatSettings)null),
   RANGE("Range", "&6▸", "&f", "&6⏏&f", 7.0D, ItemStat.ItemType.WEAPON, false, false, (StatSettings)null);

   private String name;
   private String prefix;
   private String value;
   private String bonus;
   private double cap;
   private ItemStat.ItemType type;
   private boolean p;
   private boolean plus;
   private StatSettings settings;

   private ItemStat(String var3, String var4, String var5, String var6, double var7, ItemStat.ItemType var9, boolean var10, boolean var11, StatSettings var12) {
      this.name = var3;
      this.prefix = var4;
      this.value = var5;
      this.bonus = var6;
      this.cap = var7;
      this.type = var9;
      this.p = var10;
      this.plus = var11;
      this.settings = var12;
   }

   public String getName() {
      return ChatColor.translateAlternateColorCodes('&', this.name);
   }

   public void setName(String var1) {
      this.name = var1;
   }

   public String getPrefix() {
      return ChatColor.translateAlternateColorCodes('&', this.prefix);
   }

   public void setPrefix(String var1) {
      this.prefix = var1;
   }

   public String getValue() {
      return ChatColor.translateAlternateColorCodes('&', this.value);
   }

   public void setValue(String var1) {
      this.value = var1;
   }

   public String getBonus() {
      return ChatColor.translateAlternateColorCodes('&', this.bonus);
   }

   public void setBonus(String var1) {
      this.bonus = var1;
   }

   public double getCapability() {
      return this.cap;
   }

   public void setCapability(double var1) {
      this.cap = var1;
   }

   public ItemStat.ItemType getType() {
      return this.type;
   }

   public void setType(ItemStat.ItemType var1) {
      this.type = var1;
   }

   public boolean isPercent() {
      return this.p;
   }

   public boolean isPlus() {
      return this.plus;
   }

   public StatSettings getSettings() {
      return this.settings;
   }

   public void setSettings(StatSettings var1) {
      this.settings = var1;
   }

   public static enum ItemType {
      ARMOR,
      WEAPON,
      BOTH;
   }
}
