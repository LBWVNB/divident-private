package su.nightexpress.divineitems.attributes;

public class StatSettings {
   private ItemStat att;

   public StatSettings(ItemStat var1) {
      this.att = var1;
   }

   public ItemStat getAttribute() {
      return this.att;
   }
}
