package su.nightexpress.divineitems.cmds;

import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import su.nightexpress.divineitems.config.Lang;

public abstract class CommandBase {
   private boolean isPlayer;

   public final void execute(CommandSender var1, String[] var2) {
      this.isPlayer = var1 instanceof Player;
      if (!this.playersOnly() || this.isPlayer) {
         if (this.getPermission() != null && !var1.hasPermission(this.getPermission())) {
            var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_NoPerm.toMsg());
         } else {
            this.perform(var1, var2);
         }
      }
   }

   boolean isPlayer() {
      return this.isPlayer;
   }

   public abstract void perform(CommandSender var1, String[] var2);

   public abstract String getPermission();

   public abstract boolean playersOnly();
}
