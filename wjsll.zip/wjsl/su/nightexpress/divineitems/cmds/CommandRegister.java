package su.nightexpress.divineitems.cmds;

import java.lang.reflect.Field;
import java.util.Arrays;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandMap;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginIdentifiableCommand;
import org.bukkit.plugin.Plugin;

public class CommandRegister extends Command implements PluginIdentifiableCommand {
   protected Plugin plugin;
   protected final CommandExecutor owner;
   protected final Object registeredWith;

   public CommandRegister(String[] var1, String var2, String var3, CommandExecutor var4, Object var5, Plugin var6) {
      super(var1[0], var2, var3, Arrays.asList(var1));
      this.owner = var4;
      this.plugin = var6;
      this.registeredWith = var5;
   }

   public Plugin getPlugin() {
      return this.plugin;
   }

   public boolean execute(CommandSender var1, String var2, String[] var3) {
      return this.owner.onCommand(var1, this, var2, var3);
   }

   public Object getRegisteredWith() {
      return this.registeredWith;
   }

   public static void reg(Plugin var0, CommandExecutor var1, String[] var2, String var3, String var4) {
      try {
         CommandRegister var5 = new CommandRegister(var2, var3, var4, var1, new Object(), var0);
         Field var6 = Bukkit.getServer().getClass().getDeclaredField("commandMap");
         var6.setAccessible(true);
         CommandMap var7 = (CommandMap)var6.get(Bukkit.getServer());
         var7.register(var0.getDescription().getName(), var5);
      } catch (Exception var8) {
         var8.printStackTrace();
      }

   }
}
