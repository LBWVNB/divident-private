package su.nightexpress.divineitems.cmds;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;
import su.nightexpress.divineitems.DivineItems;
import su.nightexpress.divineitems.attributes.ItemStat;
import su.nightexpress.divineitems.cmds.list.HelpCommand;
import su.nightexpress.divineitems.cmds.list.InfoCommand;
import su.nightexpress.divineitems.cmds.list.ModifyCommand;
import su.nightexpress.divineitems.cmds.list.ReloadCommand;
import su.nightexpress.divineitems.cmds.list.SetCommand;
import su.nightexpress.divineitems.modules.sets.SetManager;
import su.nightexpress.divineitems.utils.Utils;

public class MainCommand implements CommandExecutor, TabExecutor {
   private DivineItems plugin;
   private Map<String, CommandBase> commands = new HashMap();
   private HelpCommand help;

   public MainCommand(DivineItems var1) {
      this.plugin = var1;
      this.help = new HelpCommand();
      this.commands.put("set", new SetCommand(var1));
      this.commands.put("modify", new ModifyCommand());
      this.commands.put("reload", new ReloadCommand(var1));
      this.commands.put("info", new InfoCommand(var1));
   }

   public void registerCmd(String var1, CommandBase var2) {
      this.commands.put(var1, var2);
   }

   public void unregisterCmd(String var1) {
      this.commands.remove(var1);
   }

   public boolean onCommand(CommandSender var1, Command var2, String var3, String[] var4) {
      Object var5 = this.help;
      if (var4.length > 0 && this.commands.containsKey(var4[0])) {
         var5 = (CommandBase)this.commands.get(var4[0]);
      }

      ((CommandBase)var5).execute(var1, var4);
      return true;
   }

   public List<String> onTabComplete(CommandSender var1, Command var2, String var3, String[] var4) {
      if (!(var1 instanceof Player)) {
         return null;
      } else if (var4.length == 1) {
         List var6 = this.plugin.getMM().getModuleLabels();
         var6.add("help");
         var6.add("info");
         var6.add("modify");
         var6.add("reload");
         var6.add("set");
         var6.remove("itemhints");
         var6.remove("combatlog");
         return var6;
      } else {
         Player var5 = (Player)var1;
         if (var4.length > 1) {
            if (var4[0].equalsIgnoreCase("gems")) {
               if (var4.length == 2) {
                  return Arrays.asList("list", "get", "give", "drop");
               }

               if (var4.length == 3) {
                  if (var4[1].equalsIgnoreCase("drop")) {
                     return Utils.getWorldNames();
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return this.plugin.getMM().getGemManager().getGemNames();
                  }

                  if (var4[1].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               } else if (var4.length == 4) {
                  if (var4[1].equalsIgnoreCase("drop")) {
                     return Arrays.asList(String.valueOf(Utils.round3(var5.getLocation().getX())));
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return Arrays.asList("1");
                  }

                  if (var4[1].equalsIgnoreCase("give")) {
                     return this.plugin.getMM().getGemManager().getGemNames();
                  }

                  if (var4[1].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               } else if (var4.length == 5) {
                  if (var4[1].equalsIgnoreCase("drop")) {
                     return Arrays.asList(String.valueOf(Utils.round3(var5.getLocation().getY())));
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return Arrays.asList("1");
                  }

                  if (var4[1].equalsIgnoreCase("give")) {
                     return Arrays.asList("1");
                  }

                  if (var4[1].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               } else if (var4.length == 6) {
                  if (var4[1].equalsIgnoreCase("drop")) {
                     return Arrays.asList(String.valueOf(Utils.round3(var5.getLocation().getZ())));
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("give")) {
                     return Arrays.asList("1");
                  }

                  if (var4[1].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               } else if (var4.length == 7) {
                  if (var4[1].equalsIgnoreCase("drop")) {
                     return this.plugin.getMM().getGemManager().getGemNames();
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("give")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               } else if (var4.length == 8) {
                  if (var4[1].equalsIgnoreCase("drop")) {
                     return Arrays.asList("1");
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("give")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               } else {
                  if (var4.length != 9) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("drop")) {
                     return Arrays.asList("1");
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("give")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               }
            } else if (var4[0].equalsIgnoreCase("abilities")) {
               if (var4.length == 2) {
                  return Arrays.asList("list", "get", "give", "drop");
               }

               if (var4.length == 3) {
                  if (var4[1].equalsIgnoreCase("drop")) {
                     return Utils.getWorldNames();
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return this.plugin.getMM().getAbilityManager().getAbilityNames();
                  }

                  if (var4[1].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               } else if (var4.length == 4) {
                  if (var4[1].equalsIgnoreCase("drop")) {
                     return Arrays.asList(String.valueOf(Utils.round3(var5.getLocation().getX())));
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return Arrays.asList("1");
                  }

                  if (var4[1].equalsIgnoreCase("give")) {
                     return this.plugin.getMM().getAbilityManager().getAbilityNames();
                  }

                  if (var4[1].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               } else if (var4.length == 5) {
                  if (var4[1].equalsIgnoreCase("drop")) {
                     return Arrays.asList(String.valueOf(Utils.round3(var5.getLocation().getY())));
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return Arrays.asList("1");
                  }

                  if (var4[1].equalsIgnoreCase("give")) {
                     return Arrays.asList("1");
                  }

                  if (var4[1].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               } else if (var4.length == 6) {
                  if (var4[1].equalsIgnoreCase("drop")) {
                     return Arrays.asList(String.valueOf(Utils.round3(var5.getLocation().getZ())));
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("give")) {
                     return Arrays.asList("1");
                  }

                  if (var4[1].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               } else if (var4.length == 7) {
                  if (var4[1].equalsIgnoreCase("drop")) {
                     return this.plugin.getMM().getAbilityManager().getAbilityNames();
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("give")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               } else if (var4.length == 8) {
                  if (var4[1].equalsIgnoreCase("drop")) {
                     return Arrays.asList("1");
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("give")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               } else {
                  if (var4.length != 9) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("drop")) {
                     return Arrays.asList("1");
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("give")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               }
            } else if (var4[0].equalsIgnoreCase("abyssdust")) {
               if (var4.length == 2) {
                  return Arrays.asList("list", "get", "give", "drop");
               }

               if (var4.length == 3) {
                  if (var4[1].equalsIgnoreCase("drop")) {
                     return Utils.getWorldNames();
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return this.plugin.getMM().getAbyssDustManager().getDustNames();
                  }

                  if (var4[1].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               } else if (var4.length == 4) {
                  if (var4[1].equalsIgnoreCase("drop")) {
                     return Arrays.asList(String.valueOf(Utils.round3(var5.getLocation().getX())));
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return Arrays.asList("1");
                  }

                  if (var4[1].equalsIgnoreCase("give")) {
                     return this.plugin.getMM().getAbyssDustManager().getDustNames();
                  }

                  if (var4[1].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               } else if (var4.length == 5) {
                  if (var4[1].equalsIgnoreCase("drop")) {
                     return Arrays.asList(String.valueOf(Utils.round3(var5.getLocation().getY())));
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("give")) {
                     return Arrays.asList("1");
                  }

                  if (var4[1].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               } else if (var4.length == 6) {
                  if (var4[1].equalsIgnoreCase("drop")) {
                     return Arrays.asList(String.valueOf(Utils.round3(var5.getLocation().getZ())));
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("give")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               } else if (var4.length == 7) {
                  if (var4[1].equalsIgnoreCase("drop")) {
                     return this.plugin.getMM().getAbyssDustManager().getDustNames();
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("give")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               } else {
                  if (var4.length != 8) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("drop")) {
                     return Arrays.asList("1");
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("give")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               }
            } else if (var4[0].equalsIgnoreCase("arrows")) {
               if (var4.length == 2) {
                  return Arrays.asList("list", "get", "give", "drop");
               }

               if (var4.length == 3) {
                  if (var4[1].equalsIgnoreCase("drop")) {
                     return Utils.getWorldNames();
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return this.plugin.getMM().getArrowManager().getArrowNames();
                  }

                  if (var4[1].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               } else if (var4.length == 4) {
                  if (var4[1].equalsIgnoreCase("drop")) {
                     return Arrays.asList(String.valueOf(Utils.round3(var5.getLocation().getX())));
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return Arrays.asList("1");
                  }

                  if (var4[1].equalsIgnoreCase("give")) {
                     return this.plugin.getMM().getArrowManager().getArrowNames();
                  }

                  if (var4[1].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               } else if (var4.length == 5) {
                  if (var4[1].equalsIgnoreCase("drop")) {
                     return Arrays.asList(String.valueOf(Utils.round3(var5.getLocation().getY())));
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("give")) {
                     return Arrays.asList("1");
                  }

                  if (var4[1].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               } else if (var4.length == 6) {
                  if (var4[1].equalsIgnoreCase("drop")) {
                     return Arrays.asList(String.valueOf(Utils.round3(var5.getLocation().getZ())));
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("give")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               } else if (var4.length == 7) {
                  if (var4[1].equalsIgnoreCase("drop")) {
                     return this.plugin.getMM().getArrowManager().getArrowNames();
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("give")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               } else {
                  if (var4.length != 8) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("drop")) {
                     return Arrays.asList("1");
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("give")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               }
            } else if (var4[0].equalsIgnoreCase("buffs")) {
               if (var4.length == 2) {
                  return Arrays.asList("add", "reset", "resetall");
               }

               if (var4.length == 4) {
                  if (var4[1].equalsIgnoreCase("add")) {
                     return Utils.getEnumsList(ItemStat.class);
                  }

                  if (var4[1].equalsIgnoreCase("reset")) {
                     return Utils.getEnumsList(ItemStat.class);
                  }
               } else if (var4.length == 5) {
                  if (var4[1].equalsIgnoreCase("add")) {
                     return Arrays.asList("50");
                  }

                  if (var4[1].equalsIgnoreCase("reset")) {
                     return Arrays.asList("");
                  }
               } else if (var4.length == 6) {
                  if (var4[1].equalsIgnoreCase("add")) {
                     return Arrays.asList("60");
                  }

                  if (var4[1].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               } else if (var4.length > 6) {
                  return Arrays.asList("");
               }
            } else if (var4[0].equalsIgnoreCase("consumables")) {
               if (var4.length == 2) {
                  return Arrays.asList("list", "get", "give", "drop");
               }

               if (var4.length == 3) {
                  if (var4[1].equalsIgnoreCase("drop")) {
                     return Utils.getWorldNames();
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return this.plugin.getMM().getConsumeManager().getConsumeNames();
                  }

                  if (var4[1].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               } else if (var4.length == 4) {
                  if (var4[1].equalsIgnoreCase("drop")) {
                     return Arrays.asList(String.valueOf(Utils.round3(var5.getLocation().getX())));
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return Arrays.asList("1");
                  }

                  if (var4[1].equalsIgnoreCase("give")) {
                     return this.plugin.getMM().getConsumeManager().getConsumeNames();
                  }

                  if (var4[1].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               } else if (var4.length == 5) {
                  if (var4[1].equalsIgnoreCase("drop")) {
                     return Arrays.asList(String.valueOf(Utils.round3(var5.getLocation().getY())));
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("give")) {
                     return Arrays.asList("1");
                  }

                  if (var4[1].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               } else if (var4.length == 6) {
                  if (var4[1].equalsIgnoreCase("drop")) {
                     return Arrays.asList(String.valueOf(Utils.round3(var5.getLocation().getZ())));
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("give")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               } else if (var4.length == 7) {
                  if (var4[1].equalsIgnoreCase("drop")) {
                     return this.plugin.getMM().getConsumeManager().getConsumeNames();
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("give")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               } else {
                  if (var4.length != 8) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("drop")) {
                     return Arrays.asList("1");
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("give")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               }
            } else if (var4[0].equalsIgnoreCase("enchants")) {
               if (var4.length == 2) {
                  return Arrays.asList("list", "get", "give", "drop");
               }

               if (var4.length == 3) {
                  if (var4[1].equalsIgnoreCase("drop")) {
                     return Utils.getWorldNames();
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return this.plugin.getMM().getEnchantManager().getEnchantNames();
                  }

                  if (var4[1].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               } else if (var4.length == 4) {
                  if (var4[1].equalsIgnoreCase("drop")) {
                     return Arrays.asList(String.valueOf(Utils.round3(var5.getLocation().getX())));
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return Arrays.asList("1");
                  }

                  if (var4[1].equalsIgnoreCase("give")) {
                     return this.plugin.getMM().getEnchantManager().getEnchantNames();
                  }

                  if (var4[1].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               } else if (var4.length == 5) {
                  if (var4[1].equalsIgnoreCase("drop")) {
                     return Arrays.asList(String.valueOf(Utils.round3(var5.getLocation().getY())));
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return Arrays.asList("1");
                  }

                  if (var4[1].equalsIgnoreCase("give")) {
                     return Arrays.asList("1");
                  }

                  if (var4[1].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               } else if (var4.length == 6) {
                  if (var4[1].equalsIgnoreCase("drop")) {
                     return Arrays.asList(String.valueOf(Utils.round3(var5.getLocation().getZ())));
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("give")) {
                     return Arrays.asList("1");
                  }

                  if (var4[1].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               } else if (var4.length == 7) {
                  if (var4[1].equalsIgnoreCase("drop")) {
                     return this.plugin.getMM().getEnchantManager().getEnchantNames();
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("give")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               } else if (var4.length == 8) {
                  if (var4[1].equalsIgnoreCase("drop")) {
                     return Arrays.asList("1");
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("give")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               } else {
                  if (var4.length != 9) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("drop")) {
                     return Arrays.asList("1");
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("give")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               }
            } else if (var4[0].equalsIgnoreCase("identify")) {
               if (var4.length == 2) {
                  return Arrays.asList("item", "tome", "force");
               }

               if (var4.length == 3) {
                  return Arrays.asList("list", "get", "give", "drop");
               }

               if (var4.length == 4) {
                  if (var4[2].equalsIgnoreCase("drop")) {
                     return Utils.getWorldNames();
                  }

                  if (var4[2].equalsIgnoreCase("get")) {
                     if (var4[1].equalsIgnoreCase("item")) {
                        return this.plugin.getMM().getIdentifyManager().getUINames();
                     }

                     if (var4[1].equalsIgnoreCase("tome")) {
                        return this.plugin.getMM().getIdentifyManager().getTomeNames();
                     }
                  } else if (var4[2].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               } else if (var4.length == 5) {
                  if (var4[2].equalsIgnoreCase("drop")) {
                     return Arrays.asList(String.valueOf(Utils.round3(var5.getLocation().getX())));
                  }

                  if (var4[2].equalsIgnoreCase("get")) {
                     return Arrays.asList("1");
                  }

                  if (var4[2].equalsIgnoreCase("give")) {
                     if (var4[1].equalsIgnoreCase("item")) {
                        return this.plugin.getMM().getIdentifyManager().getUINames();
                     }

                     if (var4[1].equalsIgnoreCase("tome")) {
                        return this.plugin.getMM().getIdentifyManager().getTomeNames();
                     }
                  } else if (var4[2].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               } else if (var4.length == 6) {
                  if (var4[2].equalsIgnoreCase("drop")) {
                     return Arrays.asList(String.valueOf(Utils.round3(var5.getLocation().getY())));
                  }

                  if (var4[2].equalsIgnoreCase("get")) {
                     return Arrays.asList("1");
                  }

                  if (var4[2].equalsIgnoreCase("give")) {
                     return Arrays.asList("1");
                  }

                  if (var4[2].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               } else if (var4.length == 7) {
                  if (var4[2].equalsIgnoreCase("drop")) {
                     return Arrays.asList(String.valueOf(Utils.round3(var5.getLocation().getZ())));
                  }

                  if (var4[2].equalsIgnoreCase("get")) {
                     return Arrays.asList("");
                  }

                  if (var4[2].equalsIgnoreCase("give")) {
                     return Arrays.asList("1");
                  }

                  if (var4[2].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               } else if (var4.length == 8) {
                  if (var4[2].equalsIgnoreCase("drop")) {
                     if (var4[1].equalsIgnoreCase("item")) {
                        return this.plugin.getMM().getIdentifyManager().getUINames();
                     }

                     if (var4[1].equalsIgnoreCase("tome")) {
                        return this.plugin.getMM().getIdentifyManager().getTomeNames();
                     }
                  } else {
                     if (var4[2].equalsIgnoreCase("get")) {
                        return Arrays.asList("");
                     }

                     if (var4[2].equalsIgnoreCase("give")) {
                        return Arrays.asList("");
                     }

                     if (var4[2].equalsIgnoreCase("list")) {
                        return Arrays.asList("");
                     }
                  }
               } else if (var4.length == 9) {
                  if (var4[2].equalsIgnoreCase("drop")) {
                     return Arrays.asList("1");
                  }

                  if (var4[2].equalsIgnoreCase("get")) {
                     return Arrays.asList("");
                  }

                  if (var4[2].equalsIgnoreCase("give")) {
                     return Arrays.asList("");
                  }

                  if (var4[2].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               } else {
                  if (var4.length != 10) {
                     return Arrays.asList("");
                  }

                  if (var4[2].equalsIgnoreCase("drop")) {
                     return Arrays.asList("1");
                  }

                  if (var4[2].equalsIgnoreCase("get")) {
                     return Arrays.asList("");
                  }

                  if (var4[2].equalsIgnoreCase("give")) {
                     return Arrays.asList("");
                  }

                  if (var4[2].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               }
            } else if (var4[0].equalsIgnoreCase("magicdust")) {
               if (var4.length == 2) {
                  return Arrays.asList("list", "get", "give", "drop");
               }

               if (var4.length == 3) {
                  if (var4[1].equalsIgnoreCase("drop")) {
                     return Utils.getWorldNames();
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return this.plugin.getMM().getMagicDustManager().getDustNames();
                  }

                  if (var4[1].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               } else if (var4.length == 4) {
                  if (var4[1].equalsIgnoreCase("drop")) {
                     return Arrays.asList(String.valueOf(Utils.round3(var5.getLocation().getX())));
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return Arrays.asList("1");
                  }

                  if (var4[1].equalsIgnoreCase("give")) {
                     return this.plugin.getMM().getMagicDustManager().getDustNames();
                  }

                  if (var4[1].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               } else if (var4.length == 5) {
                  if (var4[1].equalsIgnoreCase("drop")) {
                     return Arrays.asList(String.valueOf(Utils.round3(var5.getLocation().getY())));
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return Arrays.asList("1");
                  }

                  if (var4[1].equalsIgnoreCase("give")) {
                     return Arrays.asList("1");
                  }

                  if (var4[1].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               } else if (var4.length == 6) {
                  if (var4[1].equalsIgnoreCase("drop")) {
                     return Arrays.asList(String.valueOf(Utils.round3(var5.getLocation().getZ())));
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("give")) {
                     return Arrays.asList("1");
                  }

                  if (var4[1].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               } else if (var4.length == 7) {
                  if (var4[1].equalsIgnoreCase("drop")) {
                     return this.plugin.getMM().getMagicDustManager().getDustNames();
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("give")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               } else if (var4.length == 8) {
                  if (var4[1].equalsIgnoreCase("drop")) {
                     return Arrays.asList("1");
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("give")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               } else {
                  if (var4.length != 9) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("drop")) {
                     return Arrays.asList("1");
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("give")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               }
            } else if (var4[0].equalsIgnoreCase("repair")) {
               if (var4.length == 2) {
                  return Arrays.asList("item", "get", "give", "drop");
               }

               if (var4.length == 3) {
                  if (var4[1].equalsIgnoreCase("drop")) {
                     return Utils.getWorldNames();
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return Arrays.asList("1");
                  }

                  if (var4[1].equalsIgnoreCase("item")) {
                     return Arrays.asList("99999");
                  }
               } else if (var4.length == 4) {
                  if (var4[1].equalsIgnoreCase("drop")) {
                     return Arrays.asList(String.valueOf(Utils.round3(var5.getLocation().getX())));
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return Arrays.asList("1");
                  }

                  if (var4[1].equalsIgnoreCase("give")) {
                     return Arrays.asList("1");
                  }

                  if (var4[1].equalsIgnoreCase("item")) {
                     return Arrays.asList("");
                  }
               } else if (var4.length == 5) {
                  if (var4[1].equalsIgnoreCase("drop")) {
                     return Arrays.asList(String.valueOf(Utils.round3(var5.getLocation().getY())));
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("give")) {
                     return Arrays.asList("1");
                  }

                  if (var4[1].equalsIgnoreCase("item")) {
                     return Arrays.asList("");
                  }
               } else if (var4.length == 6) {
                  if (var4[1].equalsIgnoreCase("drop")) {
                     return Arrays.asList(String.valueOf(Utils.round3(var5.getLocation().getZ())));
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("give")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("item")) {
                     return Arrays.asList("");
                  }
               } else if (var4.length == 7) {
                  if (var4[1].equalsIgnoreCase("drop")) {
                     return Arrays.asList("1");
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("give")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("item")) {
                     return Arrays.asList("");
                  }
               } else {
                  if (var4.length != 8) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("drop")) {
                     return Arrays.asList("1");
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("give")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("item")) {
                     return Arrays.asList("");
                  }
               }
            } else if (var4[0].equalsIgnoreCase("runes")) {
               if (var4.length == 2) {
                  return Arrays.asList("list", "get", "give", "drop");
               }

               if (var4.length == 3) {
                  if (var4[1].equalsIgnoreCase("drop")) {
                     return Utils.getWorldNames();
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return this.plugin.getMM().getRuneManager().getRuneNames();
                  }

                  if (var4[1].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               } else if (var4.length == 4) {
                  if (var4[1].equalsIgnoreCase("drop")) {
                     return Arrays.asList(String.valueOf(Utils.round3(var5.getLocation().getX())));
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return Arrays.asList("1");
                  }

                  if (var4[1].equalsIgnoreCase("give")) {
                     return this.plugin.getMM().getRuneManager().getRuneNames();
                  }

                  if (var4[1].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               } else if (var4.length == 5) {
                  if (var4[1].equalsIgnoreCase("drop")) {
                     return Arrays.asList(String.valueOf(Utils.round3(var5.getLocation().getY())));
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return Arrays.asList("1");
                  }

                  if (var4[1].equalsIgnoreCase("give")) {
                     return Arrays.asList("1");
                  }

                  if (var4[1].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               } else if (var4.length == 6) {
                  if (var4[1].equalsIgnoreCase("drop")) {
                     return Arrays.asList(String.valueOf(Utils.round3(var5.getLocation().getZ())));
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("give")) {
                     return Arrays.asList("1");
                  }

                  if (var4[1].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               } else if (var4.length == 7) {
                  if (var4[1].equalsIgnoreCase("drop")) {
                     return this.plugin.getMM().getRuneManager().getRuneNames();
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("give")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               } else if (var4.length == 8) {
                  if (var4[1].equalsIgnoreCase("drop")) {
                     return Arrays.asList("1");
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("give")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               } else {
                  if (var4.length != 9) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("drop")) {
                     return Arrays.asList("1");
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("give")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               }
            } else if (var4[0].equalsIgnoreCase("scrolls")) {
               if (var4.length == 2) {
                  return Arrays.asList("list", "get", "give", "drop");
               }

               if (var4.length == 3) {
                  if (var4[1].equalsIgnoreCase("drop")) {
                     return Utils.getWorldNames();
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return this.plugin.getMM().getScrollManager().getScrollNames();
                  }

                  if (var4[1].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               } else if (var4.length == 4) {
                  if (var4[1].equalsIgnoreCase("drop")) {
                     return Arrays.asList(String.valueOf(Utils.round3(var5.getLocation().getX())));
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return Arrays.asList("1");
                  }

                  if (var4[1].equalsIgnoreCase("give")) {
                     return this.plugin.getMM().getScrollManager().getScrollNames();
                  }

                  if (var4[1].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               } else if (var4.length == 5) {
                  if (var4[1].equalsIgnoreCase("drop")) {
                     return Arrays.asList(String.valueOf(Utils.round3(var5.getLocation().getY())));
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return Arrays.asList("1");
                  }

                  if (var4[1].equalsIgnoreCase("give")) {
                     return Arrays.asList("1");
                  }

                  if (var4[1].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               } else if (var4.length == 6) {
                  if (var4[1].equalsIgnoreCase("drop")) {
                     return Arrays.asList(String.valueOf(Utils.round3(var5.getLocation().getZ())));
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("give")) {
                     return Arrays.asList("1");
                  }

                  if (var4[1].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               } else if (var4.length == 7) {
                  if (var4[1].equalsIgnoreCase("drop")) {
                     return this.plugin.getMM().getScrollManager().getScrollNames();
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("give")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               } else if (var4.length == 8) {
                  if (var4[1].equalsIgnoreCase("drop")) {
                     return Arrays.asList("1");
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("give")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               } else {
                  if (var4.length != 9) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("drop")) {
                     return Arrays.asList("1");
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("give")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               }
            } else if (var4[0].equalsIgnoreCase("tiers")) {
               if (var4.length == 2) {
                  return Arrays.asList("list", "get", "give", "drop");
               }

               if (var4.length == 3) {
                  if (var4[1].equalsIgnoreCase("drop")) {
                     return Utils.getWorldNames();
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return this.plugin.getMM().getTierManager().getTierNames();
                  }

                  if (var4[1].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               } else if (var4.length == 4) {
                  if (var4[1].equalsIgnoreCase("drop")) {
                     return Arrays.asList(String.valueOf(Utils.round3(var5.getLocation().getX())));
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return Arrays.asList("1");
                  }

                  if (var4[1].equalsIgnoreCase("give")) {
                     return this.plugin.getMM().getTierManager().getTierNames();
                  }

                  if (var4[1].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               } else if (var4.length == 5) {
                  if (var4[1].equalsIgnoreCase("drop")) {
                     return Arrays.asList(String.valueOf(Utils.round3(var5.getLocation().getY())));
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return Arrays.asList("1");
                  }

                  if (var4[1].equalsIgnoreCase("give")) {
                     return Arrays.asList("1");
                  }

                  if (var4[1].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               } else if (var4.length == 6) {
                  if (var4[1].equalsIgnoreCase("drop")) {
                     return Arrays.asList(String.valueOf(Utils.round3(var5.getLocation().getZ())));
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("give")) {
                     return Arrays.asList("1");
                  }

                  if (var4[1].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               } else if (var4.length == 7) {
                  if (var4[1].equalsIgnoreCase("drop")) {
                     return this.plugin.getMM().getTierManager().getTierNames();
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("give")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               } else if (var4.length == 8) {
                  if (var4[1].equalsIgnoreCase("drop")) {
                     return Arrays.asList("1");
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("give")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               } else {
                  if (var4.length != 9) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("drop")) {
                     return Arrays.asList("1");
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("give")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               }
            } else if (var4[0].equalsIgnoreCase("sets")) {
               if (var4.length == 2) {
                  return Arrays.asList("list", "get", "give", "drop");
               }

               if (var4.length == 3) {
                  if (var4[1].equalsIgnoreCase("drop")) {
                     return Utils.getWorldNames();
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return this.plugin.getMM().getSetManager().getSetNames();
                  }

                  if (var4[1].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               } else if (var4.length == 4) {
                  if (var4[1].equalsIgnoreCase("drop")) {
                     return Arrays.asList(String.valueOf(Utils.round3(var5.getLocation().getX())));
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return Utils.getEnumsList(SetManager.PartType.class);
                  }

                  if (var4[1].equalsIgnoreCase("give")) {
                     return this.plugin.getMM().getSetManager().getSetNames();
                  }

                  if (var4[1].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               } else if (var4.length == 5) {
                  if (var4[1].equalsIgnoreCase("drop")) {
                     return Arrays.asList(String.valueOf(Utils.round3(var5.getLocation().getY())));
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return Arrays.asList("1");
                  }

                  if (var4[1].equalsIgnoreCase("give")) {
                     return Utils.getEnumsList(SetManager.PartType.class);
                  }

                  if (var4[1].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               } else if (var4.length == 6) {
                  if (var4[1].equalsIgnoreCase("drop")) {
                     return Arrays.asList(String.valueOf(Utils.round3(var5.getLocation().getZ())));
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("give")) {
                     return Arrays.asList("1");
                  }

                  if (var4[1].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               } else if (var4.length == 7) {
                  if (var4[1].equalsIgnoreCase("drop")) {
                     return this.plugin.getMM().getSetManager().getSetNames();
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("give")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               } else if (var4.length == 8) {
                  if (var4[1].equalsIgnoreCase("drop")) {
                     return Utils.getEnumsList(SetManager.PartType.class);
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("give")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               } else {
                  if (var4.length != 9) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("drop")) {
                     return Arrays.asList("1");
                  }

                  if (var4[1].equalsIgnoreCase("get")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("give")) {
                     return Arrays.asList("");
                  }

                  if (var4[1].equalsIgnoreCase("list")) {
                     return Arrays.asList("");
                  }
               }
            }
         }

         return null;
      }
   }
}
