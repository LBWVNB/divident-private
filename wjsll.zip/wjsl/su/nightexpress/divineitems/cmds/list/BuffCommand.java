package su.nightexpress.divineitems.cmds.list;

import java.util.Iterator;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import su.nightexpress.divineitems.DivineItems;
import su.nightexpress.divineitems.cmds.CommandBase;
import su.nightexpress.divineitems.config.Lang;
import su.nightexpress.divineitems.modules.buffs.BuffManager;
import su.nightexpress.divineitems.utils.Utils;

public class BuffCommand extends CommandBase {
   private DivineItems plugin;

   public BuffCommand(DivineItems var1) {
      this.plugin = var1;
   }

   public void perform(CommandSender var1, String[] var2) {
      BuffManager var3 = this.plugin.getMM().getBuffManager();
      Player var4;
      BuffManager.Buff var5;
      BuffManager.BuffType var17;
      String var18;
      if (var2.length == 7 && var2[1].equalsIgnoreCase("add")) {
         var4 = Bukkit.getPlayer(var2[2]);
         if (var4 == null) {
            var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidPlayer.toMsg());
            return;
         }

         var5 = null;

         try {
            var17 = BuffManager.BuffType.valueOf(var2[3].toUpperCase());
         } catch (IllegalArgumentException var14) {
            var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidType.toMsg().replace("%types%", Utils.getEnums(BuffManager.BuffType.class, "§a", "§7")));
            return;
         }

         var18 = var2[4];
         double var7 = 0.0D;

         try {
            var7 = Double.parseDouble(var2[5]);
         } catch (NumberFormatException var13) {
            var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidNumber.toMsg().replace("%s", var2[5]));
            return;
         }

         boolean var9 = false;

         int var19;
         try {
            var19 = Integer.parseInt(var2[6]);
         } catch (NumberFormatException var12) {
            var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidNumber.toMsg().replace("%s", var2[6]));
            return;
         }

         if (var3.addBuff(var4, var17, var18, var7, var19, true)) {
            var1.sendMessage(Lang.Prefix.toMsg() + Lang.Buffs_Give.toMsg().replace("%value%", var2[4]).replace("%mod%", var2[5]).replace("%time%", var2[6]).replace("%type%", var2[3]).replace("%p", var2[2]));
         } else {
            var1.sendMessage(Lang.Prefix.toMsg() + Lang.Buffs_Invalid.toMsg());
         }
      } else if (var2.length == 5 && var2[1].equalsIgnoreCase("reset")) {
         var4 = Bukkit.getPlayer(var2[2]);
         if (var4 == null) {
            var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidPlayer.toMsg());
            return;
         }

         var5 = null;

         try {
            var17 = BuffManager.BuffType.valueOf(var2[3].toUpperCase());
         } catch (IllegalArgumentException var11) {
            var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidType.toMsg().replace("%types%", Utils.getEnums(BuffManager.BuffType.class, "§a", "§7")));
            return;
         }

         var18 = var2[4];
         var3.resetBuff(var4, var17, var18);
         var1.sendMessage(Lang.Prefix.toMsg() + "Done!");
      } else {
         if (var2.length != 3 || !var2[1].equalsIgnoreCase("resetall")) {
            Iterator var16 = Lang.Help_Buffs.getList().iterator();

            while(var16.hasNext()) {
               String var15 = (String)var16.next();
               var1.sendMessage(var15.replace("%m_state%", this.plugin.getMM().getColorStatus(var3.isActive())).replace("%m_ver%", var3.version()).replace("%m_name%", var3.name()));
            }

            return;
         }

         var4 = Bukkit.getPlayer(var2[2]);
         if (var4 == null) {
            var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidPlayer.toMsg());
            return;
         }

         Iterator var6 = var3.getPlayerBuffs(var4).iterator();

         while(var6.hasNext()) {
            var5 = (BuffManager.Buff)var6.next();
            var3.resetBuff(var4, var5.getType(), var5.getValue());
         }

         var1.sendMessage(Lang.Prefix.toMsg() + "Done!");
      }

   }

   public String getPermission() {
      return "divineitems.admin";
   }

   public boolean playersOnly() {
      return false;
   }
}
