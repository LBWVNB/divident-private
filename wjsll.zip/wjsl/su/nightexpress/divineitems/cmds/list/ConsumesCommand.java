package su.nightexpress.divineitems.cmds.list;

import java.util.Iterator;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import su.nightexpress.divineitems.DivineItems;
import su.nightexpress.divineitems.cmds.CommandBase;
import su.nightexpress.divineitems.config.Lang;
import su.nightexpress.divineitems.modules.consumes.ConsumeManager;
import su.nightexpress.divineitems.utils.Utils;

public class ConsumesCommand extends CommandBase {
   private DivineItems plugin;

   public ConsumesCommand(DivineItems var1) {
      this.plugin = var1;
   }

   public void perform(CommandSender var1, String[] var2) {
      ConsumeManager var3 = this.plugin.getMM().getConsumeManager();
      if ((var2.length == 2 || var2.length == 3) && var2[1].equalsIgnoreCase("list")) {
         int var23 = 1;
         if (var2.length == 3) {
            try {
               var23 = Integer.parseInt(var2[2]);
            } catch (NumberFormatException var20) {
               var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidNumber.toMsg().replace("%s", var2[3]));
            }
         }

         Utils.interactiveList(var1, var23, var3.getConsumeNames(), var3.name(), "1");
      } else {
         int var6;
         int var8;
         Player var22;
         String var25;
         ConsumeManager.Consume var26;
         if (var2.length == 4 && var2[1].equalsIgnoreCase("get")) {
            if (!(var1 instanceof Player)) {
               var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidSender.toMsg());
               return;
            }

            var22 = (Player)var1;
            var25 = var2[2];
            var6 = 1;

            try {
               var6 = Integer.parseInt(var2[3]);
            } catch (NumberFormatException var19) {
               var22.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidNumber.toMsg().replace("%s", var2[3]));
            }

            var26 = var3.getConsumeById(var25);
            if (var26 == null) {
               var22.sendMessage(Lang.Prefix.toMsg() + Lang.Consumables_Invalid.toMsg().replace("%s", var25));
               return;
            }

            for(var8 = 0; var8 < var6; ++var8) {
               if (var25.equalsIgnoreCase("random")) {
                  var26 = var3.getConsumeById(var25);
               }

               if (var22.getInventory().firstEmpty() == -1) {
                  var22.getWorld().dropItemNaturally(var22.getLocation(), var26.build()).setPickupDelay(40);
               } else {
                  var22.getInventory().addItem(new ItemStack[]{var26.build()});
               }
            }
         } else if (var2.length == 5 && var2[1].equalsIgnoreCase("give")) {
            var22 = Bukkit.getPlayer(var2[2]);
            if (var22 == null) {
               var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidPlayer.toMsg());
               return;
            }

            var25 = var2[3];
            var6 = 1;

            try {
               var6 = Integer.parseInt(var2[4]);
            } catch (NumberFormatException var18) {
               var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidNumber.toMsg().replace("%s", var2[4]));
            }

            var26 = var3.getConsumeById(var25);
            if (var26 == null) {
               var1.sendMessage(Lang.Prefix.toMsg() + Lang.Consumables_Invalid.toMsg().replace("%s", var25));
               return;
            }

            for(var8 = 0; var8 < var6; ++var8) {
               if (var25.equalsIgnoreCase("random")) {
                  var26 = var3.getConsumeById(var25);
               }

               if (var22.getInventory().firstEmpty() == -1) {
                  var22.getWorld().dropItemNaturally(var22.getLocation(), var26.build()).setPickupDelay(40);
               } else {
                  var22.getInventory().addItem(new ItemStack[]{var26.build()});
               }
            }
         } else {
            if (var2.length != 8 || !var2[1].equalsIgnoreCase("drop")) {
               Iterator var24 = Lang.Help_Consumables.getList().iterator();

               while(var24.hasNext()) {
                  String var21 = (String)var24.next();
                  var1.sendMessage(var21.replace("%m_state%", this.plugin.getMM().getColorStatus(var3.isActive())).replace("%m_ver%", var3.version()).replace("%m_name%", var3.name()));
               }

               return;
            }

            World var4 = Bukkit.getWorld(var2[2]);
            if (var4 == null) {
               var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidWorld.toMsg().replace("%s", var2[2]));
               return;
            }

            double var5 = 0.0D;
            double var7 = 0.0D;
            double var9 = 0.0D;

            try {
               var5 = Double.parseDouble(var2[3]);
               var7 = Double.parseDouble(var2[4]);
               var9 = Double.parseDouble(var2[5]);
            } catch (NumberFormatException var17) {
               var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidCoordinates.toMsg().replace("%s", var2[3] + " " + var2[4] + " " + var2[5]));
            }

            String var11 = var2[6];
            int var12 = 1;

            try {
               var12 = Integer.parseInt(var2[7]);
            } catch (NumberFormatException var16) {
               var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidNumber.toMsg().replace("%s", var2[7]));
            }

            ConsumeManager.Consume var13 = var3.getConsumeById(var11);
            if (var13 == null) {
               var1.sendMessage(Lang.Prefix.toMsg() + Lang.Consumables_Invalid.toMsg().replace("%s", var11));
               return;
            }

            Location var14 = new Location(var4, var5, var7, var9);

            for(int var15 = 0; var15 < var12; ++var15) {
               if (var11.equalsIgnoreCase("random")) {
                  var13 = var3.getConsumeById(var11);
               }

               var4.dropItemNaturally(var14, var13.build()).setPickupDelay(40);
            }
         }
      }

   }

   public String getPermission() {
      return "divineitems.admin";
   }

   public boolean playersOnly() {
      return false;
   }
}
