package su.nightexpress.divineitems.cmds.list;

import java.util.Iterator;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import su.nightexpress.divineitems.DivineItems;
import su.nightexpress.divineitems.cmds.CommandBase;
import su.nightexpress.divineitems.config.Lang;
import su.nightexpress.divineitems.modules.enchant.EnchantManager;
import su.nightexpress.divineitems.utils.Utils;

public class EnchantsCommand extends CommandBase {
   private DivineItems plugin;

   public EnchantsCommand(DivineItems var1) {
      this.plugin = var1;
   }

   public void perform(CommandSender var1, String[] var2) {
      EnchantManager var3 = this.plugin.getMM().getEnchantManager();
      if ((var2.length == 2 || var2.length == 3) && var2[1].equalsIgnoreCase("list")) {
         int var31 = 1;
         if (var2.length == 3) {
            try {
               var31 = Integer.parseInt(var2[2]);
            } catch (NumberFormatException var28) {
               var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidNumber.toMsg().replace("%s", var2[3]));
            }
         }

         Utils.interactiveList(var1, var31, var3.getEnchantNames(), var3.name(), "-1 1");
      } else {
         EnchantManager.EnchantType var6;
         int var8;
         int var10;
         Player var30;
         String var33;
         int var34;
         EnchantManager.Enchant var35;
         if (var2.length == 5 && var2[1].equalsIgnoreCase("get")) {
            if (!(var1 instanceof Player)) {
               var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidSender.toMsg());
               return;
            }

            var30 = (Player)var1;
            var33 = var2[2];
            var6 = null;

            try {
               var6 = EnchantManager.EnchantType.valueOf(var33.toUpperCase());
            } catch (IllegalArgumentException var27) {
               var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidType.toMsg().replace("%s", Utils.getEnums(EnchantManager.EnchantType.class, "§c", "§7")));
               return;
            }

            var34 = 1;
            var8 = 1;

            try {
               var34 = Integer.parseInt(var2[3]);
            } catch (NumberFormatException var26) {
               var30.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidNumber.toMsg().replace("%s", var2[3]));
            }

            try {
               var8 = Integer.parseInt(var2[4]);
            } catch (NumberFormatException var25) {
               var30.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidNumber.toMsg().replace("%s", var2[4]));
            }

            var35 = var3.getEnchantByType(var6);
            if (var35 == null) {
               var30.sendMessage(Lang.Prefix.toMsg() + Lang.Enchants_Invalid.toMsg().replace("%s", var33));
               return;
            }

            for(var10 = 0; var10 < var8; ++var10) {
               if (var30.getInventory().firstEmpty() == -1) {
                  var30.getWorld().dropItemNaturally(var30.getLocation(), var35.create(var34)).setPickupDelay(40);
               } else {
                  var30.getInventory().addItem(new ItemStack[]{var35.create(var34)});
               }
            }
         } else if (var2.length == 6 && var2[1].equalsIgnoreCase("give")) {
            var30 = Bukkit.getPlayer(var2[2]);
            if (var30 == null) {
               var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidPlayer.toMsg());
               return;
            }

            var33 = var2[3];
            var6 = null;
            if (var33.equalsIgnoreCase("random")) {
               var33 = var3.getRandomEnchant().getId();
            }

            try {
               var6 = EnchantManager.EnchantType.valueOf(var33.toUpperCase());
            } catch (IllegalArgumentException var24) {
               var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidType.toMsg().replace("%s", Utils.getEnums(EnchantManager.EnchantType.class, "§c", "§7")));
               return;
            }

            var34 = 1;
            var8 = 2;

            try {
               var34 = Integer.parseInt(var2[4]);
            } catch (NumberFormatException var23) {
               var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidNumber.toMsg().replace("%s", var2[4]));
            }

            try {
               var8 = Integer.parseInt(var2[5]);
            } catch (NumberFormatException var22) {
               var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidNumber.toMsg().replace("%s", var2[5]));
            }

            var35 = var3.getEnchantByType(var6);
            if (var35 == null) {
               var1.sendMessage(Lang.Prefix.toMsg() + Lang.Enchants_Invalid.toMsg().replace("%s", var33));
               return;
            }

            for(var10 = 0; var10 < var8; ++var10) {
               if (var30.getInventory().firstEmpty() == -1) {
                  var30.getWorld().dropItemNaturally(var30.getLocation(), var35.create(var34)).setPickupDelay(40);
               } else {
                  var30.getInventory().addItem(new ItemStack[]{var35.create(var34)});
               }
            }
         } else {
            if (var2.length != 9 || !var2[1].equalsIgnoreCase("drop")) {
               Iterator var32 = Lang.Help_Enchants.getList().iterator();

               while(var32.hasNext()) {
                  String var29 = (String)var32.next();
                  var1.sendMessage(var29.replace("%m_state%", this.plugin.getMM().getColorStatus(var3.isActive())).replace("%m_ver%", var3.version()).replace("%m_name%", var3.name()));
               }

               return;
            }

            World var4 = Bukkit.getWorld(var2[2]);
            if (var4 == null) {
               var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidWorld.toMsg().replace("%s", var2[2]));
               return;
            }

            double var5 = 0.0D;
            double var7 = 0.0D;
            double var9 = 0.0D;

            try {
               var5 = Double.parseDouble(var2[3]);
               var7 = Double.parseDouble(var2[4]);
               var9 = Double.parseDouble(var2[5]);
            } catch (NumberFormatException var21) {
               var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidCoordinates.toMsg().replace("%s", var2[3] + " " + var2[4] + " " + var2[5]));
            }

            String var11 = var2[6];
            EnchantManager.EnchantType var12 = null;

            try {
               var12 = EnchantManager.EnchantType.valueOf(var11.toUpperCase());
            } catch (IllegalArgumentException var20) {
               var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidType.toMsg().replace("%s", Utils.getEnums(EnchantManager.EnchantType.class, "§c", "§7")));
               return;
            }

            int var13 = 1;
            int var14 = 2;

            try {
               var13 = Integer.parseInt(var2[7]);
            } catch (NumberFormatException var19) {
               var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidNumber.toMsg().replace("%s", var2[7]));
            }

            try {
               var14 = Integer.parseInt(var2[8]);
            } catch (NumberFormatException var18) {
               var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidNumber.toMsg().replace("%s", var2[8]));
            }

            EnchantManager.Enchant var15 = var3.getEnchantByType(var12);
            if (var15 == null) {
               var1.sendMessage(Lang.Prefix.toMsg() + Lang.Enchants_Invalid.toMsg().replace("%s", var11));
               return;
            }

            Location var16 = new Location(var4, var5, var7, var9);

            for(int var17 = 0; var17 < var14; ++var17) {
               var4.dropItemNaturally(var16, var15.create(var13)).setPickupDelay(40);
            }
         }
      }

   }

   public String getPermission() {
      return "divineitems.admin";
   }

   public boolean playersOnly() {
      return false;
   }
}
