package su.nightexpress.divineitems.cmds.list;

import java.util.Iterator;
import org.bukkit.command.CommandSender;
import su.nightexpress.divineitems.cmds.CommandBase;
import su.nightexpress.divineitems.config.Lang;

public class HelpCommand extends CommandBase {
   public void perform(CommandSender var1, String[] var2) {
      if (var2.length <= 1) {
         Iterator var4 = Lang.Help_Main.getList().iterator();

         while(var4.hasNext()) {
            String var3 = (String)var4.next();
            var1.sendMessage(var3);
         }
      }

   }

   public String getPermission() {
      return "divineitems.admin";
   }

   public boolean playersOnly() {
      return false;
   }
}
