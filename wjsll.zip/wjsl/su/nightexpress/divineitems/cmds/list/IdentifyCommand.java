package su.nightexpress.divineitems.cmds.list;

import java.util.Iterator;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import su.nightexpress.divineitems.DivineItems;
import su.nightexpress.divineitems.cmds.CommandBase;
import su.nightexpress.divineitems.config.Lang;
import su.nightexpress.divineitems.modules.identify.IdentifyManager;
import su.nightexpress.divineitems.utils.Utils;

public class IdentifyCommand extends CommandBase {
   private DivineItems plugin;

   public IdentifyCommand(DivineItems var1) {
      this.plugin = var1;
   }

   public void perform(CommandSender var1, String[] var2) {
      IdentifyManager var3 = this.plugin.getMM().getIdentifyManager();
      Player var30;
      if (var2.length == 2 && var2[1].equalsIgnoreCase("force")) {
         if (!(var1 instanceof Player)) {
            var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidSender.toMsg());
            return;
         }

         var30 = (Player)var1;
         ItemStack var36 = var30.getInventory().getItemInMainHand();
         if (var36 == null || var36.getType() == Material.AIR) {
            var30.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidItem.toMsg());
            return;
         }

         var36 = var3.identify(var36);
         var30.getInventory().setItemInMainHand(var36);
      } else {
         World var4;
         double var5;
         double var7;
         int var8;
         double var9;
         String var11;
         int var13;
         int var31;
         String var33;
         int var35;
         if (var2.length >= 3 && var2[1].equalsIgnoreCase("tome")) {
            if ((var2.length == 3 || var2.length == 4) && var2[2].equalsIgnoreCase("list")) {
               var31 = 1;
               if (var2.length == 4) {
                  try {
                     var31 = Integer.parseInt(var2[3]);
                  } catch (NumberFormatException var29) {
                     var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidNumber.toMsg().replace("%s", var2[3]));
                  }
               }

               Utils.interactiveList(var1, var31, var3.getTomeNames(), var3.name() + "_tome", "1");
            } else {
               IdentifyManager.IdentifyTome var37;
               if (var2.length == 5 && var2[2].equalsIgnoreCase("get")) {
                  if (!(var1 instanceof Player)) {
                     var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidSender.toMsg());
                     return;
                  }

                  var30 = (Player)var1;
                  var33 = var2[3];
                  var37 = var3.getTomeById(var33);
                  if (var37 == null) {
                     var30.sendMessage(Lang.Prefix.toMsg() + Lang.Identify_Invalid_Tome.toMsg().replace("%s", var33));
                     return;
                  }

                  var35 = 1;

                  try {
                     var35 = Integer.parseInt(var2[4]);
                  } catch (NumberFormatException var28) {
                     var30.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidNumber.toMsg().replace("%s", var2[4]));
                  }

                  for(var8 = 0; var8 < var35; ++var8) {
                     if (var33.equalsIgnoreCase("random")) {
                        var37 = var3.getTomeById(var33);
                     }

                     if (var30.getInventory().firstEmpty() == -1) {
                        var30.getWorld().dropItemNaturally(var30.getLocation(), var37.create()).setPickupDelay(40);
                     } else {
                        var30.getInventory().addItem(new ItemStack[]{var37.create()});
                     }
                  }
               } else if (var2.length == 6 && var2[2].equalsIgnoreCase("give")) {
                  var30 = Bukkit.getPlayer(var2[3]);
                  if (var30 == null) {
                     var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidPlayer.toMsg());
                     return;
                  }

                  var33 = var2[4];
                  var37 = var3.getTomeById(var33);
                  if (var37 == null) {
                     var1.sendMessage(Lang.Prefix.toMsg() + Lang.Identify_Invalid_Tome.toMsg().replace("%s", var33));
                     return;
                  }

                  var35 = 1;

                  try {
                     var35 = Integer.parseInt(var2[5]);
                  } catch (NumberFormatException var27) {
                     var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidNumber.toMsg().replace("%s", var2[5]));
                  }

                  for(var8 = 0; var8 < var35; ++var8) {
                     if (var33.equalsIgnoreCase("random")) {
                        var37 = var3.getTomeById(var33);
                     }

                     if (var30.getInventory().firstEmpty() == -1) {
                        var30.getWorld().dropItemNaturally(var30.getLocation(), var37.create()).setPickupDelay(40);
                     } else {
                        var30.getInventory().addItem(new ItemStack[]{var37.create()});
                     }
                  }
               } else if (var2.length == 9 && var2[2].equalsIgnoreCase("drop")) {
                  var4 = Bukkit.getWorld(var2[3]);
                  if (var4 == null) {
                     var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidWorld.toMsg().replace("%s", var2[3]));
                     return;
                  }

                  var5 = 0.0D;
                  var7 = 0.0D;
                  var9 = 0.0D;

                  try {
                     var5 = Double.parseDouble(var2[4]);
                     var7 = Double.parseDouble(var2[5]);
                     var9 = Double.parseDouble(var2[6]);
                  } catch (NumberFormatException var26) {
                     var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidCoordinates.toMsg().replace("%s", var2[4] + " " + var2[5] + " " + var2[6]));
                  }

                  var11 = var2[7];
                  IdentifyManager.IdentifyTome var39 = var3.getTomeById(var11);
                  if (var39 == null) {
                     var1.sendMessage(Lang.Prefix.toMsg() + Lang.Identify_Invalid_Tome.toMsg().replace("%s", var11));
                     return;
                  }

                  var13 = 1;

                  try {
                     var13 = Integer.parseInt(var2[8]);
                  } catch (NumberFormatException var25) {
                     var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidNumber.toMsg().replace("%s", var2[8]));
                  }

                  Location var40 = new Location(var4, var5, var7, var9);

                  for(int var41 = 0; var41 < var13; ++var41) {
                     if (var11.equalsIgnoreCase("random")) {
                        var39 = var3.getTomeById(var11);
                     }

                     var4.dropItemNaturally(var40, var39.create()).setPickupDelay(40);
                  }
               }
            }
         } else {
            if (var2.length < 3 || !var2[1].equalsIgnoreCase("item")) {
               Iterator var34 = Lang.Help_Identify.getList().iterator();

               while(var34.hasNext()) {
                  String var32 = (String)var34.next();
                  var1.sendMessage(var32.replace("%m_state%", this.plugin.getMM().getColorStatus(var3.isActive())).replace("%m_ver%", var3.version()).replace("%m_name%", var3.name()));
               }

               return;
            }

            if ((var2.length == 3 || var2.length == 4) && var2[2].equalsIgnoreCase("list")) {
               var31 = 1;
               if (var2.length == 4) {
                  try {
                     var31 = Integer.parseInt(var2[3]);
                  } catch (NumberFormatException var24) {
                     var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidNumber.toMsg().replace("%s", var2[3]));
                  }
               }

               Utils.interactiveList(var1, var31, var3.getUINames(), var3.name() + "_item", "-1 1");
            } else {
               IdentifyManager.UnidentifiedItem var6;
               int var38;
               if (var2.length == 6 && var2[2].equalsIgnoreCase("get")) {
                  if (!(var1 instanceof Player)) {
                     var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidSender.toMsg());
                     return;
                  }

                  var30 = (Player)var1;
                  var33 = var2[3];
                  var6 = var3.getItemById(var33);
                  if (var6 == null) {
                     var30.sendMessage(Lang.Prefix.toMsg() + Lang.Identify_Invalid_Item.toMsg().replace("%s", var33));
                     return;
                  }

                  var35 = 1;

                  try {
                     var35 = Integer.parseInt(var2[4]);
                  } catch (NumberFormatException var23) {
                     var30.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidNumber.toMsg().replace("%s", var2[4]));
                  }

                  var8 = 1;

                  try {
                     var8 = Integer.parseInt(var2[5]);
                  } catch (NumberFormatException var22) {
                     var30.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidNumber.toMsg().replace("%s", var2[5]));
                  }

                  for(var38 = 0; var38 < var8; ++var38) {
                     if (var33.equalsIgnoreCase("random")) {
                        var6 = var3.getItemById(var33);
                     }

                     if (var30.getInventory().firstEmpty() == -1) {
                        var30.getWorld().dropItemNaturally(var30.getLocation(), var6.create(var35)).setPickupDelay(40);
                     } else {
                        var30.getInventory().addItem(new ItemStack[]{var6.create(var35)});
                     }
                  }
               } else if (var2.length == 7 && var2[2].equalsIgnoreCase("give")) {
                  var30 = Bukkit.getPlayer(var2[3]);
                  if (var30 == null) {
                     var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidPlayer.toMsg());
                     return;
                  }

                  var33 = var2[4];
                  var6 = var3.getItemById(var33);
                  if (var6 == null) {
                     var1.sendMessage(Lang.Prefix.toMsg() + Lang.Identify_Invalid_Tome.toMsg().replace("%s", var33));
                     return;
                  }

                  var35 = 1;

                  try {
                     var35 = Integer.parseInt(var2[5]);
                  } catch (NumberFormatException var21) {
                     var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidNumber.toMsg().replace("%s", var2[5]));
                  }

                  var8 = 1;

                  try {
                     var8 = Integer.parseInt(var2[6]);
                  } catch (NumberFormatException var20) {
                     var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidNumber.toMsg().replace("%s", var2[6]));
                  }

                  for(var38 = 0; var38 < var8; ++var38) {
                     if (var33.equalsIgnoreCase("random")) {
                        var6 = var3.getItemById(var33);
                     }

                     if (var30.getInventory().firstEmpty() == -1) {
                        var30.getWorld().dropItemNaturally(var30.getLocation(), var6.create(var35)).setPickupDelay(40);
                     } else {
                        var30.getInventory().addItem(new ItemStack[]{var6.create(var35)});
                     }
                  }
               } else if (var2.length == 10 && var2[2].equalsIgnoreCase("drop")) {
                  var4 = Bukkit.getWorld(var2[3]);
                  if (var4 == null) {
                     var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidWorld.toMsg().replace("%s", var2[3]));
                     return;
                  }

                  var5 = 0.0D;
                  var7 = 0.0D;
                  var9 = 0.0D;

                  try {
                     var5 = Double.parseDouble(var2[4]);
                     var7 = Double.parseDouble(var2[5]);
                     var9 = Double.parseDouble(var2[6]);
                  } catch (NumberFormatException var19) {
                     var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidCoordinates.toMsg().replace("%s", var2[4] + " " + var2[5] + " " + var2[6]));
                  }

                  var11 = var2[7];
                  IdentifyManager.UnidentifiedItem var12 = var3.getItemById(var11);
                  if (var12 == null) {
                     var1.sendMessage(Lang.Prefix.toMsg() + Lang.Identify_Invalid_Tome.toMsg().replace("%s", var11));
                     return;
                  }

                  var13 = 1;

                  try {
                     var13 = Integer.parseInt(var2[8]);
                  } catch (NumberFormatException var18) {
                     var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidNumber.toMsg().replace("%s", var2[8]));
                  }

                  int var14 = 1;

                  try {
                     var14 = Integer.parseInt(var2[9]);
                  } catch (NumberFormatException var17) {
                     var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidNumber.toMsg().replace("%s", var2[9]));
                  }

                  Location var15 = new Location(var4, var5, var7, var9);

                  for(int var16 = 0; var16 < var14; ++var16) {
                     if (var11.equalsIgnoreCase("random")) {
                        var12 = var3.getItemById(var11);
                     }

                     var4.dropItemNaturally(var15, var12.create(var13)).setPickupDelay(40);
                  }
               }
            }
         }
      }

   }

   public String getPermission() {
      return "divineitems.admin";
   }

   public boolean playersOnly() {
      return false;
   }
}
