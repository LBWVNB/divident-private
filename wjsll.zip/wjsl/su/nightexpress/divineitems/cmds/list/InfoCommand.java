package su.nightexpress.divineitems.cmds.list;

import org.bukkit.command.CommandSender;
import su.nightexpress.divineitems.DivineItems;
import su.nightexpress.divineitems.cmds.CommandBase;

public class InfoCommand extends CommandBase {
   private DivineItems plugin;

   public InfoCommand(DivineItems var1) {
      this.plugin = var1;
   }

   public void perform(CommandSender var1, String[] var2) {
      var1.sendMessage("§8§m--------§8§l[ §fDivine Items RPG - Info §8§l]§8§m--------");
      var1.sendMessage("§r");
      var1.sendMessage("§8§l[§aAbout§8§l]");
      var1.sendMessage("§a> §7Price: §a10.00 USD§7.");
      var1.sendMessage("§a> §7Created by: §aNightExpress");
      var1.sendMessage("§a> §7Version: §a" + this.plugin.getDescription().getVersion() + " (Export)");
      var1.sendMessage("§a> §7Licensed to: §a");
      var1.sendMessage("§a> §7Type §a/di help §7for help.");
      var1.sendMessage("§r");
      var1.sendMessage("§8§l[§eTerms of Service§8§l]");
      var1.sendMessage("§e> §7Redistributing: §c§lDisallowed§7.");
      var1.sendMessage("§e> §7Refunds: §c§lDisallowed§7.");
      var1.sendMessage("§e> §7Decompile/Modify code: §a§lAllowed§7.");
      var1.sendMessage("§r");
      var1.sendMessage("§8§l[§dSupport/Bug Report/Suggestions§8§l]");
      var1.sendMessage("§d> §7SpigotMC: §dPM §7or §dForum thread§7. §a[Fast]");
      var1.sendMessage("§d> §7ICQ: §d9-211-317§7. §a[Fast]");
      var1.sendMessage("§r");
      var1.sendMessage("§8§m------------------------------------");
   }

   public String getPermission() {
      return "divineitems.user";
   }

   public boolean playersOnly() {
      return false;
   }
}
