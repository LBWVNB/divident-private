package su.nightexpress.divineitems.cmds.list;

import java.util.Iterator;
import org.apache.commons.lang.StringUtils;
import org.bukkit.Color;
import org.bukkit.Material;
import org.bukkit.command.CommandSender;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.potion.PotionEffectType;
import su.nightexpress.divineitems.api.ItemAPI;
import su.nightexpress.divineitems.cmds.CommandBase;
import su.nightexpress.divineitems.config.Lang;
import su.nightexpress.divineitems.nms.VersionUtils;
import su.nightexpress.divineitems.utils.Utils;

public class ModifyCommand extends CommandBase {
   public void perform(CommandSender var1, String[] var2) {
      Player var3 = (Player)var1;
      ItemStack var4 = var3.getInventory().getItemInMainHand();
      if (var4 != null && var4.getType() != Material.AIR) {
         String var25;
         int var35;
         if (var2.length >= 3 && var2[1].equalsIgnoreCase("name")) {
            var25 = "";

            for(var35 = 2; var35 < var2.length; ++var35) {
               var25 = var25 + var2[var35] + " ";
            }

            var3.getInventory().setItemInMainHand(ItemAPI.setName(var4, var25.trim()));
            var3.sendMessage(Lang.Prefix.toMsg() + Lang.Admin_Set.toMsg());
         } else {
            int var31;
            int var34;
            int var36;
            if (var2.length >= 3 && var2[1].equalsIgnoreCase("lore")) {
               if (var2[2].equalsIgnoreCase("add") && var2.length >= 4) {
                  var25 = "";
                  var35 = var2.length;
                  var31 = var35;
                  var34 = -1;
                  if (StringUtils.isNumeric(var2[var35 - 1])) {
                     var31 = var35 - 1;
                     var34 = Integer.parseInt(var2[var35 - 1]);
                  }

                  for(var36 = 3; var36 < var31; ++var36) {
                     var25 = var25 + var2[var36] + " ";
                  }

                  var3.getInventory().setItemInMainHand(ItemAPI.addLoreLine(var4, var25.trim(), var34));
                  var3.sendMessage(Lang.Prefix.toMsg() + Lang.Admin_Set.toMsg());
               } else if (var2[2].equalsIgnoreCase("del") && var2.length >= 4) {
                  if (StringUtils.isNumeric(var2[3])) {
                     int var29 = Integer.parseInt(var2[3]);
                     var3.getInventory().setItemInMainHand(ItemAPI.delLoreLine(var4, var29));
                     var3.sendMessage(Lang.Prefix.toMsg() + Lang.Admin_Set.toMsg());
                  }
               } else if (var2[2].equalsIgnoreCase("clear")) {
                  var3.getInventory().setItemInMainHand(ItemAPI.clearLore(var4));
                  var3.sendMessage(Lang.Prefix.toMsg() + Lang.Admin_Set.toMsg());
               } else {
                  this.printHelp(var3);
               }
            } else {
               String[] var6;
               if (var2.length == 4 && var2[1].equalsIgnoreCase("flag")) {
                  var25 = var2[3].toUpperCase();
                  var6 = null;

                  ItemFlag var33;
                  try {
                     var33 = ItemFlag.valueOf(var25);
                  } catch (IllegalArgumentException var24) {
                     var3.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidType.toMsg().replace("%s", Utils.getEnums(ItemFlag.class, "§c", "§7")));
                     return;
                  }

                  if (var2[2].equalsIgnoreCase("add")) {
                     var4 = ItemAPI.addFlag(var4, var33);
                     var3.getInventory().setItemInMainHand(var4);
                     var3.sendMessage(Lang.Prefix.toMsg() + Lang.Admin_Set.toMsg());
                  } else if (var2[2].equalsIgnoreCase("del")) {
                     var4 = ItemAPI.delFlag(var4, var33);
                     var3.getInventory().setItemInMainHand(var4);
                     var3.sendMessage(Lang.Prefix.toMsg() + Lang.Admin_Set.toMsg());
                  } else {
                     this.printHelp(var3);
                  }
               } else {
                  String var28;
                  if (var2.length >= 4 && var2[1].equalsIgnoreCase("nbt")) {
                     var25 = var2[3];
                     if (var2[2].equalsIgnoreCase("add") && var2.length == 5) {
                        var28 = var2[4];
                        var4 = ItemAPI.addNBTTag(var4, var25, var28);
                        var3.getInventory().setItemInMainHand(var4);
                        var3.sendMessage(Lang.Prefix.toMsg() + Lang.Admin_Set.toMsg());
                     } else if (var2[2].equalsIgnoreCase("del")) {
                        var4 = ItemAPI.delNBTTag(var4, var25);
                        var3.getInventory().setItemInMainHand(var4);
                        var3.sendMessage(Lang.Prefix.toMsg() + Lang.Admin_Set.toMsg());
                     } else {
                        this.printHelp(var3);
                     }
                  } else {
                     boolean var7;
                     if (var2.length == 4 && var2[1].equalsIgnoreCase("enchant")) {
                        var25 = var2[2].toUpperCase();
                        Enchantment var30 = Enchantment.getByName(var25);
                        if (var30 == null) {
                           var3.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidType.toMsg().replace("%s", Utils.getEnums(Enchantment.class, "§c", "§7")));
                           return;
                        }

                        var7 = true;

                        try {
                           var31 = Integer.parseInt(var2[3]);
                        } catch (NumberFormatException var23) {
                           var3.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidNumber.toMsg().replace("%s", var2[3]));
                           return;
                        }

                        var4 = ItemAPI.enchant(var4, var30, var31);
                        var3.getInventory().setItemInMainHand(var4);
                        var3.sendMessage(Lang.Prefix.toMsg() + Lang.Admin_Set.toMsg());
                     } else {
                        boolean var8;
                        boolean var9;
                        if (var2.length >= 5 && var2[1].equalsIgnoreCase("potion")) {
                           PotionMeta var26 = (PotionMeta)var4.getItemMeta();
                           if (var26 == null) {
                              var3.sendMessage(Lang.Prefix.toMsg() + Lang.Other_NotAPotion.toMsg());
                              return;
                           }

                           var28 = var2[2].toUpperCase();
                           PotionEffectType var32 = PotionEffectType.getByName(var28);
                           if (var32 == null) {
                              var3.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidType.toMsg().replace("%s", Utils.getEnums(PotionEffectType.class, "§b", "§7")));
                              return;
                           }

                           var8 = true;

                           try {
                              var34 = Integer.parseInt(var2[3]);
                           } catch (NumberFormatException var22) {
                              var3.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidNumber.toMsg().replace("%s", var2[3]));
                              return;
                           }

                           var9 = true;

                           try {
                              var36 = Integer.parseInt(var2[4]);
                           } catch (NumberFormatException var21) {
                              var3.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidNumber.toMsg().replace("%s", var2[4]));
                              return;
                           }

                           boolean var10 = false;
                           boolean var11 = false;
                           if (var2.length == 6) {
                              var10 = Boolean.valueOf(var2[5]);
                           }

                           if (var2.length == 7) {
                              var11 = Boolean.valueOf(var2[6]);
                           }

                           if (VersionUtils.Version.getCurrent().isLower(VersionUtils.Version.v1_13_R1)) {
                              Color var12 = Color.WHITE;
                              if (var2.length == 8) {
                                 String[] var13 = var2[7].split(",");
                                 boolean var14 = false;
                                 boolean var15 = false;
                                 boolean var16 = false;

                                 int var38;
                                 int var39;
                                 int var40;
                                 try {
                                    var38 = Integer.parseInt(var13[0]);
                                    var39 = Integer.parseInt(var13[1]);
                                    var40 = Integer.parseInt(var13[2]);
                                 } catch (NumberFormatException var20) {
                                    var3.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidRGB.toMsg().replace("%s", var2[7]));
                                    return;
                                 }

                                 var12 = Color.fromRGB(var38, var39, var40);
                                 var4 = ItemAPI.addPotionEffect(var4, var32, var34, var36, var10, var11, var12);
                              }
                           } else {
                              boolean var37 = false;
                              if (var2.length == 8) {
                                 var37 = Boolean.valueOf(var2[7]);
                              }

                              var4 = ItemAPI.addPotionEffect(var4, var32, var34, var36, var10, var11, var37);
                           }

                           var3.getInventory().setItemInMainHand(var4);
                           var3.sendMessage(Lang.Prefix.toMsg() + Lang.Admin_Set.toMsg());
                        } else if (var2.length == 3 && var2[1].equalsIgnoreCase("eggtype")) {
                           if (!var4.getType().name().equalsIgnoreCase("MONSTER_EGG")) {
                              var3.sendMessage(Lang.Prefix.toMsg() + Lang.Other_NotAnEgg.toMsg());
                              return;
                           }

                           var25 = var2[2].toUpperCase();
                           var6 = null;

                           EntityType var27;
                           try {
                              var27 = EntityType.valueOf(var25);
                           } catch (IllegalArgumentException var19) {
                              var3.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidType.toMsg().replace("%s", Utils.getEnums(EntityType.class, "§c", "§7")));
                              return;
                           }

                           var4 = ItemAPI.setEggType(var4, var27);
                           var3.getInventory().setItemInMainHand(var4);
                           var3.sendMessage(Lang.Prefix.toMsg() + Lang.Admin_Set.toMsg());
                        } else if (var2.length == 3 && var2[1].equalsIgnoreCase("color")) {
                           if (!var4.getType().name().startsWith("LEATHER_")) {
                              var3.sendMessage(Lang.Prefix.toMsg() + Lang.Other_NotALeather.toMsg());
                              return;
                           }

                           Color var5 = Color.WHITE;
                           var6 = var2[2].split(",");
                           var7 = false;
                           var8 = false;
                           var9 = false;

                           try {
                              var31 = Integer.parseInt(var6[0]);
                              var34 = Integer.parseInt(var6[1]);
                              var36 = Integer.parseInt(var6[2]);
                           } catch (NumberFormatException var18) {
                              var3.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidRGB.toMsg().replace("%s", var2[7]));
                              return;
                           }

                           var5 = Color.fromRGB(var31, var34, var36);
                           var4 = ItemAPI.setLeatherColor(var4, var5);
                           var3.getInventory().setItemInMainHand(var4);
                           var3.sendMessage(Lang.Prefix.toMsg() + Lang.Admin_Set.toMsg());
                        } else {
                           this.printHelp(var3);
                        }
                     }
                  }
               }
            }
         }

      } else {
         var3.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidItem.toMsg());
      }
   }

   private void printHelp(Player var1) {
      Iterator var3 = Lang.Help_Modify.getList().iterator();

      while(var3.hasNext()) {
         String var2 = (String)var3.next();
         var1.sendMessage(var2);
      }

   }

   public String getPermission() {
      return "divineitems.admin";
   }

   public boolean playersOnly() {
      return true;
   }
}
