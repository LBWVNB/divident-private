package su.nightexpress.divineitems.cmds.list;

import org.bukkit.command.CommandSender;
import su.nightexpress.divineitems.DivineItems;
import su.nightexpress.divineitems.cmds.CommandBase;
import su.nightexpress.divineitems.config.Lang;

public class ReloadCommand extends CommandBase {
   private DivineItems plugin;

   public ReloadCommand(DivineItems var1) {
      this.plugin = var1;
   }

   public void perform(CommandSender var1, String[] var2) {
      if (var2.length != 2) {
         var1.sendMessage("§cUsage: §f/di reload <full/cfg>");
      } else {
         if (var2[1].equalsIgnoreCase("full")) {
            this.plugin.reloadFull();
            var1.sendMessage(Lang.Prefix.toMsg() + Lang.Admin_Reload_Full.toMsg());
         } else {
            if (!var2[1].equalsIgnoreCase("cfg")) {
               var1.sendMessage("§cUsage: §f/di reload <full/cfg>");
               return;
            }

            this.plugin.reloadCfg();
            var1.sendMessage(Lang.Prefix.toMsg() + Lang.Admin_Reload_Cfg.toMsg());
         }

      }
   }

   public String getPermission() {
      return "divineitems.admin";
   }

   public boolean playersOnly() {
      return false;
   }
}
