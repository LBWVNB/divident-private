package su.nightexpress.divineitems.cmds.list;

import java.util.Iterator;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import su.nightexpress.divineitems.DivineItems;
import su.nightexpress.divineitems.api.ItemAPI;
import su.nightexpress.divineitems.cmds.CommandBase;
import su.nightexpress.divineitems.config.Lang;
import su.nightexpress.divineitems.modules.repair.RepairManager;

public class RepairCommand extends CommandBase {
   private DivineItems plugin;

   public RepairCommand(DivineItems var1) {
      this.plugin = var1;
   }

   public void perform(CommandSender var1, String[] var2) {
      RepairManager var3 = this.plugin.getMM().getRepairManager();
      if ((var2.length == 2 || var2.length == 3) && var2[1].equalsIgnoreCase("item")) {
         if (!(var1 instanceof Player)) {
            var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidSender.toMsg());
            return;
         }

         int var26 = 999999;
         if (var2.length == 3) {
            try {
               var26 = Integer.parseInt(var2[2]);
            } catch (NumberFormatException var23) {
               var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidNumber.toMsg().replace("%s", var2[2]));
            }
         }

         Player var31 = (Player)var1;
         ItemStack var29 = var31.getInventory().getItemInMainHand();
         if (var29 == null) {
            var31.sendMessage(Lang.Prefix.toMsg() + Lang.Repair_NoItem.toMsg());
            return;
         }

         if (ItemAPI.getDurability(var29, 0) < 0) {
            var31.sendMessage(Lang.Prefix.toMsg() + Lang.Repair_NoDurability.toMsg());
            return;
         }

         var29 = ItemAPI.setDurability(var29, var26, ItemAPI.getDurability(var29, 1));
         var31.getInventory().setItemInMainHand(var29);
      } else {
         int var6;
         int var8;
         Player var25;
         int var28;
         RepairManager.RepairGem var30;
         if (var2.length == 4 && var2[1].equalsIgnoreCase("get")) {
            if (!(var1 instanceof Player)) {
               var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidSender.toMsg());
               return;
            }

            var25 = (Player)var1;
            var28 = 1;
            var6 = 1;

            try {
               var28 = Integer.parseInt(var2[2]);
            } catch (NumberFormatException var22) {
               var25.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidNumber.toMsg().replace("%s", var2[2]));
            }

            try {
               var6 = Integer.parseInt(var2[3]);
            } catch (NumberFormatException var21) {
               var25.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidNumber.toMsg().replace("%s", var2[3]));
            }

            var30 = var3.getGem();

            for(var8 = 0; var8 < var6; ++var8) {
               if (var25.getInventory().firstEmpty() == -1) {
                  var25.getWorld().dropItemNaturally(var25.getLocation(), var30.getItemGem(var28)).setPickupDelay(40);
               } else {
                  var25.getInventory().addItem(new ItemStack[]{var30.getItemGem(var28)});
               }
            }
         } else if (var2.length == 5 && var2[1].equalsIgnoreCase("give")) {
            var25 = Bukkit.getPlayer(var2[2]);
            if (var25 == null) {
               var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidPlayer.toMsg());
               return;
            }

            var28 = 1;
            var6 = 1;

            try {
               var28 = Integer.parseInt(var2[3]);
            } catch (NumberFormatException var20) {
               var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidNumber.toMsg().replace("%s", var2[3]));
            }

            try {
               var6 = Integer.parseInt(var2[4]);
            } catch (NumberFormatException var19) {
               var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidNumber.toMsg().replace("%s", var2[4]));
            }

            var30 = var3.getGem();

            for(var8 = 0; var8 < var6; ++var8) {
               if (var25.getInventory().firstEmpty() == -1) {
                  var25.getWorld().dropItemNaturally(var25.getLocation(), var30.getItemGem(var28)).setPickupDelay(40);
               } else {
                  var25.getInventory().addItem(new ItemStack[]{var30.getItemGem(var28)});
               }
            }
         } else {
            if (var2.length != 8 || !var2[1].equalsIgnoreCase("drop")) {
               Iterator var27 = Lang.Help_Repair.getList().iterator();

               while(var27.hasNext()) {
                  String var24 = (String)var27.next();
                  var1.sendMessage(var24.replace("%m_state%", this.plugin.getMM().getColorStatus(var3.isActive())).replace("%m_ver%", var3.version()).replace("%m_name%", var3.name()));
               }

               return;
            }

            World var4 = Bukkit.getWorld(var2[2]);
            if (var4 == null) {
               var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidWorld.toMsg().replace("%s", var2[2]));
               return;
            }

            double var5 = 0.0D;
            double var7 = 0.0D;
            double var9 = 0.0D;

            try {
               var5 = Double.parseDouble(var2[3]);
               var7 = Double.parseDouble(var2[4]);
               var9 = Double.parseDouble(var2[5]);
            } catch (NumberFormatException var18) {
               var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidCoordinates.toMsg().replace("%s", var2[3] + " " + var2[4] + " " + var2[5]));
            }

            int var11 = 1;
            int var12 = 2;

            try {
               var11 = Integer.parseInt(var2[6]);
            } catch (NumberFormatException var17) {
               var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidNumber.toMsg().replace("%s", var2[6]));
            }

            try {
               var12 = Integer.parseInt(var2[7]);
            } catch (NumberFormatException var16) {
               var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidNumber.toMsg().replace("%s", var2[7]));
            }

            RepairManager.RepairGem var13 = var3.getGem();
            Location var14 = new Location(var4, var5, var7, var9);

            for(int var15 = 0; var15 < var12; ++var15) {
               var4.dropItemNaturally(var14, var13.getItemGem(var11)).setPickupDelay(40);
            }
         }
      }

   }

   public String getPermission() {
      return "divineitems.admin";
   }

   public boolean playersOnly() {
      return false;
   }
}
