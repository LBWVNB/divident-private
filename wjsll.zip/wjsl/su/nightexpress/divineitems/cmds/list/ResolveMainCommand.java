package su.nightexpress.divineitems.cmds.list;

import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import su.nightexpress.divineitems.DivineItems;
import su.nightexpress.divineitems.cmds.CommandBase;
import su.nightexpress.divineitems.config.Lang;

public class ResolveMainCommand extends CommandBase {
   private DivineItems plugin;

   public ResolveMainCommand(DivineItems var1) {
      this.plugin = var1;
   }

   public void perform(CommandSender var1, String[] var2) {
      Player var3 = null;
      if (var2.length == 2) {
         var3 = Bukkit.getPlayer(var2[1]);
      } else if (var1 instanceof Player) {
         var3 = (Player)var1;
      }

      if (var3 == null) {
         var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidPlayer.toMsg());
      } else {
         this.plugin.getMM().getResolveManager().openResolveGUI(var3);
      }
   }

   public String getPermission() {
      return "divineitems.resolve";
   }

   public boolean playersOnly() {
      return false;
   }
}
