package su.nightexpress.divineitems.cmds.list;

import java.util.Iterator;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import su.nightexpress.divineitems.DivineItems;
import su.nightexpress.divineitems.cmds.CommandBase;
import su.nightexpress.divineitems.config.Lang;
import su.nightexpress.divineitems.modules.scrolls.ScrollManager;
import su.nightexpress.divineitems.utils.Utils;

public class ScrollsCommand extends CommandBase {
   private DivineItems plugin;

   public ScrollsCommand(DivineItems var1) {
      this.plugin = var1;
   }

   public void perform(CommandSender var1, String[] var2) {
      ScrollManager var3 = this.plugin.getMM().getScrollManager();
      if ((var2.length == 2 || var2.length == 3) && var2[1].equalsIgnoreCase("list")) {
         int var27 = 1;
         if (var2.length == 3) {
            try {
               var27 = Integer.parseInt(var2[2]);
            } catch (NumberFormatException var24) {
               var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidNumber.toMsg().replace("%s", var2[3]));
            }
         }

         Utils.interactiveList(var1, var27, var3.getScrollNames(), var3.name(), "-1 1");
      } else {
         ScrollManager.Scroll var6;
         int var8;
         Player var26;
         String var29;
         int var30;
         int var31;
         if (var2.length == 5 && var2[1].equalsIgnoreCase("get")) {
            if (!(var1 instanceof Player)) {
               var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidSender.toMsg());
               return;
            }

            var26 = (Player)var1;
            var29 = var2[2];
            var6 = var3.getScrollById(var29);
            if (var6 == null) {
               var26.sendMessage(Lang.Prefix.toMsg() + Lang.Scrolls_Invalid.toMsg().replace("%s", var29));
               return;
            }

            var30 = 1;
            var8 = 1;

            try {
               var30 = Integer.parseInt(var2[3]);
            } catch (NumberFormatException var23) {
               var26.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidNumber.toMsg().replace("%s", var2[3]));
            }

            try {
               var8 = Integer.parseInt(var2[4]);
            } catch (NumberFormatException var22) {
               var26.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidNumber.toMsg().replace("%s", var2[4]));
            }

            for(var31 = 0; var31 < var8; ++var31) {
               if (var29.equalsIgnoreCase("random")) {
                  var6 = var3.getScrollById(var29);
               }

               if (var26.getInventory().firstEmpty() == -1) {
                  var26.getWorld().dropItemNaturally(var26.getLocation(), var6.create(var30)).setPickupDelay(40);
               } else {
                  var26.getInventory().addItem(new ItemStack[]{var6.create(var30)});
               }
            }
         } else if (var2.length == 6 && var2[1].equalsIgnoreCase("give")) {
            var26 = Bukkit.getPlayer(var2[2]);
            if (var26 == null) {
               var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidPlayer.toMsg());
               return;
            }

            var29 = var2[3];
            var6 = var3.getScrollById(var29);
            if (var6 == null) {
               var1.sendMessage(Lang.Prefix.toMsg() + Lang.Scrolls_Invalid.toMsg().replace("%s", var29));
               return;
            }

            var30 = 1;
            var8 = 1;

            try {
               var30 = Integer.parseInt(var2[4]);
            } catch (NumberFormatException var21) {
               var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidNumber.toMsg().replace("%s", var2[4]));
            }

            try {
               var8 = Integer.parseInt(var2[5]);
            } catch (NumberFormatException var20) {
               var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidNumber.toMsg().replace("%s", var2[5]));
            }

            for(var31 = 0; var31 < var8; ++var31) {
               if (var29.equalsIgnoreCase("random")) {
                  var6 = var3.getScrollById(var29);
               }

               if (var26.getInventory().firstEmpty() == -1) {
                  var26.getWorld().dropItemNaturally(var26.getLocation(), var6.create(var30)).setPickupDelay(40);
               } else {
                  var26.getInventory().addItem(new ItemStack[]{var6.create(var30)});
               }
            }
         } else {
            if (var2.length != 9 || !var2[1].equalsIgnoreCase("drop")) {
               Iterator var28 = Lang.Help_Scrolls.getList().iterator();

               while(var28.hasNext()) {
                  String var25 = (String)var28.next();
                  var1.sendMessage(var25.replace("%m_state%", this.plugin.getMM().getColorStatus(var3.isActive())).replace("%m_ver%", var3.version()).replace("%m_name%", var3.name()));
               }

               return;
            }

            World var4 = Bukkit.getWorld(var2[2]);
            if (var4 == null) {
               var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidWorld.toMsg().replace("%s", var2[2]));
               return;
            }

            double var5 = 0.0D;
            double var7 = 0.0D;
            double var9 = 0.0D;

            try {
               var5 = Double.parseDouble(var2[3]);
               var7 = Double.parseDouble(var2[4]);
               var9 = Double.parseDouble(var2[5]);
            } catch (NumberFormatException var19) {
               var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidCoordinates.toMsg().replace("%s", var2[3] + " " + var2[4] + " " + var2[5]));
            }

            String var11 = var2[6];
            ScrollManager.Scroll var12 = var3.getScrollById(var11);
            if (var12 == null) {
               var1.sendMessage(Lang.Prefix.toMsg() + Lang.Scrolls_Invalid.toMsg().replace("%s", var11));
               return;
            }

            int var13 = 1;
            int var14 = 1;

            try {
               var13 = Integer.parseInt(var2[7]);
            } catch (NumberFormatException var18) {
               var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidNumber.toMsg().replace("%s", var2[7]));
            }

            try {
               var14 = Integer.parseInt(var2[8]);
            } catch (NumberFormatException var17) {
               var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidNumber.toMsg().replace("%s", var2[8]));
            }

            Location var15 = new Location(var4, var5, var7, var9);

            for(int var16 = 0; var16 < var14; ++var16) {
               if (var11.equalsIgnoreCase("random")) {
                  var12 = var3.getScrollById(var11);
               }

               var4.dropItemNaturally(var15, var12.create(var13)).setPickupDelay(40);
            }
         }
      }

   }

   public String getPermission() {
      return "divineitems.admin";
   }

   public boolean playersOnly() {
      return false;
   }
}
