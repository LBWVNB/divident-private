package su.nightexpress.divineitems.cmds.list;

import java.util.Iterator;
import org.apache.commons.lang.StringUtils;
import org.bukkit.Material;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import su.nightexpress.divineitems.DivineItems;
import su.nightexpress.divineitems.api.ItemAPI;
import su.nightexpress.divineitems.attributes.ItemStat;
import su.nightexpress.divineitems.cmds.CommandBase;
import su.nightexpress.divineitems.config.Lang;
import su.nightexpress.divineitems.types.AmmoType;
import su.nightexpress.divineitems.types.ArmorType;
import su.nightexpress.divineitems.types.DamageType;
import su.nightexpress.divineitems.types.SlotType;
import su.nightexpress.divineitems.utils.Utils;

public class SetCommand extends CommandBase {
   private DivineItems plugin;

   public SetCommand(DivineItems var1) {
      this.plugin = var1;
   }

   public void perform(CommandSender var1, String[] var2) {
      Player var3 = (Player)var1;
      ItemStack var4 = var3.getInventory().getItemInMainHand();
      if (var4 != null && var4.getType() != Material.AIR) {
         int var5 = -1;
         if (var2.length == 4 && StringUtils.isNumeric(var2[3])) {
            var5 = Integer.parseInt(var2[3]);
         } else if (var2.length == 5 && StringUtils.isNumeric(var2[4])) {
            var5 = Integer.parseInt(var2[4]);
         } else if (var2.length == 6 && StringUtils.isNumeric(var2[5])) {
            var5 = Integer.parseInt(var2[5]);
         } else if (var2.length == 8 && StringUtils.isNumeric(var2[7])) {
            var5 = Integer.parseInt(var2[7]);
         }

         if (var2.length == 3 && var2[1].equalsIgnoreCase("level")) {
            int var27 = -1;
            if (StringUtils.isNumeric(var2[2])) {
               var27 = Integer.parseInt(var2[2]);
            }

            var3.getInventory().setItemInMainHand(ItemAPI.setLevelRequired(var4, var27, var5));
            var3.sendMessage(Lang.Prefix.toMsg() + Lang.Admin_Set.toMsg());
         } else {
            String var6;
            if (var2.length == 3 && var2[1].equalsIgnoreCase("slot")) {
               var6 = null;

               SlotType var26;
               try {
                  var26 = SlotType.valueOf(var2[2].toUpperCase());
               } catch (IllegalArgumentException var19) {
                  var3.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidType.toMsg().replace("%s", Utils.getEnums(SlotType.class, "§c", "§7")));
                  return;
               }

               var4 = ItemAPI.addDivineSlot(var4, var26, -1);
               var3.getInventory().setItemInMainHand(var4);
               var3.sendMessage(Lang.Prefix.toMsg() + Lang.Admin_Set.toMsg());
            } else if (var2.length == 3 && var2[1].equalsIgnoreCase("class")) {
               var3.getInventory().setItemInMainHand(ItemAPI.setClassRequired(var4, var2[2], var5));
               var3.sendMessage(Lang.Prefix.toMsg() + Lang.Admin_Set.toMsg());
            } else {
               double var23;
               if (var2.length == 5 && var2[1].equalsIgnoreCase("damagetype")) {
                  var23 = 0.0D;
                  double var25 = 0.0D;

                  try {
                     var23 = Double.parseDouble(var2[3]);
                     var25 = Double.parseDouble(var2[4]);
                  } catch (NumberFormatException var12) {
                     var3.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidNumber.toMsg().replace("%s", var2[3]));
                     return;
                  }

                  DamageType var29 = (DamageType)this.plugin.getCFG().getDamageTypes().get(var2[2].toLowerCase());
                  if (var29 == null) {
                     var1.sendMessage("xyu");
                     return;
                  }

                  var3.getInventory().setItemInMainHand(ItemAPI.addDamageType(var4, var29, var23, var25, var5));
                  var3.sendMessage(Lang.Prefix.toMsg() + Lang.Admin_Set.toMsg());
                  return;
               }

               if (var2.length == 4 && (var2[1].equalsIgnoreCase("armortype") || var2[1].equalsIgnoreCase("defensetype"))) {
                  var23 = -1.0D;

                  try {
                     var23 = Double.parseDouble(var2[3]);
                  } catch (NumberFormatException var13) {
                     var3.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidNumber.toMsg().replace("%s", var2[3]));
                     return;
                  }

                  ArmorType var24 = (ArmorType)this.plugin.getCFG().getArmorTypes().get(var2[2].toLowerCase());
                  var3.getInventory().setItemInMainHand(ItemAPI.addDefenseType(var4, var24, var23, var5));
                  var3.sendMessage(Lang.Prefix.toMsg() + Lang.Admin_Set.toMsg());
                  return;
               }

               if (var2.length == 3 && var2[1].equalsIgnoreCase("ammotype")) {
                  AmmoType var22;
                  try {
                     var22 = AmmoType.valueOf(var2[2].toUpperCase());
                  } catch (IllegalArgumentException var14) {
                     var3.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidType.toMsg().replace("%s", Utils.getEnums(AmmoType.class, "§a", "§7")));
                     return;
                  }

                  var3.getInventory().setItemInMainHand(ItemAPI.setAmmoType(var4, var22, var5));
                  var3.sendMessage(Lang.Prefix.toMsg() + Lang.Admin_Set.toMsg());
                  return;
               }

               ItemStat var20;
               if ((var2.length == 5 || var2.length == 6) && var2[1].equalsIgnoreCase("attribute")) {
                  var6 = null;

                  try {
                     var20 = ItemStat.valueOf(var2[2].toUpperCase());
                  } catch (IllegalArgumentException var18) {
                     var3.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidType.toMsg().replace("%s", Utils.getEnums(ItemStat.class, "§a", "§7")));
                     return;
                  }

                  var3.getInventory().setItemInMainHand(ItemAPI.addAttribute(var4, var20, false, var2[3], var2[4], var5));
                  var3.sendMessage(Lang.Prefix.toMsg() + Lang.Admin_AttributeSet.toMsg().replace("%s", var2[2]));
               } else if (var2.length == 4 && var2[1].equalsIgnoreCase("bonus")) {
                  var6 = null;

                  try {
                     var20 = ItemStat.valueOf(var2[2].toUpperCase());
                  } catch (IllegalArgumentException var17) {
                     var3.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidType.toMsg().replace("%s", Utils.getEnums(ItemStat.class, "§a", "§7")));
                     return;
                  }

                  var3.getInventory().setItemInMainHand(ItemAPI.addAttribute(var4, var20, true, var2[3], "", var5));
                  var3.sendMessage(Lang.Prefix.toMsg() + Lang.Admin_AttributeSet.toMsg().replace("%s", var2[2]));
               } else if (var2.length == 7 && var2[1].equalsIgnoreCase("ability")) {
                  var6 = var2[2].toLowerCase();
                  if (this.plugin.getMM().getAbilityManager().getAbilityById(var6) == null) {
                     var1.sendMessage("§cAbility §f" + var6 + "§c does not exist!");
                     return;
                  }

                  boolean var7 = true;

                  int var21;
                  try {
                     var21 = Integer.parseInt(var2[3]);
                  } catch (NumberFormatException var16) {
                     var3.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidNumber.toMsg().replace("%s", var2[3]));
                     return;
                  }

                  String var8 = var2[4];
                  if (!var8.equalsIgnoreCase("RIGHT") && !var8.equalsIgnoreCase("LEFT")) {
                     var1.sendMessage("§cKey value must be §fLEFT §cor §fRIGHT");
                     var8 = "LEFT";
                  }

                  boolean var9 = Boolean.valueOf(var2[5]);
                  boolean var10 = true;

                  int var28;
                  try {
                     var28 = Integer.parseInt(var2[6]);
                  } catch (NumberFormatException var15) {
                     var3.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidNumber.toMsg().replace("%s", var2[6]));
                     return;
                  }

                  var3.getInventory().setItemInMainHand(ItemAPI.addAbility(var4, var6, var21, var8, var9, var28, var5));
                  var3.sendMessage(Lang.Prefix.toMsg() + Lang.Admin_AttributeSet.toMsg().replace("%s", var2[2]));
               } else {
                  this.printHelp(var3);
               }
            }
         }

      } else {
         var3.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidItem.toMsg());
      }
   }

   private void printHelp(Player var1) {
      Iterator var3 = Lang.Help_Set.getList().iterator();

      while(var3.hasNext()) {
         String var2 = (String)var3.next();
         var1.sendMessage(var2);
      }

   }

   public String getPermission() {
      return "divineitems.admin";
   }

   public boolean playersOnly() {
      return true;
   }
}
