package su.nightexpress.divineitems.cmds.list;

import java.util.Iterator;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import su.nightexpress.divineitems.DivineItems;
import su.nightexpress.divineitems.cmds.CommandBase;
import su.nightexpress.divineitems.config.Lang;
import su.nightexpress.divineitems.modules.sets.SetManager;
import su.nightexpress.divineitems.utils.Utils;

public class SetsCommand extends CommandBase {
   private DivineItems plugin;

   public SetsCommand(DivineItems var1) {
      this.plugin = var1;
   }

   public void perform(CommandSender var1, String[] var2) {
      SetManager var3 = this.plugin.getMM().getSetManager();
      if ((var2.length == 2 || var2.length == 3) && var2[1].equalsIgnoreCase("list")) {
         int var24 = 1;
         if (var2.length == 3) {
            try {
               var24 = Integer.parseInt(var2[2]);
            } catch (NumberFormatException var21) {
               var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidNumber.toMsg().replace("%s", var2[3]));
            }
         }

         Utils.interactiveList(var1, var24, var3.getSetNames(), var3.name(), "random 1");
      } else {
         Player var23;
         if (var2.length == 2 && var2[1].equalsIgnoreCase("test")) {
            if (!(var1 instanceof Player)) {
               var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidSender.toMsg());
               return;
            }

            var23 = (Player)var1;
            ItemStack var27 = var23.getInventory().getItemInMainHand();
            var27 = var3.replaceLore(var27);
            var23.getInventory().setItemInMainHand(var27);
            var23.sendMessage("Done!");
         } else {
            String var6;
            SetManager.ItemSet var8;
            String var26;
            int var28;
            int var29;
            if (var2.length == 5 && var2[1].equalsIgnoreCase("get")) {
               if (!(var1 instanceof Player)) {
                  var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidSender.toMsg());
                  return;
               }

               var23 = (Player)var1;
               var26 = var2[2];
               var6 = var2[3];
               var28 = 1;

               try {
                  var28 = Integer.parseInt(var2[4]);
               } catch (NumberFormatException var20) {
                  var23.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidNumber.toMsg().replace("%s", var2[4]));
               }

               var8 = var3.getSetById(var26);
               if (var8 == null) {
                  var23.sendMessage(Lang.Prefix.toMsg() + Lang.Sets_Invalid.toMsg().replace("%s", var26));
                  return;
               }

               for(var29 = 0; var29 < var28; ++var29) {
                  if (var26.equalsIgnoreCase("random")) {
                     var8 = var3.getSetById(var26);
                  }

                  if (var23.getInventory().firstEmpty() == -1) {
                     var23.getWorld().dropItemNaturally(var23.getLocation(), var8.create(var6)).setPickupDelay(40);
                  } else {
                     var23.getInventory().addItem(new ItemStack[]{var8.create(var6)});
                  }
               }
            } else if (var2.length == 6 && var2[1].equalsIgnoreCase("give")) {
               var23 = Bukkit.getPlayer(var2[2]);
               if (var23 == null) {
                  var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidPlayer.toMsg());
                  return;
               }

               var26 = var2[3];
               var6 = var2[4];
               var28 = 1;

               try {
                  var28 = Integer.parseInt(var2[5]);
               } catch (NumberFormatException var19) {
                  var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidNumber.toMsg().replace("%s", var2[5]));
               }

               var8 = var3.getSetById(var26);
               if (var8 == null) {
                  var1.sendMessage(Lang.Prefix.toMsg() + Lang.Sets_Invalid.toMsg().replace("%s", var26));
                  return;
               }

               for(var29 = 0; var29 < var28; ++var29) {
                  if (var26.equalsIgnoreCase("random")) {
                     var8 = var3.getSetById(var26);
                  }

                  if (var23.getInventory().firstEmpty() == -1) {
                     var23.getWorld().dropItemNaturally(var23.getLocation(), var8.create(var6)).setPickupDelay(40);
                  } else {
                     var23.getInventory().addItem(new ItemStack[]{var8.create(var6)});
                  }
               }
            } else {
               if (var2.length != 9 || !var2[1].equalsIgnoreCase("drop")) {
                  Iterator var25 = Lang.Help_Sets.getList().iterator();

                  while(var25.hasNext()) {
                     String var22 = (String)var25.next();
                     var1.sendMessage(var22.replace("%m_state%", this.plugin.getMM().getColorStatus(var3.isActive())).replace("%m_ver%", var3.version()).replace("%m_name%", var3.name()));
                  }

                  return;
               }

               World var4 = Bukkit.getWorld(var2[2]);
               if (var4 == null) {
                  var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidWorld.toMsg().replace("%s", var2[2]));
                  return;
               }

               double var5 = 0.0D;
               double var7 = 0.0D;
               double var9 = 0.0D;

               try {
                  var5 = Double.parseDouble(var2[3]);
                  var7 = Double.parseDouble(var2[4]);
                  var9 = Double.parseDouble(var2[5]);
               } catch (NumberFormatException var18) {
                  var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidCoordinates.toMsg().replace("%s", var2[3] + " " + var2[4] + " " + var2[5]));
               }

               String var11 = var2[6];
               String var12 = var2[7];
               int var13 = 1;

               try {
                  var13 = Integer.parseInt(var2[8]);
               } catch (NumberFormatException var17) {
                  var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidNumber.toMsg().replace("%s", var2[8]));
               }

               SetManager.ItemSet var14 = var3.getSetById(var11);
               if (var14 == null) {
                  var1.sendMessage(Lang.Prefix.toMsg() + Lang.Sets_Invalid.toMsg().replace("%s", var11));
                  return;
               }

               Location var15 = new Location(var4, var5, var7, var9);

               for(int var16 = 0; var16 < var13; ++var16) {
                  if (var11.equalsIgnoreCase("random")) {
                     var14 = var3.getSetById(var11);
                  }

                  var4.dropItemNaturally(var15, var14.create(var12)).setPickupDelay(40);
               }
            }
         }
      }

   }

   public String getPermission() {
      return "divineitems.admin";
   }

   public boolean playersOnly() {
      return false;
   }
}
