package su.nightexpress.divineitems.cmds.list;

import java.util.Iterator;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import su.nightexpress.divineitems.DivineItems;
import su.nightexpress.divineitems.api.ItemAPI;
import su.nightexpress.divineitems.cmds.CommandBase;
import su.nightexpress.divineitems.config.Lang;
import su.nightexpress.divineitems.modules.soulbound.SoulboundManager;

public class SoulboundCommand extends CommandBase {
   private DivineItems plugin;

   public SoulboundCommand(DivineItems var1) {
      this.plugin = var1;
   }

   public void perform(CommandSender var1, String[] var2) {
      SoulboundManager var3 = this.plugin.getMM().getSoulboundManager();
      Player var4 = (Player)var1;
      int var5;
      ItemStack var6;
      if (var2.length == 3 || var2.length == 4 && var2[1].equalsIgnoreCase("set")) {
         var5 = -1;
         if (var2.length == 4) {
            try {
               var5 = Integer.parseInt(var2[3]);
            } catch (NumberFormatException var8) {
               var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidNumber.toMsg().replace("%s", var2[3]));
            }
         }

         var6 = var4.getInventory().getItemInMainHand();
         if (var6 == null) {
            var4.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidItem.toMsg());
            return;
         }

         var6 = ItemAPI.setSoulboundRequired(var6, var2[2], var5);
         var4.getInventory().setItemInMainHand(var6);
      } else {
         if (var2.length != 3 && (var2.length != 4 || !var2[1].equalsIgnoreCase("untrade"))) {
            Iterator var10 = Lang.Help_Soulbound.getList().iterator();

            while(var10.hasNext()) {
               String var9 = (String)var10.next();
               var1.sendMessage(var9.replace("%m_state%", this.plugin.getMM().getColorStatus(var3.isActive())).replace("%m_ver%", var3.version()).replace("%m_name%", var3.name()));
            }

            return;
         }

         var5 = -1;
         if (var2.length == 4) {
            try {
               var5 = Integer.parseInt(var2[3]);
            } catch (NumberFormatException var7) {
               var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidNumber.toMsg().replace("%s", var2[3]));
            }
         }

         var6 = var4.getInventory().getItemInMainHand();
         if (var6 == null) {
            var4.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidItem.toMsg());
            return;
         }

         var6 = ItemAPI.setUntradeable(var6, var2[2], var5);
         var4.getInventory().setItemInMainHand(var6);
      }

   }

   public String getPermission() {
      return "divineitems.admin";
   }

   public boolean playersOnly() {
      return true;
   }
}
