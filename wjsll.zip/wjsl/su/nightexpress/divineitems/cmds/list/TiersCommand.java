package su.nightexpress.divineitems.cmds.list;

import java.util.Iterator;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import su.nightexpress.divineitems.DivineItems;
import su.nightexpress.divineitems.cmds.CommandBase;
import su.nightexpress.divineitems.config.Lang;
import su.nightexpress.divineitems.modules.tiers.TierManager;
import su.nightexpress.divineitems.utils.Utils;

public class TiersCommand extends CommandBase {
   private DivineItems plugin;

   public TiersCommand(DivineItems var1) {
      this.plugin = var1;
   }

   public void perform(CommandSender var1, String[] var2) {
      TierManager var3 = this.plugin.getMM().getTierManager();
      if ((var2.length == 2 || var2.length == 3) && var2[1].equalsIgnoreCase("list")) {
         int var27 = 1;
         if (var2.length == 3) {
            try {
               var27 = Integer.parseInt(var2[2]);
            } catch (NumberFormatException var24) {
               var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidNumber.toMsg().replace("%s", var2[3]));
            }
         }

         Utils.interactiveList(var1, var27, var3.getTierNames(), var3.name(), "-1 1");
      } else {
         int var6;
         TierManager.Tier var8;
         Player var26;
         String var29;
         int var30;
         int var31;
         if (var2.length == 5 && var2[1].equalsIgnoreCase("get")) {
            if (!(var1 instanceof Player)) {
               var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidSender.toMsg());
               return;
            }

            var26 = (Player)var1;
            var29 = var2[2];
            var6 = 1;
            var30 = 2;

            try {
               var6 = Integer.parseInt(var2[3]);
            } catch (NumberFormatException var23) {
               var26.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidNumber.toMsg().replace("%s", var2[3]));
            }

            try {
               var30 = Integer.parseInt(var2[4]);
            } catch (NumberFormatException var22) {
               var26.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidNumber.toMsg().replace("%s", var2[4]));
            }

            var8 = var3.getTierById(var29);
            if (var8 == null) {
               var26.sendMessage(Lang.Prefix.toMsg() + Lang.Tiers_Invalid.toMsg().replace("%s", var29));
               return;
            }

            for(var31 = 0; var31 < var30; ++var31) {
               if (var29.equalsIgnoreCase("random")) {
                  var8 = var3.getTierById(var29);
               }

               if (var26.getInventory().firstEmpty() == -1) {
                  var26.getWorld().dropItemNaturally(var26.getLocation(), var8.create(var6, (Material)null)).setPickupDelay(40);
               } else {
                  var26.getInventory().addItem(new ItemStack[]{var8.create(var6, (Material)null)});
               }
            }
         } else if (var2.length == 6 && var2[1].equalsIgnoreCase("give")) {
            var26 = Bukkit.getPlayer(var2[2]);
            if (var26 == null) {
               var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidPlayer.toMsg());
               return;
            }

            var29 = var2[3];
            var6 = 1;
            var30 = 2;

            try {
               var6 = Integer.parseInt(var2[4]);
            } catch (NumberFormatException var21) {
               var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidNumber.toMsg().replace("%s", var2[4]));
            }

            try {
               var30 = Integer.parseInt(var2[5]);
            } catch (NumberFormatException var20) {
               var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidNumber.toMsg().replace("%s", var2[5]));
            }

            var8 = var3.getTierById(var29);
            if (var8 == null) {
               var1.sendMessage(Lang.Prefix.toMsg() + Lang.Tiers_Invalid.toMsg().replace("%s", var29));
               return;
            }

            for(var31 = 0; var31 < var30; ++var31) {
               if (var29.equalsIgnoreCase("random")) {
                  var8 = var3.getTierById(var29);
               }

               if (var26.getInventory().firstEmpty() == -1) {
                  var26.getWorld().dropItemNaturally(var26.getLocation(), var8.create(var6, (Material)null)).setPickupDelay(40);
               } else {
                  var26.getInventory().addItem(new ItemStack[]{var8.create(var6, (Material)null)});
               }
            }
         } else {
            if (var2.length != 9 || !var2[1].equalsIgnoreCase("drop")) {
               Iterator var28 = Lang.Help_Tiers.getList().iterator();

               while(var28.hasNext()) {
                  String var25 = (String)var28.next();
                  var1.sendMessage(var25.replace("%m_state%", this.plugin.getMM().getColorStatus(var3.isActive())).replace("%m_ver%", var3.version()).replace("%m_name%", var3.name()));
               }

               return;
            }

            World var4 = Bukkit.getWorld(var2[2]);
            if (var4 == null) {
               var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidWorld.toMsg().replace("%s", var2[2]));
               return;
            }

            double var5 = 0.0D;
            double var7 = 0.0D;
            double var9 = 0.0D;

            try {
               var5 = Double.parseDouble(var2[3]);
               var7 = Double.parseDouble(var2[4]);
               var9 = Double.parseDouble(var2[5]);
            } catch (NumberFormatException var19) {
               var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidCoordinates.toMsg().replace("%s", var2[3] + " " + var2[4] + " " + var2[5]));
            }

            String var11 = var2[6];
            int var12 = 1;
            int var13 = 2;

            try {
               var12 = Integer.parseInt(var2[7]);
            } catch (NumberFormatException var18) {
               var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidNumber.toMsg().replace("%s", var2[7]));
            }

            try {
               var13 = Integer.parseInt(var2[8]);
            } catch (NumberFormatException var17) {
               var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_InvalidNumber.toMsg().replace("%s", var2[8]));
            }

            TierManager.Tier var14 = var3.getTierById(var11);
            if (var14 == null) {
               var1.sendMessage(Lang.Prefix.toMsg() + Lang.Tiers_Invalid.toMsg().replace("%s", var11));
               return;
            }

            Location var15 = new Location(var4, var5, var7, var9);

            for(int var16 = 0; var16 < var13; ++var16) {
               if (var11.equalsIgnoreCase("random")) {
                  var14 = var3.getTierById(var11);
               }

               var4.dropItemNaturally(var15, var14.create(var12, (Material)null)).setPickupDelay(40);
            }
         }
      }

   }

   public String getPermission() {
      return "divineitems.admin";
   }

   public boolean playersOnly() {
      return false;
   }
}
