package su.nightexpress.divineitems.config;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import net.md_5.bungee.api.ChatColor;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;
import su.nightexpress.divineitems.attributes.BleedRateSettings;
import su.nightexpress.divineitems.attributes.DisarmRateSettings;
import su.nightexpress.divineitems.attributes.ItemStat;
import su.nightexpress.divineitems.hooks.Hook;
import su.nightexpress.divineitems.types.AmmoType;
import su.nightexpress.divineitems.types.ArmorType;
import su.nightexpress.divineitems.types.DamageType;

public class Config {
   private MyConfig config;
   private String lang;
   private Hook g_LevelPlugin;
   private Hook g_ClassPlugin;
   private String global_dformula_dmg;
   private String global_dformula_other;
   private double g_dmgReduce;
   private boolean g_itemsBreak;
   private int g_targetDist;
   private String g_attFormat;
   private String g_dtFormat;
   private String g_atFormat;
   private String g_ammoFormat;
   private boolean g_mobAtt;
   private boolean g_fishHookDmg;
   private boolean g_offAtt;
   private boolean g_sapiDur;
   private HashMap<String, Boolean> modules;
   private HashMap<DamageCause, Double> damage_values_p;
   private HashMap<DamageCause, Double> damage_values_m;
   private HashMap<String, DamageType> damage_types;
   private HashMap<String, ArmorType> armor_types;
   private String str_dmgSep;
   private String str_durSep;
   private String str_pc;
   private String str_neg;
   private String str_pos;
   private String str_mod;
   private String str_lvl;
   private String str_cls;
   private String str_clsSep;
   private String str_clsCol;
   private Set<Material> wpn;
   private Set<Material> tool;
   private Set<Material> arm;

   public Config(MyConfig var1) {
      this.config = var1;
      this.setup();
   }

   private void setup() {
      FileConfiguration var1 = this.config.getConfig();
      this.lang = var1.getString("Lang");
      String var2 = var1.getString("Global.LevelPlugin");
      String var3 = var1.getString("Global.ClassPlugin");
      Hook[] var7;
      int var6 = (var7 = Hook.values()).length;

      for(int var5 = 0; var5 < var6; ++var5) {
         Hook var4 = var7[var5];
         if (var4.isLevelPlugin() && var4.getPluginName().equalsIgnoreCase(var2)) {
            this.g_LevelPlugin = var4;
         }

         if (var4.isClassPlugin() && var4.getPluginName().equalsIgnoreCase(var3)) {
            this.g_ClassPlugin = var4;
         }
      }

      if (this.g_LevelPlugin == null) {
         try {
            this.g_LevelPlugin = Hook.valueOf(var2.toUpperCase());
         } catch (IllegalArgumentException var20) {
            this.g_LevelPlugin = Hook.NONE;
         }
      }

      if (this.g_ClassPlugin == null) {
         try {
            this.g_ClassPlugin = Hook.valueOf(var3.toUpperCase());
         } catch (IllegalArgumentException var19) {
            this.g_ClassPlugin = Hook.NONE;
         }
      }

      if (!this.g_LevelPlugin.isLevelPlugin() && this.g_LevelPlugin != Hook.NONE) {
         Bukkit.getConsoleSender().sendMessage("Warning: §c" + this.g_LevelPlugin.getPluginName() + "§7 is not a level plugin!");
      }

      if (!this.g_ClassPlugin.isClassPlugin() && this.g_ClassPlugin != Hook.NONE) {
         Bukkit.getConsoleSender().sendMessage("Warning: §c" + this.g_LevelPlugin.getPluginName() + "§7 is not a class plugin!");
      }

      this.global_dformula_dmg = var1.getString("Global.DamageFormula.damage");
      this.global_dformula_other = var1.getString("Global.DamageFormula.other");
      this.g_dmgReduce = var1.getDouble("Global.DamageReduceCooldown");
      this.g_itemsBreak = var1.getBoolean("Global.BreakItems");
      this.g_targetDist = var1.getInt("Global.MaxGetTargetDistance");
      this.g_attFormat = ChatColor.translateAlternateColorCodes('&', var1.getString("Global.AttributeFormat"));
      this.g_dtFormat = ChatColor.translateAlternateColorCodes('&', var1.getString("Global.DamageTypeFormat"));
      this.g_atFormat = ChatColor.translateAlternateColorCodes('&', var1.getString("Global.ArmorTypeFormat"));
      this.g_ammoFormat = ChatColor.translateAlternateColorCodes('&', var1.getString("Global.AmmoTypeFormat"));
      this.g_mobAtt = var1.getBoolean("Global.AllowAttributesToMobs");
      this.g_fishHookDmg = var1.getBoolean("Global.AllowFishHookDamage");
      this.g_offAtt = var1.getBoolean("Global.AllowAttributesInOffHand");
      this.g_sapiDur = var1.getBoolean("Global.SkillAPISkillsReduceDurability");
      this.modules = new HashMap();
      Iterator var24 = var1.getConfigurationSection("Modules").getKeys(false).iterator();

      String var23;
      while(var24.hasNext()) {
         var23 = (String)var24.next();
         boolean var25 = var1.getBoolean("Modules." + var23);
         this.modules.put(var23, var25);
      }

      this.damage_values_p = new HashMap();
      this.damage_values_m = new HashMap();
      var24 = var1.getConfigurationSection("DamageModifiers").getKeys(false).iterator();

      DamageCause var26;
      while(var24.hasNext()) {
         var23 = (String)var24.next();

         try {
            var26 = DamageCause.valueOf(var23.toUpperCase());
            double var28 = var1.getDouble("DamageModifiers." + var23 + ".PLAYER");
            double var9 = var1.getDouble("DamageModifiers." + var23 + ".MOB");
            this.damage_values_p.put(var26, var28);
            this.damage_values_m.put(var26, var9);
         } catch (IllegalArgumentException var18) {
         }
      }

      this.damage_types = new HashMap();
      var24 = var1.getConfigurationSection("DamageTypes").getKeys(false).iterator();

      String var8;
      String var10;
      String var13;
      Iterator var14;
      String var27;
      boolean var29;
      String var33;
      while(var24.hasNext()) {
         var23 = (String)var24.next();
         var27 = "DamageTypes." + var23 + ".";
         var29 = var1.getBoolean(var27 + "Default");
         var8 = ChatColor.translateAlternateColorCodes('&', var1.getString(var27 + "Prefix"));
         var33 = ChatColor.translateAlternateColorCodes('&', var1.getString(var27 + "Name"));
         var10 = ChatColor.translateAlternateColorCodes('&', var1.getString(var27 + "Value"));
         List var11 = var1.getStringList(var27 + "HitActions");
         HashMap var12 = new HashMap();
         if (var1.contains(var27 + "BiomeDamageModifier")) {
            var14 = var1.getConfigurationSection(var27 + "BiomeDamageModifier").getKeys(false).iterator();

            while(var14.hasNext()) {
               var13 = (String)var14.next();
               double var15 = var1.getDouble(var27 + "BiomeDamageModifier." + var13);
               var12.put(var13.toUpperCase(), var15);
            }
         }

         DamageType var39 = new DamageType(var23, var29, var8, var33, var10, var11, var12);
         this.damage_types.put(var39.getId(), var39);
      }

      this.armor_types = new HashMap();
      var24 = var1.getConfigurationSection("ArmorTypes").getKeys(false).iterator();

      String var30;
      while(var24.hasNext()) {
         var23 = (String)var24.next();
         var27 = "ArmorTypes." + var23 + ".";
         var30 = ChatColor.translateAlternateColorCodes('&', var1.getString(var27 + "Prefix"));
         var8 = ChatColor.translateAlternateColorCodes('&', var1.getString(var27 + "Name"));
         var33 = ChatColor.translateAlternateColorCodes('&', var1.getString(var27 + "Value"));
         boolean var34 = var1.getBoolean(var27 + "Percent");
         ArrayList var35 = new ArrayList();
         Iterator var40 = var1.getStringList(var27 + "BlockDamageSource").iterator();

         while(var40.hasNext()) {
            String var37 = (String)var40.next();
            var35.add(var37.toLowerCase());
         }

         ArrayList var38 = new ArrayList();
         var14 = var1.getStringList(var27 + "BlockDamageTypes").iterator();

         while(var14.hasNext()) {
            var13 = (String)var14.next();
            var38.add(var13.toLowerCase());
         }

         var13 = var1.getString(var27 + "Formula");
         ArmorType var41 = new ArmorType(var23, var30, var8, var33, var34, var35, var38, var13);
         this.armor_types.put(var41.getId(), var41);
      }

      var24 = var1.getConfigurationSection("Attributes").getKeys(false).iterator();

      while(var24.hasNext()) {
         var23 = (String)var24.next();
         var26 = null;

         ItemStat var31;
         try {
            var31 = ItemStat.valueOf(var23.toUpperCase());
         } catch (IllegalArgumentException var22) {
            continue;
         }

         var30 = ChatColor.translateAlternateColorCodes('&', var1.getString("Attributes." + var31.name() + ".Name"));
         var8 = ChatColor.translateAlternateColorCodes('&', var1.getString("Attributes." + var31.name() + ".Prefix"));
         var33 = ChatColor.translateAlternateColorCodes('&', var1.getString("Attributes." + var31.name() + ".Value"));
         var10 = ChatColor.translateAlternateColorCodes('&', var1.getString("Attributes." + var31.name() + ".Bonus"));
         double var36 = var1.getDouble("Attributes." + var31.name() + ".Capability");
         var31.setName(var30);
         var31.setPrefix(var8);
         var31.setValue(var33);
         var31.setBonus(var10);
         var31.setCapability(var36);
         String var16;
         String var43;
         if (var31 == ItemStat.DISARM_RATE) {
            var13 = "AttributeSettings." + var31.name() + ".";
            String var42 = var1.getString(var13 + "Effect");
            var43 = ChatColor.translateAlternateColorCodes('&', var1.getString(var13 + "Message.Damager"));
            var16 = ChatColor.translateAlternateColorCodes('&', var1.getString(var13 + "Message.Entity"));
            DisarmRateSettings var17 = new DisarmRateSettings(var31, var42, var43, var16);
            var31.setSettings(var17);
         } else if (var31 == ItemStat.BLEED_RATE) {
            var13 = "AttributeSettings." + var31.name() + ".";
            int var44 = var1.getInt(var13 + "Time");
            var43 = var1.getString(var13 + "Formula");
            var16 = var1.getString(var13 + "Effect");
            BleedRateSettings var45 = new BleedRateSettings(var31, var44, var43, var16);
            var31.setSettings(var45);
         }
      }

      var24 = var1.getConfigurationSection("AmmoTypes").getKeys(false).iterator();

      while(var24.hasNext()) {
         var23 = (String)var24.next();
         var26 = null;

         AmmoType var32;
         try {
            var32 = AmmoType.valueOf(var23.toUpperCase());
         } catch (IllegalArgumentException var21) {
            continue;
         }

         var29 = var1.getBoolean("AmmoTypes." + var32.name() + ".Enabled");
         var8 = ChatColor.translateAlternateColorCodes('&', var1.getString("AmmoTypes." + var32.name() + ".Name"));
         var33 = ChatColor.translateAlternateColorCodes('&', var1.getString("AmmoTypes." + var32.name() + ".Prefix"));
         var32.setEnabled(var29);
         var32.setName(var8);
         var32.setPrefix(var33);
      }

      this.str_dmgSep = ChatColor.translateAlternateColorCodes('&', var1.getString("Strings.DamageSeparator"));
      this.str_durSep = ChatColor.translateAlternateColorCodes('&', var1.getString("Strings.DurabilitySeparator"));
      this.str_pc = ChatColor.translateAlternateColorCodes('&', var1.getString("Strings.Percent"));
      this.str_neg = ChatColor.translateAlternateColorCodes('&', var1.getString("Strings.Negative"));
      this.str_pos = ChatColor.translateAlternateColorCodes('&', var1.getString("Strings.Positive"));
      this.str_mod = ChatColor.translateAlternateColorCodes('&', var1.getString("Strings.Modifier"));
      this.str_lvl = ChatColor.translateAlternateColorCodes('&', var1.getString("Strings.Level"));
      this.str_cls = ChatColor.translateAlternateColorCodes('&', var1.getString("Strings.Class"));
      this.str_clsSep = ChatColor.translateAlternateColorCodes('&', var1.getString("Strings.ClassSeparator"));
      this.str_clsCol = ChatColor.translateAlternateColorCodes('&', var1.getString("Strings.ClassColor"));
      this.wpn = new HashSet();
      var24 = var1.getStringList("ItemGroups.Weapons").iterator();

      while(var24.hasNext()) {
         var23 = (String)var24.next();
         if (Material.getMaterial(var23) != null) {
            this.wpn.add(Material.getMaterial(var23));
         }
      }

      this.tool = new HashSet();
      var24 = var1.getStringList("ItemGroups.Tools").iterator();

      while(var24.hasNext()) {
         var23 = (String)var24.next();
         if (Material.getMaterial(var23) != null) {
            this.tool.add(Material.getMaterial(var23));
         }
      }

      this.arm = new HashSet();
      var24 = var1.getStringList("ItemGroups.Armors").iterator();

      while(var24.hasNext()) {
         var23 = (String)var24.next();
         if (Material.getMaterial(var23) != null) {
            this.arm.add(Material.getMaterial(var23));
         }
      }

   }

   public String getLangCode() {
      return this.lang;
   }

   public Hook getLevelPlugin() {
      return this.g_LevelPlugin;
   }

   public Hook getClassPlugin() {
      return this.g_ClassPlugin;
   }

   public String getFormulaOther() {
      return this.global_dformula_other;
   }

   public String getFormulaDamage() {
      return this.global_dformula_dmg;
   }

   public double getDamageCDReduce() {
      return this.g_dmgReduce;
   }

   public boolean breakItems() {
      return this.g_itemsBreak;
   }

   public int getMaxTargetDistance() {
      return this.g_targetDist;
   }

   public String getAttributeFormat() {
      return this.g_attFormat;
   }

   public String getDamageTypeFormat() {
      return this.g_dtFormat;
   }

   public String getArmorTypeFormat() {
      return this.g_atFormat;
   }

   public String getAmmoTypeFormat() {
      return this.g_ammoFormat;
   }

   public boolean allowAttributesToMobs() {
      return this.g_mobAtt;
   }

   public boolean allowAttributesToOffHand() {
      return this.g_offAtt;
   }

   public boolean allowFishHookDamage() {
      return this.g_fishHookDmg;
   }

   public boolean skillAPIReduceDurability() {
      return this.g_sapiDur;
   }

   public HashMap<String, Boolean> getModules() {
      return this.modules;
   }

   public boolean isModuleEnabled(String var1) {
      return (Boolean)this.modules.get(var1);
   }

   public HashMap<DamageCause, Double> getPlayerDmgModifiers() {
      return this.damage_values_p;
   }

   public HashMap<DamageCause, Double> getMobDmgModifiers() {
      return this.damage_values_m;
   }

   public HashMap<String, DamageType> getDamageTypes() {
      return this.damage_types;
   }

   public HashMap<String, ArmorType> getArmorTypes() {
      return this.armor_types;
   }

   public DamageType getDamageTypeById(String var1) {
      return (DamageType)this.damage_types.get(var1.toLowerCase());
   }

   public ArmorType getArmorTypeById(String var1) {
      return (ArmorType)this.armor_types.get(var1.toLowerCase());
   }

   public String getStrDamageSeparator() {
      return this.str_dmgSep;
   }

   public String getStrDurabilitySeparator() {
      return this.str_durSep;
   }

   public String getStrPercent() {
      return this.str_pc;
   }

   public String getStrPositive() {
      return this.str_pos;
   }

   public String getStrNegative() {
      return this.str_neg;
   }

   public String getStrModifier() {
      return this.str_mod;
   }

   public String getStrLevel() {
      return this.str_lvl;
   }

   public String getStrClass() {
      return this.str_cls;
   }

   public String getStrClassSeparator() {
      return this.str_clsSep;
   }

   public String getStrClassColor() {
      return this.str_clsCol;
   }

   public Set<Material> getArmors() {
      return this.arm;
   }

   public Set<Material> getTools() {
      return this.tool;
   }

   public Set<Material> getWeapons() {
      return this.wpn;
   }
}
