package su.nightexpress.divineitems.config;

import java.io.File;
import java.io.IOException;
import java.util.UUID;
import org.apache.commons.lang.WordUtils;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemStack;
import su.nightexpress.divineitems.DivineItems;
import su.nightexpress.divineitems.utils.ResourceExtractor;

public class ConfigManager {
   private DivineItems plugin;
   private ConfigUpdater cu;
   private Config cfg;
   public MyConfig configLang;
   public MyConfig configMain;
   public MyConfig configGUI;
   public MyConfig item_names;
   public MyConfig ench_names;
   public MyConfig temp_hash;

   public ConfigManager(DivineItems var1) {
      this.plugin = var1;
      this.cu = new ConfigUpdater(var1, this);
   }

   public void setup() {
      this.extract("lang/en");
      this.extract("modules/drops");
      this.extract("modules/tiers");
      this.extract("modules/resolve");
      this.configMain = new MyConfig(this.plugin, "", "config.yml");
      this.cu.update();
      this.cfg = new Config(this.configMain);
      this.configLang = new MyConfig(this.plugin, "/lang/" + this.cfg.getLangCode(), "messages.yml");
      this.item_names = new MyConfig(this.plugin, "/lang/" + this.cfg.getLangCode(), "item_names.yml");
      this.ench_names = new MyConfig(this.plugin, "/lang/" + this.cfg.getLangCode(), "ench_names.yml");
      this.configGUI = new MyConfig(this.plugin, "", "gui.yml");
      this.temp_hash = new MyConfig(this.plugin, "", "temp_hash.yml");
      FileConfiguration var1 = this.item_names.getConfig();
      Material[] var5;
      int var4 = (var5 = Material.values()).length;

      for(int var3 = 0; var3 < var4; ++var3) {
         Material var2 = var5[var3];
         if (!var1.contains("Material." + var2.name())) {
            String var6 = WordUtils.capitalizeFully(var2.name().replace("_", " "));
            var1.set("Material." + var2.name(), var6);
         }
      }

      FileConfiguration var8 = this.ench_names.getConfig();
      Enchantment[] var11;
      int var10 = (var11 = Enchantment.values()).length;

      for(var4 = 0; var4 < var10; ++var4) {
         Enchantment var9 = var11[var4];
         if (!var8.contains("Enchant." + var9.getName())) {
            String var7 = WordUtils.capitalizeFully(var9.getName().replace("_", " "));
            var8.set("Enchant." + var9.getName(), var7);
         }
      }

      this.item_names.save();
      this.ench_names.save();
      Lang.setup(this.configLang);
   }

   private void extract(String var1) {
      File var2 = new File(this.plugin.getDataFolder() + "/" + var1 + "/");
      if (!var2.exists()) {
         ResourceExtractor var3 = new ResourceExtractor(this.plugin, new File(this.plugin.getDataFolder() + File.separator + var1), var1, ".*\\.(yml)$");

         try {
            var3.extract(false, true);
         } catch (IOException var5) {
            var5.printStackTrace();
         }
      }

   }

   public String getDefaultItemName(ItemStack var1) {
      return this.item_names.getConfig().contains("Material." + var1.getType().name()) ? this.item_names.getConfig().getString("Material." + var1.getType().name()) : WordUtils.capitalizeFully(var1.getType().name().replace("_", " "));
   }

   public String getDefaultEnchantName(Enchantment var1) {
      return this.ench_names.getConfig().contains("Enchant." + var1.getName()) ? ChatColor.translateAlternateColorCodes('&', this.ench_names.getConfig().getString("Enchant." + var1.getName())) : WordUtils.capitalizeFully(var1.getName().replace("_", " "));
   }

   public void createItemHash(String var1) {
      FileConfiguration var2 = this.plugin.getCM().temp_hash.getConfig();
      if (!var2.contains(var1)) {
         var2.set(var1, UUID.randomUUID().toString());
      }

      this.plugin.getCM().temp_hash.save();
   }

   public UUID getItemHash(String var1) {
      FileConfiguration var2 = this.plugin.getCM().temp_hash.getConfig();
      if (!var2.contains(var1)) {
         this.createItemHash(var1);
      }

      String var3 = var2.getString(var1);
      return UUID.fromString(var3);
   }

   public Config getCFG() {
      return this.cfg;
   }
}
