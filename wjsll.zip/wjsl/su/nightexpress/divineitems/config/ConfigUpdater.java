package su.nightexpress.divineitems.config;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import su.nightexpress.divineitems.DivineItems;
import su.nightexpress.divineitems.attributes.ItemStat;
import su.nightexpress.divineitems.types.AmmoType;
import su.nightexpress.divineitems.utils.Files;

public class ConfigUpdater {
   private DivineItems plugin;
   private ConfigManager cm;

   public ConfigUpdater(DivineItems var1, ConfigManager var2) {
      this.plugin = var1;
      this.cm = var2;
   }

   public void update() {
      this.updateConfig();
      this.updateDrops();
      this.updateTiers();
   }

   private void updateConfig() {
      FileConfiguration var1 = this.cm.configMain.getConfig();
      var1.set("DamageFormula", (Object)null);
      if (!var1.contains("Global.DamageFormula.damage")) {
         var1.set("Global.DamageFormula", (Object)null);
         var1.set("Global.DamageFormula.other", "(1 + (%pvpe_dmg% - %pvpe_def%) / 100) * (1 - %block% / 100)");
         var1.set("Global.DamageFormula.damage", "(%dmg% * %other%)");
      }

      if (!var1.contains("Global.AllowAttributesInOffHand")) {
         var1.set("Global.AllowAttributesInOffHand", false);
      }

      if (!var1.contains("Global.AmmoTypeFormat")) {
         var1.set("Global.AmmoTypeFormat", "&7Ammo Type: %type_prefix% %type_name%");
      }

      if (!var1.contains("Global.ArmorTypeFormat")) {
         var1.set("Global.ArmorTypeFormat", "%type_prefix% %type_name%: %type_value%");
      }

      if (!var1.contains("Global.SkillAPISkillsReduceDurability")) {
         var1.set("Global.SkillAPISkillsReduceDurability", true);
      }

      AmmoType[] var5;
      int var4 = (var5 = AmmoType.values()).length;

      int var3;
      for(var3 = 0; var3 < var4; ++var3) {
         AmmoType var2 = var5[var3];
         if (!var1.contains("AmmoTypes." + var2.name())) {
            var1.set("AmmoTypes." + var2.name() + ".Enabled", var2.isEnabled());
            var1.set("AmmoTypes." + var2.name() + ".Name", var2.getName());
            var1.set("AmmoTypes." + var2.name() + ".Prefix", var2.getPrefix());
         }
      }

      if (!var1.contains("Modules.Arrows")) {
         var1.set("Modules.Arrows", true);
      }

      if (!var1.contains("Modules.Consumables")) {
         var1.set("Modules.Consumables", true);
      }

      if (!var1.contains("Modules.Resolve")) {
         var1.set("Modules.Resolve", true);
      }

      if (!var1.contains("ArmorTypes")) {
         List var6 = Arrays.asList("Physical", "Magical", "Poison", "Fire", "Water", "Wind");
         Iterator var11 = var6.iterator();

         while(var11.hasNext()) {
            String var8 = (String)var11.next();
            var1.set("ArmorTypes." + var8 + ".Prefix", "&2▸");
            var1.set("ArmorTypes." + var8 + ".Name", var8 + " Defense");
            var1.set("ArmorTypes." + var8 + ".Value", "&f");
            var1.set("ArmorTypes." + var8 + ".Percent", false);
            var1.set("ArmorTypes." + var8 + ".BlockDamageSource", Arrays.asList("NONE"));
            var1.set("ArmorTypes." + var8 + ".BlockDamageTypes", Arrays.asList(var8));
            var1.set("ArmorTypes." + var8 + ".Formula", "(((%dmg% * (1 + %penetrate% / 100)) - (%def% / 10)))");
         }
      }

      Iterator var10 = var1.getConfigurationSection("DamageTypes").getKeys(false).iterator();

      String var7;
      while(var10.hasNext()) {
         var7 = (String)var10.next();
         String var12 = "DamageTypes." + var7 + ".";
         var1.set(var12 + "Enabled", (Object)null);
         if (!var1.contains(var12 + "Default")) {
            if (var7.equalsIgnoreCase("Physical")) {
               var1.set(var12 + "Default", true);
            } else {
               var1.set(var12 + "Default", false);
            }
         }

         if (!var1.contains(var12 + "BiomeDamageModifier")) {
            var1.set(var12 + "BiomeDamageModifier.PLAINS", 1.0D);
         }
      }

      if (!var1.contains("AttributeSettings.DISARM_RATE")) {
         var7 = "AttributeSettings.DISARM_RATE.";
         var1.set(var7 + "Effect", "ITEM_CRACK:IRON_SWORD");
         var1.set(var7 + "Message.Damager", "&2*** &aYou disarmed &7%s%&a! &2***");
         var1.set(var7 + "Message.Entity", "&4*** &cYou have been disarmed by &7%s%&c! &4***");
      }

      if (!var1.contains("AttributeSettings.BLEED_RATE")) {
         var7 = "AttributeSettings.BLEED_RATE.";
         var1.set(var7 + "Time", 5);
         var1.set(var7 + "Formula", "%dmg% * 0.25");
         var1.set(var7 + "Effect", "ITEM_CRACK:IRON_SWORD");
      }

      ItemStat[] var13;
      var4 = (var13 = ItemStat.values()).length;

      for(var3 = 0; var3 < var4; ++var3) {
         ItemStat var9 = var13[var3];
         if (!var1.contains("Attributes." + var9.name())) {
            var1.set("Attributes." + var9.name() + ".Name", var9.getName());
            var1.set("Attributes." + var9.name() + ".Prefix", var9.getPrefix());
            var1.set("Attributes." + var9.name() + ".Value", var9.getValue());
            var1.set("Attributes." + var9.name() + ".Bonus", var9.getBonus());
            var1.set("Attributes." + var9.name() + ".Capability", var9.getCapability());
         }
      }

      this.cm.configMain.save();
   }

   private void updateDrops() {
      Iterator var2 = Files.getFilesFolder("drops").iterator();

      while(var2.hasNext()) {
         String var1 = (String)var2.next();
         File var3 = new File(this.plugin.getDataFolder() + "/modules/drops/", var1);
         new YamlConfiguration();
         YamlConfiguration var4 = YamlConfiguration.loadConfiguration(var3);
         if (!var4.contains("General.BiomesWhitelist")) {
            var4.set("General.BiomesWhitelist.Reverse", false);
            var4.set("General.BiomesWhitelist.List", Arrays.asList("ANY", "PLAINS", "BIOME_NAME"));
         }

         if (!var4.contains("General.DropLevelPenalty")) {
            var4.set("General.DropLevelPenalty.Enabled", false);
            var4.set("General.DropLevelPenalty.Variance", 10);
         }

         try {
            var4.save(var3);
         } catch (IOException var6) {
            var6.printStackTrace();
         }
      }

   }

   private void updateTiers() {
      Iterator var2 = Files.getFilesFolder("tiers").iterator();

      while(var2.hasNext()) {
         String var1 = (String)var2.next();
         File var3 = new File(this.plugin.getDataFolder() + "/modules/tiers/", var1);
         new YamlConfiguration();
         YamlConfiguration var4 = YamlConfiguration.loadConfiguration(var3);
         if (!var4.contains("Item.MaterialData.Special")) {
            var4.set("Item.MaterialData.Special.DIAMOND_SWORD", Arrays.asList(5, 6, 7));
            var4.set("Item.MaterialData.Special.GOLD_SWORD", Arrays.asList(9, 10, 11));
         }

         if (!var4.contains("Item.Restrictions.LevelScaleBlackList")) {
            var4.set("Item.Restrictions.LevelScaleBlackList", Arrays.asList("CRITICAL_DAMAGE"));
         }

         if (!var4.contains("Item.AmmoTypes")) {
            var4.set("Item.AmmoTypes.ARROW", 100.0D);
         }

         if (!var4.contains("Item.ArmorTypes")) {
            var4.set("Item.ArmorTypes.Physical.Chance", 100.0D);
            var4.set("Item.ArmorTypes.Physical.Min", 10.0D);
            var4.set("Item.ArmorTypes.Physical.Max", 25.0D);
         }

         ItemStat[] var8;
         int var7 = (var8 = ItemStat.values()).length;

         for(int var6 = 0; var6 < var7; ++var6) {
            ItemStat var5 = var8[var6];
            if (!var4.contains("Item.Attributes." + var5.name())) {
               var4.set("Item.Attributes." + var5.name() + ".Default.Chance", 20.0D);
               var4.set("Item.Attributes." + var5.name() + ".Default.Min", 5.0D);
               var4.set("Item.Attributes." + var5.name() + ".Default.Max", 25.0D);
               var4.set("Item.Attributes." + var5.name() + ".Bonus.Chance", 20.0D);
               var4.set("Item.Attributes." + var5.name() + ".Bonus.Min", 5.0D);
               var4.set("Item.Attributes." + var5.name() + ".Bonus.Max", 25.0D);
            }
         }

         try {
            var4.save(var3);
         } catch (IOException var9) {
            var9.printStackTrace();
         }
      }

   }
}
