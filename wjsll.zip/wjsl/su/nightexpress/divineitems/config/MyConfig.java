package su.nightexpress.divineitems.config;

import java.io.File;
import java.io.IOException;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;
import su.nightexpress.divineitems.DivineItems;
import su.nightexpress.divineitems.utils.Files;

public class MyConfig {
   private JavaPlugin plugin;
   private String name;
   private String path;
   private FileConfiguration fileConfiguration;
   private File file;

   public MyConfig(JavaPlugin var1, String var2, String var3) {
      this.plugin = var1;
      this.name = var3;
      this.path = var2;
      this.load();
   }

   private void load() {
      if (!this.plugin.getDataFolder().exists()) {
         Files.mkdir(this.plugin.getDataFolder());
      }

      File var1 = new File(this.plugin.getDataFolder() + "/" + this.path);
      if (!var1.exists()) {
         var1.mkdirs();
      }

      File var2 = new File(this.plugin.getDataFolder() + "/" + this.path, this.name);
      if (!var2.exists()) {
         Files.copy(DivineItems.class.getResourceAsStream(this.path + "/" + this.name), var2);
      }

      this.file = var2;
      this.fileConfiguration = YamlConfiguration.loadConfiguration(var2);
      this.fileConfiguration.options().copyDefaults(true);
   }

   public void save() {
      try {
         this.fileConfiguration.options().copyDefaults(true);
         this.fileConfiguration.save(this.file);
      } catch (IOException var2) {
         var2.printStackTrace();
      }

   }

   public FileConfiguration getConfig() {
      return this.fileConfiguration;
   }
}
