package su.nightexpress.divineitems.gui;

public enum ContentType {
   FILLER,
   ACCEPT,
   DECLINE,
   TARGET,
   SOURCE,
   RESULT,
   VAULT,
   EXP,
   MATERIAL;
}
