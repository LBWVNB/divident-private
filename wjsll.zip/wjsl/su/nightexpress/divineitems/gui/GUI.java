package su.nightexpress.divineitems.gui;

import java.util.HashMap;
import java.util.Iterator;
import net.md_5.bungee.api.ChatColor;
import org.bukkit.Bukkit;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

public class GUI {
   private GUIType type;
   private String title;
   private int size;
   private HashMap<ContentType, GUIItem> items;

   public GUI(GUIType var1, String var2, int var3, HashMap<ContentType, GUIItem> var4) {
      this.setType(var1);
      this.setTitle(var2);
      this.setSize(var3);
      this.setItems(var4);
   }

   public GUI(GUI var1) {
      this.setType(var1.getType());
      this.setTitle(var1.getTitle());
      this.setSize(var1.getSize());
      HashMap var2 = new HashMap();
      Iterator var4 = var1.getItems().values().iterator();

      while(var4.hasNext()) {
         GUIItem var3 = (GUIItem)var4.next();
         var2.put(var3.getType(), new GUIItem(var3));
      }

      this.setItems(var2);
   }

   public GUIType getType() {
      return this.type;
   }

   public void setType(GUIType var1) {
      this.type = var1;
   }

   public String getTitle() {
      return this.title;
   }

   public void setTitle(String var1) {
      this.title = var1;
   }

   public int getSize() {
      return this.size;
   }

   public void setSize(int var1) {
      this.size = var1;
   }

   public HashMap<ContentType, GUIItem> getItems() {
      return this.items;
   }

   public void setItems(HashMap<ContentType, GUIItem> var1) {
      this.items = var1;
   }

   public Inventory build() {
      Inventory var1 = Bukkit.createInventory((InventoryHolder)null, this.getSize(), ChatColor.translateAlternateColorCodes('&', this.getTitle()));
      Iterator var3 = this.getItems().values().iterator();

      while(var3.hasNext()) {
         GUIItem var2 = (GUIItem)var3.next();
         ItemStack var4 = new ItemStack(var2.getItem());
         int[] var8;
         int var7 = (var8 = var2.getSlots()).length;

         for(int var6 = 0; var6 < var7; ++var6) {
            int var5 = var8[var6];
            var1.setItem(var5, var4);
         }
      }

      return var1;
   }
}
