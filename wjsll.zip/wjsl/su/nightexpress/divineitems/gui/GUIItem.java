package su.nightexpress.divineitems.gui;

import org.bukkit.inventory.ItemStack;

public class GUIItem {
   private ContentType type;
   private ItemStack item;
   private int[] slot;

   public GUIItem(ContentType var1, ItemStack var2, int[] var3) {
      this.setType(var1);
      this.setItem(var2);
      this.setSlots(var3);
   }

   public GUIItem(GUIItem var1) {
      this.setType(var1.getType());
      this.setItem(new ItemStack(var1.getItem()));
      this.setSlots(var1.getSlots());
   }

   public ContentType getType() {
      return this.type;
   }

   public void setType(ContentType var1) {
      this.type = var1;
   }

   public ItemStack getItem() {
      return this.item;
   }

   public void setItem(ItemStack var1) {
      this.item = var1;
   }

   public int[] getSlots() {
      return this.slot;
   }

   public void setSlots(int[] var1) {
      this.slot = var1;
   }
}
