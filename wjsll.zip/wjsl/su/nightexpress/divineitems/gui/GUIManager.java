package su.nightexpress.divineitems.gui;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import su.nightexpress.divineitems.DivineItems;

public class GUIManager {
   private DivineItems plugin;
   private HashMap<GUIType, GUI> gui;
   private HashMap<Player, GUI> gui2;

   public GUIManager(DivineItems var1) {
      this.plugin = var1;
      this.gui = new HashMap();
      this.gui2 = new HashMap();
   }

   public void setup() {
      FileConfiguration var1 = this.plugin.getCM().configGUI.getConfig();
      GUIType[] var5;
      int var4 = (var5 = GUIType.values()).length;

      for(int var3 = 0; var3 < var4; ++var3) {
         GUIType var2 = var5[var3];
         if (var1.contains(var2.name()) && var1.contains(var2.name() + ".Content")) {
            String var6 = ChatColor.translateAlternateColorCodes('&', var1.getString(var2.name() + ".Title"));
            int var7 = var1.getInt(var2.name() + ".Size");
            HashMap var8 = new HashMap();
            ContentType[] var12;
            int var11 = (var12 = ContentType.values()).length;

            for(int var10 = 0; var10 < var11; ++var10) {
               ContentType var9 = var12[var10];
               if (var1.contains(var2.name() + ".Content." + var9.name())) {
                  String var13 = var2.name() + ".Content." + var9.name() + ".";
                  String[] var14 = var1.getString(var13 + "Material").split(":");
                  String var15 = ChatColor.translateAlternateColorCodes('&', var1.getString(var13 + "Display"));
                  List var16 = var1.getStringList(var13 + "Lore");
                  ArrayList var17 = new ArrayList();
                  Iterator var19 = var16.iterator();

                  while(var19.hasNext()) {
                     String var18 = (String)var19.next();
                     var17.add(ChatColor.translateAlternateColorCodes('&', var18));
                  }

                  boolean var27 = var1.getBoolean(var13 + "Enchant");
                  String var28 = var1.getString(var13 + "Slots");
                  String[] var20 = var28.replaceAll("\\s", "").split(",");
                  int[] var21 = new int[var20.length];

                  for(int var22 = 0; var22 < var20.length; ++var22) {
                     try {
                        var21[var22] = Integer.parseInt(var20[var22]);
                     } catch (NumberFormatException var25) {
                     }
                  }

                  ItemStack var29 = new ItemStack(Material.getMaterial(var14[0]), Integer.parseInt(var14[2]), (short)Integer.parseInt(var14[1]));
                  ItemMeta var23 = var29.getItemMeta();
                  var23.setDisplayName(var15);
                  var23.setLore(var17);
                  if (var27) {
                     var29.addUnsafeEnchantment(Enchantment.LOOT_BONUS_BLOCKS, 1);
                  }

                  var23.addItemFlags(new ItemFlag[]{ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ENCHANTS, ItemFlag.HIDE_POTION_EFFECTS});
                  var29.setItemMeta(var23);
                  GUIItem var24 = new GUIItem(var9, var29, var21);
                  var8.put(var9, var24);
               }
            }

            GUI var26 = new GUI(var2, var6, var7, var8);
            this.gui.put(var2, var26);
         }
      }

   }

   public boolean isValidGui(Inventory var1, GUIType var2) {
      String var3 = ChatColor.stripColor(var1.getTitle());
      String var4 = ChatColor.stripColor((new GUI(this.getGUIByType(var2))).getTitle());
      return var3.equalsIgnoreCase(var4);
   }

   public Collection<GUI> getAllGUI() {
      return this.gui.values();
   }

   public GUI getGUIByType(GUIType var1) {
      return (GUI)this.gui.get(var1);
   }

   public void setGUI(Player var1, GUI var2) {
      this.gui2.put(var1, var2);
   }

   public GUI getPlayerGUI(Player var1, GUIType var2) {
      return ((GUI)this.gui2.get(var1)).getType() == var2 ? (GUI)this.gui2.get(var1) : null;
   }

   public boolean valid(Player var1, GUIType var2) {
      return this.gui2.get(var1) != null && ((GUI)this.gui2.get(var1)).getType() == var2;
   }

   public void reset(Player var1) {
      this.gui2.remove(var1);
   }
}
