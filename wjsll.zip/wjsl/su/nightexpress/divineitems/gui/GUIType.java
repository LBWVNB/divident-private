package su.nightexpress.divineitems.gui;

public enum GUIType {
   SOULBOUND,
   ENCHANT_GEM,
   ENCHANT_BOOK,
   ENCHANT_RUNE,
   ENCHANT_ABILITY,
   REPAIR_GEM,
   REPAIR_ANVIL;
}
