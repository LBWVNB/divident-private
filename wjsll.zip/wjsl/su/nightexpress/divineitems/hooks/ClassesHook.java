package su.nightexpress.divineitems.hooks;

import com.herocraftonline.heroes.Heroes;
import com.sucy.skill.SkillAPI;
import com.sucy.skill.api.player.PlayerData;
import com.zthana.racesofthana.Race;
import com.zthana.racesofthana.RacesOfThana;
import java.util.Iterator;
import me.leothepro555.skills.main.Skills;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.permissions.PermissionAttachmentInfo;
import ru.Capitalism.DivineClassesRPG.API.DivineAPI;
import ru.Capitalism.DivineClassesRPG.Classes.ClassManager;
import ru.Capitalism.DivineClassesRPG.Classes.ClassType;
import ru.Capitalism.DivineClassesRPG.Classes.DClass;
import su.nightexpress.divineitems.DivineItems;

public class ClassesHook {
   private DivineItems plugin;
   private HookManager hm;
   // $FF: synthetic field
   private static int[] $SWITCH_TABLE$su$nightexpress$divineitems$hooks$Hook;

   public ClassesHook(DivineItems var1, HookManager var2) {
      this.hm = var2;
      this.plugin = var1;
   }

   public String getClassReplacer(Material var1) {
      String var2 = "";
      return Hook.DIVINE_CLASSES.isEnabled() ? this.getDCClasses(var1) : var2;
   }

   private String getDCClasses(Material var1) {
      String var2 = "";
      String var3 = this.plugin.getCM().getCFG().getStrClassColor();
      String var4 = this.plugin.getCM().getCFG().getStrClassSeparator();
      ClassType[] var8;
      int var7 = (var8 = ClassType.values()).length;

      for(int var6 = 0; var6 < var7; ++var6) {
         ClassType var5 = var8[var6];
         DClass var9 = (DClass)ClassManager.getClasses().get(var5.name());
         if (var9.getWeapons().contains(var1) || var9.getArmors().contains(var1)) {
            var2 = var2 + var3 + ChatColor.stripColor(var9.getName()) + var4 + var3;
         }
      }

      if (var2.length() > 3) {
         var2 = var2.substring(0, var2.length() - 3);
      }

      return var2;
   }

   public String getPlayerClass(Player var1) {
      switch($SWITCH_TABLE$su$nightexpress$divineitems$hooks$Hook()[this.hm.getClassPlugin().ordinal()]) {
      case 3:
         return ChatColor.stripColor(DivineAPI.getSkillPlayer(var1.getUniqueId()).getDClass().getName());
      case 4:
         PlayerData var8 = SkillAPI.getPlayerData(var1);
         if (var8.hasClass()) {
            return var8.getMainClass().getData().getName();
         }

         return "";
      case 5:
         return ChatColor.stripColor(Skills.get().getPlayerDataManager().getOrLoadPlayerInfo(var1).getSkill().getConfigName());
      case 6:
      case 7:
      case 8:
      case 11:
      case 12:
      case 13:
      case 14:
      case 15:
      default:
         return "";
      case 9:
         return Heroes.getInstance().getCharacterManager().getHero(var1).getHeroClass().getName();
      case 10:
         String var7 = "";
         Iterator var4 = var1.getEffectivePermissions().iterator();

         while(var4.hasNext()) {
            PermissionAttachmentInfo var9 = (PermissionAttachmentInfo)var4.next();
            String var5 = var9.getPermission();
            if (var5.startsWith("divineitems.class")) {
               String var6 = var5.substring(var5.lastIndexOf("."), var5.length());
               var7 = var6.replace(".", "");
            }
         }

         return var7;
      case 16:
         RacesOfThana var2 = (RacesOfThana)this.plugin.getPluginManager().getPlugin("RacesOfThana");
         Race var3 = var2.getRaceHandler().getRace(var1);
         return var3 == null ? "" : var3.getName();
      }
   }

   // $FF: synthetic method
   static int[] $SWITCH_TABLE$su$nightexpress$divineitems$hooks$Hook() {
      int[] var10000 = $SWITCH_TABLE$su$nightexpress$divineitems$hooks$Hook;
      if (var10000 != null) {
         return var10000;
      } else {
         int[] var0 = new int[Hook.values().length];

         try {
            var0[Hook.BATTLE_LEVELS.ordinal()] = 2;
         } catch (NoSuchFieldError var16) {
         }

         try {
            var0[Hook.CITIZENS.ordinal()] = 1;
         } catch (NoSuchFieldError var15) {
         }

         try {
            var0[Hook.DIVINE_CLASSES.ordinal()] = 3;
         } catch (NoSuchFieldError var14) {
         }

         try {
            var0[Hook.HEROES.ordinal()] = 9;
         } catch (NoSuchFieldError var13) {
         }

         try {
            var0[Hook.HOLOGRAPHIC_DISPLAYS.ordinal()] = 7;
         } catch (NoSuchFieldError var12) {
         }

         try {
            var0[Hook.MCMMO.ordinal()] = 13;
         } catch (NoSuchFieldError var11) {
         }

         try {
            var0[Hook.MYTHIC_MOBS.ordinal()] = 8;
         } catch (NoSuchFieldError var10) {
         }

         try {
            var0[Hook.NONE.ordinal()] = 14;
         } catch (NoSuchFieldError var9) {
         }

         try {
            var0[Hook.PLACEHOLDER_API.ordinal()] = 11;
         } catch (NoSuchFieldError var8) {
         }

         try {
            var0[Hook.RACES_OF_THANA.ordinal()] = 16;
         } catch (NoSuchFieldError var7) {
         }

         try {
            var0[Hook.RPG_INVENTORY.ordinal()] = 12;
         } catch (NoSuchFieldError var6) {
         }

         try {
            var0[Hook.RPGme.ordinal()] = 15;
         } catch (NoSuchFieldError var5) {
         }

         try {
            var0[Hook.SKILLS.ordinal()] = 5;
         } catch (NoSuchFieldError var4) {
         }

         try {
            var0[Hook.SKILL_API.ordinal()] = 4;
         } catch (NoSuchFieldError var3) {
         }

         try {
            var0[Hook.VAULT.ordinal()] = 10;
         } catch (NoSuchFieldError var2) {
         }

         try {
            var0[Hook.WORLD_GUARD.ordinal()] = 6;
         } catch (NoSuchFieldError var1) {
         }

         $SWITCH_TABLE$su$nightexpress$divineitems$hooks$Hook = var0;
         return var0;
      }
   }
}
