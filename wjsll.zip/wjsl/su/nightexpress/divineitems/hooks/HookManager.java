package su.nightexpress.divineitems.hooks;

import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.PluginManager;
import su.nightexpress.divineitems.DivineItems;
import su.nightexpress.divineitems.hooks.external.HologramsHook;
import su.nightexpress.divineitems.hooks.external.MythicMobsHook;
import su.nightexpress.divineitems.hooks.external.RPGInvHook;
import su.nightexpress.divineitems.hooks.external.VaultHook;
import su.nightexpress.divineitems.hooks.external.WorldGuardHook;
import su.nightexpress.divineitems.hooks.external.citizens.CitizensHook;
import su.nightexpress.divineitems.hooks.placeholders.PlaceholderAPI;
import su.nightexpress.divineitems.listeners.MythicListener;
import su.nightexpress.divineitems.listeners.SkillAPIListener;

public class HookManager {
   private DivineItems plugin;
   private ClassesHook ch;
   private LevelsHook lh;
   private HologramsHook hh;
   private MythicMobsHook mmh;
   private CitizensHook npc;
   private WorldGuardHook wg;
   private RPGInvHook rpginv;
   private VaultHook vault;
   private Hook pl_class;
   private Hook pl_level;
   // $FF: synthetic field
   private static int[] $SWITCH_TABLE$su$nightexpress$divineitems$hooks$Hook;

   public HookManager(DivineItems var1) {
      this.plugin = var1;
      this.ch = new ClassesHook(var1, this);
      this.lh = new LevelsHook(this);
   }

   public void setup() {
      PluginManager var1 = this.plugin.getPluginManager();
      this.pl_class = this.plugin.getCM().getCFG().getClassPlugin();
      this.pl_level = this.plugin.getCM().getCFG().getLevelPlugin();
      Hook[] var5;
      int var4 = (var5 = Hook.values()).length;

      for(int var3 = 0; var3 < var4; ++var3) {
         Hook var2 = var5[var3];
         Plugin var6 = var1.getPlugin(var2.getPluginName());
         if (var6 != null && var6.isEnabled() && !var2.isEnabled()) {
            if (var2 == Hook.VAULT) {
               var2.enable();
               this.vault = new VaultHook(this.plugin);
               this.vault.setupEconomy();
            } else {
               if (var2.isClassPlugin() && this.pl_class == var2) {
                  if (var2 == Hook.SKILL_API) {
                     this.plugin.getPluginManager().registerEvents(new SkillAPIListener(this.plugin), this.plugin);
                  }

                  var2.enable();
               }

               if (var2.isLevelPlugin()) {
                  if (this.pl_level != var2) {
                     continue;
                  }

                  var2.enable();
               }

               var2.enable();
               switch($SWITCH_TABLE$su$nightexpress$divineitems$hooks$Hook()[var2.ordinal()]) {
               case 1:
                  this.npc = new CitizensHook();
                  this.npc.registerTraits();
               case 2:
               case 3:
               case 4:
               case 5:
               case 9:
               case 10:
               default:
                  break;
               case 6:
                  if (var6.getDescription().getVersion().startsWith("7")) {
                     var2.disable();
                  } else {
                     this.wg = new WorldGuardHook(this.plugin);
                  }
                  break;
               case 7:
                  this.hh = new HologramsHook(this.plugin);
                  break;
               case 8:
                  this.mmh = new MythicMobsHook();
                  this.plugin.getPluginManager().registerEvents(new MythicListener(this.plugin), this.plugin);
                  break;
               case 11:
                  PlaceholderAPI.registerPlaceholderAPI();
                  break;
               case 12:
                  this.rpginv = new RPGInvHook(this.plugin);
               }
            }
         }
      }

      this.sendStatus();
   }

   private void sendStatus() {
      this.plugin.getServer().getConsoleSender().sendMessage("§3---------[ §bHooks Initializing §3]---------");
      Hook[] var4;
      int var3 = (var4 = Hook.values()).length;

      for(int var2 = 0; var2 < var3; ++var2) {
         Hook var1 = var4[var2];
         if (var1 != Hook.NONE) {
            this.plugin.getServer().getConsoleSender().sendMessage("§7> §f" + var1.getPluginName() + ": " + this.getColorStatus(var1.isEnabled()));
         }
      }

   }

   private String getColorStatus(boolean var1) {
      return var1 ? "§aSuccess!" : "§cNot found / Error.";
   }

   public void disable() {
      Hook[] var4;
      int var3 = (var4 = Hook.values()).length;

      for(int var2 = 0; var2 < var3; ++var2) {
         Hook var1 = var4[var2];
         if (var1.isEnabled() && var1 != Hook.MYTHIC_MOBS) {
            if (var1 == Hook.CITIZENS) {
               this.npc.unregisterTraits();
            }

            var1.disable();
         }
      }

   }

   public ClassesHook getClassesHook() {
      return this.ch;
   }

   public LevelsHook getLevelsHook() {
      return this.lh;
   }

   public HologramsHook getHoloHook() {
      return this.hh;
   }

   public MythicMobsHook getMythicHook() {
      return this.mmh;
   }

   public CitizensHook getCitizens() {
      return this.npc;
   }

   public WorldGuardHook getWorldGuard() {
      return this.wg;
   }

   public RPGInvHook getRPGInventory() {
      return this.rpginv;
   }

   public VaultHook getVault() {
      return this.vault;
   }

   public Hook getLevelPlugin() {
      return this.pl_level;
   }

   public Hook getClassPlugin() {
      return this.pl_class;
   }

   // $FF: synthetic method
   static int[] $SWITCH_TABLE$su$nightexpress$divineitems$hooks$Hook() {
      int[] var10000 = $SWITCH_TABLE$su$nightexpress$divineitems$hooks$Hook;
      if (var10000 != null) {
         return var10000;
      } else {
         int[] var0 = new int[Hook.values().length];

         try {
            var0[Hook.BATTLE_LEVELS.ordinal()] = 2;
         } catch (NoSuchFieldError var16) {
         }

         try {
            var0[Hook.CITIZENS.ordinal()] = 1;
         } catch (NoSuchFieldError var15) {
         }

         try {
            var0[Hook.DIVINE_CLASSES.ordinal()] = 3;
         } catch (NoSuchFieldError var14) {
         }

         try {
            var0[Hook.HEROES.ordinal()] = 9;
         } catch (NoSuchFieldError var13) {
         }

         try {
            var0[Hook.HOLOGRAPHIC_DISPLAYS.ordinal()] = 7;
         } catch (NoSuchFieldError var12) {
         }

         try {
            var0[Hook.MCMMO.ordinal()] = 13;
         } catch (NoSuchFieldError var11) {
         }

         try {
            var0[Hook.MYTHIC_MOBS.ordinal()] = 8;
         } catch (NoSuchFieldError var10) {
         }

         try {
            var0[Hook.NONE.ordinal()] = 14;
         } catch (NoSuchFieldError var9) {
         }

         try {
            var0[Hook.PLACEHOLDER_API.ordinal()] = 11;
         } catch (NoSuchFieldError var8) {
         }

         try {
            var0[Hook.RACES_OF_THANA.ordinal()] = 16;
         } catch (NoSuchFieldError var7) {
         }

         try {
            var0[Hook.RPG_INVENTORY.ordinal()] = 12;
         } catch (NoSuchFieldError var6) {
         }

         try {
            var0[Hook.RPGme.ordinal()] = 15;
         } catch (NoSuchFieldError var5) {
         }

         try {
            var0[Hook.SKILLS.ordinal()] = 5;
         } catch (NoSuchFieldError var4) {
         }

         try {
            var0[Hook.SKILL_API.ordinal()] = 4;
         } catch (NoSuchFieldError var3) {
         }

         try {
            var0[Hook.VAULT.ordinal()] = 10;
         } catch (NoSuchFieldError var2) {
         }

         try {
            var0[Hook.WORLD_GUARD.ordinal()] = 6;
         } catch (NoSuchFieldError var1) {
         }

         $SWITCH_TABLE$su$nightexpress$divineitems$hooks$Hook = var0;
         return var0;
      }
   }
}
