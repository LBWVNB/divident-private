package su.nightexpress.divineitems.hooks;

import com.gmail.nossr50.api.ExperienceAPI;
import com.herocraftonline.heroes.Heroes;
import com.sucy.skill.SkillAPI;
import com.sucy.skill.api.player.PlayerData;
import me.leothepro555.skills.main.Skills;
import me.robin.battlelevels.api.BattleLevelsAPI;
import net.flamedek.rpgme.RPGme;
import org.bukkit.entity.Player;
import ru.Capitalism.DivineClassesRPG.API.DivineAPI;

public class LevelsHook {
   private HookManager hm;
   // $FF: synthetic field
   private static int[] $SWITCH_TABLE$su$nightexpress$divineitems$hooks$Hook;

   public LevelsHook(HookManager var1) {
      this.hm = var1;
   }

   public int getPlayerLevel(Player var1) {
      switch($SWITCH_TABLE$su$nightexpress$divineitems$hooks$Hook()[this.hm.getLevelPlugin().ordinal()]) {
      case 2:
         return BattleLevelsAPI.getLevel(var1.getUniqueId());
      case 3:
         return DivineAPI.getSkillPlayer(var1.getUniqueId()).getLevel();
      case 4:
         PlayerData var2 = SkillAPI.getPlayerData(var1);
         return var2.hasClass() ? var2.getMainClass().getLevel() : 0;
      case 5:
         return Skills.get().getPlayerDataManager().getOrLoadPlayerInfo(var1).getLevel();
      case 6:
      case 7:
      case 8:
      case 10:
      case 11:
      case 12:
      case 14:
      default:
         return var1.getLevel();
      case 9:
         return Heroes.getInstance().getCharacterManager().getHero(var1).getLevel();
      case 13:
         return ExperienceAPI.getPowerLevel(var1);
      case 15:
         return RPGme.getAPI().get(var1).getSkillSet().getCombatLevel();
      }
   }

   // $FF: synthetic method
   static int[] $SWITCH_TABLE$su$nightexpress$divineitems$hooks$Hook() {
      int[] var10000 = $SWITCH_TABLE$su$nightexpress$divineitems$hooks$Hook;
      if (var10000 != null) {
         return var10000;
      } else {
         int[] var0 = new int[Hook.values().length];

         try {
            var0[Hook.BATTLE_LEVELS.ordinal()] = 2;
         } catch (NoSuchFieldError var16) {
         }

         try {
            var0[Hook.CITIZENS.ordinal()] = 1;
         } catch (NoSuchFieldError var15) {
         }

         try {
            var0[Hook.DIVINE_CLASSES.ordinal()] = 3;
         } catch (NoSuchFieldError var14) {
         }

         try {
            var0[Hook.HEROES.ordinal()] = 9;
         } catch (NoSuchFieldError var13) {
         }

         try {
            var0[Hook.HOLOGRAPHIC_DISPLAYS.ordinal()] = 7;
         } catch (NoSuchFieldError var12) {
         }

         try {
            var0[Hook.MCMMO.ordinal()] = 13;
         } catch (NoSuchFieldError var11) {
         }

         try {
            var0[Hook.MYTHIC_MOBS.ordinal()] = 8;
         } catch (NoSuchFieldError var10) {
         }

         try {
            var0[Hook.NONE.ordinal()] = 14;
         } catch (NoSuchFieldError var9) {
         }

         try {
            var0[Hook.PLACEHOLDER_API.ordinal()] = 11;
         } catch (NoSuchFieldError var8) {
         }

         try {
            var0[Hook.RACES_OF_THANA.ordinal()] = 16;
         } catch (NoSuchFieldError var7) {
         }

         try {
            var0[Hook.RPG_INVENTORY.ordinal()] = 12;
         } catch (NoSuchFieldError var6) {
         }

         try {
            var0[Hook.RPGme.ordinal()] = 15;
         } catch (NoSuchFieldError var5) {
         }

         try {
            var0[Hook.SKILLS.ordinal()] = 5;
         } catch (NoSuchFieldError var4) {
         }

         try {
            var0[Hook.SKILL_API.ordinal()] = 4;
         } catch (NoSuchFieldError var3) {
         }

         try {
            var0[Hook.VAULT.ordinal()] = 10;
         } catch (NoSuchFieldError var2) {
         }

         try {
            var0[Hook.WORLD_GUARD.ordinal()] = 6;
         } catch (NoSuchFieldError var1) {
         }

         $SWITCH_TABLE$su$nightexpress$divineitems$hooks$Hook = var0;
         return var0;
      }
   }
}
