package su.nightexpress.divineitems.hooks.external;

import com.gmail.filoghost.holographicdisplays.api.Hologram;
import com.gmail.filoghost.holographicdisplays.api.HologramsAPI;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import su.nightexpress.divineitems.DivineItems;
import su.nightexpress.divineitems.hooks.Hook;

public class HologramsHook {
   private DivineItems plugin;
   private HashMap<Hologram, Integer> map;
   private int taskId;

   public HologramsHook(DivineItems var1) {
      this.plugin = var1;
      this.map = new HashMap();
      this.start();
   }

   public void enable() {
      this.start();
   }

   public void disable() {
      this.plugin.getServer().getScheduler().cancelTask(this.taskId);
      Iterator var2 = this.map.keySet().iterator();

      while(var2.hasNext()) {
         Hologram var1 = (Hologram)var2.next();
         var1.delete();
      }

      this.map.clear();
   }

   public void createIndicator(Location var1, List<String> var2) {
      if (Hook.HOLOGRAPHIC_DISPLAYS.isEnabled()) {
         Location var3 = new Location(var1.getWorld(), var1.getX(), var1.getY(), var1.getZ());
         Hologram var4 = HologramsAPI.createHologram(this.plugin, var3);
         Iterator var6 = var2.iterator();

         while(var6.hasNext()) {
            String var5 = (String)var6.next();
            var4.appendTextLine(var5);
         }

         this.map.put(var4, 1);
      }
   }

   public boolean isHologram(Entity var1) {
      return Hook.HOLOGRAPHIC_DISPLAYS.isEnabled() && HologramsAPI.isHologramEntity(var1);
   }

   private void up(Hologram var1) {
      int var2 = 1;
      if (this.map.containsKey(var1)) {
         var2 = (Integer)this.map.get(var1);
      }

      var1.teleport(var1.getLocation().add(0.0D, 0.1D + (double)(var2 / 15), 0.0D));
      ++var2;
      if (var2 >= 15) {
         this.map.remove(var1);
         var1.delete();
      } else {
         this.map.put(var1, var2);
      }

   }

   public HashMap<Hologram, Integer> getHolomap() {
      return this.map;
   }

   public void start() {
      this.taskId = this.plugin.getServer().getScheduler().scheduleSyncRepeatingTask(this.plugin, new Runnable() {
         public void run() {
            if (HologramsHook.this.getHolomap().size() > 0) {
               HashMap var1 = new HashMap(HologramsHook.this.getHolomap());
               Iterator var3 = var1.keySet().iterator();

               while(var3.hasNext()) {
                  Hologram var2 = (Hologram)var3.next();
                  HologramsHook.this.up(var2);
               }
            }

         }
      }, 10L, 1L);
   }
}
