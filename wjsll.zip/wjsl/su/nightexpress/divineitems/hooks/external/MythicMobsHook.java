package su.nightexpress.divineitems.hooks.external;

import io.lumine.xikage.mythicmobs.MythicMobs;
import io.lumine.xikage.mythicmobs.mobs.ActiveMob;
import io.lumine.xikage.mythicmobs.mobs.MythicMob;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import org.bukkit.entity.Entity;

public class MythicMobsHook {
   public boolean isMythicMob(Entity var1) {
      return MythicMobs.inst().getAPIHelper().isMythicMob(var1);
   }

   public String getMythicNameByEntity(Entity var1) {
      return MythicMobs.inst().getAPIHelper().getMythicMobInstance(var1).getType().getInternalName();
   }

   public MythicMob getMythicInstance(Entity var1) {
      return MythicMobs.inst().getAPIHelper().getMythicMobInstance(var1).getType();
   }

   public boolean isDropTable(String var1) {
      return MythicMobs.inst().getDropManager().getDropTable(var1) != null && MythicMobs.inst().getDropManager().getDropTable(var1).isPresent();
   }

   public int getLevel(Entity var1) {
      return MythicMobs.inst().getAPIHelper().getMythicMobInstance(var1).getLevel();
   }

   public List<String> getTableDrops(String var1) {
      try {
         Class var2 = Class.forName("io.lumine.xikage.mythicmobs.drops.DropTable");
         Method var3 = var2.getMethod("getDropTable", String.class);
         Object var4 = var3.invoke(var1);
         Field var5 = var4.getClass().getField("strDropItems");
         var5.setAccessible(true);
         List var6 = (List)var5.get(var4);
         return var6;
      } catch (IllegalArgumentException | IllegalAccessException | ClassNotFoundException | NoSuchMethodException | SecurityException | InvocationTargetException | NoSuchFieldException var7) {
         System.out.println("Error while getting MM Drops. It only works for MythicMobs 4.3.x or lower.");
         return new ArrayList();
      }
   }

   public void setSkillDamage(Entity var1, double var2) {
      if (this.isMythicMob(var1)) {
         ActiveMob var4 = MythicMobs.inst().getMobManager().getMythicMobInstance(var1);
         var4.setLastDamageSkillAmount(var2);
      }
   }
}
