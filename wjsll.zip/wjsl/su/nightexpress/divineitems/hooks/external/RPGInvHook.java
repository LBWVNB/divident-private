package su.nightexpress.divineitems.hooks.external;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import ru.endlesscode.rpginventory.api.InventoryAPI;
import su.nightexpress.divineitems.DivineItems;
import su.nightexpress.divineitems.api.ItemAPI;

public class RPGInvHook {
   private DivineItems plugin;

   public RPGInvHook(DivineItems var1) {
      this.plugin = var1;
   }

   public ItemStack[] getEquip(Player var1) {
      ArrayList var2 = new ArrayList();
      HashSet var3 = new HashSet();
      var2.addAll(InventoryAPI.getActiveItems(var1));
      var2.addAll(InventoryAPI.getPassiveItems(var1));
      if (var1.getEquipment().getItemInOffHand() != null && (this.plugin.getCM().getCFG().allowAttributesToOffHand() || var1.getEquipment().getItemInOffHand().getType() == Material.SHIELD)) {
         var2.add(var1.getEquipment().getItemInOffHand());
      }

      if (var1.getEquipment().getItemInMainHand() != null && !this.plugin.getCM().getCFG().getArmors().contains(var1.getEquipment().getItemInMainHand().getType())) {
         var2.add(var1.getEquipment().getItemInMainHand());
      }

      var2.addAll(Arrays.asList(var1.getInventory().getArmorContents()));
      Iterator var5 = var2.iterator();

      while(var5.hasNext()) {
         ItemStack var4 = (ItemStack)var5.next();
         if (ItemAPI.getDurability(var4, 0) != 0) {
            var3.add(var4);
         }
      }

      return (ItemStack[])var3.toArray(new ItemStack[var3.size()]);
   }
}
