package su.nightexpress.divineitems.hooks.external;

import net.milkbowl.vault.economy.Economy;
import net.milkbowl.vault.economy.EconomyResponse;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.RegisteredServiceProvider;
import su.nightexpress.divineitems.DivineItems;
import su.nightexpress.divineitems.hooks.Hook;

public class VaultHook {
   private Economy economy;

   public VaultHook(DivineItems var1) {
   }

   public double getBalans(Player var1) {
      if (!Hook.VAULT.isEnabled()) {
         return 0.0D;
      } else {
         double var2 = this.economy.getBalance(var1);
         return var2;
      }
   }

   public boolean give(Player var1, double var2) {
      if (Hook.VAULT.isEnabled()) {
         EconomyResponse var4 = this.economy.depositPlayer(var1, var2);
         return var4.transactionSuccess();
      } else {
         return false;
      }
   }

   public boolean take(Player var1, double var2) {
      if (Hook.VAULT.isEnabled()) {
         EconomyResponse var4 = this.economy.withdrawPlayer(var1, var2);
         return var4.transactionSuccess();
      } else {
         return false;
      }
   }

   public void setupEconomy() {
      RegisteredServiceProvider var1 = Bukkit.getServicesManager().getRegistration(Economy.class);
      if (var1 != null) {
         this.economy = (Economy)var1.getProvider();
      }
   }
}
