package su.nightexpress.divineitems.hooks.external;

import com.sk89q.worldedit.BlockVector;
import com.sk89q.worldguard.bukkit.WorldGuardPlugin;
import com.sk89q.worldguard.protection.ApplicableRegionSet;
import com.sk89q.worldguard.protection.association.RegionAssociable;
import com.sk89q.worldguard.protection.flags.DefaultFlag;
import com.sk89q.worldguard.protection.flags.StateFlag;
import com.sk89q.worldguard.protection.flags.StateFlag.State;
import com.sk89q.worldguard.protection.managers.RegionManager;
import com.sk89q.worldguard.protection.regions.ProtectedRegion;
import java.util.Iterator;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import su.nightexpress.divineitems.DivineItems;

public class WorldGuardHook {
   private DivineItems plugin;

   public WorldGuardHook(DivineItems var1) {
      this.plugin = var1;
   }

   public boolean canFights(Entity var1, Entity var2) {
      if (var1 instanceof Player && var2 instanceof Player) {
         WorldGuardPlugin var3 = (WorldGuardPlugin)this.plugin.getPluginManager().getPlugin("WorldGuard");
         RegionManager var4 = var3.getRegionManager(var1.getLocation().getWorld());
         if (var4 == null) {
            return true;
         } else {
            ApplicableRegionSet var5 = var4.getApplicableRegions(this.convertToSk89qBV(var1.getLocation()));
            ApplicableRegionSet var6 = var4.getApplicableRegions(this.convertToSk89qBV(var2.getLocation()));
            return var5 == null && var6 == null || var5.queryState((RegionAssociable)null, new StateFlag[]{DefaultFlag.PVP}) != State.DENY && var6.queryState((RegionAssociable)null, new StateFlag[]{DefaultFlag.PVP}) != State.DENY;
         }
      } else {
         return true;
      }
   }

   private BlockVector convertToSk89qBV(Location var1) {
      return new BlockVector(var1.getX(), var1.getY(), var1.getZ());
   }

   public boolean canBuilds(Player var1) {
      WorldGuardPlugin var2 = (WorldGuardPlugin)this.plugin.getPluginManager().getPlugin("WorldGuard");
      return var2.canBuild(var1, var1.getLocation().getBlock().getRelative(0, -1, 0));
   }

   public boolean isInRegion(LivingEntity var1, String var2) {
      return this.getRegion(var1).equalsIgnoreCase(var2);
   }

   public String getRegion(LivingEntity var1) {
      WorldGuardPlugin var2 = (WorldGuardPlugin)this.plugin.getPluginManager().getPlugin("WorldGuard");
      RegionManager var3 = var2.getRegionManager(var1.getWorld());
      ApplicableRegionSet var4 = var3.getApplicableRegions(var1.getLocation());
      String var5 = "";
      int var6 = -1;
      Iterator var8 = var4.iterator();

      while(var8.hasNext()) {
         ProtectedRegion var7 = (ProtectedRegion)var8.next();
         if (var7.getPriority() > var6) {
            var6 = var7.getPriority();
            var5 = var7.getId();
         }
      }

      return var5;
   }
}
