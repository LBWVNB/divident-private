package su.nightexpress.divineitems.hooks.external.citizens;

import net.citizensnpcs.api.CitizensAPI;
import net.citizensnpcs.api.trait.TraitInfo;
import org.bukkit.entity.Entity;
import su.nightexpress.divineitems.hooks.external.citizens.traits.ResolveTrait;

public class CitizensHook {
   private TraitInfo resolve = TraitInfo.create(ResolveTrait.class).withName("resolver");

   public boolean isNPC(Entity var1) {
      return CitizensAPI.getNPCRegistry().isNPC(var1);
   }

   public void registerTraits() {
      CitizensAPI.getTraitFactory().registerTrait(this.resolve);
   }

   public void unregisterTraits() {
      CitizensAPI.getTraitFactory().deregisterTrait(this.resolve);
   }
}
