package su.nightexpress.divineitems.hooks.external.citizens.traits;

import net.citizensnpcs.api.event.NPCRightClickEvent;
import net.citizensnpcs.api.trait.Trait;
import net.citizensnpcs.api.trait.TraitName;
import org.bukkit.event.EventHandler;
import su.nightexpress.divineitems.DivineItems;

@TraitName("resolver")
public class ResolveTrait extends Trait {
   public ResolveTrait() {
      super("resolver");
   }

   @EventHandler
   public void click(NPCRightClickEvent var1) {
      if (var1.getNPC() == this.getNPC() && DivineItems.instance.getMM().getResolveManager().isActive()) {
         DivineItems.instance.getMM().getResolveManager().openResolveGUI(var1.getClicker());
      }

   }
}
