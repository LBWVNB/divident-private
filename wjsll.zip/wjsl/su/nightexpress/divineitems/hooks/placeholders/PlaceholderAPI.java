package su.nightexpress.divineitems.hooks.placeholders;

import su.nightexpress.divineitems.DivineItems;

public class PlaceholderAPI {
   public static void registerPlaceholderAPI() {
      (new PlaceholderAPIHook(DivineItems.instance, "dirpg")).hook();
   }
}
