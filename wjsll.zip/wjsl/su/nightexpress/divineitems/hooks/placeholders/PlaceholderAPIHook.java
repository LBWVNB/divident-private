package su.nightexpress.divineitems.hooks.placeholders;

import java.util.HashMap;
import me.clip.placeholderapi.external.EZPlaceholderHook;
import org.bukkit.entity.Player;
import su.nightexpress.divineitems.DivineItems;
import su.nightexpress.divineitems.api.EntityAPI;
import su.nightexpress.divineitems.api.ItemAPI;
import su.nightexpress.divineitems.attributes.ItemStat;
import su.nightexpress.divineitems.types.ArmorType;
import su.nightexpress.divineitems.utils.Utils;

public class PlaceholderAPIHook extends EZPlaceholderHook {
   public PlaceholderAPIHook(DivineItems var1, String var2) {
      super(var1, var2);
   }

   public String onPlaceholderRequest(Player var1, String var2) {
      if (var1 != null && var1.getInventory() != null) {
         String var3;
         if (var2.startsWith("attribute_")) {
            var3 = var2.replace("attribute_", "");

            try {
               ItemStat var7 = ItemStat.valueOf(var3.toUpperCase());
               return String.valueOf(Utils.round3(EntityAPI.getItemStat(var1, var7)));
            } catch (IllegalArgumentException var6) {
               return "Invalid Attribute!";
            }
         } else if (var2.startsWith("damage_")) {
            var3 = var2.replace("damage_", "");
            return var1 != null && var1.getInventory() != null ? String.valueOf(Utils.round3(ItemAPI.getFinalDamageByType(var3, var1))) : "Error.";
         } else if (var2.startsWith("defense_")) {
            var3 = var2.replace("defense_", "");
            ArmorType var4 = (ArmorType)DivineItems.instance.getCFG().getArmorTypes().get(var3.toLowerCase());
            if (var4 == null) {
               return "Invalid Defense Type!";
            } else if (var1 != null && var1.getInventory() != null) {
               HashMap var5 = ItemAPI.getDefenseTypes(var1);
               return var5.containsKey(var4) ? String.valueOf(var5.get(var4)) : "0.0";
            } else {
               return "Error.";
            }
         } else {
            return null;
         }
      } else {
         return null;
      }
   }
}
