package su.nightexpress.divineitems.libs.apihelper;

import org.bukkit.plugin.Plugin;

public interface API {
   void load();

   void init(Plugin var1);

   void disable(Plugin var1);
}
