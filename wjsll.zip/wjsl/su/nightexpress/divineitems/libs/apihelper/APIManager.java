package su.nightexpress.divineitems.libs.apihelper;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.logging.Logger;
import org.bukkit.Bukkit;
import org.bukkit.event.Listener;
import org.bukkit.plugin.Plugin;
import su.nightexpress.divineitems.libs.apihelper.exception.APIRegistrationException;

public class APIManager {
   private static final Map<API, RegisteredAPI> HOST_MAP = new HashMap();
   private static final Map<Class<? extends API>, Set<Plugin>> PENDING_API_CLASSES = new HashMap();
   private static final Logger LOGGER = Logger.getLogger("APIManager");

   public static RegisteredAPI registerAPI(API var0) {
      if (HOST_MAP.containsKey(var0)) {
         throw new APIRegistrationException("API for '" + var0.getClass().getName() + "' is already registered");
      } else {
         RegisteredAPI var1 = new RegisteredAPI(var0);
         HOST_MAP.put(var0, var1);
         var0.load();
         LOGGER.fine("'" + var0.getClass().getName() + "' registered as new API");
         return var1;
      }
   }

   public static RegisteredAPI registerAPI(API var0, Plugin var1) {
      validatePlugin(var1);
      registerAPI(var0);
      return registerAPIHost(var0, var1);
   }

   public static API registerEvents(API var0, Listener var1) {
      if (!HOST_MAP.containsKey(var0)) {
         throw new APIRegistrationException("API for '" + var0.getClass().getName() + "' is not registered");
      } else {
         RegisteredAPI var2 = (RegisteredAPI)HOST_MAP.get(var0);
         if (var2.eventsRegistered) {
            return var0;
         } else {
            Bukkit.getPluginManager().registerEvents(var1, var2.getNextHost());
            var2.eventsRegistered = true;
            return var0;
         }
      }
   }

   private static void initAPI(API var0) {
      if (!HOST_MAP.containsKey(var0)) {
         throw new APIRegistrationException("API for '" + var0.getClass().getName() + "' is not registered");
      } else {
         RegisteredAPI var1 = (RegisteredAPI)HOST_MAP.get(var0);
         var1.init();
      }
   }

   public static void initAPI(Class<? extends API> var0) {
      API var1 = null;
      Iterator var3 = HOST_MAP.keySet().iterator();

      while(var3.hasNext()) {
         API var2 = (API)var3.next();
         if (var2.getClass().equals(var0)) {
            var1 = var2;
            break;
         }
      }

      if (var1 == null) {
         if (!PENDING_API_CLASSES.containsKey(var0)) {
            throw new APIRegistrationException("API for class '" + var0.getName() + "' is not registered");
         }

         LOGGER.info("API class '" + var0.getName() + "' is not yet initialized. Creating new instance.");

         try {
            var1 = (API)var0.newInstance();
            registerAPI(var1);
            var3 = ((Set)PENDING_API_CLASSES.get(var0)).iterator();

            while(var3.hasNext()) {
               Plugin var5 = (Plugin)var3.next();
               if (var5 != null) {
                  registerAPIHost(var1, var5);
               }
            }
         } catch (ReflectiveOperationException var4) {
            LOGGER.warning("API class '" + var0.getName() + "' is missing valid constructor");
         }

         PENDING_API_CLASSES.remove(var0);
      }

      initAPI(var1);
   }

   private static void disableAPI(API var0) {
      if (HOST_MAP.containsKey(var0)) {
         RegisteredAPI var1 = (RegisteredAPI)HOST_MAP.get(var0);
         var1.disable();
         HOST_MAP.remove(var0);
      }
   }

   public static void disableAPI(Class<? extends API> var0) {
      API var1 = null;
      Iterator var3 = HOST_MAP.keySet().iterator();

      while(var3.hasNext()) {
         API var2 = (API)var3.next();
         if (var2.getClass().equals(var0)) {
            var1 = var2;
            break;
         }
      }

      disableAPI(var1);
   }

   public static void require(Class<? extends API> var0, Plugin var1) {
      try {
         if (var1 == null) {
            throw new APIRegistrationException();
         }

         registerAPIHost(var0, var1);
      } catch (APIRegistrationException var4) {
         if (PENDING_API_CLASSES.containsKey(var0)) {
            ((Set)PENDING_API_CLASSES.get(var0)).add(var1);
         } else {
            HashSet var3 = new HashSet();
            var3.add(var1);
            PENDING_API_CLASSES.put(var0, var3);
         }
      }

   }

   private static RegisteredAPI registerAPIHost(API var0, Plugin var1) {
      validatePlugin(var1);
      if (!HOST_MAP.containsKey(var0)) {
         throw new APIRegistrationException("API for '" + var0.getClass().getName() + "' is not registered");
      } else {
         RegisteredAPI var2 = (RegisteredAPI)HOST_MAP.get(var0);
         var2.registerHost(var1);
         LOGGER.fine("'" + var1.getName() + "' registered as Host for '" + var0 + "'");
         return var2;
      }
   }

   public static RegisteredAPI registerAPIHost(Class<? extends API> var0, Plugin var1) {
      validatePlugin(var1);
      API var2 = null;
      Iterator var4 = HOST_MAP.keySet().iterator();

      while(var4.hasNext()) {
         API var3 = (API)var4.next();
         if (var3.getClass().equals(var0)) {
            var2 = var3;
            break;
         }
      }

      if (var2 == null) {
         throw new APIRegistrationException("API for class '" + var0.getName() + "' is not registered");
      } else {
         return registerAPIHost(var2, var1);
      }
   }

   public static Plugin getAPIHost(API var0) {
      if (!HOST_MAP.containsKey(var0)) {
         throw new APIRegistrationException("API for '" + var0.getClass().getName() + "' is not registered");
      } else {
         return ((RegisteredAPI)HOST_MAP.get(var0)).getNextHost();
      }
   }

   private static void validatePlugin(Plugin var0) {
      if (var0 instanceof API) {
         throw new IllegalArgumentException("Plugin must not implement API");
      }
   }
}
