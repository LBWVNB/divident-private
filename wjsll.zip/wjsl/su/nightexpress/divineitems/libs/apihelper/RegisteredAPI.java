package su.nightexpress.divineitems.libs.apihelper;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import org.bukkit.plugin.Plugin;
import su.nightexpress.divineitems.libs.apihelper.exception.MissingHostException;

public class RegisteredAPI {
   protected final API api;
   protected final Set<Plugin> hosts = new HashSet();
   protected boolean initialized = false;
   protected Plugin initializerHost;
   protected boolean eventsRegistered = false;

   public RegisteredAPI(API var1) {
      this.api = var1;
   }

   public void registerHost(Plugin var1) {
      this.hosts.add(var1);
   }

   public Plugin getNextHost() {
      if (this.api instanceof Plugin && ((Plugin)this.api).isEnabled()) {
         return (Plugin)this.api;
      } else if (this.hosts.isEmpty()) {
         throw new MissingHostException("API '" + this.api.getClass().getName() + "' is disabled, but no other Hosts have been registered");
      } else {
         Iterator var1 = this.hosts.iterator();

         while(var1.hasNext()) {
            Plugin var2 = (Plugin)var1.next();
            if (var2.isEnabled()) {
               return var2;
            }
         }

         throw new MissingHostException("API '" + this.api.getClass().getName() + "' is disabled and all registered Hosts are as well");
      }
   }

   public void init() {
      if (!this.initialized) {
         this.api.init(this.initializerHost = this.getNextHost());
         this.initialized = true;
      }
   }

   public void disable() {
      if (this.initialized) {
         this.api.disable(this.initializerHost);
         this.initialized = false;
      }
   }
}
