package su.nightexpress.divineitems.libs.apihelper.exception;

public class HostRegistrationException extends RuntimeException {
   private static final long serialVersionUID = 1204727076469488682L;

   public HostRegistrationException() {
   }

   public HostRegistrationException(String var1) {
      super(var1);
   }

   public HostRegistrationException(String var1, Throwable var2) {
      super(var1, var2);
   }

   public HostRegistrationException(Throwable var1) {
      super(var1);
   }

   public HostRegistrationException(String var1, Throwable var2, boolean var3, boolean var4) {
      super(var1, var2, var3, var4);
   }
}
