package su.nightexpress.divineitems.libs.glowapi;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.World;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.Plugin;
import su.nightexpress.divineitems.DivineItems;
import su.nightexpress.divineitems.libs.apihelper.API;
import su.nightexpress.divineitems.libs.apihelper.APIManager;
import su.nightexpress.divineitems.libs.packetlistener.PacketListenerAPI;
import su.nightexpress.divineitems.libs.packetlistener.handler.PacketHandler;
import su.nightexpress.divineitems.libs.packetlistener.handler.PacketOptions;
import su.nightexpress.divineitems.libs.packetlistener.handler.ReceivedPacket;
import su.nightexpress.divineitems.libs.packetlistener.handler.SentPacket;
import su.nightexpress.divineitems.libs.reflection.minecraft.DataWatcher;
import su.nightexpress.divineitems.libs.reflection.minecraft.Minecraft;
import su.nightexpress.divineitems.libs.reflection.resolver.ConstructorResolver;
import su.nightexpress.divineitems.libs.reflection.resolver.FieldResolver;
import su.nightexpress.divineitems.libs.reflection.resolver.MethodResolver;
import su.nightexpress.divineitems.libs.reflection.resolver.ResolverQuery;
import su.nightexpress.divineitems.libs.reflection.resolver.minecraft.NMSClassResolver;
import su.nightexpress.divineitems.libs.reflection.resolver.minecraft.OBCClassResolver;
import su.nightexpress.divineitems.nms.VersionUtils;

public class GlowAPI implements API, Listener {
   private static Map<UUID, GlowData> dataMap = new HashMap();
   private static final NMSClassResolver NMS_CLASS_RESOLVER = new NMSClassResolver();
   private static Class<?> PacketPlayOutEntityMetadata;
   static Class<?> DataWatcher;
   static Class<?> DataWatcherItem;
   private static Class<?> Entity;
   private static FieldResolver PacketPlayOutMetadataFieldResolver;
   private static FieldResolver EntityFieldResolver;
   private static FieldResolver DataWatcherFieldResolver;
   static FieldResolver DataWatcherItemFieldResolver;
   private static ConstructorResolver DataWatcherItemConstructorResolver;
   private static MethodResolver DataWatcherMethodResolver;
   static MethodResolver DataWatcherItemMethodResolver;
   private static MethodResolver EntityMethodResolver;
   private static Class<?> PacketPlayOutScoreboardTeam;
   private static FieldResolver PacketScoreboardTeamFieldResolver;
   private static FieldResolver EntityPlayerFieldResolver;
   private static MethodResolver PlayerConnectionMethodResolver;
   public static String TEAM_TAG_VISIBILITY = "always";
   public static String TEAM_PUSH = "always";
   protected static NMSClassResolver nmsClassResolver = new NMSClassResolver();
   protected static OBCClassResolver obcClassResolver = new OBCClassResolver();
   private static FieldResolver CraftWorldFieldResolver;
   private static FieldResolver WorldFieldResolver;
   private static MethodResolver IntHashMapMethodResolver;

   public static void setGlowing(Entity var0, GlowAPI.Color var1, String var2, String var3, Player var4) {
      if (var4 != null) {
         boolean var5 = var1 != null;
         if (var0 == null) {
            var5 = false;
         }

         if (var0 instanceof OfflinePlayer && !((OfflinePlayer)var0).isOnline()) {
            var5 = false;
         }

         boolean var6 = dataMap.containsKey(var0 != null ? var0.getUniqueId() : null);
         GlowData var7;
         if (var6 && var0 != null) {
            var7 = (GlowData)dataMap.get(var0.getUniqueId());
         } else {
            var7 = new GlowData();
         }

         GlowAPI.Color var8 = var6 ? (GlowAPI.Color)var7.colorMap.get(var4.getUniqueId()) : null;
         if (var5) {
            var7.colorMap.put(var4.getUniqueId(), var1);
         } else {
            var7.colorMap.remove(var4.getUniqueId());
         }

         if (var7.colorMap.isEmpty()) {
            dataMap.remove(var0 != null ? var0.getUniqueId() : null);
         } else if (var0 != null) {
            dataMap.put(var0.getUniqueId(), var7);
         }

         if (var1 == null || var8 != var1) {
            if (var0 != null) {
               if (!(var0 instanceof OfflinePlayer) || ((OfflinePlayer)var0).isOnline()) {
                  if (var4.isOnline()) {
                     sendGlowPacket(var0, var6, var5, var4);
                     if (var8 != null && var8 != GlowAPI.Color.NONE) {
                        sendTeamPacket(var0, var8, false, false, var2, var3, var4);
                     }

                     if (var5) {
                        sendTeamPacket(var0, var1, false, var1 != GlowAPI.Color.NONE, var2, var3, var4);
                     }

                  }
               }
            }
         }
      }
   }

   public static void setGlowing(Entity var0, GlowAPI.Color var1, Player var2) {
      setGlowing(var0, var1, "always", "always", var2);
   }

   public static void setGlowing(Entity var0, boolean var1, Player var2) {
      setGlowing(var0, var1 ? GlowAPI.Color.NONE : null, var2);
   }

   public static void setGlowing(Entity var0, boolean var1, Collection<? extends Player> var2) {
      Iterator var4 = var2.iterator();

      while(var4.hasNext()) {
         Player var3 = (Player)var4.next();
         setGlowing(var0, var1, var3);
      }

   }

   public static void setGlowing(Entity var0, GlowAPI.Color var1, Collection<? extends Player> var2) {
      Iterator var4 = var2.iterator();

      while(var4.hasNext()) {
         Player var3 = (Player)var4.next();
         setGlowing(var0, var1, var3);
      }

   }

   public static void setGlowing(Collection<? extends Entity> var0, GlowAPI.Color var1, Player var2) {
      Iterator var4 = var0.iterator();

      while(var4.hasNext()) {
         Entity var3 = (Entity)var4.next();
         setGlowing(var3, var1, var2);
      }

   }

   public static void setGlowing(Collection<? extends Entity> var0, GlowAPI.Color var1, Collection<? extends Player> var2) {
      Iterator var4 = var0.iterator();

      while(var4.hasNext()) {
         Entity var3 = (Entity)var4.next();
         setGlowing(var3, var1, var2);
      }

   }

   public static boolean isGlowing(Entity var0, Player var1) {
      return getGlowColor(var0, var1) != null;
   }

   public static boolean isGlowing(Entity var0, Collection<? extends Player> var1, boolean var2) {
      if (var2) {
         boolean var6 = true;
         Iterator var5 = var1.iterator();

         while(var5.hasNext()) {
            Player var7 = (Player)var5.next();
            if (!isGlowing(var0, var7)) {
               var6 = false;
            }
         }

         return var6;
      } else {
         Iterator var4 = var1.iterator();

         while(var4.hasNext()) {
            Player var3 = (Player)var4.next();
            if (isGlowing(var0, var3)) {
               return true;
            }
         }

         return false;
      }
   }

   public static GlowAPI.Color getGlowColor(Entity var0, Player var1) {
      if (!dataMap.containsKey(var0.getUniqueId())) {
         return null;
      } else {
         GlowData var2 = (GlowData)dataMap.get(var0.getUniqueId());
         return (GlowAPI.Color)var2.colorMap.get(var1.getUniqueId());
      }
   }

   protected static void sendGlowPacket(Entity var0, boolean var1, boolean var2, Player var3) {
      try {
         if (PacketPlayOutEntityMetadata == null) {
            PacketPlayOutEntityMetadata = NMS_CLASS_RESOLVER.resolve("PacketPlayOutEntityMetadata");
         }

         if (DataWatcher == null) {
            DataWatcher = NMS_CLASS_RESOLVER.resolve("DataWatcher");
         }

         if (DataWatcherItem == null) {
            DataWatcherItem = NMS_CLASS_RESOLVER.resolve("DataWatcher$Item");
         }

         if (Entity == null) {
            Entity = NMS_CLASS_RESOLVER.resolve("Entity");
         }

         if (PacketPlayOutMetadataFieldResolver == null) {
            PacketPlayOutMetadataFieldResolver = new FieldResolver(PacketPlayOutEntityMetadata);
         }

         if (DataWatcherItemConstructorResolver == null) {
            DataWatcherItemConstructorResolver = new ConstructorResolver(DataWatcherItem);
         }

         if (EntityFieldResolver == null) {
            EntityFieldResolver = new FieldResolver(Entity);
         }

         if (DataWatcherMethodResolver == null) {
            DataWatcherMethodResolver = new MethodResolver(DataWatcher);
         }

         if (DataWatcherItemMethodResolver == null) {
            DataWatcherItemMethodResolver = new MethodResolver(DataWatcherItem);
         }

         if (EntityMethodResolver == null) {
            EntityMethodResolver = new MethodResolver(Entity);
         }

         if (DataWatcherFieldResolver == null) {
            DataWatcherFieldResolver = new FieldResolver(DataWatcher);
         }

         ArrayList var4 = new ArrayList();
         Object var5 = EntityMethodResolver.resolve("getDataWatcher").invoke(Minecraft.getHandle(var0));
         Map var6 = (Map)DataWatcherFieldResolver.resolveByLastType(Map.class).get(var5);
         Object var7 = DataWatcher.V1_9.ValueType.ENTITY_FLAG.getType();
         byte var8 = (Byte)(var6.isEmpty() ? 0 : DataWatcherItemMethodResolver.resolve("b").invoke(var6.get(0)));
         byte var9 = (byte)(var2 ? var8 | 64 : var8 & -65);
         Object var10 = DataWatcherItemConstructorResolver.resolveFirstConstructor().newInstance(var7, var9);
         var4.add(var10);
         Object var11 = PacketPlayOutEntityMetadata.newInstance();
         PacketPlayOutMetadataFieldResolver.resolve("a").set(var11, -var0.getEntityId());
         PacketPlayOutMetadataFieldResolver.resolve("b").set(var11, var4);
         sendPacket(var11, var3);
      } catch (ReflectiveOperationException var12) {
         throw new RuntimeException(var12);
      }
   }

   public static void initTeam(Player var0, String var1, String var2) {
      GlowAPI.Color[] var6;
      int var5 = (var6 = GlowAPI.Color.values()).length;

      for(int var4 = 0; var4 < var5; ++var4) {
         GlowAPI.Color var3 = var6[var4];
         sendTeamPacket((Entity)null, var3, true, false, var1, var2, var0);
      }

   }

   public static void initTeam(Player var0) {
      initTeam(var0, TEAM_TAG_VISIBILITY, TEAM_PUSH);
   }

   protected static void sendTeamPacket(Entity var0, GlowAPI.Color var1, boolean var2, boolean var3, String var4, String var5, Player var6) {
      try {
         if (PacketPlayOutScoreboardTeam == null) {
            PacketPlayOutScoreboardTeam = NMS_CLASS_RESOLVER.resolve("PacketPlayOutScoreboardTeam");
         }

         if (PacketScoreboardTeamFieldResolver == null) {
            PacketScoreboardTeamFieldResolver = new FieldResolver(PacketPlayOutScoreboardTeam);
         }

         Object var7 = PacketPlayOutScoreboardTeam.newInstance();
         PacketScoreboardTeamFieldResolver.resolve("i").set(var7, var2 ? 0 : (var3 ? 3 : 4));
         PacketScoreboardTeamFieldResolver.resolve("a").set(var7, var1.getTeamName());
         PacketScoreboardTeamFieldResolver.resolve("e").set(var7, var4);
         PacketScoreboardTeamFieldResolver.resolve("f").set(var7, var5);
         if (var2) {
            if (!VersionUtils.Version.getCurrent().isHigher(VersionUtils.Version.v1_12_R1)) {
               PacketScoreboardTeamFieldResolver.resolve("g").set(var7, var1.packetValue);
               PacketScoreboardTeamFieldResolver.resolve("c").set(var7, "§" + var1.colorCode);
               PacketScoreboardTeamFieldResolver.resolve("b").set(var7, var1.getTeamName());
               PacketScoreboardTeamFieldResolver.resolve("d").set(var7, "");
            } else {
               if (var1 == GlowAPI.Color.NONE) {
                  return;
               }

               String var8 = var1.name();
               if (var8.equalsIgnoreCase("PURPLE")) {
                  var8 = "LIGHT_PURPLE";
               }

               Class var9 = DivineItems.getInstance().getVU().getNmsClass("EnumChatFormat");
               Enum[] var10 = (Enum[])var9.getEnumConstants();
               Enum var11 = null;
               Enum[] var15 = var10;
               int var14 = var10.length;

               for(int var13 = 0; var13 < var14; ++var13) {
                  Enum var12 = var15[var13];
                  if (var12.name().equalsIgnoreCase(var8)) {
                     var11 = var12;
                  }
               }

               Object var18 = DivineItems.getInstance().getVU().getNmsClass("ChatComponentText").getConstructor(String.class).newInstance("§" + var1.colorCode);
               Object var19 = DivineItems.getInstance().getVU().getNmsClass("ChatComponentText").getConstructor(String.class).newInstance(var1.getTeamName());
               Object var20 = DivineItems.getInstance().getVU().getNmsClass("ChatComponentText").getConstructor(String.class).newInstance("");
               PacketScoreboardTeamFieldResolver.resolve("g").set(var7, var11);
               PacketScoreboardTeamFieldResolver.resolve("c").set(var7, var18);
               PacketScoreboardTeamFieldResolver.resolve("b").set(var7, var19);
               PacketScoreboardTeamFieldResolver.resolve("d").set(var7, var20);
            }

            PacketScoreboardTeamFieldResolver.resolve("j").set(var7, 0);
         }

         if (!var2) {
            Collection var17 = (Collection)PacketScoreboardTeamFieldResolver.resolve("h").get(var7);
            if (var0 instanceof OfflinePlayer) {
               var17.add(var0.getName());
            } else {
               var17.add(var0.getUniqueId().toString());
            }
         }

         sendPacket(var7, var6);
      } catch (ReflectiveOperationException var16) {
         throw new RuntimeException(var16);
      }
   }

   protected static void sendPacket(Object var0, Player var1) {
      if (EntityPlayerFieldResolver == null) {
         EntityPlayerFieldResolver = new FieldResolver(NMS_CLASS_RESOLVER.resolve("EntityPlayer"));
      }

      if (PlayerConnectionMethodResolver == null) {
         PlayerConnectionMethodResolver = new MethodResolver(NMS_CLASS_RESOLVER.resolve("PlayerConnection"));
      }

      try {
         Object var2 = Minecraft.getHandle(var1);
         Object var3 = EntityPlayerFieldResolver.resolve("playerConnection").get(var2);
         PlayerConnectionMethodResolver.resolve("sendPacket").invoke(var3, var0);
      } catch (ReflectiveOperationException var4) {
         throw new RuntimeException(var4);
      }
   }

   public void load() {
      APIManager.require(PacketListenerAPI.class, DivineItems.instance);
   }

   public void init(Plugin var1) {
      APIManager.initAPI(PacketListenerAPI.class);
      APIManager.registerEvents(this, this);
      PacketHandler.addHandler(new PacketHandler((Plugin)(DivineItems.instance != null ? DivineItems.instance : var1)) {
         @PacketOptions(
            forcePlayer = true
         )
         public void onSend(SentPacket var1) {
            if ("PacketPlayOutEntityMetadata".equals(var1.getPacketName())) {
               int var2 = (Integer)var1.getPacketValue("a");
               if (var2 < 0) {
                  var1.setPacketValue("a", -var2);
                  return;
               }

               List var3 = (List)var1.getPacketValue("b");
               if (var3 == null || var3.isEmpty()) {
                  return;
               }

               Entity var4 = GlowAPI.getEntityById(var1.getPlayer().getWorld(), var2);
               if (var4 != null && GlowAPI.isGlowing(var4, var1.getPlayer())) {
                  if (GlowAPI.DataWatcherItemMethodResolver == null) {
                     GlowAPI.DataWatcherItemMethodResolver = new MethodResolver(GlowAPI.DataWatcherItem);
                  }

                  if (GlowAPI.DataWatcherItemFieldResolver == null) {
                     GlowAPI.DataWatcherItemFieldResolver = new FieldResolver(GlowAPI.DataWatcherItem);
                  }

                  try {
                     Iterator var6 = var3.iterator();

                     while(var6.hasNext()) {
                        Object var5 = var6.next();
                        Object var7 = GlowAPI.DataWatcherItemMethodResolver.resolve("b").invoke(var5);
                        if (var7 instanceof Byte) {
                           byte var8 = (Byte)var7;
                           byte var9 = (byte)(var8 | 64);
                           GlowAPI.DataWatcherItemFieldResolver.resolve("b").set(var5, var9);
                        }
                     }
                  } catch (Exception var10) {
                     throw new RuntimeException(var10);
                  }
               }
            }

         }

         public void onReceive(ReceivedPacket var1) {
         }
      });
   }

   public void disable(Plugin var1) {
   }

   @EventHandler
   public void onJoin(PlayerJoinEvent var1) {
      initTeam(var1.getPlayer());
   }

   @EventHandler
   public void onQuit(PlayerQuitEvent var1) {
      Iterator var3 = Bukkit.getOnlinePlayers().iterator();

      while(var3.hasNext()) {
         Player var2 = (Player)var3.next();
         if (isGlowing(var1.getPlayer(), var2)) {
            setGlowing((Entity)var1.getPlayer(), (GlowAPI.Color)null, (Player)var2);
         }
      }

   }

   public static Entity getEntityById(World var0, int var1) {
      try {
         if (CraftWorldFieldResolver == null) {
            CraftWorldFieldResolver = new FieldResolver(obcClassResolver.resolve("CraftWorld"));
         }

         if (WorldFieldResolver == null) {
            WorldFieldResolver = new FieldResolver(nmsClassResolver.resolve("World"));
         }

         if (IntHashMapMethodResolver == null) {
            IntHashMapMethodResolver = new MethodResolver(nmsClassResolver.resolve("IntHashMap"));
         }

         if (EntityMethodResolver == null) {
            EntityMethodResolver = new MethodResolver(nmsClassResolver.resolve("Entity"));
         }

         Object var2 = WorldFieldResolver.resolve("entitiesById").get(CraftWorldFieldResolver.resolve("world").get(var0));
         Object var3 = IntHashMapMethodResolver.resolve(new ResolverQuery("get", new Class[]{Integer.TYPE})).invoke(var2, var1);
         return var3 == null ? null : (Entity)EntityMethodResolver.resolve("getBukkitEntity").invoke(var3);
      } catch (Exception var4) {
         throw new RuntimeException(var4);
      }
   }

   public static enum Color {
      BLACK(0, "0"),
      DARK_BLUE(1, "1"),
      DARK_GREEN(2, "2"),
      DARK_AQUA(3, "3"),
      DARK_RED(4, "4"),
      DARK_PURPLE(5, "5"),
      GOLD(6, "6"),
      GRAY(7, "7"),
      DARK_GRAY(8, "8"),
      BLUE(9, "9"),
      GREEN(10, "a"),
      AQUA(11, "b"),
      RED(12, "c"),
      PURPLE(13, "d"),
      YELLOW(14, "e"),
      WHITE(15, "f"),
      NONE(-1, "");

      int packetValue;
      String colorCode;

      private Color(int var3, String var4) {
         this.packetValue = var3;
         this.colorCode = var4;
      }

      String getTeamName() {
         String var1 = String.format("GAPI#%s", this.name());
         if (var1.length() > 16) {
            var1 = var1.substring(0, 16);
         }

         return var1;
      }
   }
}
