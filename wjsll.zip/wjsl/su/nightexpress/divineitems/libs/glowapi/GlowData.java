package su.nightexpress.divineitems.libs.glowapi;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class GlowData {
   public Map<UUID, GlowAPI.Color> colorMap = new HashMap();

   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (var1 != null && this.getClass() == var1.getClass()) {
         GlowData var2 = (GlowData)var1;
         return this.colorMap != null ? this.colorMap.equals(var2.colorMap) : var2.colorMap == null;
      } else {
         return false;
      }
   }

   public int hashCode() {
      return this.colorMap != null ? this.colorMap.hashCode() : 0;
   }
}
