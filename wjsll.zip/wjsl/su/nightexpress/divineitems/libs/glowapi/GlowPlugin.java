package su.nightexpress.divineitems.libs.glowapi;

import su.nightexpress.divineitems.DivineItems;
import su.nightexpress.divineitems.libs.apihelper.APIManager;

public class GlowPlugin {
   private DivineItems plugin;
   private GlowAPI glowAPI;

   public GlowPlugin(DivineItems var1) {
      this.plugin = var1;
   }

   public void setup() {
      this.glowAPI = new GlowAPI();
      APIManager.registerAPI(this.glowAPI, this.plugin);
      APIManager.initAPI(GlowAPI.class);
   }

   public void disable() {
      APIManager.disableAPI(GlowAPI.class);
   }
}
