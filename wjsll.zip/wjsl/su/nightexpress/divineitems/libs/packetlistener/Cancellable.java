package su.nightexpress.divineitems.libs.packetlistener;

public class Cancellable implements org.bukkit.event.Cancellable {
   private boolean cancelled;

   public boolean isCancelled() {
      return this.cancelled;
   }

   public void setCancelled(boolean var1) {
      this.cancelled = var1;
   }
}
