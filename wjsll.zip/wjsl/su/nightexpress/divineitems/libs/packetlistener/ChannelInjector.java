package su.nightexpress.divineitems.libs.packetlistener;

import org.bukkit.entity.Player;
import su.nightexpress.divineitems.libs.packetlistener.channel.ChannelAbstract;
import su.nightexpress.divineitems.libs.reflection.resolver.ClassResolver;
import su.nightexpress.divineitems.libs.reflection.resolver.ConstructorResolver;

public class ChannelInjector {
   private static final ClassResolver CLASS_RESOLVER = new ClassResolver();
   private ChannelAbstract channel;

   public boolean inject(IPacketListener var1) {
      try {
         Class.forName("io.netty.channel.Channel");
         this.channel = this.newChannelInstance(var1, "su.nightexpress.divineitems.libs.packetlistener.channel.INCChannel");
         return true;
      } catch (Exception var3) {
         var3.printStackTrace();
         return false;
      }
   }

   protected ChannelAbstract newChannelInstance(IPacketListener var1, String var2) {
      return (ChannelAbstract)(new ConstructorResolver(CLASS_RESOLVER.resolve(var2))).resolve(new Class[]{IPacketListener.class}).newInstance(var1);
   }

   public void addChannel(Player var1) {
      this.channel.addChannel(var1);
   }

   public void removeChannel(Player var1) {
      this.channel.removeChannel(var1);
   }

   public void addServerChannel() {
      this.channel.addServerChannel();
   }
}
