package su.nightexpress.divineitems.libs.packetlistener;

public interface IPacketListener {
   Object onPacketSend(Object var1, Object var2, org.bukkit.event.Cancellable var3);

   Object onPacketReceive(Object var1, Object var2, org.bukkit.event.Cancellable var3);
}
