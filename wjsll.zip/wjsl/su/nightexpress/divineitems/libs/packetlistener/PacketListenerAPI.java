package su.nightexpress.divineitems.libs.packetlistener;

import java.util.Iterator;
import java.util.logging.Logger;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.Plugin;
import su.nightexpress.divineitems.libs.apihelper.API;
import su.nightexpress.divineitems.libs.apihelper.APIManager;
import su.nightexpress.divineitems.libs.packetlistener.channel.ChannelWrapper;
import su.nightexpress.divineitems.libs.packetlistener.handler.PacketHandler;
import su.nightexpress.divineitems.libs.packetlistener.handler.ReceivedPacket;
import su.nightexpress.divineitems.libs.packetlistener.handler.SentPacket;

public class PacketListenerAPI implements IPacketListener, Listener, API {
   private ChannelInjector channelInjector;
   protected boolean injected = false;
   Logger logger = Logger.getLogger("PacketListenerAPI");

   public void load() {
      this.channelInjector = new ChannelInjector();
      if (this.injected = this.channelInjector.inject(this)) {
         this.channelInjector.addServerChannel();
         this.logger.info("Injected custom channel handlers.");
      } else {
         this.logger.severe("Failed to inject channel handlers");
      }

   }

   public void init(Plugin var1) {
      APIManager.registerEvents(this, this);
      this.logger.info("Adding channels for online players...");
      Iterator var3 = Bukkit.getOnlinePlayers().iterator();

      while(var3.hasNext()) {
         Player var2 = (Player)var3.next();
         this.channelInjector.addChannel(var2);
      }

   }

   public void disable(Plugin var1) {
      if (this.injected) {
         this.logger.info("Removing channels for online players...");
         Iterator var3 = Bukkit.getOnlinePlayers().iterator();

         while(var3.hasNext()) {
            Player var2 = (Player)var3.next();
            this.channelInjector.removeChannel(var2);
         }

         this.logger.info("Removing packet handlers (" + PacketHandler.getHandlers().size() + ")...");

         while(!PacketHandler.getHandlers().isEmpty()) {
            PacketHandler.removeHandler((PacketHandler)PacketHandler.getHandlers().get(0));
         }

      }
   }

   public static boolean addPacketHandler(PacketHandler var0) {
      return PacketHandler.addHandler(var0);
   }

   public static boolean removePacketHandler(PacketHandler var0) {
      return PacketHandler.removeHandler(var0);
   }

   @EventHandler
   public void onJoin(PlayerJoinEvent var1) {
      this.channelInjector.addChannel(var1.getPlayer());
   }

   @EventHandler
   public void onQuit(PlayerQuitEvent var1) {
      this.channelInjector.removeChannel(var1.getPlayer());
   }

   public Object onPacketReceive(Object var1, Object var2, org.bukkit.event.Cancellable var3) {
      ReceivedPacket var4;
      if (var1 instanceof Player) {
         var4 = new ReceivedPacket(var2, var3, (Player)var1);
      } else {
         var4 = new ReceivedPacket(var2, var3, (ChannelWrapper)var1);
      }

      PacketHandler.notifyHandlers(var4);
      return var4.getPacket() != null ? var4.getPacket() : var2;
   }

   public Object onPacketSend(Object var1, Object var2, org.bukkit.event.Cancellable var3) {
      SentPacket var4;
      if (var1 instanceof Player) {
         var4 = new SentPacket(var2, var3, (Player)var1);
      } else {
         var4 = new SentPacket(var2, var3, (ChannelWrapper)var1);
      }

      PacketHandler.notifyHandlers(var4);
      return var4.getPacket() != null ? var4.getPacket() : var2;
   }
}
