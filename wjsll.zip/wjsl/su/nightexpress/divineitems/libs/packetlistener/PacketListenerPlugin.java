package su.nightexpress.divineitems.libs.packetlistener;

import su.nightexpress.divineitems.DivineItems;
import su.nightexpress.divineitems.libs.apihelper.APIManager;

public class PacketListenerPlugin {
   private DivineItems plugin;
   private PacketListenerAPI packetListenerAPI;

   public PacketListenerPlugin(DivineItems var1) {
      this.plugin = var1;
      this.packetListenerAPI = new PacketListenerAPI();
   }

   public void setup() {
      APIManager.registerAPI(this.packetListenerAPI, this.plugin);
      APIManager.initAPI(PacketListenerAPI.class);
   }

   public void disable() {
      this.packetListenerAPI.disable(this.plugin);
      APIManager.disableAPI(PacketListenerAPI.class);
   }

   public PacketListenerAPI getPLA() {
      return this.packetListenerAPI;
   }
}
