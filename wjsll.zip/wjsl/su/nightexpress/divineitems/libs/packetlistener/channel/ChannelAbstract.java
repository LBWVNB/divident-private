package su.nightexpress.divineitems.libs.packetlistener.channel;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import su.nightexpress.divineitems.libs.packetlistener.Cancellable;
import su.nightexpress.divineitems.libs.packetlistener.IPacketListener;
import su.nightexpress.divineitems.libs.reflection.resolver.FieldResolver;
import su.nightexpress.divineitems.libs.reflection.resolver.MethodResolver;
import su.nightexpress.divineitems.libs.reflection.resolver.minecraft.NMSClassResolver;
import su.nightexpress.divineitems.libs.reflection.util.AccessUtil;

public abstract class ChannelAbstract {
   protected static final NMSClassResolver nmsClassResolver = new NMSClassResolver();
   static final Class<?> EntityPlayer;
   static final Class<?> PlayerConnection;
   static final Class<?> NetworkManager;
   static final Class<?> Packet;
   static final Class<?> ServerConnection;
   static final Class<?> MinecraftServer;
   protected static final FieldResolver entityPlayerFieldResolver;
   protected static final FieldResolver playerConnectionFieldResolver;
   protected static final FieldResolver networkManagerFieldResolver;
   protected static final FieldResolver minecraftServerFieldResolver;
   protected static final FieldResolver serverConnectionFieldResolver;
   static final Field networkManager;
   static final Field playerConnection;
   static final Field serverConnection;
   static final Field connectionList;
   protected static final MethodResolver craftServerFieldResolver;
   static final Method getServer;
   final Executor addChannelExecutor = Executors.newSingleThreadExecutor();
   final Executor removeChannelExecutor = Executors.newSingleThreadExecutor();
   static final String KEY_HANDLER = "packet_handler";
   static final String KEY_PLAYER = "packet_listener_player";
   static final String KEY_SERVER = "packet_listener_server";
   private IPacketListener iPacketListener;

   static {
      EntityPlayer = nmsClassResolver.resolveSilent(new String[]{"EntityPlayer"});
      PlayerConnection = nmsClassResolver.resolveSilent(new String[]{"PlayerConnection"});
      NetworkManager = nmsClassResolver.resolveSilent(new String[]{"NetworkManager"});
      Packet = nmsClassResolver.resolveSilent(new String[]{"Packet"});
      ServerConnection = nmsClassResolver.resolveSilent(new String[]{"ServerConnection"});
      MinecraftServer = nmsClassResolver.resolveSilent(new String[]{"MinecraftServer"});
      entityPlayerFieldResolver = new FieldResolver(EntityPlayer);
      playerConnectionFieldResolver = new FieldResolver(PlayerConnection);
      networkManagerFieldResolver = new FieldResolver(NetworkManager);
      minecraftServerFieldResolver = new FieldResolver(MinecraftServer);
      serverConnectionFieldResolver = new FieldResolver(ServerConnection);
      networkManager = playerConnectionFieldResolver.resolveSilent("networkManager");
      playerConnection = entityPlayerFieldResolver.resolveSilent("playerConnection");
      serverConnection = minecraftServerFieldResolver.resolveByFirstTypeSilent(ServerConnection);
      connectionList = serverConnectionFieldResolver.resolveByLastTypeSilent(List.class);
      craftServerFieldResolver = new MethodResolver(Bukkit.getServer().getClass());
      getServer = craftServerFieldResolver.resolveSilent("getServer");
   }

   public ChannelAbstract(IPacketListener var1) {
      this.iPacketListener = var1;
   }

   public abstract void addChannel(Player var1);

   public abstract void removeChannel(Player var1);

   public void addServerChannel() {
      try {
         Object var1 = getServer.invoke(Bukkit.getServer());
         if (var1 == null) {
            return;
         }

         Object var2 = serverConnection.get(var1);
         if (var2 == null) {
            return;
         }

         List var3 = (List)connectionList.get(var2);
         Field var4 = AccessUtil.setAccessible(var3.getClass().getSuperclass().getDeclaredField("list"));
         Object var5 = var4.get(var3);
         if (ChannelAbstract.IListenerList.class.isAssignableFrom(var5.getClass())) {
            return;
         }

         List var6 = Collections.synchronizedList(this.newListenerList());
         Iterator var8 = var3.iterator();

         while(var8.hasNext()) {
            Object var7 = var8.next();
            var6.add(var7);
         }

         connectionList.set(var2, var6);
      } catch (Exception var9) {
      }

   }

   public abstract ChannelAbstract.IListenerList<Object> newListenerList();

   protected final Object onPacketSend(Object var1, Object var2, Cancellable var3) {
      return this.iPacketListener.onPacketSend(var1, var2, var3);
   }

   protected final Object onPacketReceive(Object var1, Object var2, Cancellable var3) {
      return this.iPacketListener.onPacketReceive(var1, var2, var3);
   }

   interface IChannelHandler {
   }

   interface IChannelWrapper {
   }

   interface IListenerList<E> extends List<E> {
   }
}
