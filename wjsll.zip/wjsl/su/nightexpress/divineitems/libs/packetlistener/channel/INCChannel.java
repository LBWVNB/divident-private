package su.nightexpress.divineitems.libs.packetlistener.channel;

import io.netty.channel.Channel;
import io.netty.channel.ChannelDuplexHandler;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelPromise;
import java.lang.reflect.Field;
import java.net.SocketAddress;
import java.util.ArrayList;
import org.bukkit.entity.Player;
import su.nightexpress.divineitems.libs.packetlistener.Cancellable;
import su.nightexpress.divineitems.libs.packetlistener.IPacketListener;
import su.nightexpress.divineitems.libs.reflection.minecraft.Minecraft;

public class INCChannel extends ChannelAbstract {
   private static final Field channelField;

   static {
      channelField = networkManagerFieldResolver.resolveByFirstTypeSilent(Channel.class);
   }

   public INCChannel(IPacketListener var1) {
      super(var1);
   }

   public void addChannel(final Player var1) {
      try {
         final Channel var2 = this.getChannel(var1);
         this.addChannelExecutor.execute(new Runnable() {
            public void run() {
               if (var2.pipeline().get("packet_listener_server") == null) {
                  try {
                     var2.pipeline().addBefore("packet_handler", "packet_listener_player", INCChannel.this.new ChannelHandler(var1));
                  } catch (Exception var2x) {
                  }
               }

            }
         });
      } catch (ReflectiveOperationException var3) {
         throw new RuntimeException("Failed to add channel for " + var1, var3);
      }
   }

   public void removeChannel(Player var1) {
      try {
         final Channel var2 = this.getChannel(var1);
         this.removeChannelExecutor.execute(new Runnable() {
            public void run() {
               try {
                  if (var2.pipeline().get("packet_listener_player") != null) {
                     var2.pipeline().remove("packet_listener_player");
                  }

               } catch (Exception var2x) {
                  throw new RuntimeException(var2x);
               }
            }
         });
      } catch (ReflectiveOperationException var3) {
         throw new RuntimeException("Failed to remove channel for " + var1, var3);
      }
   }

   Channel getChannel(Player var1) {
      Object var2 = Minecraft.getHandle(var1);
      Object var3 = playerConnection.get(var2);
      return (Channel)channelField.get(networkManager.get(var3));
   }

   public ChannelAbstract.IListenerList newListenerList() {
      return new INCChannel.ListenerList();
   }

   class ChannelHandler extends ChannelDuplexHandler implements ChannelAbstract.IChannelHandler {
      private Object owner;

      public ChannelHandler(Player var2) {
         this.owner = var2;
      }

      public ChannelHandler(ChannelWrapper var2) {
         this.owner = var2;
      }

      public void write(ChannelHandlerContext var1, Object var2, ChannelPromise var3) {
         Cancellable var4 = new Cancellable();
         Object var5 = var2;
         if (INCChannel.Packet.isAssignableFrom(var2.getClass())) {
            var5 = INCChannel.this.onPacketSend(this.owner, var2, var4);
         }

         if (!var4.isCancelled()) {
            super.write(var1, var5, var3);
         }
      }

      public void channelRead(ChannelHandlerContext var1, Object var2) {
         Cancellable var3 = new Cancellable();
         Object var4 = var2;
         if (INCChannel.Packet.isAssignableFrom(var2.getClass())) {
            var4 = INCChannel.this.onPacketReceive(this.owner, var2, var3);
         }

         if (!var3.isCancelled()) {
            super.channelRead(var1, var4);
         }
      }

      public String toString() {
         return "INCChannel$ChannelHandler@" + this.hashCode() + " (" + this.owner + ")";
      }
   }

   class INCChannelWrapper extends ChannelWrapper<Channel> implements ChannelAbstract.IChannelWrapper {
      public INCChannelWrapper(Channel var2) {
         super(var2);
      }

      public SocketAddress getRemoteAddress() {
         return ((Channel)this.channel()).remoteAddress();
      }

      public SocketAddress getLocalAddress() {
         return ((Channel)this.channel()).localAddress();
      }
   }

   class ListenerList<E> extends ArrayList<E> implements ChannelAbstract.IListenerList<E> {
      public boolean add(final E var1) {
         try {
            INCChannel.this.addChannelExecutor.execute(new Runnable() {
               public void run() {
                  try {
                     Channel var1x;
                     for(var1x = null; var1x == null; var1x = (Channel)INCChannel.channelField.get(var1)) {
                     }

                     if (var1x.pipeline().get("packet_listener_server") == null) {
                        var1x.pipeline().addBefore("packet_handler", "packet_listener_server", INCChannel.this.new ChannelHandler(INCChannel.this.new INCChannelWrapper(var1x)));
                     }
                  } catch (Exception var2) {
                  }

               }
            });
         } catch (Exception var3) {
         }

         return super.add(var1);
      }

      public boolean remove(final Object var1) {
         try {
            INCChannel.this.removeChannelExecutor.execute(new Runnable() {
               public void run() {
                  try {
                     Channel var1x;
                     for(var1x = null; var1x == null; var1x = (Channel)INCChannel.channelField.get(var1)) {
                     }

                     var1x.pipeline().remove("packet_listener_server");
                  } catch (Exception var2) {
                  }

               }
            });
         } catch (Exception var3) {
         }

         return super.remove(var1);
      }
   }
}
