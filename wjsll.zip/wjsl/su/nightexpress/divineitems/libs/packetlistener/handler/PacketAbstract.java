package su.nightexpress.divineitems.libs.packetlistener.handler;

import org.bukkit.entity.Player;
import org.bukkit.event.Cancellable;
import su.nightexpress.divineitems.libs.packetlistener.channel.ChannelWrapper;
import su.nightexpress.divineitems.libs.reflection.resolver.FieldResolver;

public abstract class PacketAbstract {
   private Player player;
   private ChannelWrapper channelWrapper;
   private Object packet;
   private Cancellable cancellable;
   protected FieldResolver fieldResolver;

   public PacketAbstract(Object var1, Cancellable var2, Player var3) {
      this.player = var3;
      this.packet = var1;
      this.cancellable = var2;
      this.fieldResolver = new FieldResolver(var1.getClass());
   }

   public PacketAbstract(Object var1, Cancellable var2, ChannelWrapper var3) {
      this.channelWrapper = var3;
      this.packet = var1;
      this.cancellable = var2;
      this.fieldResolver = new FieldResolver(var1.getClass());
   }

   public void setPacketValue(String var1, Object var2) {
      try {
         this.fieldResolver.resolve(var1).set(this.getPacket(), var2);
      } catch (Exception var4) {
         throw new RuntimeException(var4);
      }
   }

   public void setPacketValueSilent(String var1, Object var2) {
      try {
         this.fieldResolver.resolve(var1).set(this.getPacket(), var2);
      } catch (Exception var4) {
      }

   }

   public void setPacketValue(int var1, Object var2) {
      try {
         this.fieldResolver.resolveIndex(var1).set(this.getPacket(), var2);
      } catch (Exception var4) {
         throw new RuntimeException(var4);
      }
   }

   public void setPacketValueSilent(int var1, Object var2) {
      try {
         this.fieldResolver.resolveIndex(var1).set(this.getPacket(), var2);
      } catch (Exception var4) {
      }

   }

   public Object getPacketValue(String var1) {
      try {
         return this.fieldResolver.resolve(var1).get(this.getPacket());
      } catch (Exception var3) {
         throw new RuntimeException(var3);
      }
   }

   public Object getPacketValueSilent(String var1) {
      try {
         return this.fieldResolver.resolve(var1).get(this.getPacket());
      } catch (Exception var3) {
         return null;
      }
   }

   public Object getPacketValue(int var1) {
      try {
         return this.fieldResolver.resolveIndex(var1).get(this.getPacket());
      } catch (Exception var3) {
         throw new RuntimeException(var3);
      }
   }

   public Object getPacketValueSilent(int var1) {
      try {
         return this.fieldResolver.resolveIndex(var1).get(this.getPacket());
      } catch (Exception var3) {
         throw new RuntimeException(var3);
      }
   }

   public FieldResolver getFieldResolver() {
      return this.fieldResolver;
   }

   public void setCancelled(boolean var1) {
      this.cancellable.setCancelled(var1);
   }

   public boolean isCancelled() {
      return this.cancellable.isCancelled();
   }

   public Player getPlayer() {
      return this.player;
   }

   public boolean hasPlayer() {
      return this.player != null;
   }

   public ChannelWrapper<?> getChannel() {
      return this.channelWrapper;
   }

   public boolean hasChannel() {
      return this.channelWrapper != null;
   }

   public String getPlayername() {
      return !this.hasPlayer() ? null : this.player.getName();
   }

   public void setPacket(Object var1) {
      this.packet = var1;
   }

   public Object getPacket() {
      return this.packet;
   }

   public String getPacketName() {
      return this.packet.getClass().getSimpleName();
   }

   public String toString() {
      return "Packet{ " + (this.getClass().equals(SentPacket.class) ? "[> OUT >]" : "[< IN <]") + " " + this.getPacketName() + " " + (this.hasPlayer() ? this.getPlayername() : (this.hasChannel() ? this.getChannel().channel() : "#server#")) + " }";
   }
}
