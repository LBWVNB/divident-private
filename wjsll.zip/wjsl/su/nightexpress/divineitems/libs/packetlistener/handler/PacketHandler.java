package su.nightexpress.divineitems.libs.packetlistener.handler;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import su.nightexpress.divineitems.libs.reflection.minecraft.Minecraft;
import su.nightexpress.divineitems.libs.reflection.resolver.FieldResolver;
import su.nightexpress.divineitems.libs.reflection.resolver.MethodResolver;
import su.nightexpress.divineitems.libs.reflection.resolver.minecraft.NMSClassResolver;
import su.nightexpress.divineitems.libs.reflection.util.AccessUtil;

public abstract class PacketHandler {
   private static final List<PacketHandler> handlers = new ArrayList();
   private boolean hasSendOptions;
   private boolean forcePlayerSend;
   private boolean forceServerSend;
   private boolean hasReceiveOptions;
   private boolean forcePlayerReceive;
   private boolean forceServerReceive;
   static NMSClassResolver nmsClassResolver = new NMSClassResolver();
   static FieldResolver EntityPlayerFieldResolver;
   static MethodResolver PlayerConnectionMethodResolver;
   private Plugin plugin;

   static {
      EntityPlayerFieldResolver = new FieldResolver(nmsClassResolver.resolveSilent(new String[]{"EntityPlayer"}));
      PlayerConnectionMethodResolver = new MethodResolver(nmsClassResolver.resolveSilent(new String[]{"PlayerConnection"}));
   }

   public static boolean addHandler(PacketHandler var0) {
      boolean var1 = handlers.contains(var0);
      if (!var1) {
         PacketOptions var2;
         try {
            var2 = (PacketOptions)var0.getClass().getMethod("onSend", SentPacket.class).getAnnotation(PacketOptions.class);
            if (var2 != null) {
               var0.hasSendOptions = true;
               if (var2.forcePlayer() && var2.forceServer()) {
                  throw new IllegalArgumentException("Cannot force player and server packets at the same time!");
               }

               if (var2.forcePlayer()) {
                  var0.forcePlayerSend = true;
               } else if (var2.forceServer()) {
                  var0.forceServerSend = true;
               }
            }
         } catch (Exception var4) {
            throw new RuntimeException("Failed to register handler (onSend)", var4);
         }

         try {
            var2 = (PacketOptions)var0.getClass().getMethod("onReceive", ReceivedPacket.class).getAnnotation(PacketOptions.class);
            if (var2 != null) {
               var0.hasReceiveOptions = true;
               if (var2.forcePlayer() && var2.forceServer()) {
                  throw new IllegalArgumentException("Cannot force player and server packets at the same time!");
               }

               if (var2.forcePlayer()) {
                  var0.forcePlayerReceive = true;
               } else if (var2.forceServer()) {
                  var0.forceServerReceive = true;
               }
            }
         } catch (Exception var3) {
            throw new RuntimeException("Failed to register handler (onReceive)", var3);
         }
      }

      handlers.add(var0);
      return !var1;
   }

   public static boolean removeHandler(PacketHandler var0) {
      return handlers.remove(var0);
   }

   public static void notifyHandlers(SentPacket var0) {
      Iterator var2 = getHandlers().iterator();

      while(var2.hasNext()) {
         PacketHandler var1 = (PacketHandler)var2.next();

         try {
            if (var1.hasSendOptions) {
               if (var1.forcePlayerSend) {
                  if (!var0.hasPlayer()) {
                     continue;
                  }
               } else if (var1.forceServerSend && !var0.hasChannel()) {
                  continue;
               }
            }

            var1.onSend(var0);
         } catch (Exception var4) {
            System.err.println("[PacketListenerAPI] An exception occured while trying to execute 'onSend'" + (var1.plugin != null ? " in plugin " + var1.plugin.getName() : "") + ": " + var4.getMessage());
            var4.printStackTrace(System.err);
         }
      }

   }

   public static void notifyHandlers(ReceivedPacket var0) {
      Iterator var2 = getHandlers().iterator();

      while(var2.hasNext()) {
         PacketHandler var1 = (PacketHandler)var2.next();

         try {
            if (var1.hasReceiveOptions) {
               if (var1.forcePlayerReceive) {
                  if (!var0.hasPlayer()) {
                     continue;
                  }
               } else if (var1.forceServerReceive && !var0.hasChannel()) {
                  continue;
               }
            }

            var1.onReceive(var0);
         } catch (Exception var4) {
            System.err.println("[PacketListenerAPI] An exception occured while trying to execute 'onReceive'" + (var1.plugin != null ? " in plugin " + var1.plugin.getName() : "") + ": " + var4.getMessage());
            var4.printStackTrace(System.err);
         }
      }

   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (var1 != null && this.getClass() == var1.getClass()) {
         PacketHandler var2 = (PacketHandler)var1;
         if (this.hasSendOptions != var2.hasSendOptions) {
            return false;
         } else if (this.forcePlayerSend != var2.forcePlayerSend) {
            return false;
         } else if (this.forceServerSend != var2.forceServerSend) {
            return false;
         } else if (this.hasReceiveOptions != var2.hasReceiveOptions) {
            return false;
         } else if (this.forcePlayerReceive != var2.forcePlayerReceive) {
            return false;
         } else if (this.forceServerReceive != var2.forceServerReceive) {
            return false;
         } else {
            boolean var10000;
            label66: {
               if (this.plugin != null) {
                  if (!this.plugin.equals(var2.plugin)) {
                     break label66;
                  }
               } else if (var2.plugin != null) {
                  break label66;
               }

               var10000 = true;
               return var10000;
            }

            var10000 = false;
            return var10000;
         }
      } else {
         return false;
      }
   }

   public int hashCode() {
      int var1 = this.hasSendOptions ? 1 : 0;
      var1 = 31 * var1 + (this.forcePlayerSend ? 1 : 0);
      var1 = 31 * var1 + (this.forceServerSend ? 1 : 0);
      var1 = 31 * var1 + (this.hasReceiveOptions ? 1 : 0);
      var1 = 31 * var1 + (this.forcePlayerReceive ? 1 : 0);
      var1 = 31 * var1 + (this.forceServerReceive ? 1 : 0);
      var1 = 31 * var1 + (this.plugin != null ? this.plugin.hashCode() : 0);
      return var1;
   }

   public String toString() {
      return "PacketHandler{hasSendOptions=" + this.hasSendOptions + ", forcePlayerSend=" + this.forcePlayerSend + ", forceServerSend=" + this.forceServerSend + ", hasReceiveOptions=" + this.hasReceiveOptions + ", forcePlayerReceive=" + this.forcePlayerReceive + ", forceServerReceive=" + this.forceServerReceive + ", plugin=" + this.plugin + '}';
   }

   public static List<PacketHandler> getHandlers() {
      return new ArrayList(handlers);
   }

   public static List<PacketHandler> getForPlugin(Plugin var0) {
      ArrayList var1 = new ArrayList();
      if (var0 == null) {
         return var1;
      } else {
         Iterator var3 = getHandlers().iterator();

         while(var3.hasNext()) {
            PacketHandler var2 = (PacketHandler)var3.next();
            if (var0.equals(var2.getPlugin())) {
               var1.add(var2);
            }
         }

         return var1;
      }
   }

   public void sendPacket(Player var1, Object var2) {
      if (var1 != null && var2 != null) {
         try {
            Object var3 = Minecraft.getHandle(var1);
            Object var4 = EntityPlayerFieldResolver.resolve("playerConnection").get(var3);
            PlayerConnectionMethodResolver.resolve("sendPacket").invoke(var4, var2);
         } catch (Exception var5) {
            System.err.println("[PacketListenerAPI] Exception while sending " + var2 + " to " + var1);
            var5.printStackTrace();
         }

      } else {
         throw new NullPointerException();
      }
   }

   public Object cloneObject(Object var1) {
      if (var1 == null) {
         return var1;
      } else {
         Object var2 = var1.getClass().newInstance();
         Field[] var6;
         int var5 = (var6 = var1.getClass().getDeclaredFields()).length;

         for(int var4 = 0; var4 < var5; ++var4) {
            Field var3 = var6[var4];
            var3 = AccessUtil.setAccessible(var3);
            var3.set(var2, var3.get(var1));
         }

         return var2;
      }
   }

   /** @deprecated */
   @Deprecated
   public PacketHandler() {
   }

   public PacketHandler(Plugin var1) {
      this.plugin = var1;
   }

   public Plugin getPlugin() {
      return this.plugin;
   }

   public abstract void onSend(SentPacket var1);

   public abstract void onReceive(ReceivedPacket var1);
}
