package su.nightexpress.divineitems.libs.packetlistener.handler;

import org.bukkit.entity.Player;
import org.bukkit.event.Cancellable;
import su.nightexpress.divineitems.libs.packetlistener.channel.ChannelWrapper;

public class ReceivedPacket extends PacketAbstract {
   public ReceivedPacket(Object var1, Cancellable var2, Player var3) {
      super(var1, var2, var3);
   }

   public ReceivedPacket(Object var1, Cancellable var2, ChannelWrapper var3) {
      super(var1, var2, var3);
   }
}
