package su.nightexpress.divineitems.libs.reflection.annotation;

import java.lang.annotation.Annotation;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import su.nightexpress.divineitems.libs.reflection.minecraft.Minecraft;
import su.nightexpress.divineitems.libs.reflection.resolver.ClassResolver;
import su.nightexpress.divineitems.libs.reflection.resolver.FieldResolver;
import su.nightexpress.divineitems.libs.reflection.resolver.MethodResolver;
import su.nightexpress.divineitems.libs.reflection.resolver.wrapper.ClassWrapper;
import su.nightexpress.divineitems.libs.reflection.resolver.wrapper.FieldWrapper;
import su.nightexpress.divineitems.libs.reflection.resolver.wrapper.MethodWrapper;

public class ReflectionAnnotations {
   public static final ReflectionAnnotations INSTANCE = new ReflectionAnnotations();
   static final Pattern classRefPattern = Pattern.compile("@Class\\((.*)\\)");

   private ReflectionAnnotations() {
   }

   public void load(Object var1) {
      if (var1 == null) {
         throw new IllegalArgumentException("toLoad cannot be null");
      } else {
         ClassResolver var2 = new ClassResolver();
         java.lang.reflect.Field[] var6;
         int var5 = (var6 = var1.getClass().getDeclaredFields()).length;

         for(int var4 = 0; var4 < var5; ++var4) {
            java.lang.reflect.Field var3 = var6[var4];
            Class var7 = (Class)var3.getAnnotation(Class.class);
            Field var8 = (Field)var3.getAnnotation(Field.class);
            Method var9 = (Method)var3.getAnnotation(Method.class);
            if (var7 != null || var8 != null || var9 != null) {
               var3.setAccessible(true);
               List var10;
               String[] var11;
               if (var7 != null) {
                  var10 = this.parseAnnotationVersions(Class.class, var7);
                  if (var10.isEmpty()) {
                     throw new IllegalArgumentException("@Class names cannot be empty");
                  }

                  var11 = (String[])var10.toArray(new String[var10.size()]);

                  for(int var21 = 0; var21 < var11.length; ++var21) {
                     var11[var21] = var11[var21].replace("{nms}", "net.minecraft.server." + Minecraft.VERSION.name()).replace("{obc}", "org.bukkit.craftbukkit." + Minecraft.VERSION.name());
                  }

                  try {
                     if (ClassWrapper.class.isAssignableFrom(var3.getType())) {
                        var3.set(var1, var2.resolveWrapper(var11));
                     } else {
                        if (!java.lang.Class.class.isAssignableFrom(var3.getType())) {
                           this.throwInvalidFieldType(var3, var1, "Class or ClassWrapper");
                           return;
                        }

                        var3.set(var1, var2.resolve(var11));
                     }
                  } catch (ReflectiveOperationException var17) {
                     if (!var7.ignoreExceptions()) {
                        this.throwReflectionException("@Class", var3, var1, var17);
                        return;
                     }
                  }
               } else if (var8 != null) {
                  var10 = this.parseAnnotationVersions(Field.class, var8);
                  if (var10.isEmpty()) {
                     throw new IllegalArgumentException("@Field names cannot be empty");
                  }

                  var11 = (String[])var10.toArray(new String[var10.size()]);

                  try {
                     FieldResolver var20 = new FieldResolver(this.parseClass(Field.class, var8, var1));
                     if (FieldWrapper.class.isAssignableFrom(var3.getType())) {
                        var3.set(var1, var20.resolveWrapper(var11));
                     } else {
                        if (!java.lang.reflect.Field.class.isAssignableFrom(var3.getType())) {
                           this.throwInvalidFieldType(var3, var1, "Field or FieldWrapper");
                           return;
                        }

                        var3.set(var1, var20.resolve(var11));
                     }
                  } catch (ReflectiveOperationException var18) {
                     if (!var8.ignoreExceptions()) {
                        this.throwReflectionException("@Field", var3, var1, var18);
                        return;
                     }
                  }
               } else if (var9 != null) {
                  var10 = this.parseAnnotationVersions(Method.class, var9);
                  if (var10.isEmpty()) {
                     throw new IllegalArgumentException("@Method names cannot be empty");
                  }

                  var11 = (String[])var10.toArray(new String[var10.size()]);
                  boolean var12 = var11[0].contains(" ");
                  String[] var16 = var11;
                  int var15 = var11.length;

                  for(int var14 = 0; var14 < var15; ++var14) {
                     String var13 = var16[var14];
                     if (var13.contains(" ") != var12) {
                        throw new IllegalArgumentException("Inconsistent method names: Cannot have mixed signatures/names");
                     }
                  }

                  try {
                     MethodResolver var22 = new MethodResolver(this.parseClass(Method.class, var9, var1));
                     if (MethodWrapper.class.isAssignableFrom(var3.getType())) {
                        if (var12) {
                           var3.set(var1, var22.resolveSignatureWrapper(var11));
                        } else {
                           var3.set(var1, var22.resolveWrapper(var11));
                        }
                     } else {
                        if (!java.lang.reflect.Method.class.isAssignableFrom(var3.getType())) {
                           this.throwInvalidFieldType(var3, var1, "Method or MethodWrapper");
                           return;
                        }

                        if (var12) {
                           var3.set(var1, var22.resolveSignature(var11));
                        } else {
                           var3.set(var1, var22.resolve(var11));
                        }
                     }
                  } catch (ReflectiveOperationException var19) {
                     if (!var9.ignoreExceptions()) {
                        this.throwReflectionException("@Method", var3, var1, var19);
                        return;
                     }
                  }
               }
            }
         }

      }
   }

   <A extends Annotation> List<String> parseAnnotationVersions(java.lang.Class<A> var1, A var2) {
      ArrayList var3 = new ArrayList();

      try {
         String[] var4 = (String[])var1.getMethod("value").invoke(var2);
         Minecraft.Version[] var5 = (Minecraft.Version[])var1.getMethod("versions").invoke(var2);
         if (var5.length == 0) {
            String[] var9 = var4;
            int var8 = var4.length;

            for(int var7 = 0; var7 < var8; ++var7) {
               String var6 = var9[var7];
               var3.add(var6);
            }
         } else {
            if (var5.length > var4.length) {
               throw new RuntimeException("versions array cannot have more elements than the names (" + var1 + ")");
            }

            for(int var11 = 0; var11 < var5.length; ++var11) {
               if (Minecraft.VERSION == var5[var11]) {
                  var3.add(var4[var11]);
               } else if (var4[var11].startsWith(">") && Minecraft.VERSION.newerThan(var5[var11])) {
                  var3.add(var4[var11].substring(1));
               } else if (var4[var11].startsWith("<") && Minecraft.VERSION.olderThan(var5[var11])) {
                  var3.add(var4[var11].substring(1));
               }
            }
         }

         return var3;
      } catch (ReflectiveOperationException var10) {
         throw new RuntimeException(var10);
      }
   }

   <A extends Annotation> String parseClass(java.lang.Class<A> var1, A var2, Object var3) {
      try {
         String var4 = (String)var1.getMethod("className").invoke(var2);
         Matcher var5 = classRefPattern.matcher(var4);

         while(var5.find()) {
            if (var5.groupCount() == 1) {
               String var6 = var5.group(1);
               java.lang.reflect.Field var7 = var3.getClass().getField(var6);
               if (ClassWrapper.class.isAssignableFrom(var7.getType())) {
                  return ((ClassWrapper)var7.get(var3)).getName();
               }

               if (java.lang.Class.class.isAssignableFrom(var7.getType())) {
                  return ((java.lang.Class)var7.get(var3)).getName();
               }
            }
         }

         return var4;
      } catch (ReflectiveOperationException var8) {
         throw new RuntimeException(var8);
      }
   }

   void throwInvalidFieldType(java.lang.reflect.Field var1, Object var2, String var3) {
      throw new IllegalArgumentException("Field " + var1.getName() + " in " + var2.getClass() + " is not of type " + var3 + ", it's " + var1.getType());
   }

   void throwReflectionException(String var1, java.lang.reflect.Field var2, Object var3, ReflectiveOperationException var4) {
      throw new RuntimeException("Failed to set " + var1 + " field " + var2.getName() + " in " + var3.getClass(), var4);
   }
}
