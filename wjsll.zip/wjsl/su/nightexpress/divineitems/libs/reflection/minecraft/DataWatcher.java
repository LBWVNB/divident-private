package su.nightexpress.divineitems.libs.reflection.minecraft;

import java.lang.reflect.Field;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import su.nightexpress.divineitems.libs.reflection.resolver.ClassResolver;
import su.nightexpress.divineitems.libs.reflection.resolver.ConstructorResolver;
import su.nightexpress.divineitems.libs.reflection.resolver.FieldResolver;
import su.nightexpress.divineitems.libs.reflection.resolver.MethodResolver;
import su.nightexpress.divineitems.libs.reflection.resolver.ResolverQuery;
import su.nightexpress.divineitems.libs.reflection.resolver.minecraft.NMSClassResolver;

public class DataWatcher {
   static ClassResolver classResolver = new ClassResolver();
   static NMSClassResolver nmsClassResolver = new NMSClassResolver();
   static Class<?> ItemStack;
   static Class<?> ChunkCoordinates;
   static Class<?> BlockPosition;
   static Class<?> Vector3f;
   static Class<?> DataWatcher;
   static Class<?> Entity;
   static Class<?> TIntObjectMap;
   static ConstructorResolver DataWacherConstructorResolver;
   static FieldResolver DataWatcherFieldResolver;
   static MethodResolver TIntObjectMapMethodResolver;
   static MethodResolver DataWatcherMethodResolver;

   static {
      ItemStack = nmsClassResolver.resolveSilent(new String[]{"ItemStack"});
      ChunkCoordinates = nmsClassResolver.resolveSilent(new String[]{"ChunkCoordinates"});
      BlockPosition = nmsClassResolver.resolveSilent(new String[]{"BlockPosition"});
      Vector3f = nmsClassResolver.resolveSilent(new String[]{"Vector3f"});
      DataWatcher = nmsClassResolver.resolveSilent(new String[]{"DataWatcher"});
      Entity = nmsClassResolver.resolveSilent(new String[]{"Entity"});
      TIntObjectMap = classResolver.resolveSilent("gnu.trove.map.TIntObjectMap", "net.minecraft.util.gnu.trove.map.TIntObjectMap");
      DataWacherConstructorResolver = new ConstructorResolver(DataWatcher);
      DataWatcherFieldResolver = new FieldResolver(DataWatcher);
      TIntObjectMapMethodResolver = new MethodResolver(TIntObjectMap);
      DataWatcherMethodResolver = new MethodResolver(DataWatcher);
   }

   public static Object newDataWatcher(Object var0) {
      return DataWacherConstructorResolver.resolve(new Class[]{Entity}).newInstance(var0);
   }

   public static Object setValue(Object var0, int var1, Object var2, Object var3) {
      return Minecraft.VERSION.olderThan(Minecraft.Version.v1_9_R1) ? DataWatcher.V1_8.setValue(var0, var1, var3) : DataWatcher.V1_9.setValue(var0, var2, var3);
   }

   public static Object setValue(Object var0, int var1, DataWatcher.V1_9.ValueType var2, Object var3) {
      return setValue(var0, var1, var2.getType(), var3);
   }

   public static Object setValue(Object var0, int var1, Object var2, FieldResolver var3, String... var4) {
      if (Minecraft.VERSION.olderThan(Minecraft.Version.v1_9_R1)) {
         return DataWatcher.V1_8.setValue(var0, var1, var2);
      } else {
         Object var5 = var3.resolve(var4).get((Object)null);
         return DataWatcher.V1_9.setValue(var0, var5, var2);
      }
   }

   /** @deprecated */
   @Deprecated
   public static Object getValue(DataWatcher var0, int var1) {
      return Minecraft.VERSION.olderThan(Minecraft.Version.v1_9_R1) ? DataWatcher.V1_8.getValue(var0, var1) : DataWatcher.V1_9.getValue(var0, (Object)var1);
   }

   public static Object getValue(Object var0, int var1, DataWatcher.V1_9.ValueType var2) {
      return getValue(var0, var1, var2.getType());
   }

   public static Object getValue(Object var0, int var1, Object var2) {
      return Minecraft.VERSION.olderThan(Minecraft.Version.v1_9_R1) ? DataWatcher.V1_8.getWatchableObjectValue(DataWatcher.V1_8.getValue(var0, var1)) : DataWatcher.V1_9.getValue(var0, var2);
   }

   public static int getValueType(Object var0) {
      byte var1 = 0;
      if (var0 instanceof Number) {
         if (var0 instanceof Byte) {
            var1 = 0;
         } else if (var0 instanceof Short) {
            var1 = 1;
         } else if (var0 instanceof Integer) {
            var1 = 2;
         } else if (var0 instanceof Float) {
            var1 = 3;
         }
      } else if (var0 instanceof String) {
         var1 = 4;
      } else if (var0 != null && var0.getClass().equals(ItemStack)) {
         var1 = 5;
      } else if (var0 == null || !var0.getClass().equals(ChunkCoordinates) && !var0.getClass().equals(BlockPosition)) {
         if (var0 != null && var0.getClass().equals(Vector3f)) {
            var1 = 7;
         }
      } else {
         var1 = 6;
      }

      return var1;
   }

   private DataWatcher() {
   }

   public static class V1_8 {
      static Class<?> WatchableObject;
      static ConstructorResolver WatchableObjectConstructorResolver;
      static FieldResolver WatchableObjectFieldResolver;

      static {
         WatchableObject = su.nightexpress.divineitems.libs.reflection.minecraft.DataWatcher.nmsClassResolver.resolveSilent(new String[]{"WatchableObject", "DataWatcher$WatchableObject"});
      }

      public static Object newWatchableObject(int var0, Object var1) {
         return newWatchableObject(su.nightexpress.divineitems.libs.reflection.minecraft.DataWatcher.getValueType(var1), var0, var1);
      }

      public static Object newWatchableObject(int var0, int var1, Object var2) {
         if (WatchableObjectConstructorResolver == null) {
            WatchableObjectConstructorResolver = new ConstructorResolver(WatchableObject);
         }

         return WatchableObjectConstructorResolver.resolve(new Class[]{Integer.TYPE, Integer.TYPE, Object.class}).newInstance(var0, var1, var2);
      }

      public static Object setValue(Object var0, int var1, Object var2) {
         int var3 = su.nightexpress.divineitems.libs.reflection.minecraft.DataWatcher.getValueType(var2);
         Map var4 = (Map)su.nightexpress.divineitems.libs.reflection.minecraft.DataWatcher.DataWatcherFieldResolver.resolveByLastType(Map.class).get(var0);
         var4.put(var1, newWatchableObject(var3, var1, var2));
         return var0;
      }

      public static Object getValue(Object var0, int var1) {
         Map var2 = (Map)su.nightexpress.divineitems.libs.reflection.minecraft.DataWatcher.DataWatcherFieldResolver.resolveByLastType(Map.class).get(var0);
         return var2.get(var1);
      }

      public static int getWatchableObjectIndex(Object var0) {
         if (WatchableObjectFieldResolver == null) {
            WatchableObjectFieldResolver = new FieldResolver(WatchableObject);
         }

         return WatchableObjectFieldResolver.resolve("b").getInt(var0);
      }

      public static int getWatchableObjectType(Object var0) {
         if (WatchableObjectFieldResolver == null) {
            WatchableObjectFieldResolver = new FieldResolver(WatchableObject);
         }

         return WatchableObjectFieldResolver.resolve("a").getInt(var0);
      }

      public static Object getWatchableObjectValue(Object var0) {
         if (WatchableObjectFieldResolver == null) {
            WatchableObjectFieldResolver = new FieldResolver(WatchableObject);
         }

         return WatchableObjectFieldResolver.resolve("c").get(var0);
      }
   }

   public static class V1_9 {
      static Class<?> DataWatcherItem;
      static Class<?> DataWatcherObject;
      static ConstructorResolver DataWatcherItemConstructorResolver;
      static FieldResolver DataWatcherItemFieldResolver;
      static FieldResolver DataWatcherObjectFieldResolver;

      static {
         DataWatcherItem = su.nightexpress.divineitems.libs.reflection.minecraft.DataWatcher.nmsClassResolver.resolveSilent(new String[]{"DataWatcher$Item"});
         DataWatcherObject = su.nightexpress.divineitems.libs.reflection.minecraft.DataWatcher.nmsClassResolver.resolveSilent(new String[]{"DataWatcherObject"});
      }

      public static Object newDataWatcherItem(Object var0, Object var1) {
         if (DataWatcherItemConstructorResolver == null) {
            DataWatcherItemConstructorResolver = new ConstructorResolver(DataWatcherItem);
         }

         return DataWatcherItemConstructorResolver.resolveFirstConstructor().newInstance(var0, var1);
      }

      public static Object setItem(Object var0, int var1, Object var2, Object var3) {
         return setItem(var0, var1, newDataWatcherItem(var2, var3));
      }

      public static Object setItem(Object var0, int var1, Object var2) {
         Map var3 = (Map)su.nightexpress.divineitems.libs.reflection.minecraft.DataWatcher.DataWatcherFieldResolver.resolveByLastTypeSilent(Map.class).get(var0);
         var3.put(var1, var2);
         return var0;
      }

      public static Object setValue(Object var0, Object var1, Object var2) {
         su.nightexpress.divineitems.libs.reflection.minecraft.DataWatcher.DataWatcherMethodResolver.resolve("set").invoke(var0, var1, var2);
         return var0;
      }

      public static Object getItem(Object var0, Object var1) {
         return su.nightexpress.divineitems.libs.reflection.minecraft.DataWatcher.DataWatcherMethodResolver.resolve(new ResolverQuery("c", new Class[]{DataWatcherObject})).invoke(var0, var1);
      }

      public static Object getValue(Object var0, Object var1) {
         return su.nightexpress.divineitems.libs.reflection.minecraft.DataWatcher.DataWatcherMethodResolver.resolve("get").invoke(var0, var1);
      }

      public static Object getValue(Object var0, DataWatcher.V1_9.ValueType var1) {
         return getValue(var0, var1.getType());
      }

      public static Object getItemObject(Object var0) {
         if (DataWatcherItemFieldResolver == null) {
            DataWatcherItemFieldResolver = new FieldResolver(DataWatcherItem);
         }

         return DataWatcherItemFieldResolver.resolve("a").get(var0);
      }

      public static int getItemIndex(Object var0, Object var1) {
         int var2 = -1;
         Map var3 = (Map)su.nightexpress.divineitems.libs.reflection.minecraft.DataWatcher.DataWatcherFieldResolver.resolveByLastTypeSilent(Map.class).get(var0);
         Iterator var5 = var3.entrySet().iterator();

         while(var5.hasNext()) {
            Entry var4 = (Entry)var5.next();
            if (var4.getValue().equals(var1)) {
               var2 = (Integer)var4.getKey();
               break;
            }
         }

         return var2;
      }

      public static Type getItemType(Object var0) {
         if (DataWatcherObjectFieldResolver == null) {
            DataWatcherObjectFieldResolver = new FieldResolver(DataWatcherObject);
         }

         Object var1 = getItemObject(var0);
         Object var2 = DataWatcherObjectFieldResolver.resolve("b").get(var1);
         Type[] var3 = var2.getClass().getGenericInterfaces();
         if (var3.length > 0) {
            Type var4 = var3[0];
            if (var4 instanceof ParameterizedType) {
               Type[] var5 = ((ParameterizedType)var4).getActualTypeArguments();
               if (var5.length > 0) {
                  return var5[0];
               }
            }
         }

         return null;
      }

      public static Object getItemValue(Object var0) {
         if (DataWatcherItemFieldResolver == null) {
            DataWatcherItemFieldResolver = new FieldResolver(DataWatcherItem);
         }

         return DataWatcherItemFieldResolver.resolve("b").get(var0);
      }

      public static void setItemValue(Object var0, Object var1) {
         DataWatcherItemFieldResolver.resolve("b").set(var0, var1);
      }

      public static enum ValueType {
         ENTITY_FLAG("Entity", 57, 0),
         ENTITY_AIR_TICKS("Entity", 58, 1),
         ENTITY_NAME("Entity", 59, 2),
         ENTITY_NAME_VISIBLE("Entity", 60, 3),
         ENTITY_SILENT("Entity", 61, 4),
         ENTITY_as("EntityLiving", 2, 0),
         ENTITY_LIVING_HEALTH("EntityLiving", new String[]{"HEALTH"}),
         ENTITY_LIVING_f("EntityLiving", 4, 2),
         ENTITY_LIVING_g("EntityLiving", 5, 3),
         ENTITY_LIVING_h("EntityLiving", 6, 4),
         ENTITY_INSENTIENT_FLAG("EntityInsentient", 0, 0),
         ENTITY_SLIME_SIZE("EntitySlime", 0, 0),
         ENTITY_WITHER_a("EntityWither", 0, 0),
         ENTITY_WIHER_b("EntityWither", 1, 1),
         ENTITY_WITHER_c("EntityWither", 2, 2),
         ENTITY_WITHER_bv("EntityWither", 3, 3),
         ENTITY_WITHER_bw("EntityWither", 4, 4),
         ENTITY_AGEABLE_CHILD("EntityAgeable", 0, 0),
         ENTITY_HORSE_STATUS("EntityHorse", 3, 0),
         ENTITY_HORSE_HORSE_TYPE("EntityHorse", 4, 1),
         ENTITY_HORSE_HORSE_VARIANT("EntityHorse", 5, 2),
         ENTITY_HORSE_OWNER_UUID("EntityHorse", 6, 3),
         ENTITY_HORSE_HORSE_ARMOR("EntityHorse", 7, 4),
         ENTITY_HUMAN_ABSORPTION_HEARTS("EntityHuman", 0, 0),
         ENTITY_HUMAN_SCORE("EntityHuman", 1, 1),
         ENTITY_HUMAN_SKIN_LAYERS("EntityHuman", 2, 2),
         ENTITY_HUMAN_MAIN_HAND("EntityHuman", 3, 3);

         private Object type;

         private ValueType(String var3, String... var4) {
            try {
               this.type = (new FieldResolver(su.nightexpress.divineitems.libs.reflection.minecraft.DataWatcher.nmsClassResolver.resolve(var3))).resolve(var4).get((Object)null);
            } catch (Exception var6) {
               if (Minecraft.VERSION.newerThan(Minecraft.Version.v1_9_R1)) {
                  System.err.println("[ReflectionHelper] Failed to find DataWatcherObject for " + var3 + " " + Arrays.toString(var4));
               }
            }

         }

         private ValueType(String var3, int var4) {
            try {
               this.type = (new FieldResolver(su.nightexpress.divineitems.libs.reflection.minecraft.DataWatcher.nmsClassResolver.resolve(var3))).resolveIndex(var4).get((Object)null);
            } catch (Exception var6) {
               if (Minecraft.VERSION.newerThan(Minecraft.Version.v1_9_R1)) {
                  System.err.println("[ReflectionHelper] Failed to find DataWatcherObject for " + var3 + " #" + var4);
               }
            }

         }

         private ValueType(String var3, int var4, int var5) {
            int var6 = 0;

            try {
               Class var7 = su.nightexpress.divineitems.libs.reflection.minecraft.DataWatcher.nmsClassResolver.resolve(var3);
               Field[] var11;
               int var10 = (var11 = var7.getDeclaredFields()).length;

               for(int var9 = 0; var9 < var10; ++var9) {
                  Field var8 = var11[var9];
                  if ("DataWatcherObject".equals(var8.getType().getSimpleName())) {
                     break;
                  }

                  ++var6;
               }

               this.type = (new FieldResolver(var7)).resolveIndex(var6 + var5).get((Object)null);
            } catch (Exception var12) {
               if (Minecraft.VERSION.newerThan(Minecraft.Version.v1_9_R1)) {
                  System.err.println("[ReflectionHelper] Failed to find DataWatcherObject for " + var3 + " #" + var4 + " (" + var6 + "+" + var5 + ")");
               }
            }

         }

         public boolean hasType() {
            return this.getType() != null;
         }

         public Object getType() {
            return this.type;
         }
      }
   }
}
