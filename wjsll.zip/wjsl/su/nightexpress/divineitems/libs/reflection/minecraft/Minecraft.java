package su.nightexpress.divineitems.libs.reflection.minecraft;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.bukkit.Bukkit;
import org.bukkit.entity.Entity;
import su.nightexpress.divineitems.libs.reflection.resolver.ConstructorResolver;
import su.nightexpress.divineitems.libs.reflection.resolver.FieldResolver;
import su.nightexpress.divineitems.libs.reflection.resolver.MethodResolver;
import su.nightexpress.divineitems.libs.reflection.resolver.minecraft.NMSClassResolver;
import su.nightexpress.divineitems.libs.reflection.resolver.minecraft.OBCClassResolver;
import su.nightexpress.divineitems.libs.reflection.util.AccessUtil;
import sun.reflect.ConstructorAccessor;

public class Minecraft {
   static final Pattern NUMERIC_VERSION_PATTERN = Pattern.compile("v([0-9])_([0-9]*)_R([0-9])");
   public static final Minecraft.Version VERSION = Minecraft.Version.getVersion();
   private static NMSClassResolver nmsClassResolver = new NMSClassResolver();
   private static OBCClassResolver obcClassResolver = new OBCClassResolver();
   private static Class<?> NmsEntity;
   private static Class<?> CraftEntity;

   static {
      System.out.println("[ReflectionHelper] Version is " + VERSION);

      try {
         NmsEntity = nmsClassResolver.resolve("Entity");
         CraftEntity = obcClassResolver.resolve("entity.CraftEntity");
      } catch (ReflectiveOperationException var1) {
         throw new RuntimeException(var1);
      }
   }

   public static String getVersion() {
      return VERSION.name() + ".";
   }

   public static Object getHandle(Object var0) {
      Method var1;
      try {
         var1 = AccessUtil.setAccessible(var0.getClass().getDeclaredMethod("getHandle"));
      } catch (ReflectiveOperationException var3) {
         var1 = AccessUtil.setAccessible(CraftEntity.getDeclaredMethod("getHandle"));
      }

      return var1.invoke(var0);
   }

   public static Entity getBukkitEntity(Object var0) {
      Method var1;
      try {
         var1 = AccessUtil.setAccessible(NmsEntity.getDeclaredMethod("getBukkitEntity"));
      } catch (ReflectiveOperationException var3) {
         var1 = AccessUtil.setAccessible(CraftEntity.getDeclaredMethod("getHandle"));
      }

      return (Entity)var1.invoke(var0);
   }

   public static Object getHandleSilent(Object var0) {
      try {
         return getHandle(var0);
      } catch (Exception var2) {
         return null;
      }
   }

   public static Object newEnumInstance(Class var0, Class[] var1, Object[] var2) {
      Constructor var3 = (new ConstructorResolver(var0)).resolve(var1);
      Field var4 = (new FieldResolver(Constructor.class)).resolve("constructorAccessor");
      ConstructorAccessor var5 = (ConstructorAccessor)var4.get(var3);
      if (var5 == null) {
         (new MethodResolver(Constructor.class)).resolve("acquireConstructorAccessor").invoke(var3);
         var5 = (ConstructorAccessor)var4.get(var3);
      }

      return var5.newInstance(var2);
   }

   public static enum Version {
      UNKNOWN(-1) {
         public boolean matchesPackageName(String var1) {
            return false;
         }
      },
      v1_7_R1(10701),
      v1_7_R2(10702),
      v1_7_R3(10703),
      v1_7_R4(10704),
      v1_8_R1(10801),
      v1_8_R2(10802),
      v1_8_R3(10803),
      v1_8_R4(10804),
      v1_9_R1(10901),
      v1_9_R2(10902),
      v1_10_R1(11001),
      v1_11_R1(11101),
      v1_12_R1(11201),
      v1_13_R1(11301),
      v1_13_R2(11302);

      private int version;

      private Version(int var3) {
         this.version = var3;
      }

      public int version() {
         return this.version;
      }

      public boolean olderThan(Minecraft.Version var1) {
         return this.version() < var1.version();
      }

      public boolean newerThan(Minecraft.Version var1) {
         return this.version() >= var1.version();
      }

      public boolean inRange(Minecraft.Version var1, Minecraft.Version var2) {
         return this.newerThan(var1) && this.olderThan(var2);
      }

      public boolean matchesPackageName(String var1) {
         return var1.toLowerCase().contains(this.name().toLowerCase());
      }

      public static Minecraft.Version getVersion() {
         String var0 = Bukkit.getServer().getClass().getPackage().getName();
         String var1 = var0.substring(var0.lastIndexOf(46) + 1) + ".";
         Minecraft.Version[] var5;
         int var4 = (var5 = values()).length;

         for(int var3 = 0; var3 < var4; ++var3) {
            Minecraft.Version var2 = var5[var3];
            if (var2.matchesPackageName(var1)) {
               return var2;
            }
         }

         System.err.println("[ReflectionHelper] Failed to find version enum for '" + var0 + "'/'" + var1 + "'");
         System.out.println("[ReflectionHelper] Generating dynamic constant...");
         Matcher var14 = Minecraft.NUMERIC_VERSION_PATTERN.matcher(var1);

         while(true) {
            do {
               if (!var14.find()) {
                  return UNKNOWN;
               }
            } while(var14.groupCount() < 3);

            String var15 = var14.group(1);
            String var16 = var14.group(2);
            if (var16.length() == 1) {
               var16 = "0" + var16;
            }

            String var17 = var14.group(3);
            if (var17.length() == 1) {
               var17 = "0" + var17;
            }

            String var6 = var15 + var16 + var17;
            int var7 = Integer.parseInt(var6);
            String var8 = var1.substring(0, var1.length() - 1);

            try {
               Field var9 = (new FieldResolver(Minecraft.Version.class)).resolve("$VALUES");
               Minecraft.Version[] var10 = (Minecraft.Version[])var9.get((Object)null);
               Minecraft.Version[] var11 = new Minecraft.Version[var10.length + 1];
               System.arraycopy(var10, 0, var11, 0, var10.length);
               Minecraft.Version var12 = (Minecraft.Version)Minecraft.newEnumInstance(Minecraft.Version.class, new Class[]{String.class, Integer.TYPE, Integer.TYPE}, new Object[]{var8, var11.length - 1, var7});
               var11[var11.length - 1] = var12;
               var9.set((Object)null, var11);
               System.out.println("[ReflectionHelper] Injected dynamic version " + var8 + " (#" + var7 + ").");
               System.out.println("[ReflectionHelper] Please inform inventivetalent about the outdated version, as this is not guaranteed to work.");
               return var12;
            } catch (ReflectiveOperationException var13) {
               var13.printStackTrace();
            }
         }
      }

      public String toString() {
         return this.name() + " (" + this.version() + ")";
      }

      // $FF: synthetic method
      Version(int var3, Minecraft.Version var4) {
         this(var3);
      }
   }
}
