package su.nightexpress.divineitems.libs.reflection.resolver;

import su.nightexpress.divineitems.libs.reflection.resolver.wrapper.ClassWrapper;

public class ClassResolver extends ResolverAbstract<Class> {
   public ClassWrapper resolveWrapper(String... var1) {
      return new ClassWrapper(this.resolveSilent(var1));
   }

   public Class resolveSilent(String... var1) {
      try {
         return this.resolve(var1);
      } catch (Exception var3) {
         return null;
      }
   }

   public Class resolve(String... var1) {
      ResolverQuery.Builder var2 = ResolverQuery.builder();
      String[] var6 = var1;
      int var5 = var1.length;

      for(int var4 = 0; var4 < var5; ++var4) {
         String var3 = var6[var4];
         var2.with(var3);
      }

      try {
         return (Class)super.resolve(var2.build());
      } catch (ReflectiveOperationException var7) {
         throw (ClassNotFoundException)var7;
      }
   }

   protected Class resolveObject(ResolverQuery var1) {
      return Class.forName(var1.getName());
   }

   protected ClassNotFoundException notFoundException(String var1) {
      return new ClassNotFoundException("Could not resolve class for " + var1);
   }
}
