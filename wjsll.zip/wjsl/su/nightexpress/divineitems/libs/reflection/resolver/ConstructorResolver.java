package su.nightexpress.divineitems.libs.reflection.resolver;

import java.lang.reflect.Constructor;
import su.nightexpress.divineitems.libs.reflection.resolver.wrapper.ConstructorWrapper;
import su.nightexpress.divineitems.libs.reflection.util.AccessUtil;

public class ConstructorResolver extends MemberResolver<Constructor> {
   public ConstructorResolver(Class<?> var1) {
      super(var1);
   }

   public ConstructorResolver(String var1) {
      super(var1);
   }

   public Constructor resolveIndex(int var1) {
      return AccessUtil.setAccessible(this.clazz.getDeclaredConstructors()[var1]);
   }

   public Constructor resolveIndexSilent(int var1) {
      try {
         return this.resolveIndex(var1);
      } catch (ReflectiveOperationException | IndexOutOfBoundsException var3) {
         return null;
      }
   }

   public ConstructorWrapper resolveIndexWrapper(int var1) {
      return new ConstructorWrapper(this.resolveIndexSilent(var1));
   }

   public ConstructorWrapper resolveWrapper(Class<?>[]... var1) {
      return new ConstructorWrapper(this.resolveSilent(var1));
   }

   public Constructor resolveSilent(Class<?>[]... var1) {
      try {
         return this.resolve(var1);
      } catch (Exception var3) {
         return null;
      }
   }

   public Constructor resolve(Class<?>[]... var1) {
      ResolverQuery.Builder var2 = ResolverQuery.builder();
      Class[][] var6 = var1;
      int var5 = var1.length;

      for(int var4 = 0; var4 < var5; ++var4) {
         Class[] var3 = var6[var4];
         var2.with(var3);
      }

      try {
         return (Constructor)super.resolve(var2.build());
      } catch (ReflectiveOperationException var7) {
         throw (NoSuchMethodException)var7;
      }
   }

   protected Constructor resolveObject(ResolverQuery var1) {
      return AccessUtil.setAccessible(this.clazz.getDeclaredConstructor(var1.getTypes()));
   }

   public Constructor resolveFirstConstructor() {
      Constructor[] var2;
      if ((var2 = this.clazz.getDeclaredConstructors()).length != 0) {
         Constructor var1 = var2[0];
         return AccessUtil.setAccessible(var1);
      } else {
         return null;
      }
   }

   public Constructor resolveFirstConstructorSilent() {
      try {
         return this.resolveFirstConstructor();
      } catch (Exception var2) {
         return null;
      }
   }

   public Constructor resolveLastConstructor() {
      Constructor var1 = null;
      Constructor[] var5;
      int var4 = (var5 = this.clazz.getDeclaredConstructors()).length;

      for(int var3 = 0; var3 < var4; ++var3) {
         Constructor var2 = var5[var3];
         var1 = var2;
      }

      return var1 != null ? AccessUtil.setAccessible(var1) : null;
   }

   public Constructor resolveLastConstructorSilent() {
      try {
         return this.resolveLastConstructor();
      } catch (Exception var2) {
         return null;
      }
   }

   protected NoSuchMethodException notFoundException(String var1) {
      return new NoSuchMethodException("Could not resolve constructor for " + var1 + " in class " + this.clazz);
   }
}
