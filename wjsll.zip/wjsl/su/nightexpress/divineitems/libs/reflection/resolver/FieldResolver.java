package su.nightexpress.divineitems.libs.reflection.resolver;

import java.lang.reflect.Field;
import su.nightexpress.divineitems.libs.reflection.resolver.wrapper.FieldWrapper;
import su.nightexpress.divineitems.libs.reflection.util.AccessUtil;

public class FieldResolver extends MemberResolver<Field> {
   public FieldResolver(Class<?> var1) {
      super(var1);
   }

   public FieldResolver(String var1) {
      super(var1);
   }

   public Field resolveIndex(int var1) {
      return AccessUtil.setAccessible(this.clazz.getDeclaredFields()[var1]);
   }

   public Field resolveIndexSilent(int var1) {
      try {
         return this.resolveIndex(var1);
      } catch (ReflectiveOperationException | IndexOutOfBoundsException var3) {
         return null;
      }
   }

   public FieldWrapper resolveIndexWrapper(int var1) {
      return new FieldWrapper(this.resolveIndexSilent(var1));
   }

   public FieldWrapper resolveWrapper(String... var1) {
      return new FieldWrapper(this.resolveSilent(var1));
   }

   public Field resolveSilent(String... var1) {
      try {
         return this.resolve(var1);
      } catch (Exception var3) {
         return null;
      }
   }

   public Field resolve(String... var1) {
      ResolverQuery.Builder var2 = ResolverQuery.builder();
      String[] var6 = var1;
      int var5 = var1.length;

      for(int var4 = 0; var4 < var5; ++var4) {
         String var3 = var6[var4];
         var2.with(var3);
      }

      try {
         return (Field)super.resolve(var2.build());
      } catch (ReflectiveOperationException var7) {
         throw (NoSuchFieldException)var7;
      }
   }

   public Field resolveSilent(ResolverQuery... var1) {
      try {
         return this.resolve(var1);
      } catch (Exception var3) {
         return null;
      }
   }

   public Field resolve(ResolverQuery... var1) {
      try {
         return (Field)super.resolve(var1);
      } catch (ReflectiveOperationException var3) {
         throw (NoSuchFieldException)var3;
      }
   }

   protected Field resolveObject(ResolverQuery var1) {
      if (var1.getTypes() != null && var1.getTypes().length != 0) {
         Field[] var5;
         int var4 = (var5 = this.clazz.getDeclaredFields()).length;

         for(int var3 = 0; var3 < var4; ++var3) {
            Field var2 = var5[var3];
            if (var2.getName().equals(var1.getName())) {
               Class[] var9;
               int var8 = (var9 = var1.getTypes()).length;

               for(int var7 = 0; var7 < var8; ++var7) {
                  Class var6 = var9[var7];
                  if (var2.getType().equals(var6)) {
                     return var2;
                  }
               }
            }
         }

         return null;
      } else {
         return AccessUtil.setAccessible(this.clazz.getDeclaredField(var1.getName()));
      }
   }

   public Field resolveByFirstType(Class<?> var1) {
      Field[] var5;
      int var4 = (var5 = this.clazz.getDeclaredFields()).length;

      for(int var3 = 0; var3 < var4; ++var3) {
         Field var2 = var5[var3];
         if (var2.getType().equals(var1)) {
            return AccessUtil.setAccessible(var2);
         }
      }

      throw new NoSuchFieldException("Could not resolve field of type '" + var1.toString() + "' in class " + this.clazz);
   }

   public Field resolveByFirstTypeSilent(Class<?> var1) {
      try {
         return this.resolveByFirstType(var1);
      } catch (Exception var3) {
         return null;
      }
   }

   public Field resolveByLastType(Class<?> var1) {
      Field var2 = null;
      Field[] var6;
      int var5 = (var6 = this.clazz.getDeclaredFields()).length;

      for(int var4 = 0; var4 < var5; ++var4) {
         Field var3 = var6[var4];
         if (var3.getType().equals(var1)) {
            var2 = var3;
         }
      }

      if (var2 == null) {
         throw new NoSuchFieldException("Could not resolve field of type '" + var1.toString() + "' in class " + this.clazz);
      } else {
         return AccessUtil.setAccessible(var2);
      }
   }

   public Field resolveByLastTypeSilent(Class<?> var1) {
      try {
         return this.resolveByLastType(var1);
      } catch (Exception var3) {
         return null;
      }
   }

   protected NoSuchFieldException notFoundException(String var1) {
      return new NoSuchFieldException("Could not resolve field for " + var1 + " in class " + this.clazz);
   }
}
