package su.nightexpress.divineitems.libs.reflection.resolver;

import java.lang.reflect.Member;
import su.nightexpress.divineitems.libs.reflection.resolver.wrapper.WrapperAbstract;

public abstract class MemberResolver<T extends Member> extends ResolverAbstract<T> {
   protected Class<?> clazz;

   public MemberResolver(Class<?> var1) {
      if (var1 == null) {
         throw new IllegalArgumentException("class cannot be null");
      } else {
         this.clazz = var1;
      }
   }

   public MemberResolver(String var1) {
      this((new ClassResolver()).resolve(var1));
   }

   public abstract T resolveIndex(int var1);

   public abstract T resolveIndexSilent(int var1);

   public abstract WrapperAbstract resolveIndexWrapper(int var1);
}
