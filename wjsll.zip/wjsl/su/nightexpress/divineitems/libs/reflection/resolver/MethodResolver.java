package su.nightexpress.divineitems.libs.reflection.resolver;

import java.lang.reflect.Method;
import su.nightexpress.divineitems.libs.reflection.resolver.wrapper.MethodWrapper;
import su.nightexpress.divineitems.libs.reflection.util.AccessUtil;

public class MethodResolver extends MemberResolver<Method> {
   public MethodResolver(Class<?> var1) {
      super(var1);
   }

   public MethodResolver(String var1) {
      super(var1);
   }

   public Method resolveSignature(String... var1) {
      Method[] var5;
      int var4 = (var5 = this.clazz.getDeclaredMethods()).length;

      for(int var3 = 0; var3 < var4; ++var3) {
         Method var2 = var5[var3];
         String var6 = MethodWrapper.getMethodSignature(var2);
         String[] var10 = var1;
         int var9 = var1.length;

         for(int var8 = 0; var8 < var9; ++var8) {
            String var7 = var10[var8];
            if (var7.equals(var6)) {
               return AccessUtil.setAccessible(var2);
            }
         }
      }

      return null;
   }

   public Method resolveSignatureSilent(String... var1) {
      try {
         return this.resolveSignature(var1);
      } catch (ReflectiveOperationException var3) {
         return null;
      }
   }

   public MethodWrapper resolveSignatureWrapper(String... var1) {
      return new MethodWrapper(this.resolveSignatureSilent(var1));
   }

   public Method resolveIndex(int var1) {
      return AccessUtil.setAccessible(this.clazz.getDeclaredMethods()[var1]);
   }

   public Method resolveIndexSilent(int var1) {
      try {
         return this.resolveIndex(var1);
      } catch (ReflectiveOperationException | IndexOutOfBoundsException var3) {
         return null;
      }
   }

   public MethodWrapper resolveIndexWrapper(int var1) {
      return new MethodWrapper(this.resolveIndexSilent(var1));
   }

   public MethodWrapper resolveWrapper(String... var1) {
      return new MethodWrapper(this.resolveSilent(var1));
   }

   public MethodWrapper resolveWrapper(ResolverQuery... var1) {
      return new MethodWrapper(this.resolveSilent(var1));
   }

   public Method resolveSilent(String... var1) {
      try {
         return this.resolve(var1);
      } catch (Exception var3) {
         return null;
      }
   }

   public Method resolveSilent(ResolverQuery... var1) {
      return (Method)super.resolveSilent(var1);
   }

   public Method resolve(String... var1) {
      ResolverQuery.Builder var2 = ResolverQuery.builder();
      String[] var6 = var1;
      int var5 = var1.length;

      for(int var4 = 0; var4 < var5; ++var4) {
         String var3 = var6[var4];
         var2.with(var3);
      }

      return this.resolve(var2.build());
   }

   public Method resolve(ResolverQuery... var1) {
      try {
         return (Method)super.resolve(var1);
      } catch (ReflectiveOperationException var3) {
         throw (NoSuchMethodException)var3;
      }
   }

   protected Method resolveObject(ResolverQuery var1) {
      Method[] var5;
      int var4 = (var5 = this.clazz.getDeclaredMethods()).length;

      for(int var3 = 0; var3 < var4; ++var3) {
         Method var2 = var5[var3];
         if (var2.getName().equals(var1.getName()) && (var1.getTypes().length == 0 || ClassListEqual(var1.getTypes(), var2.getParameterTypes()))) {
            return AccessUtil.setAccessible(var2);
         }
      }

      throw new NoSuchMethodException();
   }

   protected NoSuchMethodException notFoundException(String var1) {
      return new NoSuchMethodException("Could not resolve method for " + var1 + " in class " + this.clazz);
   }

   static boolean ClassListEqual(Class<?>[] var0, Class<?>[] var1) {
      boolean var2 = true;
      if (var0.length != var1.length) {
         return false;
      } else {
         for(int var3 = 0; var3 < var0.length; ++var3) {
            if (var0[var3] != var1[var3]) {
               var2 = false;
               break;
            }
         }

         return var2;
      }
   }
}
