package su.nightexpress.divineitems.libs.reflection.resolver;

import java.util.Arrays;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public abstract class ResolverAbstract<T> {
   protected final Map<ResolverQuery, T> resolvedObjects = new ConcurrentHashMap();

   protected T resolveSilent(ResolverQuery... var1) {
      try {
         return this.resolve(var1);
      } catch (Exception var3) {
         return null;
      }
   }

   protected T resolve(ResolverQuery... var1) {
      if (var1 != null && var1.length > 0) {
         ResolverQuery[] var5 = var1;
         int var4 = var1.length;
         int var3 = 0;

         while(var3 < var4) {
            ResolverQuery var2 = var5[var3];
            if (this.resolvedObjects.containsKey(var2)) {
               return this.resolvedObjects.get(var2);
            }

            try {
               Object var6 = this.resolveObject(var2);
               this.resolvedObjects.put(var2, var6);
               return var6;
            } catch (ReflectiveOperationException var7) {
               ++var3;
            }
         }

         throw this.notFoundException(Arrays.asList(var1).toString());
      } else {
         throw new IllegalArgumentException("Given possibilities are empty");
      }
   }

   protected abstract T resolveObject(ResolverQuery var1);

   protected ReflectiveOperationException notFoundException(String var1) {
      return new ReflectiveOperationException("Objects could not be resolved: " + var1);
   }
}
