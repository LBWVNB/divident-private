package su.nightexpress.divineitems.libs.reflection.resolver;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ResolverQuery {
   private String name;
   private Class<?>[] types;

   public ResolverQuery(String var1, Class<?>... var2) {
      this.name = var1;
      this.types = var2;
   }

   public ResolverQuery(String var1) {
      this.name = var1;
      this.types = new Class[0];
   }

   public ResolverQuery(Class<?>... var1) {
      this.types = var1;
   }

   public String getName() {
      return this.name;
   }

   public Class<?>[] getTypes() {
      return this.types;
   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (var1 != null && this.getClass() == var1.getClass()) {
         ResolverQuery var2 = (ResolverQuery)var1;
         if (this.name != null) {
            if (!this.name.equals(var2.name)) {
               return false;
            }
         } else if (var2.name != null) {
            return false;
         }

         return Arrays.equals(this.types, var2.types);
      } else {
         return false;
      }
   }

   public int hashCode() {
      int var1 = this.name != null ? this.name.hashCode() : 0;
      var1 = 31 * var1 + (this.types != null ? Arrays.hashCode(this.types) : 0);
      return var1;
   }

   public String toString() {
      return "ResolverQuery{name='" + this.name + '\'' + ", types=" + Arrays.toString(this.types) + '}';
   }

   public static ResolverQuery.Builder builder() {
      return new ResolverQuery.Builder((ResolverQuery.Builder)null);
   }

   public static class Builder {
      private List<ResolverQuery> queryList;

      private Builder() {
         this.queryList = new ArrayList();
      }

      public ResolverQuery.Builder with(String var1, Class<?>[] var2) {
         this.queryList.add(new ResolverQuery(var1, var2));
         return this;
      }

      public ResolverQuery.Builder with(String var1) {
         this.queryList.add(new ResolverQuery(var1));
         return this;
      }

      public ResolverQuery.Builder with(Class<?>[] var1) {
         this.queryList.add(new ResolverQuery(var1));
         return this;
      }

      public ResolverQuery[] build() {
         return (ResolverQuery[])this.queryList.toArray(new ResolverQuery[this.queryList.size()]);
      }

      // $FF: synthetic method
      Builder(ResolverQuery.Builder var1) {
         this();
      }
   }
}
