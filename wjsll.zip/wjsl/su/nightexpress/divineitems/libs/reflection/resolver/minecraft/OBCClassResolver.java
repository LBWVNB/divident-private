package su.nightexpress.divineitems.libs.reflection.resolver.minecraft;

import su.nightexpress.divineitems.libs.reflection.minecraft.Minecraft;
import su.nightexpress.divineitems.libs.reflection.resolver.ClassResolver;

public class OBCClassResolver extends ClassResolver {
   public Class<?> resolve(String... var1) {
      for(int var2 = 0; var2 < var1.length; ++var2) {
         if (!var1[var2].startsWith("org.bukkit.craftbukkit")) {
            var1[var2] = "org.bukkit.craftbukkit." + Minecraft.getVersion() + var1[var2];
         }
      }

      return super.resolve(var1);
   }
}
