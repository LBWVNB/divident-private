package su.nightexpress.divineitems.libs.reflection.resolver.wrapper;

public class ClassWrapper<R> extends WrapperAbstract {
   private final Class<R> clazz;

   public ClassWrapper(Class<R> var1) {
      this.clazz = var1;
   }

   public boolean exists() {
      return this.clazz != null;
   }

   public Class<R> getClazz() {
      return this.clazz;
   }

   public String getName() {
      return this.clazz.getName();
   }

   public R newInstance() {
      try {
         return this.clazz.newInstance();
      } catch (Exception var2) {
         throw new RuntimeException(var2);
      }
   }

   public R newInstanceSilent() {
      try {
         return this.clazz.newInstance();
      } catch (Exception var2) {
         return null;
      }
   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (var1 != null && this.getClass() == var1.getClass()) {
         ClassWrapper var2 = (ClassWrapper)var1;
         return this.clazz != null ? this.clazz.equals(var2.clazz) : var2.clazz == null;
      } else {
         return false;
      }
   }

   public int hashCode() {
      return this.clazz != null ? this.clazz.hashCode() : 0;
   }
}
