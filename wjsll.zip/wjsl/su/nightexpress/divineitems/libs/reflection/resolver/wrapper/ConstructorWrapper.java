package su.nightexpress.divineitems.libs.reflection.resolver.wrapper;

import java.lang.reflect.Constructor;

public class ConstructorWrapper<R> extends WrapperAbstract {
   private final Constructor<R> constructor;

   public ConstructorWrapper(Constructor<R> var1) {
      this.constructor = var1;
   }

   public boolean exists() {
      return this.constructor != null;
   }

   public R newInstance(Object... var1) {
      try {
         return this.constructor.newInstance(var1);
      } catch (Exception var3) {
         throw new RuntimeException(var3);
      }
   }

   public R newInstanceSilent(Object... var1) {
      try {
         return this.constructor.newInstance(var1);
      } catch (Exception var3) {
         return null;
      }
   }

   public Class<?>[] getParameterTypes() {
      return this.constructor.getParameterTypes();
   }

   public Constructor<R> getConstructor() {
      return this.constructor;
   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (var1 != null && this.getClass() == var1.getClass()) {
         ConstructorWrapper var2 = (ConstructorWrapper)var1;
         return this.constructor != null ? this.constructor.equals(var2.constructor) : var2.constructor == null;
      } else {
         return false;
      }
   }

   public int hashCode() {
      return this.constructor != null ? this.constructor.hashCode() : 0;
   }
}
