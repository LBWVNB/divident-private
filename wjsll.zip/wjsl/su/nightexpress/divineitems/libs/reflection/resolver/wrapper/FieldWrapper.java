package su.nightexpress.divineitems.libs.reflection.resolver.wrapper;

import java.lang.reflect.Field;

public class FieldWrapper<R> extends WrapperAbstract {
   private final Field field;

   public FieldWrapper(Field var1) {
      this.field = var1;
   }

   public boolean exists() {
      return this.field != null;
   }

   public String getName() {
      return this.field.getName();
   }

   public R get(Object var1) {
      try {
         return this.field.get(var1);
      } catch (Exception var3) {
         throw new RuntimeException(var3);
      }
   }

   public R getSilent(Object var1) {
      try {
         return this.field.get(var1);
      } catch (Exception var3) {
         return null;
      }
   }

   public void set(Object var1, R var2) {
      try {
         this.field.set(var1, var2);
      } catch (Exception var4) {
         throw new RuntimeException(var4);
      }
   }

   public void setSilent(Object var1, R var2) {
      try {
         this.field.set(var1, var2);
      } catch (Exception var4) {
      }

   }

   public Field getField() {
      return this.field;
   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (var1 != null && this.getClass() == var1.getClass()) {
         FieldWrapper var2 = (FieldWrapper)var1;
         if (this.field != null) {
            if (!this.field.equals(var2.field)) {
               return false;
            }
         } else if (var2.field != null) {
            return false;
         }

         return true;
      } else {
         return false;
      }
   }

   public int hashCode() {
      return this.field != null ? this.field.hashCode() : 0;
   }
}
