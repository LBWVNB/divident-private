package su.nightexpress.divineitems.libs.reflection.resolver.wrapper;

import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MethodWrapper<R> extends WrapperAbstract {
   private final Method method;

   public MethodWrapper(Method var1) {
      this.method = var1;
   }

   public boolean exists() {
      return this.method != null;
   }

   public String getName() {
      return this.method.getName();
   }

   public R invoke(Object var1, Object... var2) {
      try {
         return this.method.invoke(var1, var2);
      } catch (Exception var4) {
         throw new RuntimeException(var4);
      }
   }

   public R invokeSilent(Object var1, Object... var2) {
      try {
         return this.method.invoke(var1, var2);
      } catch (Exception var4) {
         return null;
      }
   }

   public Method getMethod() {
      return this.method;
   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (var1 != null && this.getClass() == var1.getClass()) {
         MethodWrapper var2 = (MethodWrapper)var1;
         return this.method != null ? this.method.equals(var2.method) : var2.method == null;
      } else {
         return false;
      }
   }

   public int hashCode() {
      return this.method != null ? this.method.hashCode() : 0;
   }

   public static String getMethodSignature(Method var0, boolean var1) {
      return MethodWrapper.MethodSignature.of(var0, var1).getSignature();
   }

   public static String getMethodSignature(Method var0) {
      return getMethodSignature(var0, false);
   }

   public static class MethodSignature {
      static final Pattern SIGNATURE_STRING_PATTERN = Pattern.compile("(.+) (.*)\\((.*)\\)");
      private final String returnType;
      private final Pattern returnTypePattern;
      private final String name;
      private final Pattern namePattern;
      private final String[] parameterTypes;
      private final String signature;

      public MethodSignature(String var1, String var2, String[] var3) {
         this.returnType = var1;
         this.returnTypePattern = Pattern.compile(var1.replace("?", "\\w").replace("*", "\\w*").replace("[", "\\[").replace("]", "\\]"));
         this.name = var2;
         this.namePattern = Pattern.compile(var2.replace("?", "\\w").replace("*", "\\w*"));
         this.parameterTypes = var3;
         StringBuilder var4 = new StringBuilder();
         var4.append(var1).append(" ").append(var2).append("(");
         boolean var5 = true;
         String[] var9 = var3;
         int var8 = var3.length;

         for(int var7 = 0; var7 < var8; ++var7) {
            String var6 = var9[var7];
            if (!var5) {
               var4.append(",");
            }

            var4.append(var6);
            var5 = false;
         }

         this.signature = var4.append(")").toString();
      }

      public static MethodWrapper.MethodSignature of(Method var0, boolean var1) {
         Class var2 = var0.getReturnType();
         Class[] var3 = var0.getParameterTypes();
         String var4;
         if (var2.isPrimitive()) {
            var4 = var2.toString();
         } else {
            var4 = var1 ? var2.getName() : var2.getSimpleName();
         }

         String var5 = var0.getName();
         String[] var6 = new String[var3.length];

         for(int var7 = 0; var7 < var6.length; ++var7) {
            if (var3[var7].isPrimitive()) {
               var6[var7] = var3[var7].toString();
            } else {
               var6[var7] = var1 ? var3[var7].getName() : var3[var7].getSimpleName();
            }
         }

         return new MethodWrapper.MethodSignature(var4, var5, var6);
      }

      public static MethodWrapper.MethodSignature fromString(String var0) {
         if (var0 == null) {
            return null;
         } else {
            Matcher var1 = SIGNATURE_STRING_PATTERN.matcher(var0);
            if (var1.find()) {
               if (var1.groupCount() != 3) {
                  throw new IllegalArgumentException("invalid signature");
               } else {
                  return new MethodWrapper.MethodSignature(var1.group(1), var1.group(2), var1.group(3).split(","));
               }
            } else {
               throw new IllegalArgumentException("invalid signature");
            }
         }
      }

      public String getReturnType() {
         return this.returnType;
      }

      public boolean isReturnTypeWildcard() {
         return "?".equals(this.returnType) || "*".equals(this.returnType);
      }

      public String getName() {
         return this.name;
      }

      public boolean isNameWildcard() {
         return "?".equals(this.name) || "*".equals(this.name);
      }

      public String[] getParameterTypes() {
         return this.parameterTypes;
      }

      public String getParameterType(int var1) {
         return this.parameterTypes[var1];
      }

      public boolean isParameterWildcard(int var1) {
         return "?".equals(this.getParameterType(var1)) || "*".equals(this.getParameterType(var1));
      }

      public String getSignature() {
         return this.signature;
      }

      public boolean matches(MethodWrapper.MethodSignature var1) {
         if (var1 == null) {
            return false;
         } else if (!this.returnTypePattern.matcher(var1.returnType).matches()) {
            return false;
         } else if (!this.namePattern.matcher(var1.name).matches()) {
            return false;
         } else if (this.parameterTypes.length != var1.parameterTypes.length) {
            return false;
         } else {
            for(int var2 = 0; var2 < this.parameterTypes.length; ++var2) {
               if (!Pattern.compile(this.getParameterType(var2).replace("?", "\\w").replace("*", "\\w*")).matcher(var1.getParameterType(var2)).matches()) {
                  return false;
               }
            }

            return true;
         }
      }

      public boolean equals(Object var1) {
         if (this == var1) {
            return true;
         } else if (var1 != null && this.getClass() == var1.getClass()) {
            MethodWrapper.MethodSignature var2 = (MethodWrapper.MethodSignature)var1;
            if (!this.returnType.equals(var2.returnType)) {
               return false;
            } else if (!this.name.equals(var2.name)) {
               return false;
            } else {
               return !Arrays.equals(this.parameterTypes, var2.parameterTypes) ? false : this.signature.equals(var2.signature);
            }
         } else {
            return false;
         }
      }

      public int hashCode() {
         int var1 = this.returnType.hashCode();
         var1 = 31 * var1 + this.name.hashCode();
         var1 = 31 * var1 + Arrays.hashCode(this.parameterTypes);
         var1 = 31 * var1 + this.signature.hashCode();
         return var1;
      }

      public String toString() {
         return this.getSignature();
      }
   }
}
