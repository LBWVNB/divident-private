package su.nightexpress.divineitems.libs.reflection.resolver.wrapper;

public abstract class WrapperAbstract {
   public abstract boolean exists();
}
