package su.nightexpress.divineitems.libs.reflection.util;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public abstract class AccessUtil {
   public static Field setAccessible(Field var0) {
      var0.setAccessible(true);
      Field var1 = Field.class.getDeclaredField("modifiers");
      var1.setAccessible(true);
      var1.setInt(var0, var0.getModifiers() & -17);
      return var0;
   }

   public static Method setAccessible(Method var0) {
      var0.setAccessible(true);
      return var0;
   }

   public static Constructor<?> setAccessible(Constructor<?> var0) {
      var0.setAccessible(true);
      return var0;
   }
}
