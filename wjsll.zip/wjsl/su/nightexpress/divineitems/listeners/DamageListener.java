package su.nightexpress.divineitems.listeners;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.EnderPearl;
import org.bukkit.entity.Entity;
import org.bukkit.entity.FallingBlock;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityChangeBlockEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityRegainHealthEvent;
import org.bukkit.event.entity.ProjectileLaunchEvent;
import org.bukkit.event.entity.EntityDamageEvent.DamageModifier;
import org.bukkit.event.entity.EntityRegainHealthEvent.RegainReason;
import org.bukkit.event.player.PlayerFishEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.metadata.MetadataValue;
import su.nightexpress.divineitems.DivineItems;
import su.nightexpress.divineitems.api.EntityAPI;
import su.nightexpress.divineitems.api.ItemAPI;
import su.nightexpress.divineitems.attributes.DisarmRateSettings;
import su.nightexpress.divineitems.attributes.ItemStat;
import su.nightexpress.divineitems.hooks.Hook;
import su.nightexpress.divineitems.modules.buffs.BuffManager;
import su.nightexpress.divineitems.types.ArmorType;
import su.nightexpress.divineitems.utils.ItemUtils;
import su.nightexpress.divineitems.utils.Utils;

public class DamageListener implements Listener {
   private DivineItems plugin;

   public DamageListener(DivineItems var1) {
      this.plugin = var1;
   }

   @EventHandler
   public void onRangeDamage(PlayerInteractEvent var1) {
      if (var1.getHand() != EquipmentSlot.OFF_HAND) {
         if (!var1.getAction().toString().contains("RIGHT")) {
            Player var2 = var1.getPlayer();
            ItemStack var3 = var2.getInventory().getItemInMainHand();
            if (var3 != null && var3.getType() != Material.BOW && ItemUtils.isWeapon(var3)) {
               double var4 = ItemAPI.getAttribute(var3, ItemStat.RANGE);
               double var6 = this.plugin.getMM().getBuffManager().getBuff(var2, BuffManager.BuffType.ITEM_STAT, ItemStat.RANGE.name());
               if (var6 > 0.0D) {
                  if (var4 <= 0.0D) {
                     var4 = 3.0D;
                  }

                  var4 *= 1.0D + var6 / 100.0D;
               }

               if (!(var4 <= 0.0D)) {
                  LivingEntity var8 = EntityAPI.getEntityTargetByRange(var2, var4);
                  if (var8 != null) {
                     double var9 = ItemAPI.getDefaultDamage(var3);
                     var8.damage(var9, var2);
                  }

               }
            }
         }
      }
   }

   @EventHandler(
      priority = EventPriority.LOW,
      ignoreCancelled = true
   )
   public void onMeleeDamage(EntityDamageByEntityEvent var1) {
      Entity var2 = var1.getEntity();
      Entity var3 = var1.getDamager();
      if (var2 instanceof LivingEntity && var2 != null) {
         if (var3 instanceof LivingEntity && var3 != null) {
            if (Hook.WORLD_GUARD.isEnabled() && !this.plugin.getHM().getWorldGuard().canFights(var2, var3)) {
               var1.setCancelled(true);
            } else if (!Hook.CITIZENS.isEnabled() || !this.plugin.getHM().getCitizens().isNPC(var2)) {
               LivingEntity var4 = (LivingEntity)var3;
               LivingEntity var5 = (LivingEntity)var2;
               ItemStack var6 = null;
               if (var4.getEquipment().getItemInMainHand() != null) {
                  var6 = new ItemStack(var4.getEquipment().getItemInMainHand());
               }

               if (var6 != null && var6.getType() != Material.BOW) {
                  double var7 = ItemAPI.getAttribute(var6, ItemStat.RANGE);
                  if (var7 > 0.0D && var4.getWorld().equals(var5.getWorld()) && var4.getLocation().distance(var5.getLocation()) > var7) {
                     var1.setCancelled(true);
                  } else {
                     this.processDmg(var6, var4, var5, var1);
                  }
               }
            }
         }
      }
   }

   @EventHandler(
      priority = EventPriority.LOW,
      ignoreCancelled = true
   )
   public void onDBows(EntityDamageByEntityEvent var1) {
      Entity var2 = var1.getEntity();
      Entity var3 = var1.getDamager();
      if (var2 instanceof LivingEntity) {
         if (var3 instanceof Projectile) {
            if (Hook.WORLD_GUARD.isEnabled() && !this.plugin.getHM().getWorldGuard().canFights(var2, var3)) {
               var1.setCancelled(true);
            } else if (!Hook.CITIZENS.isEnabled() || !this.plugin.getHM().getCitizens().isNPC(var2)) {
               Projectile var4 = (Projectile)var3;
               if (var4 instanceof EnderPearl && var2 instanceof Player) {
                  Player var5 = (Player)var2;
                  if (var4.getShooter() != null && var4.getShooter().equals(var5)) {
                     return;
                  }
               }

               if (var4.hasMetadata("DIItem") && var4.getShooter() instanceof LivingEntity) {
                  LivingEntity var8 = (LivingEntity)var2;
                  LivingEntity var6 = (LivingEntity)var4.getShooter();
                  if (var8 != null && var6 != null) {
                     if (var4.hasMetadata("DIVINE_ARROW_ID")) {
                        String var7 = ((MetadataValue)var4.getMetadata("DIVINE_ARROW_ID").get(0)).asString();
                        var8.setMetadata("DIVINE_ARROW_ID", new FixedMetadataValue(this.plugin, var7));
                     }

                     ItemStack var9 = (ItemStack)((MetadataValue)var4.getMetadata("DIItem").get(0)).value();
                     this.processDmg(var9, var6, var8, var1);
                  }
               }
            }
         }
      }
   }

   @EventHandler(
      priority = EventPriority.HIGHEST,
      ignoreCancelled = true
   )
   public void onProjectLaunch(ProjectileLaunchEvent var1) {
      Projectile var2 = var1.getEntity();
      if (var2 != null && var2 instanceof Projectile) {
         Projectile var3 = (Projectile)var2;
         if (var3.getShooter() != null && var3.getShooter() instanceof LivingEntity) {
            LivingEntity var4 = (LivingEntity)var3.getShooter();
            if (var4.getEquipment().getItemInMainHand() != null) {
               ItemStack var5 = new ItemStack(var4.getEquipment().getItemInMainHand());
               if (var4 instanceof Player || this.plugin.getCM().getCFG().allowAttributesToMobs()) {
                  ItemUtils.setProjectileData(var3, var4, var5);
               }
            }
         }
      }
   }

   @EventHandler(
      priority = EventPriority.HIGH,
      ignoreCancelled = true
   )
   public void onSimpleDamage(EntityDamageEvent var1) {
      if (var1.getEntity() instanceof LivingEntity) {
         LivingEntity var2 = (LivingEntity)var1.getEntity();
         double var3 = var1.getFinalDamage();
         double var10000;
         if (var2 instanceof Player) {
            if (this.plugin.getCM().getCFG().getPlayerDmgModifiers().containsKey(var1.getCause())) {
               var10000 = var3 * (Double)this.plugin.getCM().getCFG().getPlayerDmgModifiers().get(var1.getCause());
            }
         } else if (this.plugin.getCM().getCFG().getMobDmgModifiers().containsKey(var1.getCause())) {
            var10000 = var3 * (Double)this.plugin.getCM().getCFG().getMobDmgModifiers().get(var1.getCause());
         }

      }
   }

   @EventHandler(
      priority = EventPriority.HIGH,
      ignoreCancelled = true
   )
   public void onFinalDamage(EntityDamageEvent var1) {
      if (!(var1 instanceof EntityDamageByEntityEvent)) {
         if (var1.getEntity() instanceof LivingEntity) {
            LivingEntity var2 = (LivingEntity)var1.getEntity();
            double var3 = var1.getFinalDamage();
            if (var2 instanceof Player || this.plugin.getCFG().allowAttributesToMobs()) {
               String var5 = var1.getCause().name();
               HashMap var6 = ItemAPI.getDefenseTypes(var2);
               Iterator var8 = var6.keySet().iterator();

               while(var8.hasNext()) {
                  ArmorType var7 = (ArmorType)var8.next();
                  double var9 = 0.0D;
                  if (var7.getBlockDamageSources().contains(var5)) {
                     var9 = (Double)var6.get(var7);
                  }

                  String var11 = var7.getFormula().replace("%def%", String.valueOf(var9)).replace("%dmg%", String.valueOf(var3)).replace("%penetrate%", "0");
                  var1.setDamage(ItemUtils.calc(var11));
               }

               if (this.plugin.getMM().getCombatLogManager().isActive()) {
                  this.plugin.getMM().getCombatLogManager().setDSMeta(var2, var5, Utils.round3(var3));
               }

            }
         }
      }
   }

   @EventHandler(
      priority = EventPriority.HIGHEST,
      ignoreCancelled = true
   )
   public void onVampirism(EntityDamageByEntityEvent var1) {
      if (var1.getEntity() instanceof LivingEntity) {
         if (!(var1.getEntity() instanceof ArmorStand)) {
            Entity var2 = var1.getDamager();
            if (var2 instanceof Projectile) {
               Projectile var3 = (Projectile)var2;
               if (var3.getShooter() != null && var3.getShooter() instanceof Entity) {
                  var2 = (Entity)var3.getShooter();
               }
            }

            if (var2 instanceof LivingEntity) {
               LivingEntity var9 = (LivingEntity)var2;
               double var4 = var1.getFinalDamage();
               double var6 = Math.max(0.0D, var4 * (EntityAPI.getItemStat(var9, ItemStat.VAMPIRISM) / 100.0D));
               EntityRegainHealthEvent var8 = new EntityRegainHealthEvent(var9, var6, RegainReason.CUSTOM);
               this.plugin.getPluginManager().callEvent(var8);
               if (!var8.isCancelled() && var9.getHealth() + var6 <= var9.getMaxHealth()) {
                  var9.setHealth(var9.getHealth() + var6);
               }

            }
         }
      }
   }

   @EventHandler(
      ignoreCancelled = true
   )
   public void onFish(PlayerFishEvent var1) {
      if (this.plugin.getCM().getCFG().allowFishHookDamage()) {
         Entity var2 = var1.getCaught();
         if (var2 instanceof LivingEntity) {
            Player var3 = var1.getPlayer();
            LivingEntity var4 = (LivingEntity)var2;
            ItemStack var5 = var3.getInventory().getItemInMainHand();
            double var6 = ItemAPI.getItemTotalDamage(var5);
            double var8 = var3.getLocation().distance(var4.getLocation());
            if (var8 < 10.0D) {
               var8 /= 10.0D;
            } else {
               var8 = 1.5D;
            }

            var6 *= var8;
            var4.damage(var6, var3);
         }
      }
   }

   @EventHandler
   public void onWallFall(EntityChangeBlockEvent var1) {
      if (var1.getEntity() instanceof FallingBlock && var1.getEntity().hasMetadata("DIFall")) {
         FallingBlock var2 = (FallingBlock)var1.getEntity();
         Utils.playEffect("BLOCK_CRACK:" + var2.getMaterial().name(), 0.30000001192092896D, 0.0D, 0.30000001192092896D, 0.30000001192092896D, 15, var2.getLocation());
         var1.getEntity().remove();
         var1.setCancelled(true);
         Entity var3 = var1.getEntity();
         Player var4 = Bukkit.getPlayer(((MetadataValue)var3.getMetadata("LauncherZ").get(0)).asString());
         if (var4 != null) {
            List var5 = var1.getEntity().getNearbyEntities(3.0D, 3.0D, 3.0D);
            if (!var5.isEmpty()) {
               ItemStack var6 = (ItemStack)((MetadataValue)var3.getMetadata("DIItem").get(0)).value();
               Iterator var8 = var5.iterator();

               while(true) {
                  LivingEntity var9;
                  do {
                     do {
                        do {
                           do {
                              Entity var7;
                              do {
                                 if (!var8.hasNext()) {
                                    return;
                                 }

                                 var7 = (Entity)var8.next();
                              } while(!(var7 instanceof LivingEntity));

                              var9 = (LivingEntity)var7;
                           } while(Hook.CITIZENS.isEnabled() && this.plugin.getHM().getCitizens().isNPC(var9));
                        } while(var9.equals(var4));
                     } while(var9.equals(var3));
                  } while(Hook.WORLD_GUARD.isEnabled() && !this.plugin.getHM().getWorldGuard().canFights(var9, var4));

                  var9.damage(ItemUtils.calcDamageByFormula(var9, var4, 1.0D, var6), var4);
               }
            }
         }
      }
   }

   private void processDmg(ItemStack var1, LivingEntity var2, LivingEntity var3, EntityDamageByEntityEvent var4) {
      double var5 = EntityAPI.getItemStat(var3, ItemStat.DODGE_RATE);
      double var7 = EntityAPI.getItemStat(var2, ItemStat.ACCURACY_RATE);
      double var9 = Utils.getRandDouble(0.0D, 100.0D);
      double var11 = Utils.getRandDouble(0.0D, 100.0D);
      if (var9 <= var5 && var11 > var7) {
         var4.setDamage(0.0D);
         var4.setCancelled(true);
         if (this.plugin.getMM().getCombatLogManager().isActive()) {
            this.plugin.getMM().getCombatLogManager().setDodgeMeta(var3);
         }

      } else {
         if (var4.isApplicable(DamageModifier.ARMOR)) {
            var4.setDamage(DamageModifier.ARMOR, 0.0D);
         }

         double var13 = ItemAPI.getAttribute(var1, ItemStat.DISARM_RATE);
         if (var13 > 0.0D && Utils.getRandDouble(0.0D, 100.0D) <= var13) {
            boolean var15 = true;
            ItemStack var16 = var3.getEquipment().getItemInMainHand();
            if (var16 == null || var16.getType() == Material.AIR) {
               var16 = var3.getEquipment().getItemInOffHand();
               var15 = false;
            }

            if (var16 != null && var16.getType() != Material.AIR) {
               if (var15) {
                  var3.getEquipment().setItemInMainHand(new ItemStack(Material.AIR));
               } else {
                  var3.getEquipment().setItemInOffHand(new ItemStack(Material.AIR));
               }

               var3.getWorld().dropItemNaturally(var3.getLocation(), var16).setPickupDelay(40);
               DisarmRateSettings var17 = (DisarmRateSettings)ItemStat.DISARM_RATE.getSettings();
               Utils.playEffect(var17.getEffect(), 0.2D, 0.4D, 0.2D, 0.1D, 25, var3.getLocation());
               Player var18;
               if (var2 instanceof Player) {
                  var18 = (Player)var2;
                  var18.sendMessage(var17.getMsgToDamager().replace("%s%", Utils.getEntityName(var3)));
               }

               if (var3 instanceof Player) {
                  var18 = (Player)var3;
                  var18.sendMessage(var17.getMsgToEntity().replace("%s%", Utils.getEntityName(var2)));
               }
            }
         }

         double var26 = var4.getDamage();
         double var27 = ItemAPI.getAttribute(var1, ItemStat.BURN_RATE);
         if (Utils.getRandDouble(0.0D, 100.0D) <= var27) {
            var3.setFireTicks(100);
         }

         double var19 = EntityAPI.getItemStat(var2, ItemStat.RANGE);
         if (var19 <= 0.0D) {
            var19 = 3.0D;
         }

         double var21 = var26 * (ItemAPI.getAttribute(var1, ItemStat.AOE_DAMAGE) / 100.0D);
         if (var21 > 0.0D) {
            if (var3.hasMetadata("AOE_FIX")) {
               var3.removeMetadata("AOE_FIX", this.plugin);
            } else {
               Iterator var24 = var3.getNearbyEntities(var19, var19, var19).iterator();

               label85:
               while(true) {
                  LivingEntity var25;
                  do {
                     do {
                        do {
                           Entity var23;
                           do {
                              if (!var24.hasNext()) {
                                 break label85;
                              }

                              var23 = (Entity)var24.next();
                           } while(!(var23 instanceof LivingEntity));

                           var25 = (LivingEntity)var23;
                        } while(Hook.CITIZENS.isEnabled() && this.plugin.getHM().getCitizens().isNPC(var25));
                     } while(var25.equals(var2));
                  } while(Hook.WORLD_GUARD.isEnabled() && !this.plugin.getHM().getWorldGuard().canFights(var25, var2));

                  var25.setMetadata("AOE_FIX", new FixedMetadataValue(this.plugin, "yes"));
                  var25.damage(var21, var2);
               }
            }
         }

         double var28 = ItemUtils.calcDamageByFormula(var3, var2, var26, var1);
         var4.setDamage(var28);
         if (Hook.MYTHIC_MOBS.isEnabled()) {
            this.plugin.getHM().getMythicHook().setSkillDamage(var2, var28);
         }

      }
   }
}
