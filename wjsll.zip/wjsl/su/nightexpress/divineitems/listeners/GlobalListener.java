package su.nightexpress.divineitems.listeners;

import org.bukkit.Material;
import org.bukkit.entity.Egg;
import org.bukkit.entity.EnderPearl;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Fireball;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.LlamaSpit;
import org.bukkit.entity.Player;
import org.bukkit.entity.ShulkerBullet;
import org.bukkit.entity.Snowball;
import org.bukkit.entity.ThrownExpBottle;
import org.bukkit.entity.WitherSkull;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityShootBowEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.player.PlayerFishEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemDamageEvent;
import org.bukkit.inventory.ItemStack;
import su.nightexpress.divineitems.api.EntityAPI;
import su.nightexpress.divineitems.api.ItemAPI;
import su.nightexpress.divineitems.types.AmmoType;
import su.nightexpress.divineitems.utils.ItemUtils;

public class GlobalListener implements Listener {
   // $FF: synthetic field
   private static int[] $SWITCH_TABLE$su$nightexpress$divineitems$types$AmmoType;

   @EventHandler(
      priority = EventPriority.LOWEST,
      ignoreCancelled = true
   )
   public void onProjShoot(EntityShootBowEvent var1) {
      LivingEntity var2 = var1.getEntity();
      ItemStack var3 = var1.getBow();
      AmmoType var4 = ItemAPI.getAmmoType(var3);
      ItemStack var6;
      switch($SWITCH_TABLE$su$nightexpress$divineitems$types$AmmoType()[var4.ordinal()]) {
      case 1:
      default:
         break;
      case 2:
         Snowball var13 = (Snowball)var2.launchProjectile(Snowball.class);
         var1.setProjectile(var13);
         break;
      case 3:
         Egg var12 = (Egg)var2.launchProjectile(Egg.class);
         var1.setProjectile(var12);
         break;
      case 4:
         Fireball var11 = (Fireball)var2.launchProjectile(Fireball.class);
         var1.setProjectile(var11);
         break;
      case 5:
         WitherSkull var10 = (WitherSkull)var2.launchProjectile(WitherSkull.class);
         var1.setProjectile(var10);
         break;
      case 6:
         ShulkerBullet var9 = (ShulkerBullet)var2.getWorld().spawnEntity(var2.getEyeLocation().add(var2.getEyeLocation().getDirection()), EntityType.SHULKER_BULLET);
         var9.setShooter(var2);
         var9.setVelocity(var2.getEyeLocation().getDirection().multiply(1.0F + var1.getForce()));
         var6 = new ItemStack(var2.getEquipment().getItemInMainHand());
         ItemUtils.setProjectileData(var9, var2, var6);
         var1.setProjectile(var9);
         break;
      case 7:
         LlamaSpit var8 = (LlamaSpit)var2.getWorld().spawnEntity(var2.getEyeLocation().add(var2.getEyeLocation().getDirection()), EntityType.LLAMA_SPIT);
         var8.setShooter(var2);
         var8.setBounce(true);
         var8.setVelocity(var2.getEyeLocation().getDirection().multiply(1.0F + var1.getForce()));
         var6 = new ItemStack(var2.getEquipment().getItemInMainHand());
         ItemUtils.setProjectileData(var8, var2, var6);
         var1.setProjectile(var8);
         break;
      case 8:
         EnderPearl var7 = (EnderPearl)var2.launchProjectile(EnderPearl.class);
         var1.setProjectile(var7);
         break;
      case 9:
         ThrownExpBottle var5 = (ThrownExpBottle)var2.getWorld().spawnEntity(var2.getEyeLocation().add(var2.getEyeLocation().getDirection()), EntityType.THROWN_EXP_BOTTLE);
         var5.setShooter(var2);
         var5.setBounce(true);
         var5.setVelocity(var2.getEyeLocation().getDirection().multiply(1.0F + var1.getForce()));
         var6 = new ItemStack(var2.getEquipment().getItemInMainHand());
         ItemUtils.setProjectileData(var5, var2, var6);
         var1.setProjectile(var5);
      }

   }

   @EventHandler(
      priority = EventPriority.LOWEST,
      ignoreCancelled = true
   )
   public void onDurability(PlayerItemDamageEvent var1) {
      ItemStack var2 = var1.getItem();
      if (ItemAPI.getDurability(var2, 0) != -1) {
         var1.setCancelled(true);
      } else if (ItemAPI.getDurability(var2, 0) == -999) {
         var1.setCancelled(true);
      }

   }

   @EventHandler(
      ignoreCancelled = true
   )
   public void onBlockBreak(BlockBreakEvent var1) {
      Player var2 = var1.getPlayer();
      ItemStack var3 = var2.getInventory().getItemInMainHand();
      if (var3 != null && var3.hasItemMeta() && var3.getItemMeta().hasLore()) {
         if (ItemAPI.getDurability(var3, 0) > 0) {
            ItemAPI.setFinalDurability(var3, var2, 1);
         }

      }
   }

   @EventHandler(
      ignoreCancelled = true
   )
   public void onFish(PlayerFishEvent var1) {
      Player var2 = var1.getPlayer();
      ItemStack var3 = var2.getInventory().getItemInMainHand();
      if (var3 != null && var3.hasItemMeta() && var3.getItemMeta().hasLore()) {
         if (!ItemAPI.canUse(var3, var2)) {
            var1.setCancelled(true);
         } else {
            if (ItemAPI.getDurability(var3, 0) > 0) {
               ItemAPI.setFinalDurability(var3, var2, 1);
            }

         }
      }
   }

   @EventHandler(
      priority = EventPriority.HIGHEST,
      ignoreCancelled = true
   )
   public void onDamageArmor(EntityDamageEvent var1) {
      Entity var2 = var1.getEntity();
      if (var2 instanceof LivingEntity) {
         LivingEntity var3 = (LivingEntity)var2;
         ItemStack[] var7;
         int var6 = (var7 = EntityAPI.getEquipment(var3, true)).length;

         for(int var5 = 0; var5 < var6; ++var5) {
            ItemStack var4 = var7[var5];
            if (var4 != null && ItemAPI.getDurability(var4, 0) > 0) {
               ItemAPI.setFinalDurability(var4, var3, 1);
            }
         }

      }
   }

   @EventHandler(
      priority = EventPriority.HIGHEST,
      ignoreCancelled = true
   )
   public void onDamageItem(EntityDamageByEntityEvent var1) {
      if (var1.getDamager() instanceof Player) {
         Player var2 = (Player)var1.getDamager();
         ItemStack var3 = var2.getInventory().getItemInMainHand();
         if (var3 != null && var3.hasItemMeta() && var3.getItemMeta().hasLore()) {
            if (ItemAPI.getDurability(var3, 0) > 0) {
               ItemAPI.setFinalDurability(var3, var2, 1);
            }

         }
      }
   }

   @EventHandler(
      priority = EventPriority.HIGHEST,
      ignoreCancelled = true
   )
   public void onShoot(EntityShootBowEvent var1) {
      if (var1.getEntity() instanceof Player) {
         Player var2 = (Player)var1.getEntity();
         ItemStack var3 = var2.getInventory().getItemInMainHand();
         if (var3 != null && var3.hasItemMeta() && var3.getItemMeta().hasLore()) {
            if (ItemAPI.getDurability(var3, 0) > 0) {
               ItemAPI.setFinalDurability(var3, var2, 1);
            }

         }
      }
   }

   @EventHandler
   public void onCloseInv(InventoryCloseEvent var1) {
      Player var2 = (Player)var1.getPlayer();
      if (var1.getInventory().getType() == InventoryType.CRAFTING && var1.getInventory().getHolder().equals(var2)) {
         EntityAPI.checkForLegitItems(var2);
      }

   }

   @EventHandler(
      priority = EventPriority.LOWEST,
      ignoreCancelled = true
   )
   public void onDamageBroken(EntityDamageByEntityEvent var1) {
      if (var1.getDamager() instanceof Player) {
         Player var2 = (Player)var1.getDamager();
         ItemStack var3 = var2.getInventory().getItemInMainHand();
         if (!ItemAPI.canUse(var3, var2)) {
            var1.setCancelled(true);
         }

      }
   }

   @EventHandler(
      priority = EventPriority.LOWEST
   )
   public void onInteractBroken(PlayerInteractEvent var1) {
      Player var2 = var1.getPlayer();
      ItemStack var3 = var1.getItem();
      if (var3 != null && var3.getItemMeta() != null && var3.getItemMeta().getLore() != null) {
         if (!ItemAPI.canUse(var3, var2)) {
            var1.setCancelled(true);
         }

      }
   }

   @EventHandler(
      priority = EventPriority.LOWEST
   )
   public void onClickDenied(InventoryClickEvent var1) {
      Player var2 = (Player)var1.getWhoClicked();
      ItemStack var3 = var1.getCurrentItem();
      if (var1.getInventory().getType() == InventoryType.CRAFTING && var1.getInventory().getHolder().equals(var2)) {
         ItemStack var4 = var1.getCursor();
         if (var4 != null && var4.getType() != Material.AIR && var1.getSlot() >= 36 && var1.getSlot() <= 40 && !ItemAPI.canUse(var4, var2)) {
            var1.setCancelled(true);
            return;
         }

         if (var3 == null || !var3.hasItemMeta()) {
            return;
         }

         if (!ItemAPI.canUse(var3, var2) && var1.isShiftClick()) {
            var1.setCancelled(true);
            return;
         }
      }

   }

   @EventHandler(
      priority = EventPriority.LOWEST
   )
   public void onBlockBreakBroken(BlockBreakEvent var1) {
      Player var2 = var1.getPlayer();
      ItemStack var3 = var2.getInventory().getItemInMainHand();
      if (var3 != null && var3.hasItemMeta() && var3.getItemMeta().hasLore()) {
         if (!ItemAPI.canUse(var3, var2)) {
            var1.setCancelled(true);
         }
      }
   }

   // $FF: synthetic method
   static int[] $SWITCH_TABLE$su$nightexpress$divineitems$types$AmmoType() {
      int[] var10000 = $SWITCH_TABLE$su$nightexpress$divineitems$types$AmmoType;
      if (var10000 != null) {
         return var10000;
      } else {
         int[] var0 = new int[AmmoType.values().length];

         try {
            var0[AmmoType.ARROW.ordinal()] = 1;
         } catch (NoSuchFieldError var9) {
         }

         try {
            var0[AmmoType.EGG.ordinal()] = 3;
         } catch (NoSuchFieldError var8) {
         }

         try {
            var0[AmmoType.ENDER_PEARL.ordinal()] = 8;
         } catch (NoSuchFieldError var7) {
         }

         try {
            var0[AmmoType.EXP_POTION.ordinal()] = 9;
         } catch (NoSuchFieldError var6) {
         }

         try {
            var0[AmmoType.FIREBALL.ordinal()] = 4;
         } catch (NoSuchFieldError var5) {
         }

         try {
            var0[AmmoType.LLAMA_SPIT.ordinal()] = 7;
         } catch (NoSuchFieldError var4) {
         }

         try {
            var0[AmmoType.SHULKER_BULLET.ordinal()] = 6;
         } catch (NoSuchFieldError var3) {
         }

         try {
            var0[AmmoType.SNOWBALL.ordinal()] = 2;
         } catch (NoSuchFieldError var2) {
         }

         try {
            var0[AmmoType.WITHER_SKULL.ordinal()] = 5;
         } catch (NoSuchFieldError var1) {
         }

         $SWITCH_TABLE$su$nightexpress$divineitems$types$AmmoType = var0;
         return var0;
      }
   }
}
