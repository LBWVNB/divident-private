package su.nightexpress.divineitems.listeners;

import io.lumine.xikage.mythicmobs.api.bukkit.events.MythicMobDeathEvent;
import io.lumine.xikage.mythicmobs.api.bukkit.events.MythicMobSpawnEvent;
import io.lumine.xikage.mythicmobs.mobs.MythicMob;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;
import su.nightexpress.divineitems.DivineItems;
import su.nightexpress.divineitems.api.ItemAPI;
import su.nightexpress.divineitems.utils.Utils;

public class MythicListener implements Listener {
   private DivineItems plugin;

   public MythicListener(DivineItems var1) {
      this.plugin = var1;
   }

   @EventHandler
   public void onMDrop(MythicMobDeathEvent var1) {
      if (var1.getKiller() instanceof Player) {
         Player var2 = (Player)var1.getKiller();
         if (var2 != null) {
            var1.getDrops().addAll(this.plugin.getMM().getDropManager().methodRoll(var2, (LivingEntity)var1.getEntity(), false));
         }
      }
   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onMMSpawn(MythicMobSpawnEvent var1) {
      if (var1.getEntity() instanceof LivingEntity) {
         final LivingEntity var2 = (LivingEntity)var1.getEntity();
         MythicMob var3 = var1.getMobType();
         ArrayList var4 = new ArrayList(var3.getEquipment());
         if (!var4.isEmpty()) {
            Iterator var6 = var4.iterator();

            while(var6.hasNext()) {
               String var5 = (String)var6.next();
               if (var5.startsWith("ditems")) {
                  String[] var7 = var5.replace("ditems", "").split(":");
                  final int var8 = Integer.parseInt(var7[1]);
                  if (!this.getItem(var5).isEmpty()) {
                     final ItemStack var9 = (ItemStack)this.getItem(var5).get(0);
                     if (var9 != null) {
                        (new BukkitRunnable() {
                           public void run() {
                              switch(var8) {
                              case 0:
                                 var2.getEquipment().setItemInMainHand(var9);
                                 break;
                              case 1:
                                 var2.getEquipment().setBoots(var9);
                                 break;
                              case 2:
                                 var2.getEquipment().setLeggings(var9);
                                 break;
                              case 3:
                                 var2.getEquipment().setChestplate(var9);
                                 break;
                              case 4:
                                 var2.getEquipment().setHelmet(var9);
                                 break;
                              case 5:
                                 var2.getEquipment().setItemInOffHand(var9);
                              }

                           }
                        }).runTaskLater(this.plugin, 5L);
                     }
                  }
               }
            }

         }
      }
   }

   @EventHandler(
      priority = EventPriority.LOWEST
   )
   public void onMMDeath(MythicMobDeathEvent var1) {
      MythicMob var2 = var1.getMobType();
      ArrayList var3 = new ArrayList(var2.getDrops());
      if (!var3.isEmpty()) {
         if (var1.getKiller() != null && var1.getKiller() instanceof Player) {
            Iterator var5 = var2.getDrops().iterator();

            String var4;
            while(var5.hasNext()) {
               var4 = (String)var5.next();
               if (this.plugin.getHM().getMythicHook().isDropTable(var4)) {
                  var3.addAll(this.plugin.getHM().getMythicHook().getTableDrops(var4));
               }
            }

            var5 = var3.iterator();

            while(var5.hasNext()) {
               var4 = (String)var5.next();
               if (var4.startsWith("ditems")) {
                  List var6 = this.getItem(var4);
                  if (var6 != null && !var6.isEmpty()) {
                     var1.getDrops().addAll(var6);
                  }
               }
            }

         }
      }
   }

   private List<ItemStack> getItem(String var1) {
      ArrayList var2;
      String var4;
      String var5;
      int var6;
      int var7;
      double var8;
      int var11;
      label98: {
         String[] var3;
         int var12;
         label97: {
            var2 = new ArrayList();
            var3 = var1.replace("ditems ", "").split(" ");
            var4 = var3[0];
            var5 = var3[1];
            var6 = -1;
            var7 = -1;
            var8 = -1.0D;
            switch(var4.hashCode()) {
            case -934535283:
               if (!var4.equals("repair")) {
                  break label98;
               }
               break label97;
            case -862556560:
               if (!var4.equals("consumables")) {
                  break label98;
               }
               break;
            case -125275719:
               if (!var4.equals("abyss_dust")) {
                  break label98;
               }
               break;
            case 3169028:
               if (!var4.equals("gems")) {
                  break label98;
               }
               break label97;
            case 108875897:
               if (!var4.equals("runes")) {
                  break label98;
               }
               break label97;
            case 110357201:
               if (!var4.equals("tiers")) {
                  break label98;
               }
               break label97;
            case 721206642:
               if (var4.equals("custom_items")) {
                  try {
                     if (var3[2].contains("-")) {
                        var11 = Integer.parseInt(var3[2].split("-")[0]);
                        var12 = Integer.parseInt(var3[2].split("-")[1]);
                        var7 = Utils.randInt(var11, var12);
                     } else {
                        var7 = Integer.parseInt(var3[2]);
                     }

                     var8 = Double.parseDouble(var3[3]);
                  } catch (ArrayIndexOutOfBoundsException | NumberFormatException var15) {
                     return var2;
                  }
               }
               break label98;
            case 987883201:
               if (!var4.equals("identify:item")) {
                  break label98;
               }
               break label97;
            case 988206337:
               if (!var4.equals("identify:tome")) {
                  break label98;
               }
               break;
            case 1570000388:
               if (!var4.equals("magic_dust")) {
                  break label98;
               }
               break label97;
            case 1658381128:
               if (!var4.equals("abilities")) {
                  break label98;
               }
               break label97;
            case 1704673082:
               if (!var4.equals("enchants")) {
                  break label98;
               }
               break label97;
            case 1926689606:
               if (!var4.equals("scrolls")) {
                  break label98;
               }
               break label97;
            default:
               break label98;
            }

            try {
               if (var3[2].contains("-")) {
                  var11 = Integer.parseInt(var3[2].split("-")[0]);
                  var12 = Integer.parseInt(var3[2].split("-")[1]);
                  var7 = Utils.randInt(var11, var12);
               } else {
                  var7 = Integer.parseInt(var3[2]);
               }

               var8 = Double.parseDouble(var3[3]);
               break label98;
            } catch (ArrayIndexOutOfBoundsException | NumberFormatException var13) {
               return var2;
            }
         }

         try {
            if (var3[2].contains("-")) {
               var11 = Integer.parseInt(var3[2].split("-")[0]);
               var12 = Integer.parseInt(var3[2].split("-")[1]);
               var6 = Utils.randInt(var11, var12);
            } else {
               var6 = Integer.parseInt(var3[2]);
            }

            if (var3[3].contains("-")) {
               var11 = Integer.parseInt(var3[3].split("-")[0]);
               var12 = Integer.parseInt(var3[3].split("-")[1]);
               var7 = Utils.randInt(var11, var12);
            } else {
               var7 = Integer.parseInt(var3[3]);
            }

            var8 = Double.parseDouble(var3[4]);
         } catch (ArrayIndexOutOfBoundsException | NumberFormatException var14) {
            return var2;
         }
      }

      if (Utils.getRandDouble(0.0D, 100.0D) / 100.0D <= var8) {
         for(var11 = 0; var11 < var7; ++var11) {
            ItemStack var16 = ItemAPI.getItemByModule(var5, var4, var6);
            var2.add(var16);
         }
      }

      return var2;
   }
}
