package su.nightexpress.divineitems.listeners;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerPickupItemEvent;
import org.bukkit.inventory.ItemStack;
import su.nightexpress.divineitems.api.ItemAPI;

public class PickupListener2 implements Listener {
   @EventHandler
   public void onPickup(PlayerPickupItemEvent var1) {
      if (var1.getItem().hasMetadata("dont_pick_me")) {
         var1.setCancelled(true);
      } else {
         ItemStack var2 = var1.getItem().getItemStack();
         Player var3 = var1.getPlayer();
         if (ItemAPI.isSoulBinded(var2) && !ItemAPI.isOwner(var2, var3)) {
            var1.setCancelled(true);
         } else if (ItemAPI.hasOwner(var2) && !ItemAPI.isOwner(var2, var3)) {
            var1.setCancelled(true);
         }
      }
   }
}
