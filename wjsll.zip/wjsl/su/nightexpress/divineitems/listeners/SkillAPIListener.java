package su.nightexpress.divineitems.listeners;

import com.sucy.skill.api.event.PlayerCastSkillEvent;
import com.sucy.skill.api.event.PlayerClassChangeEvent;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.inventory.ItemStack;
import su.nightexpress.divineitems.DivineItems;
import su.nightexpress.divineitems.api.EntityAPI;
import su.nightexpress.divineitems.api.ItemAPI;

public class SkillAPIListener implements Listener {
   private DivineItems plugin;

   public SkillAPIListener(DivineItems var1) {
      this.plugin = var1;
   }

   @EventHandler
   public void onSkillCast(PlayerCastSkillEvent var1) {
      if (this.plugin.getCFG().skillAPIReduceDurability()) {
         Player var2 = var1.getPlayer();
         ItemStack var3 = var2.getInventory().getItemInMainHand();
         if (var3 != null && ItemAPI.getDurability(var3, 0) > 0) {
            ItemAPI.reduceDurability(var3, 1);
         }
      }
   }

   @EventHandler
   public void onClass(PlayerClassChangeEvent var1) {
      Player var2 = var1.getPlayerData().getPlayer();
      EntityAPI.checkForLegitItems(var2);
   }
}
