package su.nightexpress.divineitems.modules;

import java.util.ArrayList;
import java.util.List;
import org.bukkit.Sound;
import su.nightexpress.divineitems.types.DestroyType;

public class MainSettings {
   private String display;
   private List<String> lore;
   private int min_chance;
   private int max_chance;
   private DestroyType destroy;
   private boolean eff_use;
   private String eff_de_value;
   private String eff_suc_value;
   private boolean sound_use;
   private Sound sound_de_value;
   private Sound sound_suc_value;
   private String header;
   private String empty_slot;
   private String filled_slot;

   MainSettings(MainSettings var1) {
      this.display = var1.getDisplay();
      this.lore = var1.getLore();
      this.min_chance = var1.getMinChance();
      this.max_chance = var1.getMaxChance();
      this.destroy = var1.getDestroyType();
      this.header = var1.getHeader();
      this.empty_slot = var1.getEmptySlot();
      this.filled_slot = var1.getFilledSlot();
   }

   public MainSettings(String var1, List<String> var2, int var3, int var4, DestroyType var5, boolean var6, String var7, String var8, boolean var9, Sound var10, Sound var11, String var12, String var13, String var14) {
      this.setDisplay(var1);
      this.setLore(var2);
      this.setMinChance(var3);
      this.setMaxChance(var4);
      this.setDestroyType(var5);
      this.setUseEffect(var6);
      this.setDestroyEffect(var7);
      this.setSuccessEffect(var8);
      this.setUseSound(var9);
      this.setDestroySound(var10);
      this.setSuccessSound(var11);
      this.setHeader(var12);
      this.setEmptySlot(var13);
      this.setFilledSlot(var14);
   }

   public String getDisplay() {
      return this.display;
   }

   public void setDisplay(String var1) {
      this.display = var1;
   }

   public List<String> getLore() {
      return new ArrayList(this.lore);
   }

   public void setLore(List<String> var1) {
      this.lore = var1;
   }

   public int getMinChance() {
      return this.min_chance;
   }

   public void setMinChance(int var1) {
      this.min_chance = var1;
   }

   public int getMaxChance() {
      return this.max_chance;
   }

   public void setMaxChance(int var1) {
      this.max_chance = var1;
   }

   public DestroyType getDestroyType() {
      return this.destroy;
   }

   public void setDestroyType(DestroyType var1) {
      this.destroy = var1;
   }

   public boolean useEffect() {
      return this.eff_use;
   }

   public void setUseEffect(boolean var1) {
      this.eff_use = var1;
   }

   public String getDestroyEffect() {
      return this.eff_de_value;
   }

   public void setDestroyEffect(String var1) {
      this.eff_de_value = var1;
   }

   public String getSuccessEffect() {
      return this.eff_suc_value;
   }

   public void setSuccessEffect(String var1) {
      this.eff_suc_value = var1;
   }

   public boolean useSound() {
      return this.sound_use;
   }

   public void setUseSound(boolean var1) {
      this.sound_use = var1;
   }

   public Sound getDestroySound() {
      return this.sound_de_value;
   }

   public void setDestroySound(Sound var1) {
      this.sound_de_value = var1;
   }

   public Sound getSuccessSound() {
      return this.sound_suc_value;
   }

   public void setSuccessSound(Sound var1) {
      this.sound_suc_value = var1;
   }

   public String getHeader() {
      return this.header;
   }

   public void setHeader(String var1) {
      this.header = var1;
   }

   public String getEmptySlot() {
      return this.empty_slot;
   }

   public void setEmptySlot(String var1) {
      this.empty_slot = var1;
   }

   public String getFilledSlot() {
      return this.filled_slot;
   }

   public void setFilledSlot(String var1) {
      this.filled_slot = var1;
   }
}
