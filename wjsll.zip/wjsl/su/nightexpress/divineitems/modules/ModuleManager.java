package su.nightexpress.divineitems.modules;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import su.nightexpress.divineitems.DivineItems;
import su.nightexpress.divineitems.Module;
import su.nightexpress.divineitems.modules.ability.AbilityManager;
import su.nightexpress.divineitems.modules.abyssdust.AbyssDustManager;
import su.nightexpress.divineitems.modules.arrows.ArrowManager;
import su.nightexpress.divineitems.modules.buffs.BuffManager;
import su.nightexpress.divineitems.modules.combatlog.CombatLogManager;
import su.nightexpress.divineitems.modules.consumes.ConsumeManager;
import su.nightexpress.divineitems.modules.customitems.CustomItemsManager;
import su.nightexpress.divineitems.modules.drops.DropManager;
import su.nightexpress.divineitems.modules.enchant.EnchantManager;
import su.nightexpress.divineitems.modules.gems.GemManager;
import su.nightexpress.divineitems.modules.identify.IdentifyManager;
import su.nightexpress.divineitems.modules.itemhints.ItemHintsManager;
import su.nightexpress.divineitems.modules.magicdust.MagicDustManager;
import su.nightexpress.divineitems.modules.notifications.NotificationsManager;
import su.nightexpress.divineitems.modules.repair.RepairManager;
import su.nightexpress.divineitems.modules.resolve.ResolveManager;
import su.nightexpress.divineitems.modules.runes.RuneManager;
import su.nightexpress.divineitems.modules.scrolls.ScrollManager;
import su.nightexpress.divineitems.modules.sets.SetManager;
import su.nightexpress.divineitems.modules.soulbound.SoulboundManager;
import su.nightexpress.divineitems.modules.tiers.TierManager;

public class ModuleManager {
   private DivineItems plugin;
   private List<Module> modules;
   private GemManager gems;
   private EnchantManager enchants;
   private RuneManager runes;
   private AbilityManager abilities;
   private RepairManager repair;
   private IdentifyManager iden;
   private ScrollManager scrolls;
   private ItemHintsManager ihm;
   private CustomItemsManager ci;
   private ResolveManager resolve;
   private TierManager tiers;
   private AbyssDustManager agem;
   private MagicDustManager dust;
   private ConsumeManager cons;
   private SoulboundManager soul;
   private NotificationsManager note;
   private BuffManager buffs;
   private DropManager drop;
   private CombatLogManager combat;
   private SetManager sets;
   private ArrowManager arrows;

   public ModuleManager(DivineItems var1) {
      this.plugin = var1;
      this.modules = new ArrayList();
   }

   public void initialize() {
      this.gems = new GemManager(this.plugin);
      this.enchants = new EnchantManager(this.plugin);
      this.runes = new RuneManager(this.plugin);
      this.abilities = new AbilityManager(this.plugin);
      this.scrolls = new ScrollManager(this.plugin);
      this.repair = new RepairManager(this.plugin);
      this.iden = new IdentifyManager(this.plugin);
      this.ihm = new ItemHintsManager(this.plugin);
      this.ci = new CustomItemsManager(this.plugin);
      this.resolve = new ResolveManager(this.plugin);
      this.tiers = new TierManager(this.plugin);
      this.agem = new AbyssDustManager(this.plugin);
      this.dust = new MagicDustManager(this.plugin);
      this.cons = new ConsumeManager(this.plugin);
      this.soul = new SoulboundManager(this.plugin);
      this.note = new NotificationsManager(this.plugin);
      this.buffs = new BuffManager(this.plugin);
      this.drop = new DropManager(this.plugin);
      this.combat = new CombatLogManager(this.plugin);
      this.sets = new SetManager(this.plugin);
      this.arrows = new ArrowManager(this.plugin);
      this.register(this.gems);
      this.register(this.enchants);
      this.register(this.runes);
      this.register(this.abilities);
      this.register(this.scrolls);
      this.register(this.repair);
      this.register(this.iden);
      this.register(this.ci);
      this.register(this.tiers);
      this.register(this.agem);
      this.register(this.dust);
      this.register(this.cons);
      this.register(this.soul);
      this.register(this.note);
      this.register(this.buffs);
      this.register(this.drop);
      this.register(this.combat);
      this.register(this.sets);
      this.register(this.arrows);
      this.register(this.resolve);
      this.register(this.ihm);
      this.sendStatus();
   }

   public void sendStatus() {
      this.plugin.getServer().getConsoleSender().sendMessage("§6---------[ §eModules Initializing §6]---------");
      Iterator var2 = this.modules.iterator();

      while(var2.hasNext()) {
         Module var1 = (Module)var2.next();
         this.plugin.getServer().getConsoleSender().sendMessage("§7> §f" + var1.name() + "§7 v" + var1.version() + ": " + this.getColorStatus(var1.isActive()));
      }

   }

   public void disable() {
      Module var1;
      for(Iterator var2 = this.modules.iterator(); var2.hasNext(); var1 = null) {
         var1 = (Module)var2.next();
         var1.unload();
      }

      this.modules.clear();
   }

   public void cfgrel() {
      Iterator var2 = this.modules.iterator();

      while(var2.hasNext()) {
         Module var1 = (Module)var2.next();
         var1.loadConfig();
      }

   }

   public void register(Module var1) {
      var1.enable();
      this.modules.add(var1);
   }

   public <T extends Module> T getModule(Class<T> var1) {
      Iterator var3 = this.modules.iterator();

      while(var3.hasNext()) {
         Module var2 = (Module)var3.next();
         if (var1.isAssignableFrom(var2.getClass())) {
            return var2;
         }
      }

      return null;
   }

   public List<Module> getModules() {
      return this.modules;
   }

   public List<String> getModuleLabels() {
      ArrayList var1 = new ArrayList();
      Iterator var3 = this.getModules().iterator();

      while(var3.hasNext()) {
         Module var2 = (Module)var3.next();
         if (var2.isActive()) {
            String var4 = var2.name().toLowerCase().replace(" ", "_");
            String var5 = var4.replace("_", "");
            var1.add(var5);
         }
      }

      return var1;
   }

   public String getColorStatus(boolean var1) {
      return var1 ? "§aOK!" : "§cOFF";
   }

   public GemManager getGemManager() {
      return this.gems;
   }

   public EnchantManager getEnchantManager() {
      return this.enchants;
   }

   public RuneManager getRuneManager() {
      return this.runes;
   }

   public AbilityManager getAbilityManager() {
      return this.abilities;
   }

   public RepairManager getRepairManager() {
      return this.repair;
   }

   public IdentifyManager getIdentifyManager() {
      return this.iden;
   }

   public ScrollManager getScrollManager() {
      return this.scrolls;
   }

   public ItemHintsManager getItemHintsManager() {
      return this.ihm;
   }

   public CustomItemsManager getCustomItemsManager() {
      return this.ci;
   }

   public ResolveManager getResolveManager() {
      return this.resolve;
   }

   public TierManager getTierManager() {
      return this.tiers;
   }

   public AbyssDustManager getAbyssDustManager() {
      return this.agem;
   }

   public MagicDustManager getMagicDustManager() {
      return this.dust;
   }

   public SoulboundManager getSoulboundManager() {
      return this.soul;
   }

   public NotificationsManager getNotificationsManager() {
      return this.note;
   }

   public BuffManager getBuffManager() {
      return this.buffs;
   }

   public DropManager getDropManager() {
      return this.drop;
   }

   public CombatLogManager getCombatLogManager() {
      return this.combat;
   }

   public SetManager getSetManager() {
      return this.sets;
   }

   public ArrowManager getArrowManager() {
      return this.arrows;
   }

   public ConsumeManager getConsumeManager() {
      return this.cons;
   }
}
