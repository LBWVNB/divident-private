package su.nightexpress.divineitems.modules.ability;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import org.apache.commons.lang.ArrayUtils;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.block.Action;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import su.nightexpress.divineitems.DivineItems;
import su.nightexpress.divineitems.DivineListener;
import su.nightexpress.divineitems.Module;
import su.nightexpress.divineitems.api.DivineItemsAPI;
import su.nightexpress.divineitems.api.ItemAPI;
import su.nightexpress.divineitems.cmds.list.AbilitiesCommand;
import su.nightexpress.divineitems.config.Lang;
import su.nightexpress.divineitems.config.MyConfig;
import su.nightexpress.divineitems.gui.ContentType;
import su.nightexpress.divineitems.gui.GUI;
import su.nightexpress.divineitems.gui.GUIItem;
import su.nightexpress.divineitems.gui.GUIType;
import su.nightexpress.divineitems.modules.MainSettings;
import su.nightexpress.divineitems.nbt.NBTItem;
import su.nightexpress.divineitems.types.DestroyType;
import su.nightexpress.divineitems.types.SlotType;
import su.nightexpress.divineitems.utils.ErrorLog;
import su.nightexpress.divineitems.utils.ItemUtils;
import su.nightexpress.divineitems.utils.Utils;

public class AbilityManager extends DivineListener<DivineItems> implements Module {
   private DivineItems plugin;
   private boolean e;
   private MyConfig settingsCfg;
   private MyConfig absCfg;
   private HashMap<String, AbilityManager.Ability> abs;
   private HashMap<Player, List<AbilityManager.AbilityCooldown>> cds;
   private AbilityManager.AbilitySettings as;
   private Random r;
   private final String n = this.name().toLowerCase().replace(" ", "_");
   private final String label;
   private final String NBT_KEY_ABS;
   private final String NBT_KEY_ITEM_ABS;
   // $FF: synthetic field
   private static int[] $SWITCH_TABLE$su$nightexpress$divineitems$types$DestroyType;

   public AbilityManager(DivineItems var1) {
      super(var1);
      this.label = this.n.replace("_", "");
      this.NBT_KEY_ABS = "DIVINE_ABILITY_ID";
      this.NBT_KEY_ITEM_ABS = "ABILITY_";
      this.plugin = var1;
      this.e = this.plugin.getCM().getCFG().isModuleEnabled(this.name());
      this.r = new Random();
   }

   public void loadConfig() {
      this.abs = new HashMap();
      this.cds = new HashMap();
      this.settingsCfg = new MyConfig(this.plugin, "/modules/" + this.n, "settings.yml");
      this.absCfg = new MyConfig(this.plugin, "/modules/" + this.n, "abilities.yml");
      this.setupSettings();
      this.setupSlot();
      this.setupAbilities();
   }

   public boolean isActive() {
      return this.e;
   }

   public boolean isDropable() {
      return true;
   }

   public boolean isResolvable() {
      return true;
   }

   public String name() {
      return "Abilities";
   }

   public String version() {
      return "1.0";
   }

   public void enable() {
      if (this.isActive()) {
         this.plugin.getCommander().registerCmd(this.label, new AbilitiesCommand(this.plugin));
         this.loadConfig();
         this.registerListeners();
      }

   }

   public void unload() {
      if (this.isActive()) {
         this.plugin.getCommander().unregisterCmd(this.label);
         this.abs.clear();
         this.cds.clear();
         this.as = null;
         this.e = false;
         this.unregisterListeners();
      }

   }

   public void reload() {
      this.unload();
      this.enable();
   }

   private void setupSlot() {
      SlotType var1 = SlotType.ABILITY;
      var1.setModule(this);
      var1.setHeader(this.getSettings().getHeader());
      var1.setEmpty(this.getSettings().getEmptySlot());
      var1.setFilled(this.getSettings().getFilledSlot());
   }

   private void setupSettings() {
      FileConfiguration var1 = this.settingsCfg.getConfig();
      String var2 = "Item.";
      String var3 = ChatColor.translateAlternateColorCodes('&', var1.getString(var2 + "Display"));
      List var4 = var1.getStringList(var2 + "Lore");
      var2 = "Enchant.";
      int var5 = var1.getInt(var2 + "MinSuccessChance");
      int var6 = var1.getInt(var2 + "MaxSuccessChance");
      DestroyType var7 = DestroyType.CLEAR;

      try {
         var7 = DestroyType.valueOf(var1.getString(var2 + "DestroyType"));
      } catch (IllegalArgumentException var23) {
         ErrorLog.sendError(this, var2 + "DestroyType", "Invalid Destroy Type!", true);
         var1.set(var2 + "DestroyType", "CLEAR");
      }

      var2 = "Effects.";
      boolean var8 = var1.getBoolean(var2 + "Enabled");
      String var9 = var1.getString(var2 + "Failure");
      String var10 = var1.getString(var2 + "Success");
      var2 = "Sounds.";
      boolean var11 = var1.getBoolean(var2 + "Enabled");
      Sound var12 = Sound.BLOCK_ANVIL_BREAK;

      try {
         var12 = Sound.valueOf(var1.getString(var2 + "Failure"));
      } catch (IllegalArgumentException var22) {
         ErrorLog.sendError(this, var2 + "Failure", "Invalid Sound Type!", true);
         var1.set(var2 + "Failure", "BLOCK_ANVIL_BREAK");
      }

      Sound var13 = Sound.ENTITY_EXPERIENCE_ORB_PICKUP;

      try {
         var13 = Sound.valueOf(var1.getString(var2 + "Success"));
      } catch (IllegalArgumentException var21) {
         ErrorLog.sendError(this, var2 + "Success", "Invalid Sound Type!", true);
         var1.set(var2 + "Success", "ENTITY_EXPERIENCE_ORB_PICKUP");
      }

      var2 = "Design.";
      String var14 = ChatColor.translateAlternateColorCodes('&', var1.getString(var2 + "Header"));
      String var15 = ChatColor.translateAlternateColorCodes('&', var1.getString(var2 + "EmptySlot"));
      String var16 = ChatColor.translateAlternateColorCodes('&', var1.getString(var2 + "FilledSlot"));
      String var17 = ChatColor.translateAlternateColorCodes('&', var1.getString(var2 + "RightClick"));
      String var18 = ChatColor.translateAlternateColorCodes('&', var1.getString(var2 + "LeftClick"));
      String var19 = ChatColor.translateAlternateColorCodes('&', var1.getString(var2 + "Shift"));
      String var20 = ChatColor.translateAlternateColorCodes('&', var1.getString(var2 + "Cooldown"));
      this.as = new AbilityManager.AbilitySettings(var3, var4, var5, var6, var7, var8, var9, var10, var11, var12, var13, var14, var15, var16, var17, var18, var19, var20);
      this.settingsCfg.save();
   }

   private void setupAbilities() {
      FileConfiguration var1 = this.absCfg.getConfig();
      Iterator var3 = var1.getConfigurationSection("Abilities").getKeys(false).iterator();

      while(true) {
         String var4;
         String var5;
         boolean var6;
         do {
            if (!var3.hasNext()) {
               return;
            }

            String var2 = (String)var3.next();
            var4 = "Abilities." + var2 + ".";
            var5 = var2.toString().toLowerCase();
            var6 = var1.getBoolean(var4 + "Enabled");
         } while(!var6);

         String var7 = var1.getString(var4 + "Material");
         String var8 = ChatColor.translateAlternateColorCodes('&', var1.getString(var4 + "Name"));
         List var9 = var1.getStringList(var4 + "Desc");
         ArrayList var10 = new ArrayList();
         Iterator var12 = var9.iterator();

         while(var12.hasNext()) {
            String var11 = (String)var12.next();
            var10.add(ChatColor.translateAlternateColorCodes('&', var11));
         }

         HashMap var19 = new HashMap();
         Iterator var13 = var1.getConfigurationSection(var4 + "Variables").getKeys(false).iterator();

         while(var13.hasNext()) {
            String var20 = (String)var13.next();
            Object var14 = var1.get(var4 + "Variables." + var20);
            var19.put(var20, var14);
         }

         HashMap var21 = new HashMap();
         Iterator var24 = var1.getConfigurationSection(var4 + "VariablesLvl").getKeys(false).iterator();

         while(var24.hasNext()) {
            String var22 = (String)var24.next();
            Object var15 = var1.get(var4 + "VariablesLvl." + var22);
            var21.put(var22, var15);
         }

         List var23 = var1.getStringList(var4 + "Actions");
         int var25 = var1.getInt(var4 + "Cooldown");
         int var26 = var1.getInt(var4 + "CooldownLvl");
         int var16 = var1.getInt(var4 + "MinLevel");
         int var17 = var1.getInt(var4 + "MaxLevel");
         AbilityManager.Ability var18 = new AbilityManager.Ability(var6, var7, var5, var8, var10, var19, var21, var23, var25, var26, var16, var17);
         this.abs.put(var5, var18);
      }
   }

   public void setCooldown(Player var1, String var2, String var3, String var4, boolean var5, int var6) {
      AbilityManager.AbilityCooldown var7 = new AbilityManager.AbilityCooldown(var3, var2, var4, var5, System.currentTimeMillis() + (long)var6 * 1000L);
      Object var8 = (List)this.cds.get(var1);
      if (var8 == null) {
         var8 = new ArrayList();
      }

      ((List)var8).add(var7);
      this.cds.put(var1, var8);
   }

   public boolean isCooldown(Player var1, String var2, String var3, String var4, boolean var5) {
      if (!this.cds.containsKey(var1)) {
         return false;
      } else {
         List var6 = (List)this.cds.get(var1);
         ArrayList var7 = new ArrayList();
         Iterator var9 = var6.iterator();

         AbilityManager.AbilityCooldown var8;
         while(var9.hasNext()) {
            var8 = (AbilityManager.AbilityCooldown)var9.next();
            if (System.currentTimeMillis() < var8.getCd()) {
               var7.add(var8);
            }
         }

         if (var7.isEmpty()) {
            this.cds.remove(var1);
            return false;
         } else {
            this.cds.put(var1, var7);
            var9 = var7.iterator();

            do {
               if (!var9.hasNext()) {
                  return false;
               }

               var8 = (AbilityManager.AbilityCooldown)var9.next();
            } while(!var8.getAbilityType().equalsIgnoreCase(var3) || !var8.getItemName().equalsIgnoreCase(var2) || !var8.getAction().equalsIgnoreCase(var4) || var8.isShift() != var5);

            return true;
         }
      }
   }

   public int getCooldown(Player var1, String var2, String var3, String var4, boolean var5) {
      List var6 = (List)this.cds.get(var1);
      ArrayList var7 = new ArrayList();
      Iterator var9 = var6.iterator();

      AbilityManager.AbilityCooldown var8;
      while(var9.hasNext()) {
         var8 = (AbilityManager.AbilityCooldown)var9.next();
         if (System.currentTimeMillis() < var8.getCd()) {
            var7.add(var8);
         }
      }

      if (var7.isEmpty()) {
         this.cds.remove(var1);
         return 0;
      } else {
         this.cds.put(var1, var7);
         var9 = var7.iterator();

         do {
            if (!var9.hasNext()) {
               return 0;
            }

            var8 = (AbilityManager.AbilityCooldown)var9.next();
         } while(!var8.getAbilityType().equalsIgnoreCase(var3) || !var8.getItemName().equalsIgnoreCase(var2) || !var8.getAction().equalsIgnoreCase(var4) || var8.isShift() != var5);

         return Utils.transSec(var8.getCd());
      }
   }

   public AbilityManager.AbilitySettings getSettings() {
      return this.as;
   }

   public Collection<AbilityManager.Ability> getAbilities() {
      return this.abs.values();
   }

   public List<String> getAbilityNames() {
      ArrayList var1 = new ArrayList();
      Iterator var3 = this.getAbilities().iterator();

      while(var3.hasNext()) {
         AbilityManager.Ability var2 = (AbilityManager.Ability)var3.next();
         var1.add(var2.getIdName());
      }

      return var1;
   }

   public AbilityManager.Ability getAbilityById(String var1) {
      return var1.equalsIgnoreCase("random") ? (AbilityManager.Ability)(new ArrayList(this.getAbilities())).get(this.r.nextInt(this.getAbilities().size())) : (AbilityManager.Ability)this.abs.get(var1.toLowerCase());
   }

   public boolean hasAbility(ItemStack var1, String var2) {
      NBTItem var3 = new NBTItem(var1);
      Iterator var5 = var3.getKeys().iterator();

      while(var5.hasNext()) {
         String var4 = (String)var5.next();
         if (var4.startsWith("ABILITY_")) {
            String[] var6 = var3.getString(var4).split(":");
            if (var6[0].equalsIgnoreCase(var2)) {
               return true;
            }
         }
      }

      return false;
   }

   public int getItemAbilityLevel(ItemStack var1, String var2) {
      NBTItem var3 = new NBTItem(var1);
      Iterator var5 = var3.getKeys().iterator();

      while(var5.hasNext()) {
         String var4 = (String)var5.next();
         if (var4.startsWith("ABILITY_")) {
            String[] var6 = var3.getString(var4).split(":");
            if (var6[0].equalsIgnoreCase(var2)) {
               return Integer.parseInt(var6[1]);
            }
         }
      }

      return 0;
   }

   public int getItemAbsAmount(ItemStack var1) {
      NBTItem var2 = new NBTItem(var1);
      int var3 = 0;
      Iterator var5 = var2.getKeys().iterator();

      while(var5.hasNext()) {
         String var4 = (String)var5.next();
         if (var4.startsWith("ABILITY_")) {
            ++var3;
         }
      }

      return var3;
   }

   public ItemStack removeAbility(ItemStack var1, int var2) {
      NBTItem var3 = new NBTItem(var1);
      int var4 = this.getItemAbsAmount(var1);
      int var5 = var2 - 1;
      int var6 = var4 - var5;
      int var7 = var6 - 1;
      var3.removeKey("ABILITY_" + var7);
      var1 = new ItemStack(var3.getItem());
      ItemMeta var8 = var1.getItemMeta();
      ArrayList var9 = new ArrayList(var8.getLore());
      int var10 = 0;
      int var11 = 0;

      for(Iterator var13 = var8.getLore().iterator(); var13.hasNext(); ++var11) {
         String var12 = (String)var13.next();
         if (var12.startsWith(this.getSettings().getFilledSlot())) {
            ++var10;
         }

         if (var10 == var6) {
            var9.remove(var11);
            var9.add(var11, this.as.getEmptySlot());
            break;
         }
      }

      var8.setLore(var9);
      var1.setItemMeta(var8);
      return var1;
   }

   private void openGUI(Player var1, ItemStack var2, ItemStack var3) {
      GUI var4 = new GUI(this.plugin.getGUIManager().getGUIByType(GUIType.ENCHANT_ABILITY));
      ((GUIItem)var4.getItems().get(ContentType.TARGET)).setItem(var2);
      ((GUIItem)var4.getItems().get(ContentType.SOURCE)).setItem(var3);
      ((GUIItem)var4.getItems().get(ContentType.RESULT)).setItem(this.getResult(new ItemStack(var2), new ItemStack(var3)));
      this.plugin.getGUIManager().setGUI(var1, var4);
      var1.openInventory(var4.build());
   }

   private ItemStack insertAbility(ItemStack var1, ItemStack var2) {
      boolean var3 = false;
      List var4 = var1.getItemMeta().getLore();
      NBTItem var5 = new NBTItem(var2);
      String[] var6 = var5.getString("DIVINE_ABILITY_ID").split(":");
      String var7 = var6[0];
      int var8 = Integer.parseInt(var6[1]);
      int var9 = Integer.parseInt(var6[2]);
      String var10 = var6[3];
      String var11 = var6[4];
      String var12 = this.getSettings().getLeftClick();
      if (var10.equalsIgnoreCase("right")) {
         var12 = this.getSettings().getRightClick();
      }

      String var13 = "";
      if (Boolean.valueOf(var11)) {
         var13 = this.getSettings().getShiftClick() + " ";
      }

      AbilityManager.Ability var14 = this.getAbilityById(var7);
      String var15 = var14.getName().replace("%rlevel%", "").replace("%level%", "").trim();
      String var16 = var14.getName();
      String var17;
      Iterator var18;
      int var21;
      if (this.hasAbility(var1, var7)) {
         var18 = var4.iterator();

         while(var18.hasNext()) {
            var17 = (String)var18.next();
            if (var17.contains(var15)) {
               var21 = var4.indexOf(var17);
               var4.remove(var21);
               var4.add(var21, this.getSettings().getFilledSlot() + var16.replace("%level%", String.valueOf(var8)).replace("%rlevel%", Utils.IntegerToRomanNumeral(var8)) + " " + var13 + var12 + " " + this.getSettings().getCD().replace("%s", "" + var9));
               break;
            }
         }
      } else {
         var18 = var4.iterator();

         while(var18.hasNext()) {
            var17 = (String)var18.next();
            String var19 = ChatColor.stripColor(var17);
            String var20 = ChatColor.stripColor(this.getSettings().getEmptySlot());
            if (var19.contains(var20)) {
               var21 = var4.indexOf(var17);
               var4.remove(var21);
               var4.add(var21, this.getSettings().getFilledSlot() + var16.replace("%level%", String.valueOf(var8)).replace("%rlevel%", Utils.IntegerToRomanNumeral(var8)) + " " + var13 + var12 + " " + this.getSettings().getCD().replace("%s", "" + var9));
               break;
            }
         }
      }

      ItemMeta var22 = var1.getItemMeta();
      var22.setLore(var4);
      var1.setItemMeta(var22);
      NBTItem var23 = new NBTItem(var1);
      var23.setString("ABILITY_" + this.getItemAbsAmount(var1), var7 + ":" + var8 + ":" + var9 + ":" + var10.toUpperCase() + ":" + var11);
      return var23.getItem();
   }

   private ItemStack getResult(ItemStack var1, ItemStack var2) {
      ItemStack var3 = this.insertAbility(var1, var2);
      ItemMeta var4 = var3.getItemMeta();
      var4.setDisplayName(Lang.Abilities_Enchanting_Result.toMsg());
      var3.setItemMeta(var4);
      return new ItemStack(var3);
   }

   public void useAbility(Player var1, ItemStack var2, Action var3, boolean var4, EquipmentSlot var5) {
      NBTItem var6 = new NBTItem(var2);
      Iterator var8 = var6.getKeys().iterator();

      while(true) {
         while(true) {
            String var7;
            String[] var9;
            String var10;
            String var11;
            boolean var12;
            do {
               do {
                  do {
                     if (!var8.hasNext()) {
                        return;
                     }

                     var7 = (String)var8.next();
                  } while(!var7.startsWith("ABILITY_"));

                  var9 = var6.getString(var7).split(":");
                  var10 = var9[0];
                  var11 = var9[3];
                  var12 = Boolean.valueOf(var9[4]);
               } while(!var3.name().contains(var11));
            } while(var4 != var12);

            String var13 = this.plugin.getCM().getDefaultItemName(var2);
            if (var2.hasItemMeta() && var2.getItemMeta().hasDisplayName()) {
               var13 = var2.getItemMeta().getDisplayName();
            }

            if (this.isCooldown(var1, var13, var7, var11, var12)) {
               this.plugin.getNMS().sendActionBar(var1, Lang.Abilities_Cooldown.toMsg().replace("%s", "" + this.getCooldown(var1, var13, var7, var11, var12)));
            } else {
               AbilityManager.Ability var14 = this.getAbilityById(var10);
               if (var14 != null) {
                  AbilityManager.Ability var15 = new AbilityManager.Ability(var14);
                  int var16 = Integer.parseInt(var9[1]);
                  ArrayList var17 = new ArrayList(var15.getActions());
                  ArrayList var18 = new ArrayList();
                  Iterator var20 = var17.iterator();

                  while(var20.hasNext()) {
                     String var19 = (String)var20.next();

                     String var21;
                     String var24;
                     for(Iterator var22 = var15.getVariables().keySet().iterator(); var22.hasNext(); var19 = var19.replace("%var_" + var21 + "%", var24)) {
                        var21 = (String)var22.next();
                        Object var23 = var15.getVariables().get(var21);
                        var24 = var23.toString();
                        if (var15.getVariablesLvl().containsKey(var21)) {
                           if (var23 instanceof Double) {
                              double var25 = Double.parseDouble(var23.toString());
                              var25 += (double)(var16 - 1) * Double.parseDouble(var15.getVariablesLvl().get(var21).toString());
                              var24 = String.valueOf(Utils.round3(var25));
                           } else if (var23 instanceof Integer) {
                              int var28 = Integer.parseInt(var23.toString());
                              var28 += (var16 - 1) * Integer.parseInt(var15.getVariablesLvl().get(var21).toString());
                              var24 = String.valueOf(var28);
                           } else {
                              var24 = var15.getVariablesLvl().get(var21).toString();
                           }
                        }
                     }

                     var18.add(var19);
                  }

                  var15.setActions(var18);
                  if (ItemAPI.getDurability(var2, 0) > 0) {
                     var2 = ItemAPI.setFinalDurability(var2, var1, 1);
                  }

                  DivineItemsAPI.executeActions(var1, var15.getActions(), var2);
                  int var27 = Integer.parseInt(var9[2]);
                  this.setCooldown(var1, var13, var7, var11, var12, var27);
               }
            }
         }
      }
   }

   public boolean isAbility(ItemStack var1) {
      return (new NBTItem(var1)).hasKey("DIVINE_ABILITY_ID");
   }

   public String getAbilityId(ItemStack var1) {
      NBTItem var2 = new NBTItem(var1);
      String[] var3 = var2.getString("DIVINE_ABILITY_ID").split(":");
      return var3[0];
   }

   public int getAbilityLevel(ItemStack var1) {
      NBTItem var2 = new NBTItem(var1);
      String[] var3 = var2.getString("DIVINE_ABILITY_ID").split(":");
      return Integer.parseInt(var3[1]);
   }

   @EventHandler
   public void onClickGUI(InventoryClickEvent var1) {
      Player var2 = (Player)var1.getWhoClicked();
      if (this.plugin.getGUIManager().valid(var2, GUIType.ENCHANT_ABILITY)) {
         GUI var3 = this.plugin.getGUIManager().getPlayerGUI(var2, GUIType.ENCHANT_ABILITY);
         if (var3 != null && var1.getInventory().getTitle().equals(var3.getTitle())) {
            var1.setCancelled(true);
            ItemStack var4 = var1.getCurrentItem();
            if (var4 != null && var4.hasItemMeta()) {
               GUIItem var5 = (GUIItem)var3.getItems().get(ContentType.ACCEPT);
               int var6 = var1.getRawSlot();
               if (var4.isSimilar(var5.getItem()) || ArrayUtils.contains(var5.getSlots(), var6)) {
                  ItemStack var7 = new ItemStack(((GUIItem)var3.getItems().get(ContentType.TARGET)).getItem());
                  ItemStack var8 = new ItemStack(((GUIItem)var3.getItems().get(ContentType.SOURCE)).getItem());
                  if (!var2.getInventory().contains(var7)) {
                     var2.sendMessage(Lang.Prefix.toMsg() + Lang.Abilities_Enchanting_NoItem.toMsg());
                     return;
                  }

                  int var9 = this.r.nextInt(100);
                  NBTItem var10 = new NBTItem(var8);
                  int var11 = var10.getInteger("DIVINE_CHANCE");
                  AbilityManager.AbilitySettings var12 = this.getSettings();
                  if (var11 < var9) {
                     DestroyType var20 = var12.getDestroyType();
                     switch($SWITCH_TABLE$su$nightexpress$divineitems$types$DestroyType()[var20.ordinal()]) {
                     case 1:
                        var2.getInventory().removeItem(new ItemStack[]{var7});
                        var2.sendMessage(Lang.Prefix.toMsg() + Lang.Abilities_Enchanting_Failure_Item.toMsg());
                        break;
                     case 2:
                        var2.getInventory().removeItem(new ItemStack[]{var8});
                        var8.setAmount(var8.getAmount() - 1);
                        var2.getInventory().addItem(new ItemStack[]{var8});
                        var2.sendMessage(Lang.Prefix.toMsg() + Lang.Abilities_Enchanting_Failure_Source.toMsg());
                        break;
                     case 3:
                        var2.getInventory().removeItem(new ItemStack[]{var7});
                        var2.getInventory().removeItem(new ItemStack[]{var8});
                        var8.setAmount(var8.getAmount() - 1);
                        var2.getInventory().addItem(new ItemStack[]{var8});
                        ItemMeta var14 = var7.getItemMeta();
                        ArrayList var15 = new ArrayList();
                        Iterator var17 = var14.getLore().iterator();

                        while(var17.hasNext()) {
                           String var16 = (String)var17.next();
                           if (var16.startsWith(var12.getFilledSlot())) {
                              var15.add(var12.getEmptySlot());
                           } else {
                              var15.add(var16);
                           }
                        }

                        var14.setLore(var15);
                        var7.setItemMeta(var14);
                        NBTItem var21 = new NBTItem(var7);
                        Iterator var18 = var21.getKeys().iterator();

                        while(var18.hasNext()) {
                           String var22 = (String)var18.next();
                           if (var22.startsWith("ABILITY_")) {
                              var21.removeKey(var22);
                           }
                        }

                        var2.getInventory().addItem(new ItemStack[]{var21.getItem()});
                        var2.sendMessage(Lang.Prefix.toMsg() + Lang.Abilities_Enchanting_Failure_Clear.toMsg());
                        break;
                     case 4:
                        var2.getInventory().removeItem(new ItemStack[]{var7});
                        var2.getInventory().removeItem(new ItemStack[]{var8});
                        var8.setAmount(var8.getAmount() - 1);
                        var2.getInventory().addItem(new ItemStack[]{var8});
                        var2.sendMessage(Lang.Prefix.toMsg() + Lang.Abilities_Enchanting_Failure_Both.toMsg());
                     }

                     var2.closeInventory();
                     this.plugin.getGUIManager().reset(var2);
                     if (var12.useSound()) {
                        var2.playSound(var2.getLocation(), var12.getDestroySound(), 0.5F, 0.5F);
                     }

                     if (var12.useEffect()) {
                        Utils.playEffect(var12.getDestroyEffect(), 0.30000001192092896D, 0.0D, 0.30000001192092896D, 0.30000001192092896D, 15, var2.getLocation().add(0.0D, 0.5D, 0.0D));
                     }

                     return;
                  }

                  var2.getInventory().removeItem(new ItemStack[]{var7});
                  ItemStack var13 = this.insertAbility(var7, var8);
                  var2.getInventory().addItem(new ItemStack[]{var13});
                  var2.getInventory().removeItem(new ItemStack[]{var8});
                  var8.setAmount(var8.getAmount() - 1);
                  var2.getInventory().addItem(new ItemStack[]{var8});
                  var2.sendMessage(Lang.Prefix.toMsg() + Lang.Abilities_Enchanting_Success.toMsg());
                  var2.closeInventory();
                  this.plugin.getGUIManager().reset(var2);
                  if (var12.useSound()) {
                     var2.playSound(var2.getLocation(), var12.getSuccessSound(), 0.5F, 0.5F);
                  }

                  if (var12.useEffect()) {
                     Utils.playEffect(var12.getSuccessEffect(), 0.30000001192092896D, 0.0D, 0.30000001192092896D, 0.30000001192092896D, 15, var2.getLocation().add(0.0D, 0.5D, 0.0D));
                  }

                  var2.updateInventory();
               }

               GUIItem var19 = (GUIItem)var3.getItems().get(ContentType.DECLINE);
               if (var4.isSimilar(var19.getItem()) || ArrayUtils.contains(var19.getSlots(), var6)) {
                  var2.sendMessage(Lang.Prefix.toMsg() + Lang.Abilities_Enchanting_Cancel.toMsg());
                  var2.closeInventory();
                  var2.updateInventory();
                  this.plugin.getGUIManager().reset(var2);
               }

            }
         }
      }
   }

   @EventHandler
   public void onInteract(PlayerInteractEvent var1) {
      Player var2 = var1.getPlayer();
      ItemStack var3 = var1.getItem();
      if (var3 != null && var3.hasItemMeta() && var3.getItemMeta().hasLore()) {
         this.useAbility(var2, var3, var1.getAction(), var2.isSneaking(), var1.getHand());
      }
   }

   @EventHandler
   public void onClickInventory(InventoryClickEvent var1) {
      if (var1.getWhoClicked() instanceof Player) {
         Player var2 = (Player)var1.getWhoClicked();
         ItemStack var3 = var1.getCursor();
         ItemStack var4 = var1.getCurrentItem();
         if (var3 != null && var4 != null) {
            if (var1.getInventory().getType() == InventoryType.CRAFTING) {
               if (var1.getSlotType() != org.bukkit.event.inventory.InventoryType.SlotType.CRAFTING) {
                  if (var1.getSlotType() != org.bukkit.event.inventory.InventoryType.SlotType.ARMOR && var1.getSlot() != 40) {
                     if (var3.hasItemMeta() && var3.getItemMeta().hasLore()) {
                        if (var4.hasItemMeta() && var4.getItemMeta().hasLore()) {
                           NBTItem var5 = new NBTItem(var3);
                           if (var5.hasKey("DIVINE_ABILITY_ID")) {
                              String[] var6 = var5.getString("DIVINE_ABILITY_ID").split(":");
                              String var7 = var6[0];
                              AbilityManager.Ability var8 = this.getAbilityById(var7);
                              if (var8 == null) {
                                 var2.sendMessage(Lang.Prefix.toMsg() + Lang.Other_Internal.toMsg());
                              } else if (!ItemUtils.isWeapon(var4)) {
                                 var2.sendMessage(Lang.Prefix.toMsg() + Lang.Abilities_Enchanting_InvalidType.toMsg());
                              } else if (var2.getInventory().firstEmpty() == -1) {
                                 var2.sendMessage(Lang.Prefix.toMsg() + Lang.Abilities_Enchanting_FullInventory.toMsg());
                              } else {
                                 int var9 = Integer.parseInt(var6[1]);
                                 if (this.hasAbility(var4, var7) && this.getItemAbilityLevel(var4, var7) >= var9) {
                                    var2.sendMessage(Lang.Prefix.toMsg() + Lang.Abilities_Enchanting_AlreadyHave.toMsg());
                                 } else {
                                    String var10 = var8.getName().replace("%level%", "").trim();
                                    Iterator var12 = var4.getItemMeta().getLore().iterator();

                                    String var13;
                                    String var14;
                                    do {
                                       if (!var12.hasNext()) {
                                          var2.sendMessage(Lang.Prefix.toMsg() + Lang.Abilities_Enchanting_NoSlots.toMsg());
                                          return;
                                       }

                                       String var11 = (String)var12.next();
                                       var13 = ChatColor.stripColor(var11);
                                       var14 = ChatColor.stripColor(this.getSettings().getEmptySlot());
                                    } while(!var13.contains(var14) && !var13.contains(var10));

                                    var2.getInventory().addItem(new ItemStack[]{var3});
                                    var1.setCursor((ItemStack)null);
                                    var1.setCancelled(true);
                                    this.openGUI(var2, var4, var3);
                                 }
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
      }
   }

   // $FF: synthetic method
   static int[] $SWITCH_TABLE$su$nightexpress$divineitems$types$DestroyType() {
      int[] var10000 = $SWITCH_TABLE$su$nightexpress$divineitems$types$DestroyType;
      if (var10000 != null) {
         return var10000;
      } else {
         int[] var0 = new int[DestroyType.values().length];

         try {
            var0[DestroyType.BOTH.ordinal()] = 4;
         } catch (NoSuchFieldError var4) {
         }

         try {
            var0[DestroyType.CLEAR.ordinal()] = 3;
         } catch (NoSuchFieldError var3) {
         }

         try {
            var0[DestroyType.ITEM.ordinal()] = 1;
         } catch (NoSuchFieldError var2) {
         }

         try {
            var0[DestroyType.SOURCE.ordinal()] = 2;
         } catch (NoSuchFieldError var1) {
         }

         $SWITCH_TABLE$su$nightexpress$divineitems$types$DestroyType = var0;
         return var0;
      }
   }

   public class Ability {
      private boolean enabled;
      private String material;
      private String name;
      private String display;
      private List<String> desc;
      private HashMap<String, Object> vars;
      private HashMap<String, Object> vars_lvl;
      private List<String> actions;
      private int cd;
      private int cd_lvl;
      private int min_lvl;
      private int max_lvl;

      public Ability(boolean var2, String var3, String var4, String var5, List<String> var6, HashMap<String, Object> var7, HashMap<String, Object> var8, List<String> var9, int var10, int var11, int var12, int var13) {
         this.setEnabled(var2);
         this.setMaterial(var3);
         this.setIdName(var4);
         this.setName(var5);
         this.setDesc(var6);
         this.setVariables(var7);
         this.setVariablesLvl(var8);
         this.setActions(var9);
         this.setCooldown(var10);
         this.setCooldownLvl(var11);
         this.setMinLevel(var12);
         this.setMaxLevel(var13);
      }

      public Ability(AbilityManager.Ability var2) {
         this.setEnabled(var2.isEnabled());
         this.setMaterial(var2.getMaterial());
         this.setIdName(var2.getIdName());
         this.setName(var2.getName());
         this.setDesc(var2.getDesc());
         this.setVariables(new HashMap(var2.getVariables()));
         this.setVariablesLvl(new HashMap(var2.getVariablesLvl()));
         this.setActions(new ArrayList(var2.getActions()));
         this.setCooldown(var2.getCooldown());
         this.setCooldownLvl(var2.getCooldownLvl());
         this.setMinLevel(var2.getMinLevel());
         this.setMaxLevel(var2.getMaxLevel());
      }

      public boolean isEnabled() {
         return this.enabled;
      }

      public void setEnabled(boolean var1) {
         this.enabled = var1;
      }

      public String getIdName() {
         return this.name;
      }

      public void setIdName(String var1) {
         this.name = var1;
      }

      public String getMaterial() {
         return this.material;
      }

      public void setMaterial(String var1) {
         this.material = var1;
      }

      public String getName() {
         return this.display;
      }

      public void setName(String var1) {
         this.display = var1;
      }

      public List<String> getDesc() {
         return this.desc;
      }

      public void setDesc(List<String> var1) {
         this.desc = var1;
      }

      public HashMap<String, Object> getVariables() {
         return this.vars;
      }

      public void setVariables(HashMap<String, Object> var1) {
         this.vars = var1;
      }

      public HashMap<String, Object> getVariablesLvl() {
         return this.vars_lvl;
      }

      public void setVariablesLvl(HashMap<String, Object> var1) {
         this.vars_lvl = var1;
      }

      public List<String> getActions() {
         return this.actions;
      }

      public void setActions(List<String> var1) {
         this.actions = var1;
      }

      public int getCooldown() {
         return this.cd;
      }

      public void setCooldown(int var1) {
         this.cd = var1;
      }

      public int getCooldownLvl() {
         return this.cd_lvl;
      }

      public void setCooldownLvl(int var1) {
         this.cd_lvl = var1;
      }

      public int getMaxLevel() {
         return this.max_lvl;
      }

      public void setMaxLevel(int var1) {
         this.max_lvl = var1;
      }

      public int getMinLevel() {
         return this.min_lvl;
      }

      public void setMinLevel(int var1) {
         this.min_lvl = var1;
      }

      public ItemStack create(int var1) {
         if (var1 == -1) {
            var1 = Utils.randInt(this.getMinLevel(), this.getMaxLevel());
         } else if (var1 > this.getMaxLevel()) {
            var1 = this.getMaxLevel();
         } else if (var1 < 1) {
            var1 = this.getMinLevel();
         }

         String[] var2 = this.getMaterial().split(":");
         ItemStack var3 = Utils.buildItem(var2, this.getIdName());
         ItemMeta var4 = var3.getItemMeta();
         int var5 = this.getCooldown() + this.getCooldownLvl() * (var1 - 1);
         String var6 = this.getName().replace("%level%", String.valueOf(var1)).replace("%rlevel%", Utils.IntegerToRomanNumeral(var1));
         String var7 = AbilityManager.this.getSettings().getDisplay().replace("%s", var6);
         int var8 = var1 + 1;
         int var9 = Utils.randInt(AbilityManager.this.getSettings().getMinChance(), AbilityManager.this.getSettings().getMaxChance());
         int var10 = 100 - var9;
         String var11 = "Right";
         String var12 = "false";
         if (AbilityManager.this.r.nextInt(100) < 50) {
            var11 = "Left";
         }

         if (AbilityManager.this.r.nextInt(100) < 50) {
            var12 = "true";
         }

         List var13 = AbilityManager.this.getSettings().getLore();
         ArrayList var14 = new ArrayList();
         Iterator var16 = var13.iterator();

         while(true) {
            String var17;
            Iterator var18;
            while(var16.hasNext()) {
               String var15 = (String)var16.next();
               if (var15.equals("%desc%")) {
                  var18 = this.getDesc().iterator();

                  while(var18.hasNext()) {
                     var17 = (String)var18.next();
                     var14.add(ChatColor.translateAlternateColorCodes('&', var17.replace("%shift%", Lang.getCustom("Other." + var12)).replace("%key%", Lang.getCustom("Other." + var11)).replace("%rlevel%", Utils.IntegerToRomanNumeral(var8)).replace("%level%", String.valueOf(var8))));
                  }
               } else {
                  var14.add(ChatColor.translateAlternateColorCodes('&', var15.replace("%shift%", Lang.getCustom("Other." + var12)).replace("%key%", Lang.getCustom("Other." + var11)).replace("%d%", String.valueOf(var10)).replace("%s%", String.valueOf(var9)).replace("%rlevel%", Utils.IntegerToRomanNumeral(var1)).replace("%level%", String.valueOf(var1))));
               }
            }

            ArrayList var25 = new ArrayList(var14);
            ArrayList var26 = new ArrayList();
            var18 = var25.iterator();

            while(var18.hasNext()) {
               var17 = (String)var18.next();

               String var19;
               String var22;
               for(Iterator var20 = this.getVariables().keySet().iterator(); var20.hasNext(); var17 = var17.replace("%var_" + var19 + "%", var22)) {
                  var19 = (String)var20.next();
                  Object var21 = this.getVariables().get(var19);
                  var22 = var21.toString();
                  if (this.getVariablesLvl().containsKey(var19)) {
                     if (var21 instanceof Double) {
                        double var23 = Double.parseDouble(var21.toString());
                        var23 += (double)(var1 - 1) * Double.parseDouble(this.getVariablesLvl().get(var19).toString());
                        var22 = String.valueOf(Utils.round3(var23));
                     } else if (var21 instanceof Integer) {
                        int var28 = Integer.parseInt(var21.toString());
                        var28 += (var1 - 1) * Integer.parseInt(this.getVariablesLvl().get(var19).toString());
                        var22 = String.valueOf(var28);
                     } else {
                        var22 = this.getVariablesLvl().get(var19).toString();
                     }
                  }
               }

               var26.add(ChatColor.translateAlternateColorCodes('&', var17));
            }

            var4.setDisplayName(var7);
            var4.setLore(var26);
            var4.spigot().setUnbreakable(true);
            var4.addItemFlags(ItemFlag.values());
            var3.setItemMeta(var4);
            NBTItem var27 = new NBTItem(var3);
            var27.setString("DIVINE_ABILITY_ID", this.getIdName() + ":" + var1 + ":" + var5 + ":" + var11 + ":" + var12);
            var27.setInteger("DIVINE_CHANCE", var9);
            return var27.getItem();
         }
      }
   }

   public class AbilityCooldown {
      private String type;
      private String item_name;
      private String act;
      private boolean shift;
      private long cd;

      public AbilityCooldown(String var2, String var3, String var4, boolean var5, long var6) {
         this.setAbilityType(var2);
         this.setItemName(var3);
         this.setAction(var4);
         this.setShift(var5);
         this.setCd(var6);
      }

      public String getAbilityType() {
         return this.type;
      }

      public void setAbilityType(String var1) {
         this.type = var1;
      }

      public String getItemName() {
         return this.item_name;
      }

      public void setItemName(String var1) {
         this.item_name = var1;
      }

      public String getAction() {
         return this.act;
      }

      public void setAction(String var1) {
         this.act = var1;
      }

      public boolean isShift() {
         return this.shift;
      }

      public void setShift(boolean var1) {
         this.shift = var1;
      }

      public long getCd() {
         return this.cd;
      }

      public void setCd(long var1) {
         this.cd = var1;
      }
   }

   public class AbilitySettings extends MainSettings {
      private String right;
      private String left;
      private String shift;
      private String cd;

      public AbilitySettings(String var2, List<String> var3, int var4, int var5, DestroyType var6, boolean var7, String var8, String var9, boolean var10, Sound var11, Sound var12, String var13, String var14, String var15, String var16, String var17, String var18, String var19) {
         super(var2, var3, var4, var5, var6, var7, var8, var9, var10, var11, var12, var13, var14, var15);
         this.setRightClick(var16);
         this.setLeftClick(var17);
         this.setShiftClick(var18);
         this.setCD(var19);
      }

      public String getRightClick() {
         return this.right;
      }

      public void setRightClick(String var1) {
         this.right = var1;
      }

      public String getLeftClick() {
         return this.left;
      }

      public void setLeftClick(String var1) {
         this.left = var1;
      }

      public String getShiftClick() {
         return this.shift;
      }

      public void setShiftClick(String var1) {
         this.shift = var1;
      }

      public String getCD() {
         return this.cd;
      }

      public void setCD(String var1) {
         this.cd = var1;
      }
   }
}
