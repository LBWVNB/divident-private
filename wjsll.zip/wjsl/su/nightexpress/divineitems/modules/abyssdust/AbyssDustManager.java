package su.nightexpress.divineitems.modules.abyssdust;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.inventory.InventoryType.SlotType;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import su.nightexpress.divineitems.DivineItems;
import su.nightexpress.divineitems.DivineListener;
import su.nightexpress.divineitems.Module;
import su.nightexpress.divineitems.api.ItemAPI;
import su.nightexpress.divineitems.cmds.list.AbyssDustCommand;
import su.nightexpress.divineitems.config.Lang;
import su.nightexpress.divineitems.config.MyConfig;
import su.nightexpress.divineitems.nbt.NBTItem;
import su.nightexpress.divineitems.utils.ErrorLog;
import su.nightexpress.divineitems.utils.Utils;

public class AbyssDustManager extends DivineListener<DivineItems> implements Module {
   private DivineItems plugin;
   private boolean e;
   private Random r;
   private MyConfig settingsCfg;
   private HashMap<String, AbyssDustManager.AbyssDust> dusts;
   private final String n = this.name().toLowerCase().replace(" ", "_");
   private final String label;
   private final String NBT_KEY_DUST;
   // $FF: synthetic field
   private static int[] $SWITCH_TABLE$su$nightexpress$divineitems$modules$abyssdust$AbyssDustManager$AbyssType;

   public AbyssDustManager(DivineItems var1) {
      super(var1);
      this.label = this.n.replace("_", "");
      this.NBT_KEY_DUST = "DIVINE_ADUST";
      this.plugin = var1;
      this.e = this.plugin.getCM().getCFG().isModuleEnabled(this.name());
      this.r = new Random();
   }

   public void loadConfig() {
      this.dusts = new HashMap();
      this.settingsCfg = new MyConfig(this.plugin, "/modules/" + this.n, "settings.yml");
      this.setup();
   }

   public boolean isActive() {
      return this.e;
   }

   public boolean isDropable() {
      return true;
   }

   public boolean isResolvable() {
      return true;
   }

   public String name() {
      return "Abyss Dust";
   }

   public String version() {
      return "1.0";
   }

   public void enable() {
      if (this.isActive()) {
         this.plugin.getCommander().registerCmd(this.label, new AbyssDustCommand(this.plugin));
         this.loadConfig();
         this.registerListeners();
      }

   }

   public void unload() {
      if (this.isActive()) {
         this.plugin.getCommander().unregisterCmd(this.label);
         this.dusts.clear();
         this.e = false;
         this.unregisterListeners();
      }

   }

   public void reload() {
      this.unload();
      this.enable();
   }

   public void setup() {
      FileConfiguration var1 = this.settingsCfg.getConfig();
      Iterator var3 = var1.getConfigurationSection("AbyssDusts").getKeys(false).iterator();

      while(var3.hasNext()) {
         String var2 = (String)var3.next();
         String var4 = "AbyssDusts." + var2.toString() + ".";
         String var5 = var2.toString().toLowerCase();
         String var6 = var1.getString(var4 + "Material");
         String var7 = ChatColor.translateAlternateColorCodes('&', var1.getString(var4 + "Display"));
         List var8 = var1.getStringList(var4 + "Lore");
         boolean var9 = var1.getBoolean(var4 + "Enchanted");
         AbyssDustManager.AbyssType var10 = AbyssDustManager.AbyssType.valueOf(var1.getString(var4 + "Type").toUpperCase());
         int var11 = var1.getInt(var4 + "Amount");
         String var12 = var1.getString(var4 + "OnUse.Effect");
         Sound var13 = Sound.ITEM_FIRECHARGE_USE;

         try {
            var13 = Sound.valueOf(var1.getString(var4 + "OnUse.Sound"));
         } catch (IllegalArgumentException var15) {
            ErrorLog.sendError(this, var4 + "OnUse.Sound", "Invalid Sound Type!", true);
            var1.set(var4 + "OnUse.Sound", "ITEM_FIRECHARGE_USE");
         }

         AbyssDustManager.AbyssDust var14 = new AbyssDustManager.AbyssDust(var5, var6, var7, var8, var9, var10, var11, var13, var12);
         this.dusts.put(var5, var14);
      }

      this.settingsCfg.save();
   }

   public Collection<AbyssDustManager.AbyssDust> getDusts() {
      return this.dusts.values();
   }

   public List<String> getDustNames() {
      ArrayList var1 = new ArrayList();
      Iterator var3 = this.getDusts().iterator();

      while(var3.hasNext()) {
         AbyssDustManager.AbyssDust var2 = (AbyssDustManager.AbyssDust)var3.next();
         var1.add(var2.getId());
      }

      return var1;
   }

   public AbyssDustManager.AbyssDust getDustById(String var1) {
      return var1.equalsIgnoreCase("random") ? (AbyssDustManager.AbyssDust)(new ArrayList(this.getDusts())).get(this.r.nextInt(this.getDusts().size())) : (AbyssDustManager.AbyssDust)this.dusts.get(var1.toLowerCase());
   }

   public boolean isAbyssDust(ItemStack var1) {
      return (new NBTItem(var1)).hasKey("DIVINE_ADUST");
   }

   public String getDustId(ItemStack var1) {
      return (new NBTItem(var1)).getString("DIVINE_ADUST");
   }

   public ItemStack applyDust(ItemStack var1, AbyssDustManager.AbyssType var2, int var3) {
      switch($SWITCH_TABLE$su$nightexpress$divineitems$modules$abyssdust$AbyssDustManager$AbyssType()[var2.ordinal()]) {
      case 1:
         return this.plugin.getMM().getSoulboundManager().removeSoulbound(var1);
      case 2:
         return this.plugin.getMM().getGemManager().removeGem(var1, var3);
      case 3:
         return this.plugin.getMM().getRuneManager().removeRune(var1, var3);
      case 4:
         return this.plugin.getMM().getEnchantManager().removeEnchant(var1, var3);
      case 5:
         return this.plugin.getMM().getAbilityManager().removeAbility(var1, var3);
      default:
         return var1;
      }
   }

   @EventHandler
   public void onClick(InventoryClickEvent var1) {
      if (var1.getWhoClicked() instanceof Player) {
         Player var2 = (Player)var1.getWhoClicked();
         ItemStack var3 = var1.getCursor();
         ItemStack var4 = var1.getCurrentItem();
         if (var3 != null && var4 != null) {
            if (var1.getInventory().getType() == InventoryType.CRAFTING) {
               if (var1.getSlotType() != SlotType.CRAFTING) {
                  if (var1.getSlotType() != SlotType.ARMOR && var1.getSlot() != 40) {
                     if (var3.hasItemMeta() && var3.getItemMeta().hasLore()) {
                        if (var4.hasItemMeta() && var4.getItemMeta().hasLore()) {
                           if (ItemAPI.hasOwner(var4) && !ItemAPI.isOwner(var4, var2)) {
                              var2.sendMessage(Lang.Prefix.toMsg() + Lang.Restrictions_NotOwner.toMsg());
                           } else {
                              NBTItem var5 = new NBTItem(var3);
                              if (var5.hasKey("DIVINE_ADUST")) {
                                 String var6 = var5.getString("DIVINE_ADUST");
                                 AbyssDustManager.AbyssDust var7 = this.getDustById(var6);
                                 if (var7 == null) {
                                    var2.sendMessage(Lang.Prefix.toMsg() + Lang.Other_Internal.toMsg());
                                 } else {
                                    AbyssDustManager.AbyssType var8 = var7.getType();
                                    var1.setCancelled(true);
                                    String var9 = "";
                                    switch($SWITCH_TABLE$su$nightexpress$divineitems$modules$abyssdust$AbyssDustManager$AbyssType()[var8.ordinal()]) {
                                    case 1:
                                       if (!this.plugin.getMM().getSoulboundManager().hasSoulbound(var4)) {
                                          var2.sendMessage(Lang.Prefix.toMsg() + Lang.AbyssDust_NoSoulbound.toMsg());
                                          return;
                                       }

                                       var9 = Lang.AbyssDust_Applied_Soul.toMsg();
                                       break;
                                    case 2:
                                       if (this.plugin.getMM().getGemManager().getItemGemsAmount(var4) < 1) {
                                          var2.sendMessage(Lang.Prefix.toMsg() + Lang.AbyssDust_NoGems.toMsg());
                                          return;
                                       }

                                       var9 = Lang.AbyssDust_Applied_Gem.toMsg();
                                       break;
                                    case 3:
                                       if (this.plugin.getMM().getRuneManager().getItemRunesAmount(var4) < 1) {
                                          var2.sendMessage(Lang.Prefix.toMsg() + Lang.AbyssDust_NoRunes.toMsg());
                                          return;
                                       }

                                       var9 = Lang.AbyssDust_Applied_Rune.toMsg();
                                       break;
                                    case 4:
                                       if (this.plugin.getMM().getEnchantManager().getItemEnchantAmount(var4) < 1) {
                                          var2.sendMessage(Lang.Prefix.toMsg() + Lang.AbyssDust_NoEnchants.toMsg());
                                          return;
                                       }

                                       var9 = Lang.AbyssDust_Applied_Enchant.toMsg();
                                       break;
                                    case 5:
                                       if (this.plugin.getMM().getAbilityManager().getItemAbsAmount(var4) < 1) {
                                          var2.sendMessage(Lang.Prefix.toMsg() + Lang.AbyssDust_NoAbilities.toMsg());
                                          return;
                                       }

                                       var9 = Lang.AbyssDust_Applied_Ability.toMsg();
                                    }

                                    var1.setCurrentItem(this.applyDust(var4, var8, var7.getAmount()));
                                    if (var3.getAmount() == 1) {
                                       var1.setCursor((ItemStack)null);
                                    } else {
                                       var3.setAmount(var3.getAmount() - 1);
                                       var1.setCursor(var3);
                                    }

                                    String var10 = this.plugin.getCM().getDefaultItemName(var4);
                                    if (var4.hasItemMeta() && var4.getItemMeta().hasDisplayName()) {
                                       var10 = var4.getItemMeta().getDisplayName();
                                    }

                                    var2.sendMessage(Lang.Prefix.toMsg() + var9.replace("%s", String.valueOf(var7.getAmount())).replace("%item%", var10));
                                    var2.playSound(var2.getLocation(), var7.getSound(), 0.6F, 0.6F);
                                    Utils.playEffect(var7.getEffect(), 0.30000001192092896D, 0.0D, 0.30000001192092896D, 0.0D, 5, var2.getLocation().add(0.0D, 0.85D, 0.0D));
                                    Utils.playEffect(var7.getEffect(), 0.30000001192092896D, 0.0D, 0.30000001192092896D, 0.0D, 5, var2.getLocation().add(0.0D, 0.65D, 0.0D));
                                    Utils.playEffect(var7.getEffect(), 0.30000001192092896D, 0.0D, 0.30000001192092896D, 0.0D, 5, var2.getLocation().add(0.0D, 0.25D, 0.0D));
                                 }
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
      }
   }

   // $FF: synthetic method
   static int[] $SWITCH_TABLE$su$nightexpress$divineitems$modules$abyssdust$AbyssDustManager$AbyssType() {
      int[] var10000 = $SWITCH_TABLE$su$nightexpress$divineitems$modules$abyssdust$AbyssDustManager$AbyssType;
      if (var10000 != null) {
         return var10000;
      } else {
         int[] var0 = new int[AbyssDustManager.AbyssType.values().length];

         try {
            var0[AbyssDustManager.AbyssType.ABILITY.ordinal()] = 5;
         } catch (NoSuchFieldError var5) {
         }

         try {
            var0[AbyssDustManager.AbyssType.ENCHANT.ordinal()] = 4;
         } catch (NoSuchFieldError var4) {
         }

         try {
            var0[AbyssDustManager.AbyssType.GEM.ordinal()] = 2;
         } catch (NoSuchFieldError var3) {
         }

         try {
            var0[AbyssDustManager.AbyssType.RUNE.ordinal()] = 3;
         } catch (NoSuchFieldError var2) {
         }

         try {
            var0[AbyssDustManager.AbyssType.SOULBOUND.ordinal()] = 1;
         } catch (NoSuchFieldError var1) {
         }

         $SWITCH_TABLE$su$nightexpress$divineitems$modules$abyssdust$AbyssDustManager$AbyssType = var0;
         return var0;
      }
   }

   public class AbyssDust {
      private String id;
      private String mat;
      private String name;
      private List<String> lore;
      private boolean ench;
      private AbyssDustManager.AbyssType type;
      private int amount;
      private Sound sound;
      private String effect;

      public AbyssDust(String var2, String var3, String var4, List<String> var5, boolean var6, AbyssDustManager.AbyssType var7, int var8, Sound var9, String var10) {
         this.setId(var2);
         this.setMaterial(var3);
         this.setDisplay(var4);
         this.setLore(var5);
         this.setEnchanted(var6);
         this.setType(var7);
         this.setAmount(var8);
         this.setSound(var9);
         this.setEffect(var10);
      }

      public String getId() {
         return this.id;
      }

      public void setId(String var1) {
         this.id = var1;
      }

      public String getMaterial() {
         return this.mat;
      }

      public void setMaterial(String var1) {
         this.mat = var1;
      }

      public String getDisplay() {
         return this.name;
      }

      public void setDisplay(String var1) {
         this.name = var1;
      }

      public List<String> getLore() {
         return this.lore;
      }

      public void setLore(List<String> var1) {
         this.lore = var1;
      }

      public boolean isEnchanted() {
         return this.ench;
      }

      public void setEnchanted(boolean var1) {
         this.ench = var1;
      }

      public AbyssDustManager.AbyssType getType() {
         return this.type;
      }

      public void setType(AbyssDustManager.AbyssType var1) {
         this.type = var1;
      }

      public int getAmount() {
         return this.amount;
      }

      public void setAmount(int var1) {
         this.amount = var1;
      }

      public Sound getSound() {
         return this.sound;
      }

      public void setSound(Sound var1) {
         this.sound = var1;
      }

      public String getEffect() {
         return this.effect;
      }

      public void setEffect(String var1) {
         this.effect = var1;
      }

      public ItemStack create() {
         String[] var1 = this.getMaterial().split(":");
         ItemStack var2 = Utils.buildItem(var1, this.id);
         ItemMeta var3 = var2.getItemMeta();
         ArrayList var4 = new ArrayList();
         Iterator var6 = this.getLore().iterator();

         while(var6.hasNext()) {
            String var5 = (String)var6.next();
            var4.add(ChatColor.translateAlternateColorCodes('&', var5));
         }

         var3.setDisplayName(this.getDisplay());
         var3.setLore(var4);
         var3.addItemFlags(ItemFlag.values());
         var3.spigot().setUnbreakable(true);
         var2.setItemMeta(var3);
         if (this.isEnchanted()) {
            var2.addUnsafeEnchantment(Enchantment.ARROW_DAMAGE, 1);
         }

         NBTItem var7 = new NBTItem(var2);
         var7.setString("DIVINE_ADUST", this.getId());
         return new ItemStack(var7.getItem());
      }
   }

   public static enum AbyssType {
      SOULBOUND,
      GEM,
      RUNE,
      ENCHANT,
      ABILITY;
   }
}
