package su.nightexpress.divineitems.modules.arrows;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.entity.EntityShootBowEvent;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.metadata.MetadataValue;
import org.bukkit.util.Vector;
import su.nightexpress.divineitems.DivineItems;
import su.nightexpress.divineitems.DivineListener;
import su.nightexpress.divineitems.Module;
import su.nightexpress.divineitems.api.DivineItemsAPI;
import su.nightexpress.divineitems.api.ItemAPI;
import su.nightexpress.divineitems.attributes.ItemStat;
import su.nightexpress.divineitems.cmds.list.ArrowsCommand;
import su.nightexpress.divineitems.config.MyConfig;
import su.nightexpress.divineitems.nbt.NBTItem;
import su.nightexpress.divineitems.types.AmmoType;
import su.nightexpress.divineitems.utils.ErrorLog;

public class ArrowManager extends DivineListener<DivineItems> implements Module {
   private DivineItems plugin;
   private boolean e;
   private Random r;
   private MyConfig arrowsCfg;
   private HashMap<String, ArrowManager.DivineArrow> ars;
   private List<Projectile> pjs;
   private int taskId;
   private final String n = this.name().toLowerCase().replace(" ", "_");
   private final String label;
   private final String NBT_KEY_ARROW;
   private final String NBT_KEY_LAUNCH;

   public ArrowManager(DivineItems var1) {
      super(var1);
      this.label = this.n.replace("_", "");
      this.NBT_KEY_ARROW = "DIVINE_ARROW_ID";
      this.NBT_KEY_LAUNCH = "DIVINE_ARROW_LAUNCHER";
      this.plugin = var1;
      this.e = this.plugin.getCM().getCFG().isModuleEnabled(this.name());
      this.r = new Random();
      this.pjs = new ArrayList();
   }

   public void loadConfig() {
      this.ars = new HashMap();
      this.arrowsCfg = new MyConfig(this.plugin, "/modules/" + this.n, "arrows.yml");
      this.setup();
   }

   public boolean isActive() {
      return this.e;
   }

   public boolean isDropable() {
      return true;
   }

   public boolean isResolvable() {
      return true;
   }

   public String name() {
      return "Arrows";
   }

   public String version() {
      return "1.0";
   }

   public void enable() {
      if (this.isActive()) {
         this.plugin.getCommander().registerCmd(this.label, new ArrowsCommand(this.plugin));
         this.loadConfig();
         this.registerListeners();
         this.startTask();
      }

   }

   public void unload() {
      if (this.isActive()) {
         this.plugin.getCommander().unregisterCmd(this.label);
         this.ars.clear();
         this.e = false;
         this.unregisterListeners();
         this.stopTask();
      }

   }

   public void reload() {
      this.unload();
      this.enable();
   }

   private void setup() {
      FileConfiguration var1 = this.arrowsCfg.getConfig();
      Iterator var3 = var1.getConfigurationSection("Arrows").getKeys(false).iterator();

      while(var3.hasNext()) {
         String var2 = (String)var3.next();
         String var4 = "Arrows." + var2 + ".";
         String var5 = ChatColor.translateAlternateColorCodes('&', var1.getString(var4 + "Name"));
         ArrayList var6 = new ArrayList();
         Iterator var8 = var1.getStringList(var4 + "Lore").iterator();

         while(var8.hasNext()) {
            String var7 = (String)var8.next();
            var6.add(ChatColor.translateAlternateColorCodes('&', var7));
         }

         ArrowManager.ArrowType var18 = ArrowManager.ArrowType.valueOf(var1.getString(var4 + "Type").toUpperCase());
         HashMap var19 = new HashMap();
         Iterator var10 = var1.getConfigurationSection(var4 + "Attributes").getKeys(false).iterator();

         while(var10.hasNext()) {
            String var9 = (String)var10.next();
            String var11 = var4 + "Attributes" + "." + var9 + ".";
            ItemStat var12 = null;

            try {
               var12 = ItemStat.valueOf(var9.toUpperCase());
            } catch (IllegalArgumentException var17) {
               ErrorLog.sendError(this, var11, "Invalid Attribute!", false);
               continue;
            }

            double var13 = var1.getDouble(var11 + "Value");
            ArrowManager.AttributeAction var15 = ArrowManager.AttributeAction.valueOf(var1.getString(var11 + "Action").toUpperCase());
            ArrowManager.ArrowAttribute var16 = new ArrowManager.ArrowAttribute(var12, var13, var15);
            var19.put(var12, var16);
         }

         List var20 = var1.getStringList(var4 + "OnFlyActions");
         List var21 = var1.getStringList(var4 + "OnHitActions");
         ArrowManager.DivineArrow var22 = new ArrowManager.DivineArrow(var2, var5, var6, var18, var19, var20, var21);
         this.ars.put(var2.toLowerCase(), var22);
      }

   }

   private void startTask() {
      this.taskId = this.plugin.getServer().getScheduler().scheduleSyncRepeatingTask(this.plugin, new Runnable() {
         public void run() {
            ArrowManager.this.runFlyActions();
         }
      }, 10L, 1L);
   }

   private void stopTask() {
      this.plugin.getServer().getScheduler().cancelTask(this.taskId);
   }

   public boolean isDivineArrow(ItemStack var1) {
      return var1 != null && var1.getType() != Material.AIR ? (new NBTItem(var1)).hasKey("DIVINE_ARROW_ID") : false;
   }

   public String getArrowId(ItemStack var1) {
      NBTItem var2 = new NBTItem(var1);
      String var3 = var2.getString("DIVINE_ARROW_ID");
      return var3;
   }

   public List<String> getArrowNames() {
      ArrayList var1 = new ArrayList();
      Iterator var3 = this.getArrows().iterator();

      while(var3.hasNext()) {
         ArrowManager.DivineArrow var2 = (ArrowManager.DivineArrow)var3.next();
         var1.add(var2.getId());
      }

      return var1;
   }

   public ArrowManager.DivineArrow getArrowById(String var1) {
      return var1.equalsIgnoreCase("random") ? (ArrowManager.DivineArrow)(new ArrayList(this.getArrows())).get(this.r.nextInt(this.getArrows().size())) : (ArrowManager.DivineArrow)this.ars.get(var1.toLowerCase());
   }

   public Collection<ArrowManager.DivineArrow> getArrows() {
      return this.ars.values();
   }

   public ItemStack getFirstArrow(Player var1, AmmoType var2) {
      ItemStack var3 = var1.getInventory().getItemInOffHand();
      if (var3 != null && this.isDivineArrow(var3)) {
         return var3;
      } else {
         int var4 = var1.getInventory().first(Material.ARROW);
         return var4 >= 0 ? var1.getInventory().getItem(var4) : null;
      }
   }

   private void markArrow(String var1, Projectile var2, LivingEntity var3) {
      var2.setMetadata("DIVINE_ARROW_ID", new FixedMetadataValue(this.plugin, var1));
      var2.setMetadata("DIVINE_ARROW_LAUNCHER", new FixedMetadataValue(this.plugin, var3));
   }

   public void runFlyActions() {
      ArrayList var1 = new ArrayList(this.pjs);
      Iterator var3 = var1.iterator();

      while(true) {
         while(var3.hasNext()) {
            Projectile var2 = (Projectile)var3.next();
            if (!var2.isOnGround() && var2.isValid()) {
               String var4 = ((MetadataValue)var2.getMetadata("DIVINE_ARROW_ID").get(0)).asString();
               ArrowManager.DivineArrow var5 = this.getArrowById(var4);
               if (var5 == null || var5.getFlyActions() == null) {
                  return;
               }

               DivineItemsAPI.executeActions(var2, var5.getFlyActions(), (ItemStack)null);
            } else {
               this.pjs.remove(var2);
            }
         }

         return;
      }
   }

   @EventHandler(
      priority = EventPriority.HIGHEST,
      ignoreCancelled = true
   )
   public void onProj(EntityShootBowEvent var1) {
      if (var1.getProjectile() instanceof Projectile) {
         Projectile var2 = (Projectile)var1.getProjectile();
         if (var1.getEntity() instanceof Player) {
            Player var3 = (Player)var1.getEntity();
            ItemStack var4 = this.getFirstArrow(var3, ItemAPI.getAmmoType(var1.getBow()));
            if (var4 != null && this.isDivineArrow(var4)) {
               String var5 = this.getArrowId(var4);
               this.markArrow(var5, var2, var3);
               this.pjs.add(var2);
            }
         }
      }
   }

   @EventHandler(
      priority = EventPriority.HIGHEST,
      ignoreCancelled = true
   )
   public void onHit(ProjectileHitEvent var1) {
      Projectile var2 = var1.getEntity();
      if (var2.getShooter() != null && var2.getShooter() instanceof Player) {
         if (var2.hasMetadata("DIVINE_ARROW_ID")) {
            String var3 = ((MetadataValue)var2.getMetadata("DIVINE_ARROW_ID").get(0)).asString();
            Entity var4 = var1.getHitEntity();
            if (var4 != null) {
               Location var5 = var4.getLocation();
               Location var6 = var2.getLocation();
               Vector var7 = var5.toVector();
               Vector var8 = var6.toVector();
               Vector var9 = var8.subtract(var7);
               var9.normalize();
               var9.multiply(2);
               var5.setDirection(var9);
               var2.teleport(var5);
               var2.setVelocity(var9);
               var2.setMetadata("DI_TARGET", new FixedMetadataValue(this.plugin, var4));
            }

            ArrowManager.DivineArrow var10 = this.getArrowById(var3);
            DivineItemsAPI.executeActions(var2, var10.getHitActions(), (ItemStack)null);
         }
      }
   }

   public class ArrowAttribute {
      private ItemStat att;
      private double val;
      private ArrowManager.AttributeAction act;

      public ArrowAttribute(ItemStat var2, double var3, ArrowManager.AttributeAction var5) {
         this.setAttribute(var2);
         this.setValue(var3);
         this.setAction(var5);
      }

      public ItemStat getAttribute() {
         return this.att;
      }

      public void setAttribute(ItemStat var1) {
         this.att = var1;
      }

      public double getValue() {
         return this.val;
      }

      public void setValue(double var1) {
         this.val = var1;
      }

      public ArrowManager.AttributeAction getAction() {
         return this.act;
      }

      public void setAction(ArrowManager.AttributeAction var1) {
         this.act = var1;
      }
   }

   public static enum ArrowType {
      NORMAL,
      TIPPED,
      SPECTRAL;
   }

   public static enum AttributeAction {
      PLUS,
      MINUS;
   }

   public class DivineArrow {
      private String id;
      private String name;
      private List<String> lore;
      private ArrowManager.ArrowType type;
      private HashMap<ItemStat, ArrowManager.ArrowAttribute> att;
      private List<String> fly;
      private List<String> hit;
      // $FF: synthetic field
      private static int[] $SWITCH_TABLE$su$nightexpress$divineitems$modules$arrows$ArrowManager$ArrowType;

      public DivineArrow(String var2, String var3, List<String> var4, ArrowManager.ArrowType var5, HashMap<ItemStat, ArrowManager.ArrowAttribute> var6, List<String> var7, List<String> var8) {
         this.setId(var2);
         this.setName(var3);
         this.setLore(var4);
         this.setType(var5);
         this.setAttributes(var6);
         this.setFlyActions(var7);
         this.setHitActions(var8);
      }

      public String getId() {
         return this.id;
      }

      public void setId(String var1) {
         this.id = var1;
      }

      public String getName() {
         return this.name;
      }

      public void setName(String var1) {
         this.name = var1;
      }

      public List<String> getLore() {
         return this.lore;
      }

      public void setLore(List<String> var1) {
         this.lore = var1;
      }

      public ArrowManager.ArrowType getType() {
         return this.type;
      }

      public void setType(ArrowManager.ArrowType var1) {
         this.type = var1;
      }

      public HashMap<ItemStat, ArrowManager.ArrowAttribute> getAttributes() {
         return this.att;
      }

      public void setAttributes(HashMap<ItemStat, ArrowManager.ArrowAttribute> var1) {
         this.att = var1;
      }

      public List<String> getFlyActions() {
         return this.fly;
      }

      public void setFlyActions(List<String> var1) {
         this.fly = var1;
      }

      public List<String> getHitActions() {
         return this.hit;
      }

      public void setHitActions(List<String> var1) {
         this.hit = var1;
      }

      public ItemStack create() {
         ItemStack var1 = new ItemStack(Material.ARROW);
         switch($SWITCH_TABLE$su$nightexpress$divineitems$modules$arrows$ArrowManager$ArrowType()[this.type.ordinal()]) {
         case 1:
         default:
            break;
         case 2:
            var1.setType(Material.TIPPED_ARROW);
            break;
         case 3:
            var1.setType(Material.SPECTRAL_ARROW);
         }

         ItemMeta var2 = var1.getItemMeta();
         var2.setDisplayName(this.name);
         var2.setLore(this.lore);
         var2.addItemFlags(ItemFlag.values());
         var1.setItemMeta(var2);
         NBTItem var3 = new NBTItem(var1);
         var3.setString("DIVINE_ARROW_ID", this.id);
         var1 = var3.getItem();
         return var1;
      }

      // $FF: synthetic method
      static int[] $SWITCH_TABLE$su$nightexpress$divineitems$modules$arrows$ArrowManager$ArrowType() {
         int[] var10000 = $SWITCH_TABLE$su$nightexpress$divineitems$modules$arrows$ArrowManager$ArrowType;
         if (var10000 != null) {
            return var10000;
         } else {
            int[] var0 = new int[ArrowManager.ArrowType.values().length];

            try {
               var0[ArrowManager.ArrowType.NORMAL.ordinal()] = 1;
            } catch (NoSuchFieldError var3) {
            }

            try {
               var0[ArrowManager.ArrowType.SPECTRAL.ordinal()] = 3;
            } catch (NoSuchFieldError var2) {
            }

            try {
               var0[ArrowManager.ArrowType.TIPPED.ordinal()] = 2;
            } catch (NoSuchFieldError var1) {
            }

            $SWITCH_TABLE$su$nightexpress$divineitems$modules$arrows$ArrowManager$ArrowType = var0;
            return var0;
         }
      }
   }
}
