package su.nightexpress.divineitems.modules.buffs;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.entity.PlayerDeathEvent;
import su.nightexpress.divineitems.DivineItems;
import su.nightexpress.divineitems.DivineListener;
import su.nightexpress.divineitems.Module;
import su.nightexpress.divineitems.attributes.ItemStat;
import su.nightexpress.divineitems.cmds.list.BuffCommand;
import su.nightexpress.divineitems.config.Lang;
import su.nightexpress.divineitems.config.MyConfig;
import su.nightexpress.divineitems.types.ArmorType;
import su.nightexpress.divineitems.types.DamageType;
import su.nightexpress.divineitems.utils.Utils;

public class BuffManager extends DivineListener<DivineItems> implements Module {
   private DivineItems plugin;
   private MyConfig config;
   private boolean e;
   private int taskId;
   private boolean resetDeath;
   private boolean buffMsg;
   private HashMap<UUID, List<BuffManager.Buff>> buffs;
   private final String n = this.name().toLowerCase().replace(" ", "_");
   private final String label;
   // $FF: synthetic field
   private static int[] $SWITCH_TABLE$su$nightexpress$divineitems$modules$buffs$BuffManager$BuffType;

   public BuffManager(DivineItems var1) {
      super(var1);
      this.label = this.n.replace("_", "");
      this.plugin = var1;
      this.buffs = new HashMap();
      this.e = this.plugin.getCM().getCFG().isModuleEnabled(this.name());
   }

   public void loadConfig() {
      this.config = new MyConfig(this.plugin, "/modules/" + this.n, "settings.yml");
      this.resetDeath = this.config.getConfig().getBoolean("ResetBuffsOnDeath");
      if (!this.config.getConfig().contains("BuffMessages")) {
         this.config.getConfig().set("BuffMessages", true);
      }

      this.buffMsg = this.config.getConfig().getBoolean("BuffMessages");
      this.config.save();
   }

   public boolean isActive() {
      return this.e;
   }

   public boolean isDropable() {
      return false;
   }

   public boolean isResolvable() {
      return false;
   }

   public String name() {
      return "Buffs";
   }

   public String version() {
      return "1.0";
   }

   public void enable() {
      if (this.isActive()) {
         this.plugin.getCommander().registerCmd(this.label, new BuffCommand(this.plugin));
         this.loadConfig();
         this.registerListeners();
         this.startTask();
      }

   }

   public void unload() {
      if (this.isActive()) {
         this.plugin.getCommander().unregisterCmd(this.label);
         this.buffs.clear();
         this.e = false;
         this.unregisterListeners();
         this.stopTask();
      }

   }

   public void reload() {
      this.unload();
      this.enable();
   }

   public void startTask() {
      this.taskId = this.plugin.getServer().getScheduler().scheduleSyncRepeatingTask(this.plugin, new Runnable() {
         public void run() {
            HashMap var1 = new HashMap(BuffManager.this.getBuffs());
            Iterator var3 = var1.keySet().iterator();

            while(var3.hasNext()) {
               UUID var2 = (UUID)var3.next();
               Iterator var5 = ((List)var1.get(var2)).iterator();

               while(var5.hasNext()) {
                  BuffManager.Buff var4 = (BuffManager.Buff)var5.next();
                  if (var4.getTimeSec() - 1 < 0) {
                     BuffManager.this.resetBuff(var2, var4.getType(), var4.getValue());
                  } else {
                     var4.setTimeSec(var4.getTimeSec() - 1);
                     BuffManager.this.update(var2, var4);
                  }
               }
            }

         }
      }, 10L, 20L);
   }

   public void stopTask() {
      this.plugin.getServer().getScheduler().cancelTask(this.taskId);
   }

   public boolean addBuff(Player var1, BuffManager.BuffType var2, String var3, double var4, int var6, boolean var7) {
      if (!this.isValidBuff(var2, var3)) {
         return false;
      } else if (var7) {
         double var13 = this.getBuff(var1, var2, var3);
         double var12 = var4 + var13;
         this.addBuff(var1, var2, var3, var12, var6, false);
         return true;
      } else {
         this.resetBuff(var1, var2, var3);
         Object var8 = new ArrayList();
         if (this.getBuffs().containsKey(var1.getUniqueId())) {
            var8 = (List)this.buffs.get(var1.getUniqueId());
         }

         BuffManager.Buff var9 = new BuffManager.Buff(var2, var3, var4, var6);
         ((List)var8).add(var9);
         this.buffs.put(var1.getUniqueId(), var8);
         if (this.buffMsg) {
            String var10 = this.getBuffName(var2, var3);
            var1.sendMessage(Lang.Prefix.toMsg() + Lang.Buffs_Get.toMsg().replace("%type%", var10).replace("%time%", String.valueOf(var6)).replace("%value%", String.valueOf(Utils.round3(var4))));
         }

         return true;
      }
   }

   public void resetBuff(Player var1, BuffManager.BuffType var2, String var3) {
      if (this.getBuffs().containsKey(var1.getUniqueId())) {
         ArrayList var4 = new ArrayList((Collection)this.getBuffs().get(var1.getUniqueId()));
         Iterator var6 = var4.iterator();

         while(var6.hasNext()) {
            BuffManager.Buff var5 = (BuffManager.Buff)var6.next();
            if (var5.getType() == var2 && var5.getValue().equalsIgnoreCase(var3)) {
               var4.remove(var5);
               if (this.buffMsg && var1 != null && var1.isOnline()) {
                  String var7 = this.getBuffName(var2, var3);
                  var1.sendMessage(Lang.Prefix.toMsg() + Lang.Buffs_End.toMsg().replace("%type%", var7));
               }
               break;
            }
         }

         if (var4.isEmpty()) {
            this.buffs.remove(var1.getUniqueId());
         } else {
            this.buffs.put(var1.getUniqueId(), var4);
         }
      }
   }

   public void resetBuff(UUID var1, BuffManager.BuffType var2, String var3) {
      if (this.getBuffs().containsKey(var1)) {
         ArrayList var4 = new ArrayList((Collection)this.getBuffs().get(var1));
         Iterator var6 = var4.iterator();

         while(var6.hasNext()) {
            BuffManager.Buff var5 = (BuffManager.Buff)var6.next();
            if (var5.getType() == var2 && var5.getValue().equalsIgnoreCase(var3)) {
               var4.remove(var5);
               if (this.buffMsg && this.plugin.getServer().getPlayer(var1) != null) {
                  String var7 = this.getBuffName(var2, var3);
                  this.plugin.getServer().getPlayer(var1).sendMessage(Lang.Prefix.toMsg() + Lang.Buffs_End.toMsg().replace("%type%", var7));
               }
               break;
            }
         }

         if (var4.isEmpty()) {
            this.buffs.remove(var1);
         } else {
            this.buffs.put(var1, var4);
         }
      }
   }

   public void update(UUID var1, BuffManager.Buff var2) {
      ArrayList var3 = new ArrayList((Collection)this.getBuffs().get(var1));
      Iterator var5 = var3.iterator();

      while(var5.hasNext()) {
         BuffManager.Buff var4 = (BuffManager.Buff)var5.next();
         if (var4.getType() == var2.getType()) {
            var3.remove(var4);
            break;
         }
      }

      var3.add(var2);
      this.buffs.put(var1, var3);
   }

   public double getBuff(Player var1, BuffManager.BuffType var2, String var3) {
      double var4 = 0.0D;
      if (!this.getBuffs().containsKey(var1.getUniqueId())) {
         return var4;
      } else {
         ArrayList var6 = new ArrayList((Collection)this.getBuffs().get(var1.getUniqueId()));
         Iterator var8 = var6.iterator();

         while(var8.hasNext()) {
            BuffManager.Buff var7 = (BuffManager.Buff)var8.next();
            if (var7.getType() == var2 && var7.getValue().equalsIgnoreCase(var3)) {
               var4 = var7.getModifier();
               break;
            }
         }

         return var4;
      }
   }

   private String getBuffName(BuffManager.BuffType var1, String var2) {
      String var3 = var2;
      switch($SWITCH_TABLE$su$nightexpress$divineitems$modules$buffs$BuffManager$BuffType()[var1.ordinal()]) {
      case 1:
         try {
            ItemStat var7 = ItemStat.valueOf(var2.toUpperCase());
            var3 = var7.getName();
         } catch (IllegalArgumentException var5) {
         }
         break;
      case 2:
         DamageType var6 = this.plugin.getCFG().getDamageTypeById(var2);
         if (var6 != null) {
            var3 = var6.getName();
         }
         break;
      case 3:
         ArmorType var4 = this.plugin.getCFG().getArmorTypeById(var2);
         if (var4 != null) {
            var3 = var4.getName();
         }
      }

      return var3;
   }

   public boolean isValidBuff(BuffManager.BuffType var1, String var2) {
      switch($SWITCH_TABLE$su$nightexpress$divineitems$modules$buffs$BuffManager$BuffType()[var1.ordinal()]) {
      case 1:
         try {
            ItemStat.valueOf(var2.toUpperCase());
            return true;
         } catch (IllegalArgumentException var4) {
            return false;
         }
      case 2:
         DamageType var5 = this.plugin.getCFG().getDamageTypeById(var2);
         if (var5 != null) {
            return true;
         }

         return false;
      case 3:
         ArmorType var3 = this.plugin.getCFG().getArmorTypeById(var2);
         if (var3 != null) {
            return true;
         }

         return false;
      default:
         return false;
      }
   }

   public HashMap<UUID, List<BuffManager.Buff>> getBuffs() {
      return this.buffs;
   }

   public List<BuffManager.Buff> getPlayerBuffs(Player var1) {
      return (List)(this.buffs.containsKey(var1.getUniqueId()) ? (List)this.buffs.get(var1.getUniqueId()) : new ArrayList());
   }

   public List<BuffManager.Buff> getEntityBuffs(LivingEntity var1) {
      return (List)(this.buffs.containsKey(var1.getUniqueId()) ? (List)this.buffs.get(var1.getUniqueId()) : new ArrayList());
   }

   @EventHandler
   public void onDeath(PlayerDeathEvent var1) {
      if (this.resetDeath) {
         Player var2 = var1.getEntity();
         Iterator var4 = this.getPlayerBuffs(var2).iterator();

         while(var4.hasNext()) {
            BuffManager.Buff var3 = (BuffManager.Buff)var4.next();
            this.resetBuff(var2, var3.getType(), var3.getValue());
         }
      }

   }

   // $FF: synthetic method
   static int[] $SWITCH_TABLE$su$nightexpress$divineitems$modules$buffs$BuffManager$BuffType() {
      int[] var10000 = $SWITCH_TABLE$su$nightexpress$divineitems$modules$buffs$BuffManager$BuffType;
      if (var10000 != null) {
         return var10000;
      } else {
         int[] var0 = new int[BuffManager.BuffType.values().length];

         try {
            var0[BuffManager.BuffType.DAMAGE.ordinal()] = 2;
         } catch (NoSuchFieldError var3) {
         }

         try {
            var0[BuffManager.BuffType.DEFENSE.ordinal()] = 3;
         } catch (NoSuchFieldError var2) {
         }

         try {
            var0[BuffManager.BuffType.ITEM_STAT.ordinal()] = 1;
         } catch (NoSuchFieldError var1) {
         }

         $SWITCH_TABLE$su$nightexpress$divineitems$modules$buffs$BuffManager$BuffType = var0;
         return var0;
      }
   }

   public class Buff {
      private BuffManager.BuffType type;
      private String value;
      private double modifier;
      private int time;

      public Buff(BuffManager.BuffType var2, String var3, double var4, int var6) {
         this.setType(var2);
         this.setValue(var3);
         this.setModifier(var4);
         this.setTimeSec(var6);
      }

      public BuffManager.BuffType getType() {
         return this.type;
      }

      public void setType(BuffManager.BuffType var1) {
         this.type = var1;
      }

      public String getValue() {
         return this.value;
      }

      public void setValue(String var1) {
         this.value = var1;
      }

      public double getModifier() {
         return this.modifier;
      }

      public void setModifier(double var1) {
         this.modifier = var1;
      }

      public int getTimeSec() {
         return this.time;
      }

      public void setTimeSec(int var1) {
         this.time = var1;
      }
   }

   public static enum BuffType {
      ITEM_STAT,
      DAMAGE,
      DEFENSE;
   }
}
