package su.nightexpress.divineitems.modules.combatlog;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import net.md_5.bungee.api.ChatColor;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.metadata.MetadataValue;
import su.nightexpress.divineitems.DivineItems;
import su.nightexpress.divineitems.DivineListener;
import su.nightexpress.divineitems.Module;
import su.nightexpress.divineitems.config.Lang;
import su.nightexpress.divineitems.config.MyConfig;
import su.nightexpress.divineitems.hooks.Hook;
import su.nightexpress.divineitems.utils.ActionTitle;
import su.nightexpress.divineitems.utils.ErrorLog;
import su.nightexpress.divineitems.utils.Utils;

public class CombatLogManager extends DivineListener<DivineItems> implements Module {
   private DivineItems plugin;
   private MyConfig config;
   private boolean e;
   private boolean combat_out_chat;
   private boolean combat_out_action;
   private boolean combat_msg_default;
   private boolean combat_msg_critical;
   private boolean combat_msg_dodge;
   private boolean combat_msg_block;
   private boolean combat_msg_zero;
   private boolean combat_hd_e;
   private boolean combat_sound_default;
   private boolean combat_sound_critical;
   private boolean combat_sound_dodge;
   private boolean combat_sound_block;
   private Sound combat_sound_default_value;
   private Sound combat_sound_critical_value;
   private Sound combat_sound_dodge_value;
   private Sound combat_sound_block_value;
   private String f_crit;
   private String f_block;
   private String f_dodge;
   private List<String> f_total;
   private HashMap<String, String> f_dt;
   private HashMap<String, String> f_ds;
   private final String META_CRIT = "DI_CRIT";
   private final String META_BLOCK = "DI_BLOCK";
   private final String META_DODGE = "DI_DODGE";
   private final String META_DT = "DDT_";
   private final String META_DS = "DDS_";
   private final String n = this.name().toLowerCase().replace(" ", "_");

   public CombatLogManager(DivineItems var1) {
      super(var1);
      this.plugin = var1;
      this.e = this.plugin.getCM().getCFG().isModuleEnabled(this.name());
   }

   public void loadConfig() {
      this.config = new MyConfig(this.plugin, "/modules/" + this.n, "settings.yml");
      FileConfiguration var1 = this.config.getConfig();
      if (!var1.contains("Messages.IgnoreZeroDamage")) {
         var1.set("Messages.IgnoreZeroDamage", false);
      }

      if (!var1.contains("Indicators.Format")) {
         var1.set("Indicators.Format.Critical", "&8[&c&lCritical!&8]");
         var1.set("Indicators.Format.Block", "&8[&e&lBlocked!&8]");
         var1.set("Indicators.Format.Dodge", "&8[&b&lDodge!&8]");
         var1.set("Indicators.Format.Total", Arrays.asList("%crit%", "%block%", "%dodge%", "%dmg%"));
         var1.set("Indicators.Format.DamageTypes.Physical", "&c-%dmg%");
         var1.set("Indicators.Format.DamageTypes.Magical", "&d-%dmg%");
         var1.set("Indicators.Format.DamageTypes.Fire", "&4-%dmg%");
         var1.set("Indicators.Format.DamageTypes.Poison", "&a-%dmg%");
         var1.set("Indicators.Format.DamageTypes.Water", "&9-%dmg%");
         var1.set("Indicators.Format.DamageTypes.Wind", "&7-%dmg%");
         var1.set("Indicators.Format.DamageSources.default", "&c-%dmg%");
         var1.set("Indicators.Format.DamageSources.POISON", "&a-%dmg%");
      }

      this.combat_out_chat = var1.getBoolean("Messages.Chat");
      this.combat_out_action = var1.getBoolean("Messages.ActionBar");
      this.combat_msg_default = var1.getBoolean("Messages.Default");
      this.combat_msg_critical = var1.getBoolean("Messages.Critical");
      this.combat_msg_dodge = var1.getBoolean("Messages.Dodge");
      this.combat_msg_block = var1.getBoolean("Messages.Block");
      this.combat_msg_zero = var1.getBoolean("Messages.IgnoreZeroDamage");
      this.combat_hd_e = var1.getBoolean("Indicators.Enabled");
      this.combat_sound_default = var1.getBoolean("Sounds.Default.Enabled");
      this.combat_sound_critical = var1.getBoolean("Sounds.Critical.Enabled");
      this.combat_sound_dodge = var1.getBoolean("Sounds.Dodge.Enabled");
      this.combat_sound_block = var1.getBoolean("Sounds.Block.Enabled");
      this.combat_sound_default_value = Sound.ENTITY_ZOMBIE_ATTACK_IRON_DOOR;

      try {
         this.combat_sound_default_value = Sound.valueOf(var1.getString("Sounds.Default.Value"));
      } catch (IllegalArgumentException var8) {
         ErrorLog.sendError(this, "Sounds.Default.Value", "Invalid Sound value!", true);
         var1.set("Sounds.Default.Value", "ENTITY_ZOMBIE_ATTACK_IRON_DOOR");
      }

      this.combat_sound_critical_value = Sound.ENTITY_GENERIC_EXPLODE;

      try {
         this.combat_sound_critical_value = Sound.valueOf(var1.getString("Sounds.Critical.Value"));
      } catch (IllegalArgumentException var7) {
         ErrorLog.sendError(this, "Sounds.Critical.Value", "Invalid Sound value!", true);
         var1.set("Sounds.Critical.Value", "ENTITY_GENERIC_EXPLODE");
      }

      this.combat_sound_dodge_value = Sound.ENTITY_COW_MILK;

      try {
         this.combat_sound_dodge_value = Sound.valueOf(var1.getString("Sounds.Dodge.Value"));
      } catch (IllegalArgumentException var6) {
         ErrorLog.sendError(this, "Sounds.Dodge.Value", "Invalid Sound value!", true);
         var1.set("Sounds.Block.Value", "ENTITY_COW_MILK");
      }

      this.combat_sound_block_value = Sound.BLOCK_ANVIL_PLACE;

      try {
         this.combat_sound_block_value = Sound.valueOf(var1.getString("Sounds.Block.Value"));
      } catch (IllegalArgumentException var5) {
         ErrorLog.sendError(this, "Sounds.Block.Value", "Invalid Sound value!", true);
         var1.set("Sounds.Block.Value", "BLOCK_ANVIL_PLACE");
      }

      this.f_crit = ChatColor.translateAlternateColorCodes('&', var1.getString("Indicators.Format.Critical"));
      this.f_block = ChatColor.translateAlternateColorCodes('&', var1.getString("Indicators.Format.Block"));
      this.f_dodge = ChatColor.translateAlternateColorCodes('&', var1.getString("Indicators.Format.Dodge"));
      this.f_total = var1.getStringList("Indicators.Format.Total");
      this.f_dt = new HashMap();
      String var2;
      Iterator var3;
      String var4;
      if (var1.contains("Indicators.Format.DamageTypes")) {
         var3 = var1.getConfigurationSection("Indicators.Format.DamageTypes").getKeys(false).iterator();

         while(var3.hasNext()) {
            var2 = (String)var3.next();
            var4 = ChatColor.translateAlternateColorCodes('&', var1.getString("Indicators.Format.DamageTypes." + var2));
            this.f_dt.put(var2.toLowerCase(), var4);
         }
      }

      this.f_ds = new HashMap();
      if (var1.contains("Indicators.Format.DamageSources")) {
         var3 = var1.getConfigurationSection("Indicators.Format.DamageSources").getKeys(false).iterator();

         while(var3.hasNext()) {
            var2 = (String)var3.next();
            var4 = ChatColor.translateAlternateColorCodes('&', var1.getString("Indicators.Format.DamageSources." + var2));
            this.f_ds.put(var2.toUpperCase(), var4);
         }
      }

      this.config.save();
   }

   public boolean isActive() {
      return this.e;
   }

   public boolean isDropable() {
      return false;
   }

   public boolean isResolvable() {
      return false;
   }

   public String name() {
      return "Combat Log";
   }

   public String version() {
      return "1.0";
   }

   public void enable() {
      if (this.isActive()) {
         this.loadConfig();
         this.registerListeners();
      }

   }

   public void unload() {
      if (this.isActive()) {
         this.e = false;
         this.unregisterListeners();
      }

   }

   public void reload() {
      this.unload();
      this.loadConfig();
      this.enable();
   }

   public void sendDamageMsg(double var1, String var3, String var4, Entity var5, Entity var6) {
      if (!(var1 <= 0.0D) || !this.combat_msg_zero) {
         var1 = Utils.round3(var1);
         Player var7;
         if (var5 instanceof Player) {
            var7 = (Player)var5;
            if (this.combat_msg_default) {
               if (this.combat_out_chat) {
                  var7.sendMessage(Lang.CombatLog_Get.toMsg().replace("%s", "" + var1).replace("%e", var4));
               }

               if (this.combat_out_action) {
                  ActionTitle.sendActionBar(var7, Lang.CombatLog_Get.toMsg().replace("%s", "" + var1).replace("%e", var4));
               }
            }

            if (this.combat_sound_default) {
               var7.playSound(var7.getLocation(), this.combat_sound_default_value, 1.0F, 1.0F);
            }
         }

         if (var6 instanceof Projectile) {
            Projectile var8 = (Projectile)var6;
            if (var8.getShooter() != null && var8.getShooter() instanceof Player) {
               var6 = (Entity)var8.getShooter();
            }
         }

         if (var6 instanceof Player) {
            var7 = (Player)var6;
            if (this.combat_msg_default) {
               if (this.combat_out_chat) {
                  var7.sendMessage(Lang.CombatLog_Deal.toMsg().replace("%s", "" + var1).replace("%e", var3));
               }

               if (this.combat_out_action) {
                  ActionTitle.sendActionBar(var7, Lang.CombatLog_Deal.toMsg().replace("%s", "" + var1).replace("%e", var3));
               }
            }

            if (this.combat_sound_default) {
               var7.playSound(var7.getLocation(), this.combat_sound_default_value, 1.0F, 1.0F);
            }
         }

      }
   }

   public void sendCritDmgMsg(double var1, String var3, String var4, Entity var5, Entity var6) {
      if (!(var1 <= 0.0D) || !this.combat_msg_zero) {
         var1 = Utils.round3(var1);
         Player var7;
         if (var5 instanceof Player) {
            var7 = (Player)var5;
            if (this.combat_msg_critical) {
               if (this.combat_out_chat) {
                  var7.sendMessage(Lang.CombatLog_GetCrit.toMsg().replace("%s", "" + var1).replace("%e", var4));
               }

               if (this.combat_out_action) {
                  ActionTitle.sendActionBar(var7, Lang.CombatLog_GetCrit.toMsg().replace("%s", "" + var1).replace("%e", var4));
               }
            }

            if (this.combat_sound_critical) {
               var7.playSound(var7.getLocation(), this.combat_sound_critical_value, 1.0F, 1.0F);
            }
         }

         if (var6 instanceof Projectile) {
            Projectile var8 = (Projectile)var6;
            if (var8.getShooter() != null && var8.getShooter() instanceof Player) {
               var6 = (Entity)var8.getShooter();
            }
         }

         if (var6 instanceof Player) {
            var7 = (Player)var6;
            if (this.combat_msg_critical) {
               if (this.combat_out_chat) {
                  var7.sendMessage(Lang.CombatLog_DealCrit.toMsg().replace("%s", "" + var1).replace("%e", var3));
               }

               if (this.combat_out_action) {
                  ActionTitle.sendActionBar(var7, Lang.CombatLog_DealCrit.toMsg().replace("%s", "" + var1).replace("%e", var3));
               }
            }

            if (this.combat_sound_critical) {
               var7.playSound(var7.getLocation(), this.combat_sound_critical_value, 1.0F, 1.0F);
            }
         }

      }
   }

   public void sendDodgeMsg(String var1, String var2, Entity var3, Entity var4) {
      Player var5;
      if (var3 instanceof Player) {
         var5 = (Player)var3;
         if (this.combat_msg_dodge) {
            if (this.combat_out_chat) {
               var5.sendMessage(Lang.CombatLog_Dodge.toMsg().replace("%e", var2));
            }

            if (this.combat_out_action) {
               ActionTitle.sendActionBar(var5, Lang.CombatLog_Dodge.toMsg().replace("%e", var2));
            }
         }

         if (this.combat_sound_dodge) {
            var5.playSound(var5.getLocation(), this.combat_sound_dodge_value, 1.0F, 1.0F);
         }
      }

      if (var4 instanceof Projectile) {
         Projectile var6 = (Projectile)var4;
         if (var6.getShooter() != null && var6.getShooter() instanceof Player) {
            var4 = (Entity)var6.getShooter();
         }
      }

      if (var4 instanceof Player) {
         var5 = (Player)var4;
         if (this.combat_msg_dodge) {
            if (this.combat_out_chat) {
               var5.sendMessage(Lang.CombatLog_DodgeEnemy.toMsg().replace("%e", var1));
            }

            if (this.combat_out_action) {
               ActionTitle.sendActionBar(var5, Lang.CombatLog_DodgeEnemy.toMsg().replace("%e", var1));
            }
         }

         if (this.combat_sound_dodge) {
            var5.playSound(var5.getLocation(), this.combat_sound_dodge_value, 1.0F, 1.0F);
         }
      }

   }

   public void sendBlockMsg(double var1, String var3, String var4, Entity var5, Entity var6) {
      var1 = Utils.round3(var1);
      Player var7;
      if (var5 instanceof Player) {
         var7 = (Player)var5;
         if (this.combat_msg_block) {
            if (this.combat_out_chat) {
               var7.sendMessage(Lang.CombatLog_Block.toMsg().replace("%d", "" + Utils.round3(var1)).replace("%e", var4));
            }

            if (this.combat_out_action) {
               ActionTitle.sendActionBar(var7, Lang.CombatLog_Block.toMsg().replace("%d", "" + Utils.round3(var1)).replace("%e", var4));
            }
         }

         if (this.combat_sound_block) {
            var7.playSound(var7.getLocation(), this.combat_sound_block_value, 1.0F, 1.0F);
         }
      }

      if (var6 instanceof Projectile) {
         Projectile var8 = (Projectile)var6;
         if (var8.getShooter() != null && var8.getShooter() instanceof Player) {
            var6 = (Entity)var8.getShooter();
         }
      }

      if (var6 instanceof Player) {
         var7 = (Player)var6;
         if (this.combat_msg_block) {
            if (this.combat_out_chat) {
               var7.sendMessage(Lang.CombatLog_BlockEnemy.toMsg().replace("%d", "" + Utils.round3(var1)).replace("%e", var3));
            }

            if (this.combat_out_action) {
               ActionTitle.sendActionBar(var7, Lang.CombatLog_BlockEnemy.toMsg().replace("%d", "" + Utils.round3(var1)).replace("%e", var3));
            }
         }

         if (this.combat_sound_block) {
            var7.playSound(var7.getLocation(), this.combat_sound_block_value, 1.0F, 1.0F);
         }
      }

   }

   public String getDamageTypeFormat(String var1) {
      var1 = var1.toLowerCase();
      return this.f_dt.containsKey(var1) ? (String)this.f_dt.get(var1) : "§cError # Invalid Type!";
   }

   public String getDamageTypeSource(String var1) {
      var1 = var1.toUpperCase();
      return this.f_ds.containsKey(var1) ? (String)this.f_ds.get(var1) : "§cError # Invalid Type!";
   }

   public void setDTMeta(LivingEntity var1, String var2, double var3) {
      var1.setMetadata("DDT_" + var2, new FixedMetadataValue(this.plugin, var3));
   }

   public void setDSMeta(LivingEntity var1, String var2, double var3) {
      var2 = var2.toUpperCase();
      if (!this.f_ds.containsKey(var2)) {
         var2 = "DEFAULT";
      }

      var1.setMetadata("DDS_" + var2, new FixedMetadataValue(this.plugin, var3));
   }

   public void setCritMeta(LivingEntity var1) {
      var1.setMetadata("DI_CRIT", new FixedMetadataValue(this.plugin, "SU"));
   }

   public void setBlockMeta(LivingEntity var1, double var2) {
      var1.setMetadata("DI_BLOCK", new FixedMetadataValue(this.plugin, var2));
   }

   public void setDodgeMeta(LivingEntity var1) {
      var1.setMetadata("DI_DODGE", new FixedMetadataValue(this.plugin, "SU"));
   }

   public void removeAllMeta(LivingEntity var1) {
      var1.removeMetadata("DI_BLOCK", this.plugin);
      var1.removeMetadata("DI_CRIT", this.plugin);
      var1.removeMetadata("DI_DODGE", this.plugin);
      Iterator var3 = this.f_dt.keySet().iterator();

      String var2;
      while(var3.hasNext()) {
         var2 = (String)var3.next();
         var1.removeMetadata("DDT_" + var2, this.plugin);
      }

      var3 = this.f_ds.keySet().iterator();

      while(var3.hasNext()) {
         var2 = (String)var3.next();
         var1.removeMetadata("DDS_" + var2, this.plugin);
      }

   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onDamageIndicator(EntityDamageEvent var1) {
      Entity var2 = var1.getEntity();
      if (!var1.isCancelled() || var2.hasMetadata("DI_DODGE")) {
         if (var2.hasMetadata("DI_DODGE") && !var1.isCancelled()) {
            var1.setCancelled(true);
         }

         double var3 = var1.getFinalDamage();
         double var5 = 0.0D;
         if (!(var3 <= 0.0D) || !this.combat_msg_zero) {
            String var9;
            if (var1 instanceof EntityDamageByEntityEvent) {
               EntityDamageByEntityEvent var7 = (EntityDamageByEntityEvent)var1;
               Entity var8 = var7.getDamager();
               var9 = Utils.getEntityName(var2);
               String var10 = Utils.getEntityName(var8);
               if (var2.hasMetadata("DI_CRIT")) {
                  this.sendCritDmgMsg(var3, var9, var10, var2, var8);
               } else if (var2.hasMetadata("DI_DODGE")) {
                  this.sendDodgeMsg(var9, var10, var2, var8);
               } else if (var2.hasMetadata("DI_BLOCK")) {
                  var5 = ((MetadataValue)var2.getMetadata("DI_BLOCK").get(0)).asDouble();
                  this.sendBlockMsg(var5, var9, var10, var2, var8);
               } else {
                  this.sendDamageMsg(var3, var9, var10, var2, var8);
               }
            }

            if (var2 instanceof LivingEntity) {
               LivingEntity var15 = (LivingEntity)var2;
               if (Hook.HOLOGRAPHIC_DISPLAYS.isEnabled() && this.combat_hd_e && !this.plugin.getHM().getHoloHook().isHologram(var2)) {
                  ArrayList var16 = new ArrayList();
                  Iterator var18 = this.f_total.iterator();

                  while(var18.hasNext()) {
                     var9 = (String)var18.next();
                     if (var9.equalsIgnoreCase("%dodge%") && var15.hasMetadata("DI_DODGE")) {
                        var16.add(this.f_dodge);
                        break;
                     }

                     if (var9.equalsIgnoreCase("%crit%") && var15.hasMetadata("DI_CRIT")) {
                        var16.add(this.f_crit);
                     } else if (var9.equalsIgnoreCase("%block%") && var15.hasMetadata("DI_BLOCK")) {
                        var5 = ((MetadataValue)var2.getMetadata("DI_BLOCK").get(0)).asDouble();
                        var16.add(this.f_block);
                     } else if (var9.equalsIgnoreCase("%dmg%")) {
                        Iterator var12 = this.f_dt.keySet().iterator();

                        String var11;
                        double var13;
                        while(var12.hasNext()) {
                           var11 = (String)var12.next();
                           if (var15.hasMetadata("DDT_" + var11)) {
                              var13 = ((MetadataValue)var15.getMetadata("DDT_" + var11).get(0)).asDouble();
                              if (var5 > 0.0D) {
                                 var13 /= var5;
                              }

                              if (var13 > 0.0D) {
                                 var16.add(this.getDamageTypeFormat(var11).replace("%dmg%", String.valueOf(Utils.round3(var13))));
                              }
                           }
                        }

                        var12 = this.f_ds.keySet().iterator();

                        while(var12.hasNext()) {
                           var11 = (String)var12.next();
                           if (var15.hasMetadata("DDS_" + var11)) {
                              var13 = ((MetadataValue)var15.getMetadata("DDS_" + var11).get(0)).asDouble();
                              if (var5 > 0.0D) {
                                 var13 /= var5;
                              }

                              if (var13 > 0.0D) {
                                 var16.add(this.getDamageTypeSource(var11).replace("%dmg%", String.valueOf(Utils.round3(var13))));
                              }
                           }
                        }
                     }
                  }

                  Location var17 = var15.getEyeLocation().clone().add(0.0D, 1.25D, 0.0D);
                  this.plugin.getHM().getHoloHook().createIndicator(var17, var16);
                  this.removeAllMeta(var15);
               } else {
                  this.removeAllMeta(var15);
               }
            }
         }
      }
   }
}
