package su.nightexpress.divineitems.modules.consumes;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Color;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.FurnaceRecipe;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.PotionMeta;
import su.nightexpress.divineitems.DivineItems;
import su.nightexpress.divineitems.DivineListener;
import su.nightexpress.divineitems.Module;
import su.nightexpress.divineitems.api.DivineItemsAPI;
import su.nightexpress.divineitems.cmds.list.ConsumesCommand;
import su.nightexpress.divineitems.config.Lang;
import su.nightexpress.divineitems.config.MyConfig;
import su.nightexpress.divineitems.nbt.NBTItem;
import su.nightexpress.divineitems.nms.VersionUtils;
import su.nightexpress.divineitems.utils.ErrorLog;
import su.nightexpress.divineitems.utils.Utils;

public class ConsumeManager extends DivineListener<DivineItems> implements Module {
   private DivineItems plugin;
   private boolean e;
   private Random r;
   private MyConfig settingsCfg;
   private MyConfig consCfg;
   private ConsumeManager.ConsumeSettings settings;
   private HashMap<String, ConsumeManager.Consume> consumes;
   private HashMap<String, List<ConsumeManager.ConsumeCD>> cd;
   private final String n = this.name().toLowerCase().replace(" ", "_");
   private final String label;
   private final String NBT_KEY_CONS;

   public ConsumeManager(DivineItems var1) {
      super(var1);
      this.label = this.n.replace("_", "");
      this.NBT_KEY_CONS = "DIVINE_CONSUME_ID";
      this.plugin = var1;
      this.e = this.plugin.getCM().getCFG().isModuleEnabled(this.name());
      this.r = new Random();
   }

   public void loadConfig() {
      this.consumes = new HashMap();
      this.cd = new HashMap();
      this.settingsCfg = new MyConfig(this.plugin, "/modules/" + this.n, "settings.yml");
      this.consCfg = new MyConfig(this.plugin, "/modules/" + this.n, "consumables.yml");
      this.setup();
   }

   public boolean isActive() {
      return this.e;
   }

   public boolean isDropable() {
      return true;
   }

   public boolean isResolvable() {
      return true;
   }

   public String name() {
      return "Consumables";
   }

   public String version() {
      return "1.0";
   }

   public void enable() {
      if (this.isActive()) {
         this.plugin.getCommander().registerCmd(this.label, new ConsumesCommand(this.plugin));
         this.loadConfig();
         this.registerListeners();
      }

   }

   public void unload() {
      if (this.isActive()) {
         this.plugin.getCommander().unregisterCmd(this.label);
         this.consumes.clear();
         this.settings = null;
         this.e = false;
         this.unregisterListeners();
      }

   }

   public void reload() {
      this.unload();
      this.enable();
   }

   public void setup() {
      this.setupSettings();
      this.setupConsumes();
   }

   private void setupSettings() {
      FileConfiguration var1 = this.settingsCfg.getConfig();
      boolean var2 = var1.getBoolean("General.PreventEatIfFullHP");
      boolean var3 = var1.getBoolean("General.PreventEatIfFullHunger");
      this.settings = new ConsumeManager.ConsumeSettings(var2, var3);
   }

   private void setupConsumes() {
      FileConfiguration var1 = this.consCfg.getConfig();
      if (var1.contains("Consumables")) {
         Iterator var3 = var1.getConfigurationSection("Consumables").getKeys(false).iterator();

         while(true) {
            while(var3.hasNext()) {
               String var2 = (String)var3.next();
               String var4 = "Consumables." + var2 + ".";
               int var5 = var1.getInt(var4 + "Cooldown");
               String[] var6 = var1.getString(var4 + "Item.Material").split(":");
               Material var7 = Material.getMaterial(var6[0]);
               if (var7 == null) {
                  ErrorLog.sendError(this, var4 + "Item.Material", "Invalid Material!", false);
               } else {
                  ItemStack var8 = new ItemStack(var7, 1, (short)Integer.parseInt(var6[1]));
                  String var9 = ChatColor.translateAlternateColorCodes('&', var1.getString(var4 + "Item.Display"));
                  ArrayList var10 = new ArrayList();
                  Iterator var12 = var1.getStringList(var4 + "Item.Lore").iterator();

                  String var11;
                  while(var12.hasNext()) {
                     var11 = (String)var12.next();
                     var10.add(ChatColor.translateAlternateColorCodes('&', var11));
                  }

                  var11 = var1.getString(var4 + "Item.Extras.Color");
                  boolean var26 = var1.getBoolean(var4 + "Item.Extras.Enchanted");
                  String var13 = var1.getString(var4 + "Item.Extras.SkullHash");
                  List var14 = var1.getStringList(var4 + "Item.Extras.Flags");
                  boolean var15 = var1.getBoolean(var4 + "Item.Extras.Unbreakable");
                  double var16 = var1.getDouble(var4 + "Effects.Health");
                  double var18 = var1.getDouble(var4 + "Effects.Hunger");
                  ArrayList var20 = new ArrayList(var1.getStringList(var4 + "Effects.Actions"));
                  boolean var21 = var1.getBoolean(var4 + "Craft.Workbench.Enabled");
                  List var22 = var1.getStringList(var4 + "Craft.Workbench.Template");
                  boolean var23 = var1.getBoolean(var4 + "Craft.Furnace.Enabled");
                  String var24 = var1.getString(var4 + "Craft.Furnace.Input");
                  ConsumeManager.Consume var25 = new ConsumeManager.Consume(var2.toLowerCase(), var5, var8, var9, var10, var11, var26, var13, var14, var15, var16, var18, var20, var21, var22, var23, var24);
                  var25.registerRecipes();
                  this.consumes.put(var2.toLowerCase(), var25);
               }
            }

            return;
         }
      }
   }

   public ConsumeManager.Consume getConsumeById(String var1) {
      return var1.equalsIgnoreCase("random") ? (ConsumeManager.Consume)(new ArrayList(this.getConsumes())).get(this.r.nextInt(this.getConsumes().size())) : (ConsumeManager.Consume)this.consumes.get(var1.toLowerCase());
   }

   public boolean isConsume(ItemStack var1) {
      return (new NBTItem(var1)).hasKey("DIVINE_CONSUME_ID");
   }

   public String getConsumeId(ItemStack var1) {
      return (new NBTItem(var1)).getString("DIVINE_CONSUME_ID");
   }

   public Collection<ConsumeManager.Consume> getConsumes() {
      return this.consumes.values();
   }

   public List<String> getConsumeNames() {
      ArrayList var1 = new ArrayList();
      Iterator var3 = this.getConsumes().iterator();

      while(var3.hasNext()) {
         ConsumeManager.Consume var2 = (ConsumeManager.Consume)var3.next();
         var1.add(var2.getId());
      }

      return var1;
   }

   public boolean isOnCd(Player var1, String var2) {
      if (!this.cd.containsKey(var1.getName())) {
         return false;
      } else {
         Iterator var4 = ((List)this.cd.get(var1.getName())).iterator();

         while(var4.hasNext()) {
            ConsumeManager.ConsumeCD var3 = (ConsumeManager.ConsumeCD)var4.next();
            if (var3.getFoodId().equalsIgnoreCase(var2)) {
               if (System.currentTimeMillis() > var3.getTimeEnd()) {
                  ((List)this.cd.get(var1.getName())).remove(var3);
                  return false;
               }

               return true;
            }
         }

         return false;
      }
   }

   public int getCooldown(Player var1, String var2) {
      byte var3 = 0;
      Iterator var5 = ((List)this.cd.get(var1.getName())).iterator();

      while(var5.hasNext()) {
         ConsumeManager.ConsumeCD var4 = (ConsumeManager.ConsumeCD)var5.next();
         if (var4.getFoodId().equalsIgnoreCase(var2)) {
            return Utils.transSec(var4.getTimeEnd());
         }
      }

      return var3;
   }

   public void setCd(Player var1, ConsumeManager.Consume var2) {
      ArrayList var3 = new ArrayList();
      if (this.cd.containsKey(var1.getName())) {
         var3 = new ArrayList((Collection)this.cd.get(var1.getName()));
      }

      ConsumeManager.ConsumeCD var4 = new ConsumeManager.ConsumeCD(var2.getId(), System.currentTimeMillis() + (long)var2.getCooldown() * 1000L);
      var3.add(var4);
      this.cd.put(var1.getName(), var3);
   }

   private boolean consume(ItemStack var1, Player var2) {
      if (!this.isConsume(var1)) {
         return true;
      } else {
         String var3 = this.getConsumeId(var1);
         ConsumeManager.Consume var4 = this.getConsumeById(var3);
         if (this.isOnCd(var2, var3)) {
            var2.sendMessage(Lang.Prefix.toMsg() + Lang.Consumables_Cooldown.toMsg().replace("%s", "" + this.getCooldown(var2, var3)));
            return false;
         } else if (var4.getHealth() > 0.0D && this.settings.prevent_FullHp && var2.getHealth() == var2.getMaxHealth()) {
            var2.sendMessage(Lang.Prefix.toMsg() + Lang.Consumables_FullHp.toMsg());
            return false;
         } else if (var4.getHunger() > 0.0D && this.settings.prevent_FullFood && var2.getFoodLevel() >= 20) {
            var2.sendMessage(Lang.Prefix.toMsg() + Lang.Consumables_FullHunger.toMsg());
            return false;
         } else {
            var4.applyEffects(var2);
            if (var4.getCooldown() > 0) {
               this.setCd(var2, var4);
            }

            return true;
         }
      }
   }

   @EventHandler
   public void onConsume(PlayerItemConsumeEvent var1) {
      ItemStack var2 = var1.getItem();
      if (!this.consume(var2, var1.getPlayer())) {
         var1.setCancelled(true);
      }

   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onConsume(PlayerInteractEvent var1) {
      if (var1.getHand() != EquipmentSlot.OFF_HAND) {
         ItemStack var2 = var1.getItem();
         if (var2 != null && var2.getType() != Material.AIR) {
            if (!var2.getType().isEdible()) {
               if (!this.consume(var2, var1.getPlayer())) {
                  var1.setCancelled(true);
               } else if (this.isConsume(var2)) {
                  var2.setAmount(var2.getAmount() - 1);
               }
            }
         }
      }
   }

   public class Consume {
      private String id;
      private int cd;
      private ItemStack mat;
      private String display;
      private List<String> lore;
      private String color;
      private boolean enchant;
      private String hash;
      private List<String> flags;
      private boolean unbreak;
      private double hp;
      private double hunger;
      private List<String> actions;
      private boolean wb;
      private List<String> wb_rec;
      private boolean fur;
      private String fur_rec;

      public Consume(String var2, int var3, ItemStack var4, String var5, List<String> var6, String var7, boolean var8, String var9, List<String> var10, boolean var11, double var12, double var14, List<String> var16, boolean var17, List<String> var18, boolean var19, String var20) {
         this.setId(var2);
         this.setCooldown(var3);
         this.setMaterial(var4);
         this.setDisplay(var5);
         this.setLore(var6);
         this.setColor(var7);
         this.setEnchanted(var8);
         this.setSkullHash(var9);
         this.setFlags(var10);
         this.setUnbreakable(var11);
         this.setHealth(var12);
         this.setHunger(var14);
         this.setActions(var16);
         this.setWorkbench(var17);
         this.setWorkbenchRecipe(var18);
         this.setFurnace(var19);
         this.setFurnaceRecipe(var20);
      }

      public String getId() {
         return this.id;
      }

      public void setId(String var1) {
         this.id = var1;
      }

      public int getCooldown() {
         return this.cd;
      }

      public void setCooldown(int var1) {
         this.cd = var1;
      }

      public ItemStack getMaterial() {
         return this.mat;
      }

      public void setMaterial(ItemStack var1) {
         this.mat = var1;
      }

      public String getDisplay() {
         return this.display;
      }

      public void setDisplay(String var1) {
         this.display = var1;
      }

      public List<String> getLore() {
         return this.lore;
      }

      public void setLore(List<String> var1) {
         this.lore = var1;
      }

      public String getColor() {
         return this.color;
      }

      public void setColor(String var1) {
         this.color = var1;
      }

      public boolean isEnchanted() {
         return this.enchant;
      }

      public void setEnchanted(boolean var1) {
         this.enchant = var1;
      }

      public String getSkullHash() {
         return this.hash;
      }

      public void setSkullHash(String var1) {
         this.hash = var1;
      }

      public List<String> getFlags() {
         return this.flags;
      }

      public void setFlags(List<String> var1) {
         this.flags = var1;
      }

      public boolean isUnbreakable() {
         return this.unbreak;
      }

      public void setUnbreakable(boolean var1) {
         this.unbreak = var1;
      }

      public double getHealth() {
         return this.hp;
      }

      public void setHealth(double var1) {
         this.hp = var1;
      }

      public double getHunger() {
         return this.hunger;
      }

      public void setHunger(double var1) {
         this.hunger = var1;
      }

      public List<String> getActions() {
         return this.actions;
      }

      public void setActions(List<String> var1) {
         this.actions = var1;
      }

      public boolean isWorkbench() {
         return this.wb;
      }

      public void setWorkbench(boolean var1) {
         this.wb = var1;
      }

      public List<String> getWorkbenchRecicpe() {
         return this.wb_rec;
      }

      public void setWorkbenchRecipe(List<String> var1) {
         this.wb_rec = var1;
      }

      public boolean isFurnace() {
         return this.fur;
      }

      public void setFurnace(boolean var1) {
         this.fur = var1;
      }

      public String getFurnaceRecipe() {
         return this.fur_rec;
      }

      public void setFurnaceRecipe(String var1) {
         this.fur_rec = var1;
      }

      public ItemStack build() {
         ItemStack var1 = this.getMaterial().clone();
         UUID var2 = ConsumeManager.this.plugin.getCM().getItemHash(this.id);
         var1 = new ItemStack(Utils.getHashed(var1, this.getSkullHash(), var2));
         ItemMeta var3 = var1.getItemMeta();
         var3.setDisplayName(this.getDisplay());
         var3.setLore(this.getLore());
         Iterator var5 = this.getFlags().iterator();

         while(var5.hasNext()) {
            String var4 = (String)var5.next();

            try {
               ItemFlag var6 = ItemFlag.valueOf(var4.toUpperCase());
               var3.addItemFlags(new ItemFlag[]{var6});
            } catch (IllegalArgumentException var10) {
            }
         }

         var3.spigot().setUnbreakable(this.isUnbreakable());
         var1.setItemMeta(var3);
         if (this.isEnchanted()) {
            var1.addUnsafeEnchantment(Enchantment.LOOT_BONUS_BLOCKS, 1);
         }

         NBTItem var11 = new NBTItem(var1);
         var11.setString("DIVINE_CONSUME_ID", this.getId());
         var1 = var11.getItem();
         if (var1.getType().name().contains("POTION")) {
            PotionMeta var12 = (PotionMeta)var1.getItemMeta();
            String[] var13 = this.getColor().split(",");
            int var7 = Integer.parseInt(var13[0]);
            int var8 = Integer.parseInt(var13[1]);
            int var9 = Integer.parseInt(var13[2]);
            var12.setColor(Color.fromRGB(var7, var8, var9));
            var1.setItemMeta(var12);
         }

         return var11.getItem().clone();
      }

      public void applyEffects(Player var1) {
         var1.setHealth(Math.min(var1.getHealth() + this.getHealth(), var1.getMaxHealth()));
         var1.setFoodLevel((int)((double)var1.getFoodLevel() + this.getHunger()));
         DivineItemsAPI.executeActions(var1, this.actions, (ItemStack)null);
      }

      public void registerRecipes() {
         Bukkit.getRecipesFor(this.build()).clear();
         if (this.isWorkbench()) {
            ShapedRecipe var1;
            if (VersionUtils.Version.getCurrent().isHigher(VersionUtils.Version.v1_11_R1)) {
               try {
                  NamespacedKey var2 = new NamespacedKey(ConsumeManager.this.plugin, "DIVINE_CONSUME_ID" + this.id);
                  var1 = new ShapedRecipe(var2, this.build());
               } catch (IllegalArgumentException var15) {
                  ConsumeManager.this.plugin.getServer().getConsoleSender().sendMessage("§7[§c!§7] §cUnable to register craft recipe for: §f" + this.id);
                  return;
               }
            } else {
               var1 = new ShapedRecipe(this.build());
            }

            var1.shape(new String[]{"ABC", "DEF", "GHI"});
            char[] var17 = new char[]{'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I'};
            int var3 = 0;
            Iterator var5 = this.getWorkbenchRecicpe().iterator();

            while(var5.hasNext()) {
               String var4 = (String)var5.next();
               String[] var6 = var4.split(" , ");
               String[] var10 = var6;
               int var9 = var6.length;

               for(int var8 = 0; var8 < var9; ++var8) {
                  String var7 = var10[var8];
                  String[] var11 = var7.split(":");
                  ItemStack var12 = new ItemStack(Material.getMaterial(var11[0]), 1, (short)Integer.parseInt(var11[1]));
                  var1.setIngredient(var17[var3], var12.getData());
                  ++var3;
               }
            }

            try {
               Bukkit.getServer().addRecipe(var1);
            } catch (IllegalStateException var14) {
            }
         }

         if (this.isFurnace()) {
            String[] var16 = this.getFurnaceRecipe().split(":");
            ItemStack var18 = new ItemStack(Material.getMaterial(var16[0]), 1, (short)Integer.parseInt(var16[1]));
            FurnaceRecipe var19 = new FurnaceRecipe(this.build(), var18.getData());

            try {
               Bukkit.getServer().addRecipe(var19);
            } catch (IllegalStateException var13) {
            }
         }

      }
   }

   public class ConsumeCD {
      private String id;
      private long time;

      public ConsumeCD(String var2, long var3) {
         this.id = var2;
         this.time = var3;
      }

      public String getFoodId() {
         return this.id;
      }

      public long getTimeEnd() {
         return this.time;
      }
   }

   public class ConsumeSettings {
      private boolean prevent_FullHp;
      private boolean prevent_FullFood;

      public ConsumeSettings(boolean var2, boolean var3) {
         this.setPreventOnFullHp(var2);
         this.setPreventOnFullHunger(var3);
      }

      public boolean isPreventOnFullHp() {
         return this.prevent_FullHp;
      }

      public void setPreventOnFullHp(boolean var1) {
         this.prevent_FullHp = var1;
      }

      public boolean isPreventOnFullHunger() {
         return this.prevent_FullFood;
      }

      public void setPreventOnFullHunger(boolean var1) {
         this.prevent_FullFood = var1;
      }
   }
}
