package su.nightexpress.divineitems.modules.customitems;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import org.bukkit.Material;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemStack;
import su.nightexpress.divineitems.DivineItems;
import su.nightexpress.divineitems.Module;
import su.nightexpress.divineitems.cmds.list.CustomItemsCommand;
import su.nightexpress.divineitems.nbt.NBTItem;

public class CustomItemsManager implements Module {
   private DivineItems plugin;
   private boolean e;
   private Random r;
   private final String n = this.name().toLowerCase().replace(" ", "_");
   private final String label;
   private HashMap<String, ItemStack> items;
   private final String NBT_KEY_CI;

   public CustomItemsManager(DivineItems var1) {
      this.label = this.n.replace("_", "");
      this.NBT_KEY_CI = "DI_CI";
      this.plugin = var1;
      this.items = new HashMap();
      this.e = this.plugin.getCM().getCFG().isModuleEnabled(this.name());
      this.r = new Random();
   }

   public void loadConfig() {
      this.setupCustomItems();
   }

   public boolean isActive() {
      return this.e;
   }

   public boolean isDropable() {
      return true;
   }

   public boolean isResolvable() {
      return false;
   }

   public String name() {
      return "Custom Items";
   }

   public String version() {
      return "1.0";
   }

   public void enable() {
      this.plugin.getCommander().registerCmd(this.label, new CustomItemsCommand(this.plugin));
      this.loadConfig();
   }

   public void unload() {
      if (this.isActive()) {
         this.plugin.getCommander().unregisterCmd(this.label);
         this.items.clear();
         this.e = false;
      }

   }

   public void reload() {
      this.unload();
      this.enable();
   }

   private void setupCustomItems() {
      Iterator var2 = this.listf("/modules/" + this.n + "/").iterator();

      while(var2.hasNext()) {
         File var1 = (File)var2.next();
         ItemStack var3 = this.loadFromConfig(var1);
         this.items.put(var1.getPath().split(this.n)[1].replaceAll("\\\\", "/").replaceFirst("\\/", "").replace(".yml", "").toLowerCase(), var3);
      }

   }

   public boolean isCustomItem(ItemStack var1) {
      return (new NBTItem(var1)).hasKey("DI_CI");
   }

   public ItemStack loadFromConfig(File var1) {
      new YamlConfiguration();
      YamlConfiguration var2 = YamlConfiguration.loadConfiguration(var1);
      ItemStack var3 = var2.getItemStack("Item");
      NBTItem var4 = new NBTItem(var3);
      var4.setString("DI_CI", var1.getName().replace(".yml", ""));
      return var4.getItem();
   }

   private List<File> listf(String var1) {
      File var2 = new File(this.plugin.getDataFolder() + var1);
      ArrayList var3 = new ArrayList();
      File[] var4 = var2.listFiles();
      if (var4 == null) {
         return var3;
      } else {
         File[] var8 = var4;
         int var7 = var4.length;

         for(int var6 = 0; var6 < var7; ++var6) {
            File var5 = var8[var6];
            if (var5.isFile()) {
               var3.add(var5);
            } else if (var5.isDirectory()) {
               var3.addAll(this.listf("/modules/" + this.n + "/" + var5.getName() + "/"));
            }
         }

         return var3;
      }
   }

   public boolean removeCustomItem(String var1) {
      var1 = var1.toLowerCase();
      if (!this.items.containsKey(var1)) {
         return false;
      } else {
         this.items.remove(var1);
         File var2 = new File(this.plugin.getDataFolder() + "/modules/" + this.n + "/", var1 + ".yml");
         var2.delete();
         return true;
      }
   }

   public void saveCustomItem(ItemStack var1, String var2) {
      var2 = var2.toLowerCase();
      File var3 = new File(this.plugin.getDataFolder() + "/modules/" + this.n + "/", var2 + ".yml");
      if (!var3.exists()) {
         var3.getParentFile().mkdirs();

         try {
            var3.createNewFile();
         } catch (IOException var7) {
            var7.printStackTrace();
         }
      }

      var3 = new File(this.plugin.getDataFolder() + "/modules/" + this.n + "/", var2 + ".yml");
      YamlConfiguration var4 = YamlConfiguration.loadConfiguration(var3);
      var4.set("Item", var1);

      try {
         var4.save(new File(this.plugin.getDataFolder() + "/modules/" + this.n + "/", var2 + ".yml"));
      } catch (IOException var6) {
      }

      this.items.put(var2, var1);
   }

   public ItemStack getCustomItem(String var1) {
      if (var1.equalsIgnoreCase("random")) {
         return (ItemStack)this.items.get(this.getCustomItemsNames().get(this.r.nextInt(this.getCustomItemsNames().size())));
      } else if (this.items.get(var1.toLowerCase()) == null) {
         return new ItemStack(Material.AIR);
      } else {
         ItemStack var2 = ((ItemStack)this.items.get(var1.toLowerCase())).clone();
         if (this.plugin.getMM().getSetManager().isActive()) {
            var2 = this.plugin.getMM().getSetManager().replaceLore(var2);
         }

         return var2;
      }
   }

   public List<String> getCustomItemsNames() {
      return new ArrayList(this.items.keySet());
   }
}
