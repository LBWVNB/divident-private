package su.nightexpress.divineitems.modules.drops;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Random;
import java.util.Set;
import org.bukkit.Material;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Animals;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Monster;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.scheduler.BukkitRunnable;
import su.nightexpress.divineitems.DivineItems;
import su.nightexpress.divineitems.DivineListener;
import su.nightexpress.divineitems.Module;
import su.nightexpress.divineitems.api.EntityAPI;
import su.nightexpress.divineitems.attributes.ItemStat;
import su.nightexpress.divineitems.config.Lang;
import su.nightexpress.divineitems.hooks.Hook;
import su.nightexpress.divineitems.modules.enchant.EnchantManager;
import su.nightexpress.divineitems.modules.tiers.TierManager;
import su.nightexpress.divineitems.utils.ItemUtils;
import su.nightexpress.divineitems.utils.Utils;

public class DropManager extends DivineListener<DivineItems> implements Module {
   private DivineItems plugin;
   private boolean e;
   private HashMap<Module, DropManager.Drops> drops;
   private final String nodrop = "NO_DROP:";

   public DropManager(DivineItems var1) {
      super(var1);
      this.plugin = var1;
      this.drops = new HashMap();
      this.e = var1.getCM().getCFG().isModuleEnabled(this.name());
   }

   public void loadConfig() {
      Iterator var2 = this.plugin.getMM().getModules().iterator();

      while(true) {
         Module var1;
         File var3;
         do {
            do {
               do {
                  if (!var2.hasNext()) {
                     return;
                  }

                  var1 = (Module)var2.next();
               } while(!var1.isDropable());
            } while(!var1.isActive());

            var3 = new File(this.plugin.getDataFolder() + "/modules/drops/", var1.name().toLowerCase().replace(" ", "_") + ".yml");
         } while(!var3.exists());

         YamlConfiguration var4 = YamlConfiguration.loadConfiguration(var3);
         if (!var4.contains("General.RollOnce")) {
            var4.set("General.RollOnce", false);
         }

         double var5 = var4.getDouble("General.Chance");
         boolean var7 = var4.getBoolean("General.RollOnce");
         LinkedHashMap var8 = new LinkedHashMap();
         Iterator var10 = var4.getConfigurationSection("General.Multipliers").getKeys(false).iterator();

         while(var10.hasNext()) {
            String var9 = (String)var10.next();
            double var11 = var4.getDouble("Global.Multipliers." + var9);
            var8.put(var9, var11);
         }

         HashSet var38 = new HashSet(var4.getStringList("General.Worlds"));
         boolean var39 = var4.getBoolean("General.NoDropInRegions.Reverse");
         HashSet var40 = new HashSet(var4.getStringList("General.NoDropInRegions.List"));
         boolean var12 = var4.getBoolean("General.BiomesWhitelist.Reverse");
         HashSet var13 = new HashSet(var4.getStringList("General.BiomesWhitelist.List"));
         HashSet var14 = new HashSet(var4.getStringList("General.EntityTypes"));
         HashSet var15 = new HashSet(var4.getStringList("General.MythicMobs"));
         HashSet var16 = new HashSet(var4.getStringList("General.PreventFrom"));
         boolean var17 = var4.getBoolean("General.DropLevelPenalty.Enabled", false);
         int var18 = var4.getInt("General.DropLevelPenalty.Variance");
         DropManager.DropGlobalSettings var19 = new DropManager.DropGlobalSettings(var5, var7, var8, var38, var39, var40, var12, var13, var14, var15, var16, var17, var18);
         HashMap var20 = new HashMap();
         HashMap var21 = new HashMap();
         if (var4.contains("Items")) {
            Iterator var23 = var4.getConfigurationSection("Items").getKeys(false).iterator();

            while(var23.hasNext()) {
               String var22 = (String)var23.next();
               String var24 = "Items." + var22 + ".";
               double var25 = var4.getDouble(var24 + "Chance");
               HashMap var27 = new HashMap();
               if (var4.contains(var24 + "Worlds")) {
                  Iterator var29 = var4.getConfigurationSection(var24 + "Worlds").getKeys(false).iterator();

                  while(var29.hasNext()) {
                     String var28 = (String)var29.next();
                     String var30 = var4.getString(var24 + "Worlds." + var28 + ".levels");
                     var27.put(var28, var30);
                  }
               }

               boolean var42 = var4.getBoolean(var24 + "NoDropInRegions.Reverse");
               HashMap var43 = new HashMap();
               Object[] var44 = var4.getConfigurationSection(var24 + "NoDropInRegions.List").getKeys(false).toArray();
               Object[] var34 = var44;
               int var33 = var44.length;

               for(int var32 = 0; var32 < var33; ++var32) {
                  Object var31 = var34[var32];
                  String var35 = var31.toString();
                  String var36 = var4.getString(var24 + "NoDropInRegions.List." + var35 + ".levels");
                  var43.put(var35, var36);
               }

               HashSet var45 = new HashSet(var4.getStringList(var24 + "EntityTypes"));
               HashSet var46 = new HashSet(var4.getStringList(var24 + "MythicMobs"));
               HashSet var47 = new HashSet(var4.getStringList(var24 + "PreventFrom"));
               DropManager.DropItemSettings var48 = new DropManager.DropItemSettings(var25, var27, var42, var43, var45, var46, var47);
               var20.put(var22.toLowerCase(), var48);
               var21.put(var22, var25);
            }
         }

         var21 = (HashMap)Utils.sortByValue(var21);
         DropManager.Drops var41 = new DropManager.Drops(var19, var20, var21);
         this.drops.put(var1, var41);

         try {
            var4.save(var3);
         } catch (IOException var37) {
            var37.printStackTrace();
         }
      }
   }

   public boolean isDropable() {
      return false;
   }

   public boolean isResolvable() {
      return false;
   }

   public boolean isActive() {
      return this.e;
   }

   public String name() {
      return "Drops";
   }

   public String version() {
      return "2.0";
   }

   public void enable() {
      if (this.isActive()) {
         this.loadConfig();
         this.registerListeners();
      }

   }

   public void unload() {
      if (this.isActive()) {
         this.drops.clear();
         this.e = false;
         this.unregisterListeners();
      }

   }

   public void reload() {
      this.unload();
      this.enable();
   }

   private boolean checkRegion(DropManager.DropGlobalSettings var1, LivingEntity var2) {
      if (!Hook.WORLD_GUARD.isEnabled()) {
         return true;
      } else {
         String var3;
         Iterator var4;
         if (var1.isRegionReversed()) {
            var4 = var1.getRegions().iterator();

            while(var4.hasNext()) {
               var3 = (String)var4.next();
               if (this.plugin.getHM().getWorldGuard().isInRegion(var2, var3)) {
                  return true;
               }
            }

            return false;
         } else {
            var4 = var1.getRegions().iterator();

            while(var4.hasNext()) {
               var3 = (String)var4.next();
               if (this.plugin.getHM().getWorldGuard().isInRegion(var2, var3)) {
                  return false;
               }
            }

            return true;
         }
      }
   }

   private boolean checkRegion(DropManager.DropItemSettings var1, LivingEntity var2) {
      if (!Hook.WORLD_GUARD.isEnabled()) {
         return true;
      } else {
         String var3;
         Iterator var4;
         if (var1.isRegionReversed()) {
            var4 = var1.getRegions().keySet().iterator();

            while(var4.hasNext()) {
               var3 = (String)var4.next();
               if (this.plugin.getHM().getWorldGuard().isInRegion(var2, var3)) {
                  return true;
               }
            }

            return false;
         } else {
            var4 = var1.getRegions().keySet().iterator();

            while(var4.hasNext()) {
               var3 = (String)var4.next();
               if (this.plugin.getHM().getWorldGuard().isInRegion(var2, var3)) {
                  return false;
               }
            }

            return true;
         }
      }
   }

   private boolean checkBiome(DropManager.DropGlobalSettings var1, LivingEntity var2) {
      String var3 = var2.getLocation().getBlock().getBiome().name();
      String var4;
      Iterator var5;
      if (var1.isBiomesReversed()) {
         var5 = var1.getBiomes().iterator();

         do {
            if (!var5.hasNext()) {
               return true;
            }

            var4 = (String)var5.next();
         } while(!var4.equalsIgnoreCase(var3) && !var4.equalsIgnoreCase("ANY"));

         return false;
      } else {
         var5 = var1.getBiomes().iterator();

         do {
            if (!var5.hasNext()) {
               return false;
            }

            var4 = (String)var5.next();
         } while(!var4.equalsIgnoreCase(var3) && !var4.equalsIgnoreCase("ANY"));

         return true;
      }
   }

   private boolean checkEntity(DropManager.DropGlobalSettings var1, LivingEntity var2, String var3) {
      if (var2.hasMetadata("NO_DROP:" + var3)) {
         return false;
      } else {
         if (Hook.MYTHIC_MOBS.isEnabled() && this.plugin.getHM().getMythicHook().isMythicMob(var2)) {
            String var4 = this.plugin.getHM().getMythicHook().getMythicNameByEntity(var2);
            if (var1.getMythics().contains("ALL")) {
               return true;
            }

            if (var1.getMythics().contains(var4)) {
               return true;
            }
         } else {
            if (var1.getEntities() != null && var1.getEntities().contains("ALL")) {
               return true;
            }

            if (var2 instanceof Animals && var1.getEntities().contains("PASSIVE")) {
               return true;
            }

            if (var2 instanceof Monster && var1.getEntities().contains("HOSTILE")) {
               return true;
            }

            if (var1.getEntities().contains(var2.getType().name())) {
               return true;
            }
         }

         return false;
      }
   }

   private boolean checkEntity(DropManager.DropItemSettings var1, LivingEntity var2, String var3) {
      if (var2.hasMetadata("NO_DROP:" + var3)) {
         return false;
      } else {
         if (Hook.MYTHIC_MOBS.isEnabled() && this.plugin.getHM().getMythicHook().isMythicMob(var2)) {
            String var4 = this.plugin.getHM().getMythicHook().getMythicNameByEntity(var2);
            if (var1.getMythics().contains("ALL")) {
               return true;
            }

            if (var1.getMythics().contains(var4)) {
               return true;
            }
         } else {
            if (var1.getEntities() != null && var1.getEntities().contains("ALL")) {
               return true;
            }

            if (var2 instanceof Animals && var1.getEntities().contains("PASSIVE")) {
               return true;
            }

            if (var2 instanceof Monster && var1.getEntities().contains("HOSTILE")) {
               return true;
            }

            if (var1.getEntities().contains(var2.getType().name())) {
               return true;
            }
         }

         return false;
      }
   }

   public ItemStack getDropItem(Player var1, String var2, String var3, int var4) {
      ItemStack var5 = new ItemStack(Material.AIR);
      switch(var3.hashCode()) {
      case -1850668115:
         if (var3.equals("Repair")) {
            var5 = this.plugin.getMM().getRepairManager().getGem().getItemGem(var4);
         }
         break;
      case -947662255:
         if (var3.equals("Custom Items")) {
            var5 = this.plugin.getMM().getCustomItemsManager().getCustomItem(var2);
         }
         break;
      case -790637179:
         if (var3.equals("Magic Dust")) {
            if (this.plugin.getMM().getMagicDustManager().getDustById(var2) == null) {
               return var5;
            }

            var5 = this.plugin.getMM().getMagicDustManager().getDustById(var2).create(var4);
         }
         break;
      case -703624410:
         if (var3.equals("Scrolls")) {
            if (this.plugin.getMM().getScrollManager().getScrollById(var2) == null) {
               return var5;
            }

            var5 = this.plugin.getMM().getScrollManager().getScrollById(var2).create(var4);
         }
         break;
      case -632618200:
         if (var3.equals("Abilities")) {
            if (this.plugin.getMM().getAbilityManager().getAbilityById(var2) == null) {
               return var5;
            }

            var5 = this.plugin.getMM().getAbilityManager().getAbilityById(var2).create(var4);
         }
         break;
      case -71118036:
         if (var3.equals("Identify")) {
            String[] var9 = var2.split("-");
            if (var9.length == 2) {
               if (var9[0].equalsIgnoreCase("tome")) {
                  if (this.plugin.getMM().getIdentifyManager().getTomeById(var9[1]) == null) {
                     return var5;
                  }

                  var5 = this.plugin.getMM().getIdentifyManager().getTomeById(var9[1]).create();
               } else {
                  if (this.plugin.getMM().getIdentifyManager().getItemById(var9[1]) == null) {
                     return var5;
                  }

                  var5 = this.plugin.getMM().getIdentifyManager().getItemById(var9[1]).create(var4);
               }
            }
         }
         break;
      case 2215716:
         if (var3.equals("Gems")) {
            if (this.plugin.getMM().getGemManager().getGemById(var2) == null) {
               return var5;
            }

            var5 = this.plugin.getMM().getGemManager().getGemById(var2).create(var4);
         }
         break;
      case 79323225:
         if (var3.equals("Runes")) {
            if (this.plugin.getMM().getRuneManager().getRuneById(var2) == null) {
               return var5;
            }

            var5 = this.plugin.getMM().getRuneManager().getRuneById(var2).create(var4);
         }
         break;
      case 80804529:
         if (var3.equals("Tiers")) {
            if (this.plugin.getMM().getTierManager().getTierById(var2) == null) {
               return var5;
            }

            var5 = this.plugin.getMM().getTierManager().getTierById(var2).create(var4, (Material)null);
            String var7 = this.plugin.getMM().getTierManager().getTierId(var5);
            TierManager.Tier var8 = this.plugin.getMM().getTierManager().getTierById(var7);
            if (var8.isBroadcast() && !var8.isEquipOnEntity()) {
               this.plugin.getServer().broadcastMessage(Lang.Other_Broadcast.toMsg().replace("%p", var1.getName()).replace("%item%", var5.getItemMeta().getDisplayName()));
            }
         }
         break;
      case 805312080:
         if (var3.equals("Consumables")) {
            if (this.plugin.getMM().getConsumeManager().getConsumeById(var2) == null) {
               return var5;
            }

            var5 = this.plugin.getMM().getConsumeManager().getConsumeById(var2).build();
         }
         break;
      case 1769317210:
         if (var3.equals("Enchants")) {
            if (var2.equalsIgnoreCase("random")) {
               var5 = this.plugin.getMM().getEnchantManager().getRandomEnchant().create(var4);
            } else {
               var5 = this.plugin.getMM().getEnchantManager().getEnchantByType(EnchantManager.EnchantType.valueOf(var2.toUpperCase())).create(var4);
            }
         }
         break;
      case 1809054010:
         if (var3.equals("Abyss Dust")) {
            if (this.plugin.getMM().getAbyssDustManager().getDustById(var2) == null) {
               return var5;
            }

            var5 = this.plugin.getMM().getAbyssDustManager().getDustById(var2).create();
         }
      }

      return var5;
   }

   private boolean checkPenalty(Player var1, LivingEntity var2, DropManager.DropGlobalSettings var3) {
      if (Hook.MYTHIC_MOBS.isEnabled() && this.plugin.getHM().getMythicHook().isMythicMob(var2) && var3.isLevelPenalty()) {
         int var4 = var3.getPenaltyVariance();
         int var5 = this.plugin.getHM().getMythicHook().getLevel(var2);
         int var6 = this.plugin.getHM().getLevelsHook().getPlayerLevel(var1);
         if (var6 > var5 && var6 - var5 >= var4) {
            return false;
         }
      }

      return true;
   }

   public List<ItemStack> methodRoll(Player var1, LivingEntity var2, boolean var3) {
      ArrayList var4 = new ArrayList();
      Iterator var6 = this.drops.keySet().iterator();

      label154:
      while(true) {
         Module var5;
         DropManager.Drops var7;
         DropManager.DropGlobalSettings var8;
         ArrayList var18;
         String var21;
         Iterator var22;
         ArrayList var28;
         do {
            double var11;
            do {
               do {
                  do {
                     do {
                        double var9;
                        do {
                           do {
                              do {
                                 do {
                                    do {
                                       if (!var6.hasNext()) {
                                          return var4;
                                       }

                                       var5 = (Module)var6.next();
                                    } while(var3 && !var5.name().equals("Tiers"));

                                    var7 = (DropManager.Drops)this.drops.get(var5);
                                    var8 = var7.getGlobalSettings();
                                 } while(!this.checkPenalty(var1, var2, var8));

                                 var9 = Utils.getRandDouble(0.0D, 100.0D);
                                 var11 = EntityAPI.getItemStat(var1, ItemStat.LOOT_RATE) / 100.0D;
                                 var9 = this.getMultiplier(var1, var9, var5, var8);
                                 var9 *= 1.0D - var11;
                              } while(var9 == 0.0D);
                           } while(var9 > var8.getRate());
                        } while(var8.getRate() <= 0.0D);
                     } while(!var8.getWorlds().contains(var1.getWorld().getName()));
                  } while(!this.checkEntity(var8, var2, var5.name()));
               } while(!this.checkBiome(var8, var2));
            } while(!this.checkRegion((DropManager.DropGlobalSettings)var8, var1));

            double var13 = 0.0D;

            double var15;
            for(Iterator var17 = var7.getItemRates().values().iterator(); var17.hasNext(); var13 = var15) {
               var15 = (Double)var17.next();
            }

            var15 = Utils.getRandDouble(0.0D, var13);
            var15 = Math.min(var15 * (1.0D - var11), var13);
            var28 = new ArrayList();
            var18 = new ArrayList();
            double var19 = 0.0D;
            var22 = var7.getItemRates().keySet().iterator();

            while(var22.hasNext()) {
               var21 = (String)var22.next();
               if (var15 > 0.0D && var15 <= (Double)var7.getItemRates().get(var21)) {
                  var19 = (Double)var7.getItemRates().get(var21);
                  break;
               }
            }

            var22 = var7.getItemRates().keySet().iterator();

            while(var22.hasNext()) {
               var21 = (String)var22.next();
               if ((Double)var7.getItemRates().get(var21) == var19) {
                  var28.add(var21);
               }
            }
         } while(var28.isEmpty());

         if (var8.isRollOnce()) {
            var21 = (String)var28.get((new Random()).nextInt(var28.size()));
            var18.add(var21);
         } else {
            var18.addAll(var28);
         }

         var22 = var18.iterator();

         while(true) {
            DropManager.DropItemSettings var23;
            String var24;
            do {
               do {
                  do {
                     do {
                        if (!var22.hasNext()) {
                           continue label154;
                        }

                        var21 = (String)var22.next();
                        var23 = var7.getItemSettings(var21);
                     } while(var23 == null);
                  } while(!this.checkEntity(var23, var2, var5.name()));

                  var24 = var1.getWorld().getName();
               } while(!var23.getWorlds().containsKey(var24));
            } while(!this.checkRegion((DropManager.DropItemSettings)var23, var1));

            boolean var25 = false;
            int var29;
            if (Hook.WORLD_GUARD.isEnabled() && var23.getRegions().containsKey(this.plugin.getHM().getWorldGuard().getRegion(var1))) {
               String var26 = this.plugin.getHM().getWorldGuard().getRegion(var1);
               String var27 = (String)var23.getRegions().get(var26);
               var29 = this.getItemLevel(var1, var2, var27);
            } else {
               var29 = this.getItemLevel(var1, var2, (String)var23.getWorlds().get(var24));
            }

            ItemStack var30 = this.getDropItem(var1, var21, var5.name(), var29);
            if (var30 != null && var30.getType() != Material.AIR) {
               var4.add(var30);
            }
         }
      }
   }

   private int getItemLevel(Player var1, LivingEntity var2, String var3) {
      double var4 = 0.0D;
      double var6 = 0.0D;
      int var8 = this.plugin.getHM().getLevelsHook().getPlayerLevel(var1);
      int var9 = 0;
      if (Hook.MYTHIC_MOBS.isEnabled() && this.plugin.getHM().getMythicHook().isMythicMob(var2)) {
         var9 = this.plugin.getHM().getMythicHook().getLevel(var2);
      }

      var3 = var3.replace("%mob.lvl%", String.valueOf(var9)).replace("%player.lvl%", String.valueOf(var8));
      if (!var3.contains("<") && !var3.contains(">")) {
         String[] var14 = var3.split("-");
         var4 = (double)Integer.parseInt(var14[0]);
         if (var14.length == 2) {
            var6 = (double)Integer.parseInt(var14[1]);
         } else {
            var6 = var4;
         }

         return Utils.randInt((int)var4, (int)var6);
      } else {
         int var10;
         int var11;
         String var12;
         String var13;
         if (var3.startsWith("<") && var3.endsWith(">")) {
            var10 = var3.indexOf("<");
            var11 = var3.indexOf(">");
            var12 = var3.substring(var10 + 1, var11);
            var4 = ItemUtils.calc(var12);
            var10 = var3.lastIndexOf("<");
            var11 = var3.lastIndexOf(">");
            var13 = var3.substring(var10 + 1, var11);
            var6 = ItemUtils.calc(var13);
         } else if (var3.startsWith("<") && !var3.endsWith(">")) {
            var10 = var3.indexOf("<");
            var11 = var3.indexOf(">");
            var12 = var3.substring(var10 + 1, var11);
            var4 = ItemUtils.calc(var12);
            var13 = var3.substring(var11 + 2);
            var6 = (double)Integer.parseInt(var13);
         } else if (!var3.startsWith("<") && var3.endsWith(">")) {
            var10 = var3.lastIndexOf("<");
            var11 = var3.lastIndexOf(">");
            var12 = var3.substring(var10 + 1, var11);
            var6 = ItemUtils.calc(var12);
            var13 = var3.substring(0, var10 - 1);
            var4 = (double)Integer.parseInt(var13);
         }

         return Utils.randInt((int)var4, (int)var6);
      }
   }

   private double getMultiplier(Player var1, double var2, Module var4, DropManager.DropGlobalSettings var5) {
      double var6 = 1.0D;
      String var8 = "ditems.drop." + var4.name().toLowerCase().replace(" ", "_") + ".";
      Iterator var10 = var5.getMultipliers().keySet().iterator();

      while(var10.hasNext()) {
         String var9 = (String)var10.next();
         if (var1.hasPermission(var8 + var9)) {
            double var11 = (Double)var5.getMultipliers().get(var9);
            if (var11 > 0.0D) {
               var6 = var11 - 1.0D;
            } else {
               var6 = var11 + 1.0D;
            }
         }
      }

      return var2 * var6;
   }

   private void equip(LivingEntity var1, ItemStack var2) {
      if (var2.getType().name().endsWith("_HELMET")) {
         var1.getEquipment().setHelmet(var2);
         var1.getEquipment().setHelmetDropChance(1.0F);
      } else if (var2.getType().name().endsWith("_CHESTPLATE")) {
         var1.getEquipment().setChestplate(var2);
         var1.getEquipment().setChestplateDropChance(1.0F);
      } else if (var2.getType().name().endsWith("_LEGGINGS")) {
         var1.getEquipment().setLeggings(var2);
         var1.getEquipment().setLeggingsDropChance(1.0F);
      } else if (var2.getType().name().endsWith("_BOOTS")) {
         var1.getEquipment().setBoots(var2);
         var1.getEquipment().setBootsDropChance(1.0F);
      } else if (var2.getType().name().endsWith("SHIELD")) {
         var1.getEquipment().setItemInOffHand(var2);
         var1.getEquipment().setItemInOffHandDropChance(1.0F);
      } else {
         var1.getEquipment().setItemInMainHand(var2);
         var1.getEquipment().setItemInMainHandDropChance(1.0F);
      }

   }

   @EventHandler(
      priority = EventPriority.HIGH
   )
   public void onDrop(EntityDeathEvent var1) {
      Player var2 = var1.getEntity().getKiller();
      if (var2 != null) {
         LivingEntity var3 = var1.getEntity();
         if (!Hook.MYTHIC_MOBS.isEnabled() || !this.plugin.getHM().getMythicHook().isMythicMob(var3)) {
            if (var1.getDrops() != null) {
               var1.getDrops().addAll(this.methodRoll(var2, var3, false));
            }
         }
      }
   }

   @EventHandler(
      priority = EventPriority.HIGHEST,
      ignoreCancelled = true
   )
   public void onSpawn(final CreatureSpawnEvent var1) {
      if (var1.getEntity().getEquipment() != null && !(var1.getEntity() instanceof ArmorStand)) {
         (new BukkitRunnable() {
            public void run() {
               LivingEntity var1x = var1.getEntity();
               if (!Hook.MYTHIC_MOBS.isEnabled() || !DropManager.this.plugin.getHM().getMythicHook().isMythicMob(var1x)) {
                  Iterator var3 = DropManager.this.drops.keySet().iterator();

                  while(true) {
                     while(var3.hasNext()) {
                        Module var2 = (Module)var3.next();
                        DropManager.Drops var4 = (DropManager.Drops)DropManager.this.drops.get(var2);
                        DropManager.DropGlobalSettings var5 = var4.getGlobalSettings();
                        String var6 = var1.getSpawnReason().name();
                        if (var5.getReasons().contains(var6)) {
                           var1x.setMetadata("NO_DROP:" + var2.name(), new FixedMetadataValue(DropManager.this.plugin, "yeah"));
                        } else if (var2.name().equals("Tiers")) {
                           Player var7 = null;
                           Iterator var9 = var1x.getNearbyEntities(30.0D, 5.0D, 30.0D).iterator();

                           while(var9.hasNext()) {
                              Entity var8 = (Entity)var9.next();
                              if (var8 instanceof Player && (!Hook.CITIZENS.isEnabled() || !DropManager.this.plugin.getHM().getCitizens().isNPC(var8))) {
                                 var7 = (Player)var8;
                                 break;
                              }
                           }

                           if (var7 != null && DropManager.this.checkPenalty(var7, var1x, var5)) {
                              List var12 = DropManager.this.methodRoll(var7, var1x, true);
                              if (!var12.isEmpty()) {
                                 ItemStack var13 = (ItemStack)var12.get(0);
                                 if (var13 != null) {
                                    String var10 = DropManager.this.plugin.getMM().getTierManager().getTierId(var13);
                                    TierManager.Tier var11 = DropManager.this.plugin.getMM().getTierManager().getTierById(var10);
                                    if (var11.isEquipOnEntity()) {
                                       DropManager.this.equip(var1x, var13);
                                       var1x.setMetadata("NO_DROP:" + var2.name(), new FixedMetadataValue(DropManager.this.plugin, "yeah"));
                                    }
                                 }
                              }
                           }
                        }
                     }

                     return;
                  }
               }
            }
         }).runTaskLater(this.plugin, 1L);
      }
   }

   public class DropGlobalSettings {
      private double rate;
      private boolean once;
      private LinkedHashMap<String, Double> mult;
      private Set<String> worlds;
      private boolean reg_reverse;
      private Set<String> reg_list;
      private boolean biome_reverse;
      private Set<String> biome_list;
      private Set<String> entity;
      private Set<String> mythic;
      private Set<String> reasons;
      private boolean lvl_penal;
      private int lvl_penalVar;

      public DropGlobalSettings(double var2, boolean var4, LinkedHashMap<String, Double> var5, Set<String> var6, boolean var7, Set<String> var8, boolean var9, Set<String> var10, Set<String> var11, Set<String> var12, Set<String> var13, boolean var14, int var15) {
         this.setRate(var2);
         this.setRollOnce(var4);
         this.setMultipliers(var5);
         this.setWorlds(var6);
         this.setRegionReversed(var7);
         this.setRegions(var8);
         this.setBiomesReversed(var9);
         this.setBiomes(var10);
         this.setEntities(var11);
         this.setMythics(var12);
         this.setReasons(var13);
         this.setLevelPenalty(var14);
         this.setPenaltyVariance(var15);
      }

      public double getRate() {
         return this.rate;
      }

      public void setRate(double var1) {
         this.rate = var1;
      }

      public boolean isRollOnce() {
         return this.once;
      }

      public void setRollOnce(boolean var1) {
         this.once = var1;
      }

      public LinkedHashMap<String, Double> getMultipliers() {
         return this.mult;
      }

      public void setMultipliers(LinkedHashMap<String, Double> var1) {
         this.mult = var1;
      }

      public Set<String> getWorlds() {
         return this.worlds;
      }

      public void setWorlds(Set<String> var1) {
         this.worlds = var1;
      }

      public boolean isRegionReversed() {
         return this.reg_reverse;
      }

      public void setRegionReversed(boolean var1) {
         this.reg_reverse = var1;
      }

      public Set<String> getRegions() {
         return this.reg_list;
      }

      public void setRegions(Set<String> var1) {
         this.reg_list = var1;
      }

      public boolean isBiomesReversed() {
         return this.biome_reverse;
      }

      public void setBiomesReversed(boolean var1) {
         this.biome_reverse = var1;
      }

      public Set<String> getBiomes() {
         return this.biome_list;
      }

      public void setBiomes(Set<String> var1) {
         this.biome_list = var1;
      }

      public Set<String> getEntities() {
         return this.entity;
      }

      public void setEntities(Set<String> var1) {
         this.entity = var1;
      }

      public Set<String> getMythics() {
         return this.mythic;
      }

      public void setMythics(Set<String> var1) {
         this.mythic = var1;
      }

      public Set<String> getReasons() {
         return this.reasons;
      }

      public void setReasons(Set<String> var1) {
         this.reasons = var1;
      }

      public boolean isLevelPenalty() {
         return this.lvl_penal;
      }

      public void setLevelPenalty(boolean var1) {
         this.lvl_penal = var1;
      }

      public int getPenaltyVariance() {
         return this.lvl_penalVar;
      }

      public void setPenaltyVariance(int var1) {
         this.lvl_penalVar = var1;
      }
   }

   public class DropItemSettings {
      private double rate;
      private HashMap<String, String> worlds;
      private boolean reg_reverse;
      private HashMap<String, String> reg_list;
      private Set<String> entity;
      private Set<String> mythic;
      private Set<String> reasons;

      public DropItemSettings(double var2, HashMap<String, String> var4, boolean var5, HashMap<String, String> var6, Set<String> var7, Set<String> var8, Set<String> var9) {
         this.setRate(var2);
         this.setWorlds(var4);
         this.setRegionReversed(var5);
         this.setRegions(var6);
         this.setEntities(var7);
         this.setMythics(var8);
         this.setReasons(var9);
      }

      public double getRate() {
         return this.rate;
      }

      public void setRate(double var1) {
         this.rate = var1;
      }

      public HashMap<String, String> getWorlds() {
         return this.worlds;
      }

      public void setWorlds(HashMap<String, String> var1) {
         this.worlds = var1;
      }

      public boolean isRegionReversed() {
         return this.reg_reverse;
      }

      public void setRegionReversed(boolean var1) {
         this.reg_reverse = var1;
      }

      public HashMap<String, String> getRegions() {
         return this.reg_list;
      }

      public void setRegions(HashMap<String, String> var1) {
         this.reg_list = var1;
      }

      public Set<String> getEntities() {
         return this.entity;
      }

      public void setEntities(Set<String> var1) {
         this.entity = var1;
      }

      public Set<String> getMythics() {
         return this.mythic;
      }

      public void setMythics(Set<String> var1) {
         this.mythic = var1;
      }

      public Set<String> getReasons() {
         return this.reasons;
      }

      public void setReasons(Set<String> var1) {
         this.reasons = var1;
      }
   }

   public class Drops {
      private DropManager.DropGlobalSettings global;
      private HashMap<String, DropManager.DropItemSettings> items;
      private HashMap<String, Double> rates;

      public Drops(DropManager.DropGlobalSettings var2, HashMap<String, DropManager.DropItemSettings> var3, HashMap<String, Double> var4) {
         this.global = var2;
         this.items = var3;
         this.rates = var4;
      }

      public DropManager.DropGlobalSettings getGlobalSettings() {
         return this.global;
      }

      public HashMap<String, DropManager.DropItemSettings> getItemsMap() {
         return this.items;
      }

      public DropManager.DropItemSettings getItemSettings(String var1) {
         return (DropManager.DropItemSettings)this.items.get(var1.toLowerCase());
      }

      public HashMap<String, Double> getItemRates() {
         return this.rates;
      }
   }
}
