package su.nightexpress.divineitems.modules.enchant;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.TreeMap;
import net.md_5.bungee.api.ChatColor;
import org.apache.commons.lang.ArrayUtils;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.block.BlockState;
import org.bukkit.block.CreatureSpawner;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.entity.TNTPrimed;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPistonExtendEvent;
import org.bukkit.event.block.BlockPistonRetractEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.enchantment.EnchantItemEvent;
import org.bukkit.event.enchantment.PrepareItemEnchantEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.EntityShootBowEvent;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.BlockStateMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.metadata.MetadataValue;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;
import su.nightexpress.divineitems.DivineItems;
import su.nightexpress.divineitems.DivineListener;
import su.nightexpress.divineitems.Module;
import su.nightexpress.divineitems.api.EntityAPI;
import su.nightexpress.divineitems.cmds.list.EnchantsCommand;
import su.nightexpress.divineitems.config.Lang;
import su.nightexpress.divineitems.config.MyConfig;
import su.nightexpress.divineitems.gui.ContentType;
import su.nightexpress.divineitems.gui.GUI;
import su.nightexpress.divineitems.gui.GUIItem;
import su.nightexpress.divineitems.gui.GUIType;
import su.nightexpress.divineitems.hooks.Hook;
import su.nightexpress.divineitems.modules.MainSettings;
import su.nightexpress.divineitems.nbt.NBTItem;
import su.nightexpress.divineitems.types.DestroyType;
import su.nightexpress.divineitems.types.SlotType;
import su.nightexpress.divineitems.utils.ErrorLog;
import su.nightexpress.divineitems.utils.ItemUtils;
import su.nightexpress.divineitems.utils.ParticleUtils;
import su.nightexpress.divineitems.utils.Utils;

public class EnchantManager extends DivineListener<DivineItems> implements Module {
   private DivineItems plugin;
   private Random r;
   private boolean e;
   private MyConfig settingsCfg;
   private MyConfig enchantsCfg;
   private EnchantManager.EnchantSettings es;
   private HashMap<EnchantManager.EnchantType, EnchantManager.Enchant> enchants;
   private TreeMap<String, Double> table_rate;
   private final String n = this.name().toLowerCase().replace(" ", "_");
   private final String label;
   private final String NBT_KEY_BOOK;
   private final String NBT_KEY_ITEM_ENCHANT;
   // $FF: synthetic field
   private static int[] $SWITCH_TABLE$su$nightexpress$divineitems$types$DestroyType;
   // $FF: synthetic field
   private static int[] $SWITCH_TABLE$su$nightexpress$divineitems$modules$enchant$EnchantManager$EnchantType;

   public EnchantManager(DivineItems var1) {
      super(var1);
      this.label = this.n.replace("_", "");
      this.NBT_KEY_BOOK = "DIVINE_ENCHANT";
      this.NBT_KEY_ITEM_ENCHANT = "ENCHANT_";
      this.plugin = var1;
      this.e = this.plugin.getCM().getCFG().isModuleEnabled(this.name());
      this.r = new Random();
   }

   public void loadConfig() {
      this.enchants = new HashMap();
      this.table_rate = new TreeMap();
      this.settingsCfg = new MyConfig(this.plugin, "/modules/" + this.n, "settings.yml");
      this.enchantsCfg = new MyConfig(this.plugin, "/modules/" + this.n, "enchants.yml");
      this.setup();
   }

   public boolean isActive() {
      return this.e;
   }

   public boolean isDropable() {
      return true;
   }

   public boolean isResolvable() {
      return true;
   }

   public String name() {
      return "Enchants";
   }

   public String version() {
      return "1.0";
   }

   public void enable() {
      if (this.isActive()) {
         this.plugin.getCommander().registerCmd(this.label, new EnchantsCommand(this.plugin));
         this.loadConfig();
         this.registerListeners();
      }

   }

   public void unload() {
      if (this.isActive()) {
         this.plugin.getCommander().unregisterCmd(this.label);
         this.enchants.clear();
         this.table_rate.clear();
         this.es = null;
         this.e = false;
         this.unregisterListeners();
      }

   }

   public void reload() {
      this.unload();
      this.enable();
   }

   private void setup() {
      this.setupSettings();
      this.setupSlot();
      this.setupEnchants();
      this.setupTableRates();
   }

   private void setupSlot() {
      SlotType var1 = SlotType.ENCHANT;
      var1.setModule(this);
      var1.setHeader(this.getSettings().getHeader());
      var1.setEmpty(this.getSettings().getEmptySlot());
      var1.setFilled(this.getSettings().getFilledSlot());
   }

   private void setupSettings() {
      FileConfiguration var1 = this.settingsCfg.getConfig();
      String var2 = "Item.";
      List var3 = var1.getStringList(var2 + "Materials");
      String var4 = ChatColor.translateAlternateColorCodes('&', var1.getString(var2 + "Display"));
      List var5 = var1.getStringList(var2 + "Lore");
      var2 = "Enchant.";
      int var6 = var1.getInt(var2 + "MinSuccessChance");
      int var7 = var1.getInt(var2 + "MaxSuccessChance");
      DestroyType var8 = DestroyType.CLEAR;

      try {
         var8 = DestroyType.valueOf(var1.getString(var2 + "DestroyType"));
      } catch (IllegalArgumentException var23) {
         ErrorLog.sendError(this, var2 + "DestroyType", "Invalid Destroy Type!", true);
         var1.set(var2 + "DestroyType", "CLEAR");
      }

      var2 = "Effects.";
      boolean var9 = var1.getBoolean(var2 + "Enabled");
      String var10 = var1.getString(var2 + "Failure");
      String var11 = var1.getString(var2 + "Success");
      var2 = "Sounds.";
      boolean var12 = var1.getBoolean(var2 + "Enabled");
      Sound var13 = Sound.BLOCK_ANVIL_BREAK;

      try {
         var13 = Sound.valueOf(var1.getString(var2 + "Failure"));
      } catch (IllegalArgumentException var22) {
         ErrorLog.sendError(this, var2 + "Failure", "Invalid Sound Type!", true);
         var1.set(var2 + "Failure", "BLOCK_ANVIL_BREAK");
      }

      Sound var14 = Sound.ENTITY_EXPERIENCE_ORB_PICKUP;

      try {
         var14 = Sound.valueOf(var1.getString(var2 + "Success"));
      } catch (IllegalArgumentException var21) {
         ErrorLog.sendError(this, var2 + "Success", "Invalid Sound Type!", true);
         var1.set(var2 + "Success", "ENTITY_EXPERIENCE_ORB_PICKUP");
      }

      var2 = "Design.";
      String var15 = ChatColor.translateAlternateColorCodes('&', var1.getString(var2 + "Header"));
      String var16 = ChatColor.translateAlternateColorCodes('&', var1.getString(var2 + "EmptySlot"));
      String var17 = ChatColor.translateAlternateColorCodes('&', var1.getString(var2 + "FilledSlot"));
      var2 = "EnchantmentTable.";
      boolean var18 = var1.getBoolean(var2 + "Enabled");
      double var19 = var1.getDouble(var2 + "ChanceToGet");
      this.es = new EnchantManager.EnchantSettings(var3, var4, var5, var6, var7, var8, var9, var10, var11, var12, var13, var14, var15, var16, var17, var18, var19);
   }

   private void setupEnchants() {
      FileConfiguration var1 = this.enchantsCfg.getConfig();
      Iterator var3 = var1.getConfigurationSection("Enchants").getKeys(false).iterator();

      while(true) {
         String var2;
         String var4;
         boolean var5;
         EnchantManager.EnchantType var7;
         while(true) {
            do {
               if (!var3.hasNext()) {
                  return;
               }

               var2 = (String)var3.next();
               var4 = "Enchants." + var2 + ".";
               var5 = var1.getBoolean(var4 + "Enabled");
            } while(!var5);

            String var6 = var2;

            try {
               var7 = EnchantManager.EnchantType.valueOf(var6.toUpperCase());
               break;
            } catch (IllegalArgumentException var23) {
               ErrorLog.sendError(this, var4 + var2, "Invalid Enchantment Type!", false);
            }
         }

         String var8 = ChatColor.translateAlternateColorCodes('&', var1.getString(var4 + "Name"));
         List var9 = var1.getStringList(var4 + "Desc");
         ArrayList var10 = new ArrayList();
         Iterator var12 = var9.iterator();

         while(var12.hasNext()) {
            String var11 = (String)var12.next();
            var10.add(ChatColor.translateAlternateColorCodes('&', var11));
         }

         double var24 = var1.getDouble(var4 + "Value");
         double var13 = var1.getDouble(var4 + "ValuePerLvl");
         int var15 = var1.getInt(var4 + "PlayerTableLevel");
         int var16 = var1.getInt(var4 + "LevelMin");
         int var17 = var1.getInt(var4 + "LevelMax");
         double var18 = var1.getDouble(var4 + "TableChance");
         ArrayList var20 = new ArrayList(var1.getStringList(var4 + "ItemTypes"));
         ArrayList var21 = new ArrayList();
         EnchantManager.Enchant var22 = new EnchantManager.Enchant(var5, var2.toUpperCase(), var8, var10, var24, var13, var15, var16, var17, var18, var20, var21);
         this.enchants.put(var7, var22);
      }
   }

   private void setupTableRates() {
      TreeMap var1 = new TreeMap();
      Iterator var3 = this.getEnchants().iterator();

      while(var3.hasNext()) {
         EnchantManager.Enchant var2 = (EnchantManager.Enchant)var3.next();
         if (var2.isEnabled()) {
            var1.put(var2.getId(), var2.getTableRate());
         }
      }

      this.table_rate = var1;
   }

   public boolean haveEnchant(ItemStack var1, EnchantManager.EnchantType var2) {
      NBTItem var3 = new NBTItem(var1);
      Iterator var5 = var3.getKeys().iterator();

      while(var5.hasNext()) {
         String var4 = (String)var5.next();
         if (var4.startsWith("ENCHANT_")) {
            String[] var6 = var3.getString(var4).split(":");
            EnchantManager.EnchantType var7 = EnchantManager.EnchantType.valueOf(var6[0]);
            if (var2 == var7) {
               return true;
            }
         }
      }

      return false;
   }

   public int getItemEnchantLevel(ItemStack var1, EnchantManager.EnchantType var2) {
      NBTItem var3 = new NBTItem(var1);
      Iterator var5 = var3.getKeys().iterator();

      while(var5.hasNext()) {
         String var4 = (String)var5.next();
         if (var4.startsWith("ENCHANT_")) {
            String[] var6 = var3.getString(var4).split(":");
            if (var6[0].equalsIgnoreCase(var2.name())) {
               return Integer.parseInt(var6[1]);
            }
         }
      }

      return 0;
   }

   public String getEnchantBookId(ItemStack var1) {
      NBTItem var2 = new NBTItem(var1);
      String[] var3 = var2.getString("DIVINE_ENCHANT").split(":");
      return var3[0];
   }

   public int getEnchantBookLevel(ItemStack var1) {
      NBTItem var2 = new NBTItem(var1);
      String[] var3 = var2.getString("DIVINE_ENCHANT").split(":");
      return Integer.parseInt(var3[1]);
   }

   private double getEnchantBookValue(ItemStack var1) {
      NBTItem var2 = new NBTItem(var1);
      String[] var3 = var2.getString("DIVINE_ENCHANT").split(":");
      return Double.parseDouble(var3[2]);
   }

   public EnchantManager.EnchantSettings getSettings() {
      return this.es;
   }

   public Collection<EnchantManager.Enchant> getEnchants() {
      return this.enchants.values();
   }

   public List<String> getEnchantNames() {
      ArrayList var1 = new ArrayList();
      Iterator var3 = this.getEnchants().iterator();

      while(var3.hasNext()) {
         EnchantManager.Enchant var2 = (EnchantManager.Enchant)var3.next();
         var1.add(var2.getId());
      }

      return var1;
   }

   public EnchantManager.Enchant getEnchantByType(EnchantManager.EnchantType var1) {
      return (EnchantManager.Enchant)this.enchants.get(var1);
   }

   public EnchantManager.Enchant getRandomEnchant() {
      return (EnchantManager.Enchant)(new ArrayList(this.getEnchants())).get(this.r.nextInt(this.getEnchants().size()));
   }

   private ItemStack getResult(ItemStack var1, ItemStack var2) {
      ItemStack var3 = this.enchantItem(var1, var2);
      ItemMeta var4 = var3.getItemMeta();
      var4.setDisplayName(Lang.Enchants_Enchanting_Result.toMsg());
      var3.setItemMeta(var4);
      return var3;
   }

   private void openGUI(Player var1, ItemStack var2, ItemStack var3) {
      GUI var4 = new GUI(this.plugin.getGUIManager().getGUIByType(GUIType.ENCHANT_BOOK));
      ((GUIItem)var4.getItems().get(ContentType.TARGET)).setItem(var2);
      ((GUIItem)var4.getItems().get(ContentType.SOURCE)).setItem(var3);
      ((GUIItem)var4.getItems().get(ContentType.RESULT)).setItem(this.getResult(new ItemStack(var2), new ItemStack(var3)));
      this.plugin.getGUIManager().setGUI(var1, var4);
      var1.openInventory(var4.build());
   }

   private ItemStack enchantItem(ItemStack var1, ItemStack var2) {
      String var3 = this.getEnchantBookId(var2);
      int var4 = this.getEnchantBookLevel(var2);
      double var5 = this.getEnchantBookValue(var2);
      EnchantManager.EnchantType var7 = EnchantManager.EnchantType.valueOf(var3);
      EnchantManager.Enchant var8 = this.getEnchantByType(var7);
      List var9 = var1.getItemMeta().getLore();
      String var10 = this.getSettings().getFilledSlot() + var8.getName().replace("%level%", String.valueOf(var4)).replace("%rlevel%", Utils.IntegerToRomanNumeral(var4));
      String var11;
      Iterator var12;
      if (this.haveEnchant(var1, var7)) {
         var12 = var9.iterator();

         while(var12.hasNext()) {
            var11 = (String)var12.next();
            if (var11.contains(var3)) {
               int var13 = var9.indexOf(var11);
               var9.remove(var13);
               var9.add(var13, var10);
               break;
            }
         }

         var1 = this.removeEnchant(var1, var3);
      } else {
         var12 = var9.iterator();

         while(var12.hasNext()) {
            var11 = (String)var12.next();
            String var18 = ChatColor.stripColor(var11);
            String var14 = ChatColor.stripColor(this.getSettings().getEmptySlot());
            if (var18.equals(var14)) {
               int var15 = var9.indexOf(var11);
               var9.remove(var15);
               var9.add(var15, var10);
               break;
            }
         }
      }

      ItemMeta var16 = var1.getItemMeta();
      var16.setLore(var9);
      var1.setItemMeta(var16);
      NBTItem var17 = new NBTItem(var1);
      var17.setString("ENCHANT_" + this.getItemEnchantAmount(var1), var3 + ":" + var4 + ":" + var5);
      return var17.getItem();
   }

   public int getItemEnchantAmount(ItemStack var1) {
      NBTItem var2 = new NBTItem(var1);
      int var3 = 0;
      Iterator var5 = var2.getKeys().iterator();

      while(var5.hasNext()) {
         String var4 = (String)var5.next();
         if (var4.startsWith("ENCHANT_")) {
            ++var3;
         }
      }

      return var3;
   }

   public ItemStack removeEnchant(ItemStack var1, String var2) {
      NBTItem var3 = new NBTItem(var1);
      Iterator var5 = var3.getKeys().iterator();

      while(var5.hasNext()) {
         String var4 = (String)var5.next();
         if (var4.startsWith("ENCHANT_")) {
            String[] var6 = var3.getString(var4).split(":");
            if (var6[0].equalsIgnoreCase(var2)) {
               var3.removeKey(var4);
               break;
            }
         }
      }

      return var3.getItem();
   }

   public ItemStack removeEnchant(ItemStack var1, int var2) {
      NBTItem var3 = new NBTItem(var1);
      int var4 = this.getItemEnchantAmount(var1);
      int var5 = var2 - 1;
      int var6 = var4 - var5;
      int var7 = var6;
      if (var5 == 0) {
         var7 = var6 - 1;
      }

      var3.removeKey("ENCHANT_" + var7);
      var1 = new ItemStack(var3.getItem());
      ItemMeta var8 = var1.getItemMeta();
      ArrayList var9 = new ArrayList(var8.getLore());
      int var10 = 0;
      int var11 = 0;

      for(Iterator var13 = var8.getLore().iterator(); var13.hasNext(); ++var11) {
         String var12 = (String)var13.next();
         if (var12.startsWith(this.getSettings().getFilledSlot())) {
            ++var10;
         }

         if (var10 == var6) {
            var9.remove(var11);
            var9.add(var11, this.es.getEmptySlot());
            break;
         }
      }

      var8.setLore(var9);
      var1.setItemMeta(var8);
      return var1;
   }

   public boolean isEnchant(ItemStack var1) {
      return (new NBTItem(var1)).hasKey("DIVINE_ENCHANT");
   }

   @EventHandler
   public void onInventoryClick(InventoryClickEvent var1) {
      if (var1.getWhoClicked() instanceof Player) {
         Player var2 = (Player)var1.getWhoClicked();
         ItemStack var3 = var1.getCursor();
         ItemStack var4 = var1.getCurrentItem();
         if (var3 != null && var4 != null) {
            if (var1.getInventory().getType() == InventoryType.CRAFTING) {
               if (var1.getSlotType() != org.bukkit.event.inventory.InventoryType.SlotType.CRAFTING) {
                  if (var1.getSlotType() != org.bukkit.event.inventory.InventoryType.SlotType.ARMOR && var1.getSlot() != 40) {
                     if (var3.hasItemMeta() && var3.getItemMeta().hasLore()) {
                        if (var4.hasItemMeta() && var4.getItemMeta().hasLore()) {
                           NBTItem var5 = new NBTItem(var3);
                           if (var5.hasKey("DIVINE_ENCHANT")) {
                              String[] var6 = var5.getString("DIVINE_ENCHANT").split(":");
                              EnchantManager.EnchantType var7 = EnchantManager.EnchantType.valueOf(var6[0]);
                              int var8 = Integer.parseInt(var6[1]);
                              EnchantManager.Enchant var9 = this.getEnchantByType(var7);
                              if (var9 == null) {
                                 var2.sendMessage(Lang.Prefix.toMsg() + Lang.Other_Internal.toMsg());
                              } else {
                                 boolean var10 = false;
                                 Iterator var12 = var9.getItemTypes().iterator();

                                 String var11;
                                 while(var12.hasNext()) {
                                    var11 = (String)var12.next();
                                    if (ItemUtils.isValidItemType(var11, var4)) {
                                       var10 = true;
                                       break;
                                    }
                                 }

                                 if (!var10) {
                                    var2.sendMessage(Lang.Prefix.toMsg() + Lang.Enchants_Enchanting_InvalidType.toMsg());
                                 } else if (this.haveEnchant(var4, var7) && this.getItemEnchantLevel(var4, var7) >= var8) {
                                    var2.sendMessage(Lang.Prefix.toMsg() + Lang.Enchants_Enchanting_AlreadyHave.toMsg());
                                 } else if (var2.getInventory().firstEmpty() == -1) {
                                    var2.sendMessage(Lang.Prefix.toMsg() + Lang.Enchants_Enchanting_FullInventory.toMsg());
                                 } else {
                                    var11 = var9.getName().replace("%level%", "").trim();
                                    Iterator var13 = var4.getItemMeta().getLore().iterator();

                                    String var14;
                                    String var15;
                                    do {
                                       if (!var13.hasNext()) {
                                          var2.sendMessage(Lang.Prefix.toMsg() + Lang.Enchants_Enchanting_NoSlots.toMsg());
                                          return;
                                       }

                                       String var16 = (String)var13.next();
                                       var14 = ChatColor.stripColor(var16);
                                       var15 = ChatColor.stripColor(this.getSettings().getEmptySlot());
                                    } while(!var14.equalsIgnoreCase(var15) && !var14.contains(var11));

                                    var1.setCursor((ItemStack)null);
                                    var2.getInventory().addItem(new ItemStack[]{var3});
                                    var1.setCancelled(true);
                                    this.openGUI(var2, var4, var3);
                                 }
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
      }
   }

   @EventHandler
   public void onPreEnchant(PrepareItemEnchantEvent var1) {
      if (this.getSettings().isTableEnabled()) {
         ItemStack var2 = var1.getItem();
         if (var2 != null) {
            String var3 = var2.getType().name() + ":" + var2.getData().getData();
            if (this.getSettings().getMaterials().contains(var3)) {
               NBTItem var4 = new NBTItem(var2);
               if (var4.hasKey("DIVINE_ENCHANT")) {
                  var1.setCancelled(true);
               }

            }
         }
      }
   }

   @EventHandler
   public void onEnchant(EnchantItemEvent var1) {
      if (this.getSettings().isTableEnabled()) {
         Player var2 = var1.getEnchanter();
         ItemStack var3 = var1.getItem();
         if (var3 != null) {
            String var4 = var3.getType().name() + ":" + var3.getData().getData();
            if (this.getSettings().getMaterials().contains(var4)) {
               ArrayList var5 = new ArrayList();
               double var6 = 0.0D;
               double var8 = Utils.getRandDouble(0.0D, 100.0D) / 100.0D;
               if (var8 <= this.getSettings().getTableChance()) {
                  double var10 = Utils.getRandDouble(0.0D, 100.0D) / 100.0D;
                  Iterator var13 = this.table_rate.keySet().iterator();

                  String var12;
                  EnchantManager.Enchant var14;
                  while(var13.hasNext()) {
                     var12 = (String)var13.next();
                     var14 = this.getEnchantByType(EnchantManager.EnchantType.valueOf(var12));
                     if (var2.getLevel() >= var14.getEnchantLevel() && var10 <= var14.getTableRate()) {
                        var6 = var14.getTableRate();
                        break;
                     }
                  }

                  var13 = this.table_rate.keySet().iterator();

                  while(var13.hasNext()) {
                     var12 = (String)var13.next();
                     var14 = this.getEnchantByType(EnchantManager.EnchantType.valueOf(var12));
                     if (var2.getLevel() >= var14.getEnchantLevel() && var14.getTableRate() == var6) {
                        var5.add(var14);
                     }
                  }

                  if (var5.isEmpty()) {
                     return;
                  }

                  EnchantManager.Enchant var16 = (EnchantManager.Enchant)var5.get((new Random()).nextInt(var5.size()));
                  var2.setLevel(var2.getLevel() - var1.getExpLevelCost());
                  int var17 = var16.getMinLevel();
                  int var18 = var16.getMaxLevel();
                  int var15 = Utils.randInt(var17, var18);
                  var1.getInventory().setItem(0, new ItemStack(var16.create(var15)));
                  var1.setCancelled(true);
               }

            }
         }
      }
   }

   @EventHandler
   public void onClickGUI(InventoryClickEvent var1) {
      Player var2 = (Player)var1.getWhoClicked();
      if (this.plugin.getGUIManager().valid(var2, GUIType.ENCHANT_BOOK)) {
         GUI var3 = this.plugin.getGUIManager().getPlayerGUI(var2, GUIType.ENCHANT_BOOK);
         if (var3 != null && var1.getInventory().getTitle().equals(var3.getTitle())) {
            var1.setCancelled(true);
            ItemStack var4 = var1.getCurrentItem();
            if (var4 != null && var4.hasItemMeta()) {
               GUIItem var5 = (GUIItem)var3.getItems().get(ContentType.ACCEPT);
               int var6 = var1.getRawSlot();
               if (var4.isSimilar(var5.getItem()) || ArrayUtils.contains(var5.getSlots(), var6)) {
                  ItemStack var7 = new ItemStack(((GUIItem)var3.getItems().get(ContentType.TARGET)).getItem());
                  ItemStack var8 = new ItemStack(((GUIItem)var3.getItems().get(ContentType.SOURCE)).getItem());
                  if (!var2.getInventory().contains(var7)) {
                     var2.sendMessage(Lang.Prefix.toMsg() + Lang.Enchants_Enchanting_NoItem.toMsg());
                     return;
                  }

                  int var9 = (new Random()).nextInt(100);
                  NBTItem var10 = new NBTItem(var8);
                  int var11 = var10.getInteger("DIVINE_CHANCE");
                  EnchantManager.EnchantSettings var12 = this.getSettings();
                  if (var11 < var9) {
                     switch($SWITCH_TABLE$su$nightexpress$divineitems$types$DestroyType()[var12.getDestroyType().ordinal()]) {
                     case 1:
                        var2.getInventory().removeItem(new ItemStack[]{var7});
                        var2.sendMessage(Lang.Prefix.toMsg() + Lang.Enchants_Enchanting_Failure_Item.toMsg());
                        break;
                     case 2:
                        var2.getInventory().removeItem(new ItemStack[]{var8});
                        var8.setAmount(var8.getAmount() - 1);
                        var2.getInventory().addItem(new ItemStack[]{var8});
                        var2.sendMessage(Lang.Prefix.toMsg() + Lang.Enchants_Enchanting_Failure_Source.toMsg());
                        break;
                     case 3:
                        var2.getInventory().removeItem(new ItemStack[]{var7});
                        var2.getInventory().removeItem(new ItemStack[]{var8});
                        var8.setAmount(var8.getAmount() - 1);
                        var2.getInventory().addItem(new ItemStack[]{var8});
                        ItemMeta var19 = var7.getItemMeta();
                        ArrayList var14 = new ArrayList();
                        Iterator var16 = var19.getLore().iterator();

                        while(var16.hasNext()) {
                           String var15 = (String)var16.next();
                           if (var15.startsWith(var12.getFilledSlot())) {
                              var14.add(var12.getEmptySlot());
                           } else {
                              var14.add(var15);
                           }
                        }

                        var19.setLore(var14);
                        var7.setItemMeta(var19);
                        NBTItem var20 = new NBTItem(var7);
                        Iterator var17 = var20.getKeys().iterator();

                        while(var17.hasNext()) {
                           String var21 = (String)var17.next();
                           if (var21.startsWith("ENCHANT_")) {
                              var20.removeKey(var21);
                           }
                        }

                        var2.getInventory().addItem(new ItemStack[]{var20.getItem()});
                        var2.sendMessage(Lang.Prefix.toMsg() + Lang.Enchants_Enchanting_Failure_Clear.toMsg());
                        break;
                     case 4:
                        var2.getInventory().removeItem(new ItemStack[]{var7});
                        var2.getInventory().removeItem(new ItemStack[]{var8});
                        var8.setAmount(var8.getAmount() - 1);
                        var2.getInventory().addItem(new ItemStack[]{var8});
                        var2.sendMessage(Lang.Prefix.toMsg() + Lang.Enchants_Enchanting_Failure_Both.toMsg());
                     }

                     var2.closeInventory();
                     this.plugin.getGUIManager().reset(var2);
                     if (var12.useSound()) {
                        var2.playSound(var2.getLocation(), var12.getDestroySound(), 0.5F, 0.5F);
                     }

                     if (var12.useEffect()) {
                        Utils.playEffect(var12.getDestroyEffect(), 0.30000001192092896D, 0.0D, 0.30000001192092896D, 0.30000001192092896D, 15, var2.getLocation().add(0.0D, 0.5D, 0.0D));
                     }

                     return;
                  }

                  var2.getInventory().removeItem(new ItemStack[]{var7});
                  ItemStack var13 = this.enchantItem(var7, var8);
                  var2.getInventory().addItem(new ItemStack[]{var13});
                  var2.getInventory().removeItem(new ItemStack[]{var8});
                  var8.setAmount(var8.getAmount() - 1);
                  var2.getInventory().addItem(new ItemStack[]{var8});
                  var2.sendMessage(Lang.Prefix.toMsg() + Lang.Enchants_Enchanting_Success.toMsg());
                  var2.closeInventory();
                  this.plugin.getGUIManager().reset(var2);
                  if (var12.useSound()) {
                     var2.playSound(var2.getLocation(), var12.getSuccessSound(), 0.5F, 0.5F);
                  }

                  if (var12.useEffect()) {
                     Utils.playEffect(var12.getSuccessEffect(), 0.30000001192092896D, 0.0D, 0.30000001192092896D, 0.30000001192092896D, 15, var2.getLocation().add(0.0D, 0.5D, 0.0D));
                  }

                  var2.updateInventory();
               }

               GUIItem var18 = (GUIItem)var3.getItems().get(ContentType.DECLINE);
               if (var4.isSimilar(var18.getItem()) || ArrayUtils.contains(var18.getSlots(), var6)) {
                  var2.sendMessage(Lang.Prefix.toMsg() + Lang.Enchants_Enchanting_Cancel.toMsg());
                  var2.closeInventory();
                  var2.updateInventory();
                  this.plugin.getGUIManager().reset(var2);
               }

            }
         }
      }
   }

   @EventHandler
   public void onEDeath(EntityDeathEvent var1) {
      Player var2 = var1.getEntity().getKiller();
      if (var2 != null) {
         ItemStack var3 = var2.getInventory().getItemInMainHand();
         if (var3 != null && var3.hasItemMeta() && var3.getItemMeta().hasLore()) {
            NBTItem var4 = new NBTItem(var3);
            Iterator var6 = var4.getKeys().iterator();

            while(var6.hasNext()) {
               String var5 = (String)var6.next();
               if (var5.startsWith("ENCHANT_") && this.isValidEnchant(var5, var4)) {
                  EnchantManager.EnchantType var7 = EnchantManager.EnchantType.valueOf(var4.getString(var5).split(":")[0]);
                  int var8 = Integer.parseInt(var4.getString(var5).split(":")[1]);
                  double var9 = Double.parseDouble(var4.getString(var5).split(":")[2]);
                  switch($SWITCH_TABLE$su$nightexpress$divineitems$modules$enchant$EnchantManager$EnchantType()[var7.ordinal()]) {
                  case 1:
                     this.getExecute(var9, var1.getEntity());
                     break;
                  case 9:
                     var1.setDroppedExp(this.getExpHunter(var8, var9, var1.getDroppedExp()));
                  }
               }
            }

         }
      }
   }

   @EventHandler
   public void onArmorEnch2(PlayerMoveEvent var1) {
      Player var2 = var1.getPlayer();
      Location var3 = new Location(var2.getLocation().getWorld(), var2.getLocation().getX(), var2.getLocation().getY() - 1.0D, var2.getLocation().getZ());
      Block var4 = var3.getBlock();
      if (var4.getType().name().contains("LAVA")) {
         ItemStack[] var5 = EntityAPI.getEquipment(var2, true);
         ItemStack[] var9 = var5;
         int var8 = var5.length;

         for(int var7 = 0; var7 < var8; ++var7) {
            ItemStack var6 = var9[var7];
            if (var6 != null && var6.getType() != Material.AIR) {
               NBTItem var10 = new NBTItem(var6);
               Iterator var12 = var10.getKeys().iterator();

               while(var12.hasNext()) {
                  String var11 = (String)var12.next();
                  if (var11.startsWith("ENCHANT_") && this.isValidEnchant(var11, var10)) {
                     EnchantManager.EnchantType var13 = EnchantManager.EnchantType.valueOf(var10.getString(var11).split(":")[0]);
                     switch($SWITCH_TABLE$su$nightexpress$divineitems$modules$enchant$EnchantManager$EnchantType()[var13.ordinal()]) {
                     case 17:
                        this.getLavaWalk(var4, var2);
                     }
                  }
               }
            }
         }

      }
   }

   @EventHandler(
      ignoreCancelled = true
   )
   public void onArmorEnch3(EntityDamageEvent var1) {
      if (var1.getEntity() instanceof Player) {
         if (var1.getCause() == DamageCause.FIRE || var1.getCause() == DamageCause.FIRE_TICK || var1.getCause() == DamageCause.LAVA) {
            Player var2 = (Player)var1.getEntity();
            ItemStack[] var3 = EntityAPI.getEquipment(var2, true);
            ItemStack[] var7 = var3;
            int var6 = var3.length;

            for(int var5 = 0; var5 < var6; ++var5) {
               ItemStack var4 = var7[var5];
               if (var4 != null && var4.getType() != Material.AIR) {
                  NBTItem var8 = new NBTItem(var4);
                  Iterator var10 = var8.getKeys().iterator();

                  while(var10.hasNext()) {
                     String var9 = (String)var10.next();
                     if (var9.startsWith("ENCHANT_") && this.isValidEnchant(var9, var8)) {
                        EnchantManager.EnchantType var11 = EnchantManager.EnchantType.valueOf(var8.getString(var9).split(":")[0]);
                        double var12 = Double.parseDouble(var8.getString(var9).split(":")[2]);
                        switch($SWITCH_TABLE$su$nightexpress$divineitems$modules$enchant$EnchantManager$EnchantType()[var11.ordinal()]) {
                        case 17:
                           if ((double)this.r.nextInt(100) < var12) {
                              var1.setCancelled(true);
                           }
                        }
                     }
                  }
               }
            }

         }
      }
   }

   @EventHandler(
      ignoreCancelled = true
   )
   public void onArmorEnch(EntityDamageByEntityEvent var1) {
      if (!var1.isCancelled()) {
         Entity var2 = var1.getEntity();
         Entity var3 = var1.getDamager();
         if (var3 instanceof Arrow) {
            Arrow var4 = (Arrow)var3;
            if (!(var4.getShooter() instanceof LivingEntity)) {
               return;
            }

            var3 = (Entity)var4.getShooter();
         }

         if (var2 instanceof Player) {
            if (var3 instanceof LivingEntity) {
               Player var18 = (Player)var2;
               LivingEntity var5 = (LivingEntity)var3;
               ItemStack[] var6 = EntityAPI.getEquipment(var18, true);
               ItemStack[] var10 = var6;
               int var9 = var6.length;

               for(int var8 = 0; var8 < var9; ++var8) {
                  ItemStack var7 = var10[var8];
                  if (var7 != null && var7.getType() != Material.AIR) {
                     NBTItem var11 = new NBTItem(var7);
                     Iterator var13 = var11.getKeys().iterator();

                     while(var13.hasNext()) {
                        String var12 = (String)var13.next();
                        if (var12.startsWith("ENCHANT_") && this.isValidEnchant(var12, var11)) {
                           EnchantManager.EnchantType var14 = EnchantManager.EnchantType.valueOf(var11.getString(var12).split(":")[0]);
                           int var15 = Integer.parseInt(var11.getString(var12).split(":")[1]);
                           double var16 = Double.parseDouble(var11.getString(var12).split(":")[2]);
                           switch($SWITCH_TABLE$su$nightexpress$divineitems$modules$enchant$EnchantManager$EnchantType()[var14.ordinal()]) {
                           case 12:
                              this.getFireSpray(var15, var16, var5);
                              break;
                           case 13:
                              this.getPunishWave(var15, var16, var18);
                              break;
                           case 14:
                              this.getPrayVictor(var16, var18);
                              break;
                           case 15:
                              this.getAmbush(var15, var16, var18, var5);
                              break;
                           case 16:
                              this.getEternalDenial(var15, var16, var5);
                           }
                        }
                     }
                  }
               }

            }
         }
      }
   }

   @EventHandler(
      ignoreCancelled = true
   )
   public void onEDamage(EntityDamageByEntityEvent var1) {
      Entity var2 = var1.getEntity();
      Entity var3 = var1.getDamager();
      if (var3 instanceof Arrow) {
         Arrow var4 = (Arrow)var3;
         if (!(var4.getShooter() instanceof LivingEntity)) {
            return;
         }

         var3 = (Entity)var4.getShooter();
      }

      if (var2 instanceof LivingEntity) {
         if (var3 instanceof LivingEntity) {
            LivingEntity var16 = (LivingEntity)var3;
            LivingEntity var5 = (LivingEntity)var2;
            ItemStack var6 = var16.getEquipment().getItemInMainHand();
            if (var6 != null && var6.hasItemMeta() && var6.getItemMeta().hasLore()) {
               NBTItem var7 = new NBTItem(var6);
               Iterator var9 = var7.getKeys().iterator();

               while(var9.hasNext()) {
                  String var8 = (String)var9.next();
                  if (var8.startsWith("ENCHANT_") && this.isValidEnchant(var8, var7)) {
                     EnchantManager.EnchantType var10 = EnchantManager.EnchantType.valueOf(var7.getString(var8).split(":")[0]);
                     int var11 = Integer.parseInt(var7.getString(var8).split(":")[1]);
                     double var12 = Double.parseDouble(var7.getString(var8).split(":")[2]);
                     switch($SWITCH_TABLE$su$nightexpress$divineitems$modules$enchant$EnchantManager$EnchantType()[var10.ordinal()]) {
                     case 2:
                        this.getLegGrab(var11, var12, var5);
                        break;
                     case 3:
                        this.getVenom(var11, var12, var5);
                        break;
                     case 4:
                        this.getWither(var11, var12, var5);
                        break;
                     case 5:
                        this.getEyeBurn(var11, var12, var5);
                        break;
                     case 6:
                        this.getExhaust(var11, var12, var5);
                        break;
                     case 7:
                        this.getParalyze(var11, var12, var5);
                        break;
                     case 8:
                        this.getJustice(var11, var12, var5);
                     case 9:
                     default:
                        break;
                     case 10:
                        this.getMagicImp(var12, var5);
                        break;
                     case 11:
                        if (var16 instanceof Player && var5 instanceof Player) {
                           Player var14 = (Player)var5;
                           Player var15 = (Player)var16;
                           this.getGTM(var11, var12, var14, var15);
                        }
                     }
                  }
               }

            }
         }
      }
   }

   @EventHandler(
      ignoreCancelled = true
   )
   public void onRicDamage(EntityDamageByEntityEvent var1) {
      Entity var2 = var1.getEntity();
      Entity var3 = var1.getDamager();
      if (var3 instanceof Projectile) {
         Projectile var4 = (Projectile)var3;
         if (var4.getShooter() instanceof LivingEntity) {
            if (var2 instanceof LivingEntity) {
               LivingEntity var5 = (LivingEntity)var2;
               this.onRicochet((Projectile)var3, var5, var1.getFinalDamage(), var1);
            }
         }
      }
   }

   @EventHandler(
      ignoreCancelled = true
   )
   public void onBowEDamage(EntityShootBowEvent var1) {
      Entity var2 = var1.getProjectile();
      LivingEntity var3 = var1.getEntity();
      ItemStack var4 = var3.getEquipment().getItemInMainHand();
      if (var4 != null && var4.hasItemMeta() && var4.getItemMeta().hasLore()) {
         NBTItem var5 = new NBTItem(var4);
         Iterator var7 = var5.getKeys().iterator();

         while(var7.hasNext()) {
            String var6 = (String)var7.next();
            if (var6.startsWith("ENCHANT_") && this.isValidEnchant(var6, var5)) {
               EnchantManager.EnchantType var8 = EnchantManager.EnchantType.valueOf(var5.getString(var6).split(":")[0]);
               int var9 = Integer.parseInt(var5.getString(var6).split(":")[1]);
               double var10 = Double.parseDouble(var5.getString(var6).split(":")[2]);
               switch($SWITCH_TABLE$su$nightexpress$divineitems$modules$enchant$EnchantManager$EnchantType()[var8.ordinal()]) {
               case 18:
                  var1.setProjectile(this.getMalice((double)var1.getForce(), var10, var3, var2));
                  break;
               case 19:
                  this.getMinigun((double)var1.getForce(), var9, var10, var3, var2);
               case 20:
               case 21:
               default:
                  break;
               case 22:
                  var1.getProjectile().setGravity(false);
                  break;
               case 23:
                  var1.setProjectile(this.getRicochet((Projectile)var2, var3, var9, var10));
               }
            }
         }

      }
   }

   @EventHandler(
      ignoreCancelled = true
   )
   public void onPickE(BlockBreakEvent var1) {
      if (!var1.isCancelled()) {
         if (!var1.getBlock().hasMetadata("Divine")) {
            Player var2 = var1.getPlayer();
            ItemStack var3 = var2.getInventory().getItemInMainHand();
            if (var3 != null && var3.hasItemMeta() && var3.getItemMeta().hasLore()) {
               NBTItem var4 = new NBTItem(var3);
               Iterator var6 = var4.getKeys().iterator();

               while(var6.hasNext()) {
                  String var5 = (String)var6.next();
                  if (var5.startsWith("ENCHANT_") && this.isValidEnchant(var5, var4)) {
                     EnchantManager.EnchantType var7 = EnchantManager.EnchantType.valueOf(var4.getString(var5).split(":")[0]);
                     int var8 = Integer.parseInt(var4.getString(var5).split(":")[1]);
                     double var9 = Double.parseDouble(var4.getString(var5).split(":")[2]);
                     switch($SWITCH_TABLE$su$nightexpress$divineitems$modules$enchant$EnchantManager$EnchantType()[var7.ordinal()]) {
                     case 20:
                        if (var1.getBlock().getType().name().contains("_ORE")) {
                           this.getLuckyMiner(var8, var9, var1.getBlock(), var3);
                        }
                        break;
                     case 21:
                        if (var1.getBlock().getType() == Material.MOB_SPAWNER) {
                           this.getDivineTouch(var9, var1.getBlock());
                        }
                     }
                  }
               }

            }
         }
      }
   }

   @EventHandler(
      ignoreCancelled = true
   )
   public void onPlaceB(BlockPlaceEvent var1) {
      Block var2 = var1.getBlock();
      if (var2.getType().name().contains("_ORE")) {
         var2.setMetadata("Divine", new FixedMetadataValue(this.plugin, "yes"));
      }

   }

   @EventHandler
   public void onPiston(BlockPistonExtendEvent var1) {
      Iterator var3 = var1.getBlocks().iterator();

      while(var3.hasNext()) {
         Block var2 = (Block)var3.next();
         if (var2.hasMetadata("Divine")) {
            var1.setCancelled(true);
            return;
         }
      }

   }

   @EventHandler
   public void onPiston2(BlockPistonRetractEvent var1) {
      Iterator var3 = var1.getBlocks().iterator();

      while(var3.hasNext()) {
         Block var2 = (Block)var3.next();
         if (var2.hasMetadata("Divine")) {
            var1.setCancelled(true);
            return;
         }
      }

   }

   public void getExecute(double var1, Entity var3) {
      if ((double)this.r.nextInt(100) <= var1) {
         ItemStack var4 = new ItemStack(Material.SKULL_ITEM, 1, (short)3);
         SkullMeta var5 = (SkullMeta)var4.getItemMeta();
         if (!(var3 instanceof Player)) {
            var5.setDisplayName(Lang.Enchants_Misc_SkullName.toMsg().replace("%name%", Lang.getCustom("EntityNames." + var3.getType().name())));
            var5.setOwner(ItemUtils.getValidSkullName(var3));
         } else {
            var5.setDisplayName(Lang.Enchants_Misc_SkullName.toMsg().replace("%name%", var3.getName()));
            var5.setOwner(var3.getName());
         }

         var4.setItemMeta(var5);
         var3.getLocation().getWorld().dropItem(var3.getLocation(), var4);
      }

   }

   public int getExpHunter(int var1, double var2, int var4) {
      ++var1;
      if ((double)this.r.nextInt(100) <= var2) {
         var4 *= var1;
      }

      return var4;
   }

   public void getLegGrab(int var1, double var2, LivingEntity var4) {
      if ((double)this.r.nextInt(100) <= var2) {
         var4.addPotionEffect(new PotionEffect(PotionEffectType.SLOW, 100, var1 - 1));
         ParticleUtils.doParticle(var4, "SPELL_MOB", "VILLAGER_ANGRY");
      }

   }

   public void getVenom(int var1, double var2, LivingEntity var4) {
      if ((double)this.r.nextInt(100) <= var2) {
         var4.addPotionEffect(new PotionEffect(PotionEffectType.POISON, 100, var1 - 1));
         ParticleUtils.doParticle(var4, "SPELL_MOB_AMBIENT", "SLIME");
      }

   }

   public void getWither(int var1, double var2, LivingEntity var4) {
      if ((double)this.r.nextInt(100) <= var2) {
         var4.addPotionEffect(new PotionEffect(PotionEffectType.WITHER, 100, var1 - 1));
         ParticleUtils.doParticle(var4, "SPELL_WITCH", "CLOUD");
      }

   }

   public void getEyeBurn(int var1, double var2, LivingEntity var4) {
      if ((double)this.r.nextInt(100) <= var2) {
         var4.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 100, var1 - 1));
         ParticleUtils.doParticle(var4, "TOWN_AURA", "LAVA");
      }

   }

   public void getExhaust(int var1, double var2, LivingEntity var4) {
      if ((double)this.r.nextInt(100) <= var2) {
         var4.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, 100, var1 - 1));
         ParticleUtils.doParticle(var4, "FIREWORKS_SPARK", "CRIT");
      }

   }

   public void getParalyze(int var1, double var2, LivingEntity var4) {
      if ((double)this.r.nextInt(100) <= var2) {
         var4.addPotionEffect(new PotionEffect(PotionEffectType.SLOW_DIGGING, 100, var1 + 5));
         ParticleUtils.doParticle(var4, "CRIT_MAGIC", "PORTAL");
      }

   }

   public void getJustice(int var1, double var2, LivingEntity var4) {
      if ((double)this.r.nextInt(100) <= var2) {
         Location var5 = var4.getLocation();
         var5.getWorld().strikeLightning(var5);
         var4.damage((double)(var1 * 2));
      }

   }

   public void getMagicImp(double var1, LivingEntity var3) {
      if ((double)this.r.nextInt(100) <= var1) {
         Iterator var5 = var3.getActivePotionEffects().iterator();

         while(var5.hasNext()) {
            PotionEffect var4 = (PotionEffect)var5.next();
            var3.removePotionEffect(var4.getType());
         }

         ParticleUtils.doParticle(var3, "CRIT_MAGIC", "VILLAGER_ANGRY");
      }

   }

   public void getGTM(int var1, double var2, Player var4, Player var5) {
      if ((double)this.r.nextInt(100) <= var2) {
         double var6 = this.plugin.getHM().getVault().getBalans(var4);
         double var8 = var6 * (double)(1 - var1 / 100);
         double var10 = var6 - var8;
         if (this.plugin.getHM().getVault().take(var4, var10)) {
            var4.sendMessage(Lang.Enchants_Misc_GTM_Robbed.toMsg().replace("%s", String.valueOf(var10)).replace("%p", var5.getName()));
            var4.playSound(var4.getLocation(), Sound.ENTITY_BLAZE_DEATH, 0.3F, 0.3F);
         }

         if (this.plugin.getHM().getVault().give(var5, var10)) {
            var5.sendMessage(Lang.Enchants_Misc_GTM_Steal.toMsg().replace("%s", String.valueOf(var10)).replace("%p", var4.getName()));
            var5.playSound(var5.getLocation(), Sound.ENTITY_WITCH_AMBIENT, 0.3F, 0.3F);
         }
      }

   }

   public void getFireSpray(int var1, double var2, LivingEntity var4) {
      if ((double)this.r.nextInt(100) <= var2) {
         var4.setFireTicks(20 * var1);
      }

   }

   public void getLavaWalk(Block var1, Player var2) {
      if (Hook.WORLD_GUARD.isEnabled() && this.plugin.getHM().getWorldGuard().canBuilds(var2)) {
         var1.setType(Material.STAINED_GLASS);
         var2.playSound(var1.getLocation(), Sound.BLOCK_LAVA_EXTINGUISH, 0.5F, 0.5F);
      }

   }

   public void getPrayVictor(double var1, LivingEntity var3) {
      if ((double)this.r.nextInt(100) <= var1) {
         Iterator var5 = var3.getActivePotionEffects().iterator();

         while(true) {
            PotionEffect var4;
            do {
               if (!var5.hasNext()) {
                  ParticleUtils.doParticle(var3, "CRIT_MAGIC", "VILLAGER_HAPPY");
                  return;
               }

               var4 = (PotionEffect)var5.next();
            } while(var4.getType() != PotionEffectType.BLINDNESS && var4.getType() != PotionEffectType.CONFUSION && var4.getType() != PotionEffectType.HUNGER && var4.getType() != PotionEffectType.LEVITATION && var4.getType() != PotionEffectType.POISON && var4.getType() != PotionEffectType.SLOW && var4.getType() != PotionEffectType.SLOW_DIGGING && var4.getType() != PotionEffectType.UNLUCK && var4.getType() != PotionEffectType.WEAKNESS && var4.getType() != PotionEffectType.WITHER);

            var3.removePotionEffect(var4.getType());
         }
      }
   }

   public void getEternalDenial(int var1, double var2, LivingEntity var4) {
      if ((double)this.r.nextInt(100) <= var2) {
         Location var5 = var4.getLocation();
         var5.getWorld().strikeLightning(var5);
         var4.damage((double)var1);
      }

   }

   public void getAmbush(int var1, double var2, LivingEntity var4, LivingEntity var5) {
      if ((double)this.r.nextInt(100) <= var2) {
         Utils.playEffect("EXPLOSION_NORMAL", 0.0D, 0.0D, 0.0D, 0.15000000596046448D, 15, var4.getLocation());
         var4.teleport(var5.getLocation().add(var5.getLocation().getDirection().multiply(-2.0D)));
         var5.damage((double)var1);
         Utils.playEffect("EXPLOSION_NORMAL", 0.0D, 0.0D, 0.0D, 0.15000000596046448D, 15, var4.getLocation());
      }

   }

   public void getPunishWave(int var1, double var2, LivingEntity var4) {
      if ((double)this.r.nextInt(100) <= var2) {
         Iterator var6 = var4.getLocation().getWorld().getNearbyEntities(var4.getLocation(), 5.0D, 5.0D, 5.0D).iterator();

         while(true) {
            Entity var5;
            do {
               do {
                  do {
                     if (!var6.hasNext()) {
                        ParticleUtils.wave(var4.getLocation());
                        return;
                     }

                     var5 = (Entity)var6.next();
                  } while(!(var5 instanceof LivingEntity));
               } while(var5.equals(var4));
            } while(Hook.WORLD_GUARD.isEnabled() && !this.plugin.getHM().getWorldGuard().canFights(var4, var5));

            Location var7 = var5.getLocation();
            Location var8 = var7.subtract(var4.getLocation());
            Vector var9 = var8.getDirection().normalize().multiply(-1.4D);
            if (var9.getY() >= 1.15D) {
               var9.setY(var9.getY() * 0.45D);
            } else if (var9.getY() >= 1.0D) {
               var9.setY(var9.getY() * 0.6D);
            } else if (var9.getY() >= 0.8D) {
               var9.setY(var9.getY() * 0.85D);
            }

            if (var9.getY() <= 0.0D) {
               var9.setY(-var9.getY() + 0.3D);
            }

            if (Math.abs(var8.getX()) <= 1.0D) {
               var9.setX(var9.getX() * 1.2D);
            }

            if (Math.abs(var8.getZ()) <= 1.0D) {
               var9.setZ(var9.getZ() * 1.2D);
            }

            double var10 = var9.getX() * 2.0D;
            double var12 = var9.getY() * 2.0D;
            double var14 = var9.getZ() * 2.0D;
            if (var10 >= 3.0D) {
               var10 *= 0.5D;
            }

            if (var12 >= 3.0D) {
               var12 *= 0.5D;
            }

            if (var14 >= 3.0D) {
               var14 *= 0.5D;
            }

            var9.setX(var10);
            var9.setY(var12);
            var9.setZ(var14);
            var5.setVelocity(var9);
            ((LivingEntity)var5).damage((double)var1);
         }
      }
   }

   public Entity getMalice(double var1, double var3, LivingEntity var5, Entity var6) {
      if ((double)this.r.nextInt(100) <= var3) {
         TNTPrimed var7 = (TNTPrimed)var6.getWorld().spawn(var6.getLocation(), TNTPrimed.class);
         var7.setVelocity(var5.getEyeLocation().getDirection().multiply(var1 * 2.0D));
         return var7;
      } else {
         return var6;
      }
   }

   private Projectile getRicochet(Projectile var1, LivingEntity var2, int var3, double var4) {
      var1.setMetadata("RICOCHET-L", new FixedMetadataValue(this.plugin, var2));
      var1.setMetadata("RICOCHET-LVL", new FixedMetadataValue(this.plugin, var3));
      var1.setMetadata("RICOCHET-VAL", new FixedMetadataValue(this.plugin, var4));
      return var1;
   }

   private void onRicochet(Projectile var1, LivingEntity var2, double var3, EntityDamageByEntityEvent var5) {
      if (var1.hasMetadata("RICOCHET-L")) {
         var5.setCancelled(true);
         LivingEntity var6 = (LivingEntity)((MetadataValue)var1.getMetadata("RICOCHET-L").get(0)).value();
         var2.damage(var3, var6);
         double var7 = ((MetadataValue)var1.getMetadata("RICOCHET-LVL").get(0)).asDouble();
         double var9 = ((MetadataValue)var1.getMetadata("RICOCHET-VAL").get(0)).asDouble();
         Iterator var12 = var2.getNearbyEntities(var9, 2.5D, var9).iterator();

         while(var12.hasNext()) {
            Entity var11 = (Entity)var12.next();
            if (var11 instanceof LivingEntity && !var11.equals(var2) && !var11.getUniqueId().toString().equals(var6.getUniqueId().toString())) {
               LivingEntity var13 = (LivingEntity)var11;
               if (!Hook.CITIZENS.isEnabled() || !this.plugin.getHM().getCitizens().isNPC(var13)) {
                  Location var14 = var13.getEyeLocation();
                  Location var15 = var2.getEyeLocation();
                  Vector var16 = (new Location(var14.getWorld(), var14.getX(), var14.getY(), var14.getZ())).toVector();
                  var15.setDirection(var16.subtract(var15.toVector()));
                  Vector var17 = var15.getDirection();
                  var1.setVelocity(var17.multiply(-var7 * 1.5D));
                  break;
               }
            }
         }

      }
   }

   public void getMinigun(double var1, final int var3, double var4, final LivingEntity var6, Entity var7) {
      if ((double)this.r.nextInt(100) <= var4) {
         final Vector var8 = var7.getVelocity();
         (new BukkitRunnable() {
            int i = 0;

            public void run() {
               if (this.i == var3 + 3) {
                  this.cancel();
               }

               ((Arrow)var6.launchProjectile(Arrow.class)).setVelocity(var8);
               ++this.i;
            }
         }).runTaskTimer(this.plugin, 1L, 2L);
      }

   }

   public void getLuckyMiner(int var1, double var2, Block var4, ItemStack var5) {
      if ((double)this.r.nextInt(100) <= var2) {
         Location var6 = var4.getLocation();
         ItemStack var7 = new ItemStack(var4.getType());
         if (!var5.containsEnchantment(Enchantment.SILK_TOUCH)) {
            String[] var8 = var4.getType().toString().split("_");

            for(int var9 = 0; var9 < var8.length; ++var9) {
               Material var10 = Material.getMaterial(var8[var9]);
               if (var10 != null) {
                  var7 = new ItemStack(var10);
                  break;
               }
            }
         }

         for(int var11 = 0; var11 < var1 - 1; ++var11) {
            var6.getWorld().dropItem(var6, var7);
         }
      }

   }

   @EventHandler(
      priority = EventPriority.LOWEST,
      ignoreCancelled = true
   )
   public void onBlockP(BlockPlaceEvent var1) {
      Block var2 = var1.getBlock();
      if (var2.getType() == Material.MOB_SPAWNER) {
         ItemStack var3 = var1.getPlayer().getInventory().getItemInMainHand();
         if (var3 != null && var3.getType() == Material.MOB_SPAWNER) {
            BlockStateMeta var4 = (BlockStateMeta)var3.getItemMeta();
            BlockState var5 = var4.getBlockState();
            CreatureSpawner var6 = (CreatureSpawner)var5;
            BlockState var7 = var2.getState();
            CreatureSpawner var8 = (CreatureSpawner)var7;
            var8.setSpawnedType(var6.getSpawnedType());
            var7.update();
         }

      }
   }

   private void getDivineTouch(double var1, Block var3) {
      if ((double)this.r.nextInt(100) <= var1) {
         Location var4 = var3.getLocation();
         CreatureSpawner var5 = (CreatureSpawner)var3.getState();
         ItemStack var6 = new ItemStack(Material.MOB_SPAWNER);
         BlockStateMeta var7 = (BlockStateMeta)var6.getItemMeta();
         BlockState var8 = var7.getBlockState();
         CreatureSpawner var9 = (CreatureSpawner)var8;
         var9.setSpawnedType(var5.getSpawnedType());
         var8.update(true);
         var7.setDisplayName(Lang.Enchants_Misc_SpawnerName.toMsg().replace("%type%", Lang.getCustom("EntityNames." + var5.getSpawnedType().name())));
         var7.setBlockState(var8);
         var6.setItemMeta(var7);
         var4.getWorld().dropItem(var4, var6);
      }

   }

   private boolean isValidEnchant(String var1, NBTItem var2) {
      EnchantManager.EnchantType var3;
      try {
         var3 = EnchantManager.EnchantType.valueOf(var2.getString(var1).split(":")[0]);
      } catch (IllegalArgumentException var5) {
         return false;
      }

      EnchantManager.Enchant var4 = this.getEnchantByType(var3);
      return var4 != null && var4.isEnabled();
   }

   // $FF: synthetic method
   static int[] $SWITCH_TABLE$su$nightexpress$divineitems$types$DestroyType() {
      int[] var10000 = $SWITCH_TABLE$su$nightexpress$divineitems$types$DestroyType;
      if (var10000 != null) {
         return var10000;
      } else {
         int[] var0 = new int[DestroyType.values().length];

         try {
            var0[DestroyType.BOTH.ordinal()] = 4;
         } catch (NoSuchFieldError var4) {
         }

         try {
            var0[DestroyType.CLEAR.ordinal()] = 3;
         } catch (NoSuchFieldError var3) {
         }

         try {
            var0[DestroyType.ITEM.ordinal()] = 1;
         } catch (NoSuchFieldError var2) {
         }

         try {
            var0[DestroyType.SOURCE.ordinal()] = 2;
         } catch (NoSuchFieldError var1) {
         }

         $SWITCH_TABLE$su$nightexpress$divineitems$types$DestroyType = var0;
         return var0;
      }
   }

   // $FF: synthetic method
   static int[] $SWITCH_TABLE$su$nightexpress$divineitems$modules$enchant$EnchantManager$EnchantType() {
      int[] var10000 = $SWITCH_TABLE$su$nightexpress$divineitems$modules$enchant$EnchantManager$EnchantType;
      if (var10000 != null) {
         return var10000;
      } else {
         int[] var0 = new int[EnchantManager.EnchantType.values().length];

         try {
            var0[EnchantManager.EnchantType.AMBUSH.ordinal()] = 15;
         } catch (NoSuchFieldError var23) {
         }

         try {
            var0[EnchantManager.EnchantType.DIVINE_TOUCH.ordinal()] = 21;
         } catch (NoSuchFieldError var22) {
         }

         try {
            var0[EnchantManager.EnchantType.ETERNAL_DENIAL.ordinal()] = 16;
         } catch (NoSuchFieldError var21) {
         }

         try {
            var0[EnchantManager.EnchantType.EXECUTIONER.ordinal()] = 1;
         } catch (NoSuchFieldError var20) {
         }

         try {
            var0[EnchantManager.EnchantType.EXHAUST.ordinal()] = 6;
         } catch (NoSuchFieldError var19) {
         }

         try {
            var0[EnchantManager.EnchantType.EXP_HUNTER.ordinal()] = 9;
         } catch (NoSuchFieldError var18) {
         }

         try {
            var0[EnchantManager.EnchantType.EYE_BURN.ordinal()] = 5;
         } catch (NoSuchFieldError var17) {
         }

         try {
            var0[EnchantManager.EnchantType.FLAME_SPRAY.ordinal()] = 12;
         } catch (NoSuchFieldError var16) {
         }

         try {
            var0[EnchantManager.EnchantType.GTM.ordinal()] = 11;
         } catch (NoSuchFieldError var15) {
         }

         try {
            var0[EnchantManager.EnchantType.JUSTICE.ordinal()] = 8;
         } catch (NoSuchFieldError var14) {
         }

         try {
            var0[EnchantManager.EnchantType.LAVA_WALKER.ordinal()] = 17;
         } catch (NoSuchFieldError var13) {
         }

         try {
            var0[EnchantManager.EnchantType.LEG_GRAB.ordinal()] = 2;
         } catch (NoSuchFieldError var12) {
         }

         try {
            var0[EnchantManager.EnchantType.LUCKY_MINER.ordinal()] = 20;
         } catch (NoSuchFieldError var11) {
         }

         try {
            var0[EnchantManager.EnchantType.MAGIC_IMPLOSION.ordinal()] = 10;
         } catch (NoSuchFieldError var10) {
         }

         try {
            var0[EnchantManager.EnchantType.MALICE_JOKE.ordinal()] = 18;
         } catch (NoSuchFieldError var9) {
         }

         try {
            var0[EnchantManager.EnchantType.MINIGUN.ordinal()] = 19;
         } catch (NoSuchFieldError var8) {
         }

         try {
            var0[EnchantManager.EnchantType.NO_GRAVITY.ordinal()] = 22;
         } catch (NoSuchFieldError var7) {
         }

         try {
            var0[EnchantManager.EnchantType.PARALYZE.ordinal()] = 7;
         } catch (NoSuchFieldError var6) {
         }

         try {
            var0[EnchantManager.EnchantType.PRAYER_OF_VICTORY.ordinal()] = 14;
         } catch (NoSuchFieldError var5) {
         }

         try {
            var0[EnchantManager.EnchantType.PUNISHING_WAVE.ordinal()] = 13;
         } catch (NoSuchFieldError var4) {
         }

         try {
            var0[EnchantManager.EnchantType.RICOCHET.ordinal()] = 23;
         } catch (NoSuchFieldError var3) {
         }

         try {
            var0[EnchantManager.EnchantType.VENOM.ordinal()] = 3;
         } catch (NoSuchFieldError var2) {
         }

         try {
            var0[EnchantManager.EnchantType.WITHER.ordinal()] = 4;
         } catch (NoSuchFieldError var1) {
         }

         $SWITCH_TABLE$su$nightexpress$divineitems$modules$enchant$EnchantManager$EnchantType = var0;
         return var0;
      }
   }

   public class Enchant {
      private boolean enabled;
      private String id;
      private String name;
      private List<String> desc;
      private double value;
      private double value_lvl;
      private int lvl_get;
      private int min_lvl;
      private int max_lvl;
      private double table;
      private List<String> item_types;
      private List<String> conflict;

      public Enchant(boolean var2, String var3, String var4, List<String> var5, double var6, double var8, int var10, int var11, int var12, double var13, List<String> var15, List<String> var16) {
         this.setEnabled(var2);
         this.setId(var3);
         this.setName(var4);
         this.setDesc(var5);
         this.setValue(var6);
         this.setValueLvl(var8);
         this.setEnchantLevel(var10);
         this.setMinLevel(var11);
         this.setMaxLevel(var12);
         this.setTableRate(var13);
         this.setItemTypes(var15);
         this.setConflicts(var16);
      }

      public boolean isEnabled() {
         return this.enabled;
      }

      public void setEnabled(boolean var1) {
         this.enabled = var1;
      }

      public String getId() {
         return this.id;
      }

      public void setId(String var1) {
         this.id = var1;
      }

      public String getName() {
         return this.name;
      }

      public void setName(String var1) {
         this.name = var1;
      }

      public List<String> getDesc() {
         return this.desc;
      }

      public void setDesc(List<String> var1) {
         this.desc = var1;
      }

      public double getValue() {
         return this.value;
      }

      public void setValue(double var1) {
         this.value = var1;
      }

      public double getValueLvl() {
         return this.value_lvl;
      }

      public void setValueLvl(double var1) {
         this.value_lvl = var1;
      }

      public int getEnchantLevel() {
         return this.lvl_get;
      }

      public void setEnchantLevel(int var1) {
         this.lvl_get = var1;
      }

      public int getMinLevel() {
         return this.min_lvl;
      }

      public void setMinLevel(int var1) {
         this.min_lvl = var1;
      }

      public int getMaxLevel() {
         return this.max_lvl;
      }

      public void setMaxLevel(int var1) {
         this.max_lvl = var1;
      }

      public double getTableRate() {
         return this.table;
      }

      public void setTableRate(double var1) {
         this.table = var1;
      }

      public List<String> getItemTypes() {
         return this.item_types;
      }

      public void setItemTypes(List<String> var1) {
         this.item_types = var1;
      }

      public List<String> getConflicts() {
         return this.conflict;
      }

      public void setConflicts(List<String> var1) {
         this.conflict = var1;
      }

      public ItemStack create(int var1) {
         if (!this.isEnabled()) {
            return null;
         } else {
            if (var1 == -1) {
               var1 = Utils.randInt(this.getMinLevel(), this.getMaxLevel());
            } else if (var1 > this.getMaxLevel()) {
               var1 = this.getMaxLevel();
            } else if (var1 < 1) {
               var1 = this.getMinLevel();
            }

            String var2 = (String)EnchantManager.this.getSettings().getMaterials().get((new Random()).nextInt(EnchantManager.this.getSettings().getMaterials().size()));
            String[] var3 = var2.split(":");
            ItemStack var4 = Utils.buildItem(var3, this.id);
            ItemMeta var5 = var4.getItemMeta();
            double var6 = Utils.round3(this.getValue() + this.getValueLvl() * (double)(var1 - 1));
            String var8 = this.getName().replace("%level%", String.valueOf(var1)).replace("%rlevel%", Utils.IntegerToRomanNumeral(var1));
            String var9 = EnchantManager.this.getSettings().getDisplay().replace("%s", var8);
            int var10 = Utils.randInt(EnchantManager.this.getSettings().getMinChance(), EnchantManager.this.getSettings().getMaxChance());
            int var11 = 100 - var10;
            String var12 = "";
            String var13 = EnchantManager.this.plugin.getCM().getCFG().getStrClassColor();
            String var14 = EnchantManager.this.plugin.getCM().getCFG().getStrClassSeparator();

            String var17;
            for(Iterator var16 = this.getItemTypes().iterator(); var16.hasNext(); var12 = var12 + var13 + var17 + var14) {
               String var15 = (String)var16.next();
               var17 = var15.replace("*", "");
               if (Lang.hasPath("ItemTypes." + var17)) {
                  var17 = Lang.getCustom("ItemTypes." + var17);
               }
            }

            if (var12.length() > 3) {
               var12 = var12.substring(0, var12.length() - 3);
            }

            ArrayList var20 = new ArrayList();
            Iterator var23 = EnchantManager.this.getSettings().getLore().iterator();

            while(true) {
               while(var23.hasNext()) {
                  String var21 = (String)var23.next();
                  if (var21.equals("%desc%")) {
                     Iterator var19 = this.getDesc().iterator();

                     while(var19.hasNext()) {
                        String var18 = (String)var19.next();
                        var20.add(var18.replace("%value%", "" + var6).replace("%rlevel%", Utils.IntegerToRomanNumeral(var1)).replace("%level%", String.valueOf(var1)));
                     }
                  } else {
                     var20.add(ChatColor.translateAlternateColorCodes('&', var21.replace("%d%", String.valueOf(var11)).replace("%s%", String.valueOf(var10)).replace("%type%", var12).replace("%value%", "" + var6).replace("%rlevel%", Utils.IntegerToRomanNumeral(var1)).replace("%level%", String.valueOf(var1))));
                  }
               }

               var5.setDisplayName(var9);
               var5.setLore(var20);
               var5.addItemFlags(ItemFlag.values());
               var5.spigot().setUnbreakable(true);
               var4.setItemMeta(var5);
               NBTItem var22 = new NBTItem(var4);
               var22.setString("DIVINE_ENCHANT", this.getId().toUpperCase() + ":" + var1 + ":" + var6);
               var22.setInteger("DIVINE_CHANCE", var10);
               return var22.getItem();
            }
         }
      }
   }

   public class EnchantSettings extends MainSettings {
      private List<String> material;
      private boolean table;
      private double table_chance;

      public EnchantSettings(List<String> var2, String var3, List<String> var4, int var5, int var6, DestroyType var7, boolean var8, String var9, String var10, boolean var11, Sound var12, Sound var13, String var14, String var15, String var16, boolean var17, double var18) {
         super(var3, var4, var5, var6, var7, var8, var9, var10, var11, var12, var13, var14, var15, var16);
         this.setMaterials(var2);
         this.setTableEnabled(var17);
         this.setTableChance(var18);
      }

      public List<String> getMaterials() {
         return this.material;
      }

      public void setMaterials(List<String> var1) {
         this.material = var1;
      }

      public boolean isTableEnabled() {
         return this.table;
      }

      public void setTableEnabled(boolean var1) {
         this.table = var1;
      }

      public double getTableChance() {
         return this.table_chance;
      }

      public void setTableChance(double var1) {
         this.table_chance = var1;
      }
   }

   public static enum EnchantType {
      EXECUTIONER,
      LEG_GRAB,
      VENOM,
      WITHER,
      EYE_BURN,
      EXHAUST,
      PARALYZE,
      JUSTICE,
      EXP_HUNTER,
      MAGIC_IMPLOSION,
      GTM,
      FLAME_SPRAY,
      PUNISHING_WAVE,
      PRAYER_OF_VICTORY,
      AMBUSH,
      ETERNAL_DENIAL,
      LAVA_WALKER,
      MALICE_JOKE,
      MINIGUN,
      LUCKY_MINER,
      DIVINE_TOUCH,
      NO_GRAVITY,
      RICOCHET;
   }
}
