package su.nightexpress.divineitems.modules.gems;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import net.md_5.bungee.api.ChatColor;
import org.apache.commons.lang.ArrayUtils;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import su.nightexpress.divineitems.DivineItems;
import su.nightexpress.divineitems.DivineListener;
import su.nightexpress.divineitems.Module;
import su.nightexpress.divineitems.attributes.ItemStat;
import su.nightexpress.divineitems.cmds.list.GemsCommand;
import su.nightexpress.divineitems.config.Lang;
import su.nightexpress.divineitems.config.MyConfig;
import su.nightexpress.divineitems.gui.ContentType;
import su.nightexpress.divineitems.gui.GUI;
import su.nightexpress.divineitems.gui.GUIItem;
import su.nightexpress.divineitems.gui.GUIType;
import su.nightexpress.divineitems.modules.MainSettings;
import su.nightexpress.divineitems.nbt.NBTItem;
import su.nightexpress.divineitems.types.ArmorType;
import su.nightexpress.divineitems.types.DamageType;
import su.nightexpress.divineitems.types.DestroyType;
import su.nightexpress.divineitems.types.SlotType;
import su.nightexpress.divineitems.utils.ErrorLog;
import su.nightexpress.divineitems.utils.ItemUtils;
import su.nightexpress.divineitems.utils.Utils;

public class GemManager extends DivineListener<DivineItems> implements Module {
   private DivineItems plugin;
   private boolean e;
   private Random r;
   private MyConfig settingsCfg;
   private MyConfig gemsCfg;
   private GemManager.GemSettings settings;
   private HashMap<String, GemManager.Gem> gems;
   private final String n = this.name().toLowerCase().replace(" ", "_");
   private final String label;
   private final String NBT_KEY_VAR_ATT;
   private final String NBT_KEY_ITEM_GEM;
   private final String NBT_KEY_GEM;
   private final String NBT_KEY_GEM_ILD;
   // $FF: synthetic field
   private static int[] $SWITCH_TABLE$su$nightexpress$divineitems$types$DestroyType;

   public GemManager(DivineItems var1) {
      super(var1);
      this.label = this.n.replace("_", "");
      this.NBT_KEY_VAR_ATT = "DIVINE_VAR_ATT_";
      this.NBT_KEY_ITEM_GEM = "GEM_";
      this.NBT_KEY_GEM = "DIVINE_GEM_ID";
      this.NBT_KEY_GEM_ILD = "DIVINE_GEM_ILD";
      this.plugin = var1;
      this.e = this.plugin.getCM().getCFG().isModuleEnabled(this.name());
      this.r = new Random();
   }

   public void loadConfig() {
      this.gems = new HashMap();
      this.settingsCfg = new MyConfig(this.plugin, "/modules/" + this.n, "settings.yml");
      this.gemsCfg = new MyConfig(this.plugin, "/modules/" + this.n, "gems.yml");
      this.setupSettings();
      this.setupGems();
      this.setupSlot();
   }

   public boolean isActive() {
      return this.e;
   }

   public boolean isDropable() {
      return true;
   }

   public boolean isResolvable() {
      return true;
   }

   public String name() {
      return "Gems";
   }

   public String version() {
      return "1.0";
   }

   public void enable() {
      if (this.isActive()) {
         this.plugin.getCommander().registerCmd(this.label, new GemsCommand(this.plugin));
         this.loadConfig();
         this.registerListeners();
      }

   }

   public void unload() {
      if (this.isActive()) {
         this.plugin.getCommander().unregisterCmd(this.label);
         this.gems.clear();
         this.settings = null;
         this.e = false;
         this.unregisterListeners();
      }

   }

   public void reload() {
      this.unload();
      this.enable();
   }

   private void setupSlot() {
      SlotType var1 = SlotType.GEM;
      var1.setModule(this);
      var1.setHeader(this.getSettings().getHeader());
      var1.setEmpty(this.getSettings().getEmptySlot());
      var1.setFilled(this.getSettings().getFilledSlot());
   }

   private void setupSettings() {
      FileConfiguration var1 = this.settingsCfg.getConfig();
      if (!var1.contains("General.AllowMultipleSameGemsInOneItem")) {
         var1.set("General.AllowMultipleSameGemsInOneItem", true);
      }

      boolean var2 = var1.getBoolean("General.AllowMultipleSameGemsInOneItem");
      String var3 = "Item.";
      String var4 = ChatColor.translateAlternateColorCodes('&', var1.getString(var3 + "Display"));
      List var5 = var1.getStringList(var3 + "Lore");
      var3 = "Enchant.";
      int var6 = var1.getInt(var3 + "MinSuccessChance");
      int var7 = var1.getInt(var3 + "MaxSuccessChance");
      DestroyType var8 = DestroyType.CLEAR;

      try {
         var8 = DestroyType.valueOf(var1.getString(var3 + "DestroyType"));
      } catch (IllegalArgumentException var20) {
         ErrorLog.sendError(this, var3 + "DestroyType", "Invalid Destroy Type!", true);
         var1.set(var3 + "DestroyType", "CLEAR");
      }

      var3 = "Effects.";
      boolean var9 = var1.getBoolean(var3 + "Enabled");
      String var10 = var1.getString(var3 + "Failure");
      String var11 = var1.getString(var3 + "Success");
      var3 = "Sounds.";
      boolean var12 = var1.getBoolean(var3 + "Enabled");
      Sound var13 = Sound.BLOCK_ANVIL_BREAK;

      try {
         var13 = Sound.valueOf(var1.getString(var3 + "Failure"));
      } catch (IllegalArgumentException var19) {
         ErrorLog.sendError(this, var3 + "Failure", "Invalid Sound Type!", true);
         var1.set(var3 + "Failure", "BLOCK_ANVIL_BREAK");
      }

      Sound var14 = Sound.ENTITY_EXPERIENCE_ORB_PICKUP;

      try {
         var14 = Sound.valueOf(var1.getString(var3 + "Success"));
      } catch (IllegalArgumentException var18) {
         ErrorLog.sendError(this, var3 + "Success", "Invalid Sound Type!", true);
         var1.set(var3 + "Success", "ENTITY_EXPERIENCE_ORB_PICKUP");
      }

      var3 = "Design.";
      String var15 = ChatColor.translateAlternateColorCodes('&', var1.getString(var3 + "Header"));
      String var16 = ChatColor.translateAlternateColorCodes('&', var1.getString(var3 + "EmptySlot"));
      String var17 = ChatColor.translateAlternateColorCodes('&', var1.getString(var3 + "FilledSlot"));
      this.settings = new GemManager.GemSettings(var2, var4, var5, var6, var7, var8, var9, var10, var11, var12, var13, var14, var15, var16, var17);
      this.settingsCfg.save();
   }

   private void setupGems() {
      FileConfiguration var1 = this.gemsCfg.getConfig();
      if (var1.contains("Gems")) {
         Iterator var3 = var1.getConfigurationSection("Gems").getKeys(false).iterator();

         while(true) {
            String var4;
            String var5;
            boolean var6;
            do {
               if (!var3.hasNext()) {
                  this.gemsCfg.save();
                  return;
               }

               String var2 = (String)var3.next();
               var4 = "Gems." + var2 + ".";
               var5 = var2.toLowerCase();
               var6 = var1.getBoolean(var4 + "Enabled");
            } while(!var6);

            boolean var7 = var1.getBoolean(var4 + "Enchanted");
            String var8 = var1.getString(var4 + "Material");
            String var9 = ChatColor.translateAlternateColorCodes('&', var1.getString(var4 + "Name"));
            if (!var1.contains(var4 + "ItemLoreDisplay")) {
               var1.set(var4 + "ItemLoreDisplay", var9);
            }

            String var10 = ChatColor.translateAlternateColorCodes('&', var1.getString(var4 + "ItemLoreDisplay"));
            List var11 = var1.getStringList(var4 + "Desc");
            HashMap var12 = new HashMap();
            if (var1.contains(var4 + "Variables")) {
               Iterator var14 = var1.getConfigurationSection(var4 + "Variables").getKeys(false).iterator();

               while(var14.hasNext()) {
                  String var13 = (String)var14.next();
                  double var15 = var1.getDouble(var4 + "Variables." + var13);
                  var12.put(var13, var15);
               }
            }

            HashMap var20 = new HashMap();
            Iterator var23 = var1.getConfigurationSection(var4 + "VariablesPerLvl").getKeys(false).iterator();

            while(var23.hasNext()) {
               String var21 = (String)var23.next();
               double var16 = var1.getDouble(var4 + "VariablesPerLvl." + var21);
               var20.put(var21, var16);
            }

            HashMap var22 = new HashMap();
            Iterator var26 = var1.getConfigurationSection(var4 + "VariablesAttributes").getKeys(false).iterator();

            while(var26.hasNext()) {
               String var24 = (String)var26.next();
               String var17 = var1.getString(var4 + "VariablesAttributes." + var24).toUpperCase();
               var22.put(var24, var17);
            }

            HashMap var25 = new HashMap();
            Iterator var29 = var1.getConfigurationSection(var4 + "VariablesPercentage").getKeys(false).iterator();

            while(var29.hasNext()) {
               String var27 = (String)var29.next();
               boolean var18 = var1.getBoolean(var4 + "VariablesPercentage." + var27);
               var25.put(var27, var18);
            }

            int var28 = var1.getInt(var4 + "LevelMin");
            int var30 = var1.getInt(var4 + "LevelMax");
            List var31 = var1.getStringList(var4 + "ItemTypes");
            GemManager.Gem var19 = new GemManager.Gem(var6, var7, var5, var8, var9, var10, var11, var12, var20, var22, var25, var28, var30, var31);
            this.gems.put(var5, var19);
         }
      }
   }

   public HashMap<String, String> getGemValues(ItemStack var1) {
      HashMap var2 = new HashMap();
      if (var1 == null) {
         return var2;
      } else {
         NBTItem var3 = new NBTItem(var1);
         Iterator var5 = var3.getKeys().iterator();

         while(var5.hasNext()) {
            String var4 = (String)var5.next();
            if (var4.startsWith("DIVINE_VAR_ATT_")) {
               String[] var6 = var3.getString(var4).split("@");
               String var7 = var6[0];
               boolean var8 = Boolean.valueOf(var6[1]);
               double var9 = Double.parseDouble(var6[2]);
               String var11 = String.valueOf(var9);
               if (var8) {
                  var11 = var11 + "%";
               }

               if (var2.containsKey(var7)) {
                  var11 = (String)var2.get(var7) + "/" + var11;
               }

               var2.put(var7, var11);
            }
         }

         return var2;
      }
   }

   public HashMap<ItemStat, Double> getItemGemStats(ItemStack var1, boolean var2) {
      HashMap var3 = new HashMap();
      if (var1 == null) {
         return var3;
      } else {
         NBTItem var4 = new NBTItem(var1);
         Iterator var6 = var4.getKeys().iterator();

         while(true) {
            String var5;
            do {
               if (!var6.hasNext()) {
                  return var3;
               }

               var5 = (String)var6.next();
            } while(!var5.startsWith("GEM_"));

            String var7 = var4.getString(var5);
            String[] var8 = var7.split("\\|");
            String[] var12 = var8;
            int var11 = var8.length;

            for(int var10 = 0; var10 < var11; ++var10) {
               String var9 = var12[var10];

               try {
                  ItemStat var13 = ItemStat.valueOf(var9.split("@")[0]);
                  String[] var14 = var9.split("@")[1].split("\\/");
                  String[] var18 = var14;
                  int var17 = var14.length;

                  for(int var16 = 0; var16 < var17; ++var16) {
                     String var15 = var18[var16];
                     double var19 = 0.0D;
                     if (var15.endsWith("%")) {
                        if (!var2) {
                           continue;
                        }

                        var19 = Double.parseDouble(var15.replace("%", ""));
                     } else {
                        if (var2) {
                           continue;
                        }

                        var19 = Double.parseDouble(var15);
                     }

                     if (var3.containsKey(var13)) {
                        var19 += (Double)var3.get(var13);
                     }

                     var3.put(var13, var19);
                  }
               } catch (IllegalArgumentException var21) {
               }
            }
         }
      }
   }

   public HashMap<DamageType, Double> getItemGemDamages(ItemStack var1, boolean var2) {
      HashMap var3 = new HashMap();
      if (var1 == null) {
         return var3;
      } else {
         NBTItem var4 = new NBTItem(var1);
         Iterator var6 = var4.getKeys().iterator();

         while(true) {
            String var5;
            do {
               if (!var6.hasNext()) {
                  return var3;
               }

               var5 = (String)var6.next();
            } while(!var5.startsWith("GEM_"));

            String var7 = var4.getString(var5);
            String[] var8 = var7.split("\\|");
            String[] var12 = var8;
            int var11 = var8.length;

            for(int var10 = 0; var10 < var11; ++var10) {
               String var9 = var12[var10];
               String var13 = var9.split("@")[0];
               if (var13.endsWith("_DAMAGE_TYPE")) {
                  var13 = var13.replace("_DAMAGE_TYPE", "");
                  DamageType var14 = this.plugin.getCFG().getDamageTypeById(var13);
                  if (var14 != null) {
                     String[] var15 = var9.split("@")[1].split("\\/");
                     String[] var19 = var15;
                     int var18 = var15.length;

                     for(int var17 = 0; var17 < var18; ++var17) {
                        String var16 = var19[var17];
                        double var20 = 0.0D;
                        if (var16.endsWith("%")) {
                           if (!var2) {
                              continue;
                           }

                           var20 = Double.parseDouble(var16.replace("%", ""));
                        } else {
                           if (var2) {
                              continue;
                           }

                           var20 = Double.parseDouble(var16);
                        }

                        if (var3.containsKey(var14)) {
                           var20 += (Double)var3.get(var14);
                        }

                        var3.put(var14, var20);
                     }
                  }
               }
            }
         }
      }
   }

   public HashMap<ArmorType, Double> getItemGemArmors(ItemStack var1, boolean var2) {
      HashMap var3 = new HashMap();
      NBTItem var4 = new NBTItem(var1);
      Iterator var6 = var4.getKeys().iterator();

      while(true) {
         String var5;
         do {
            if (!var6.hasNext()) {
               return var3;
            }

            var5 = (String)var6.next();
         } while(!var5.startsWith("GEM_"));

         String var7 = var4.getString(var5);
         String[] var8 = var7.split("\\|");
         String[] var12 = var8;
         int var11 = var8.length;

         for(int var10 = 0; var10 < var11; ++var10) {
            String var9 = var12[var10];
            String var13 = var9.split("@")[0];
            if (var13.endsWith("_ARMOR_TYPE") || var13.endsWith("_DEFENSE_TYPE")) {
               var13 = var13.replace("_ARMOR_TYPE", "").replace("_DEFENSE_TYPE", "");
               ArmorType var14 = this.plugin.getCFG().getArmorTypeById(var13);
               if (var14 != null) {
                  String[] var15 = var9.split("@")[1].split("\\/");
                  String[] var19 = var15;
                  int var18 = var15.length;

                  for(int var17 = 0; var17 < var18; ++var17) {
                     String var16 = var19[var17];
                     double var20 = 0.0D;
                     if (var16.endsWith("%")) {
                        if (!var2) {
                           continue;
                        }

                        var20 = Double.parseDouble(var16.replace("%", ""));
                     } else {
                        if (var2) {
                           continue;
                        }

                        var20 = Double.parseDouble(var16);
                     }

                     if (var3.containsKey(var14)) {
                        var20 += (Double)var3.get(var14);
                     }

                     var3.put(var14, var20);
                  }
               }
            }
         }
      }
   }

   public ItemStack insertGem(ItemStack var1, ItemStack var2) {
      String var3 = "";

      String var6;
      String var7;
      for(Iterator var5 = this.getGemValues(var1).keySet().iterator(); var5.hasNext(); var3 = var3 + var7) {
         String var4 = (String)var5.next();
         var6 = (String)this.getGemValues(var1).get(var4);
         var7 = var4 + "@" + var6;
         if (!var3.isEmpty()) {
            var3 = var3 + "|";
         }
      }

      NBTItem var14 = new NBTItem(var2);
      int var15 = 0;
      Iterator var17 = var14.getKeys().iterator();

      while(var17.hasNext()) {
         var6 = (String)var17.next();
         if (var6.startsWith("GEM_")) {
            ++var15;
         }
      }

      NBTItem var16 = new NBTItem(var1);
      var7 = var16.getString("DIVINE_GEM_ILD");
      List var8 = var2.getItemMeta().getLore();
      Iterator var10 = var8.iterator();

      String var11;
      while(var10.hasNext()) {
         String var9 = (String)var10.next();
         var11 = ChatColor.stripColor(var9);
         String var12 = ChatColor.stripColor(this.getSettings().getEmptySlot());
         if (var11.equals(var12)) {
            int var13 = var8.indexOf(var9);
            var8.remove(var13);
            var8.add(var13, this.getSettings().getFilledSlot() + var7);
            break;
         }
      }

      ItemMeta var18 = var2.getItemMeta();
      var18.setLore(var8);
      var2.setItemMeta(var18);
      NBTItem var19 = new NBTItem(var2);
      var11 = (new NBTItem(var1)).getString("DIVINE_GEM_ID");
      var19.setString("GEM_" + var15 + "_" + var11, var3);
      return var19.getItem();
   }

   public int getItemGemsAmount(ItemStack var1) {
      NBTItem var2 = new NBTItem(var1);
      int var3 = 0;
      Iterator var5 = var2.getKeys().iterator();

      while(var5.hasNext()) {
         String var4 = (String)var5.next();
         if (var4.startsWith("GEM_")) {
            ++var3;
         }
      }

      return var3;
   }

   public ItemStack removeGem(ItemStack var1, int var2) {
      NBTItem var3 = new NBTItem(var1);
      int var4 = this.getItemGemsAmount(var1);
      int var5 = var2 - 1;
      int var6 = var4 - var5;
      int var7 = var6;
      if (var5 == 0) {
         var7 = var6 - 1;
      }

      Iterator var9 = var3.getKeys().iterator();

      while(var9.hasNext()) {
         String var8 = (String)var9.next();
         if (var8.startsWith("GEM_" + var7)) {
            var3.removeKey(var8);
            break;
         }
      }

      var1 = new ItemStack(var3.getItem());
      ItemMeta var14 = var1.getItemMeta();
      ArrayList var15 = new ArrayList(var14.getLore());
      int var10 = 0;
      int var11 = 0;

      for(Iterator var13 = var14.getLore().iterator(); var13.hasNext(); ++var11) {
         String var12 = (String)var13.next();
         if (var12.startsWith(this.getSettings().getFilledSlot())) {
            ++var10;
         }

         if (var10 == var6) {
            var15.remove(var11);
            var15.add(var11, this.settings.getEmptySlot());
            break;
         }
      }

      var14.setLore(var15);
      var1.setItemMeta(var14);
      return var1;
   }

   private ItemStack getResult(ItemStack var1, ItemStack var2) {
      ItemStack var3 = new ItemStack(this.insertGem(var1, var2));
      ItemMeta var4 = var3.getItemMeta();
      var4.setDisplayName(Lang.Gems_Enchanting_Result.toMsg());
      var3.setItemMeta(var4);
      return var3;
   }

   private void openEnchantGUI(Player var1, ItemStack var2, ItemStack var3) {
      GUI var4 = new GUI(this.plugin.getGUIManager().getGUIByType(GUIType.ENCHANT_GEM));
      ((GUIItem)var4.getItems().get(ContentType.TARGET)).setItem(var2);
      ((GUIItem)var4.getItems().get(ContentType.SOURCE)).setItem(var3);
      ((GUIItem)var4.getItems().get(ContentType.RESULT)).setItem(this.getResult(new ItemStack(var3), new ItemStack(var2)));
      this.plugin.getGUIManager().setGUI(var1, var4);
      var1.openInventory(var4.build());
   }

   public boolean hasGem(ItemStack var1, String var2) {
      NBTItem var3 = new NBTItem(var1);
      Iterator var5 = var3.getKeys().iterator();

      while(var5.hasNext()) {
         String var4 = (String)var5.next();
         if (var4.startsWith("GEM_")) {
            String[] var6 = var3.getString(var4).split("_");
            if (var6.length != 3) {
               return false;
            }

            if (var6[2].equalsIgnoreCase(var2)) {
               return true;
            }
         }
      }

      return false;
   }

   public GemManager.GemSettings getSettings() {
      return this.settings;
   }

   public Collection<GemManager.Gem> getGems() {
      return this.gems.values();
   }

   public List<String> getGemNames() {
      ArrayList var1 = new ArrayList();
      Iterator var3 = this.getGems().iterator();

      while(var3.hasNext()) {
         GemManager.Gem var2 = (GemManager.Gem)var3.next();
         var1.add(var2.getId());
      }

      return var1;
   }

   public GemManager.Gem getGemById(String var1) {
      return var1.equalsIgnoreCase("random") ? (GemManager.Gem)(new ArrayList(this.getGems())).get(this.r.nextInt(this.getGems().size())) : (GemManager.Gem)this.gems.get(var1.toLowerCase());
   }

   public boolean isGem(ItemStack var1) {
      return (new NBTItem(var1)).hasKey("DIVINE_GEM_ID");
   }

   public String getGemId(ItemStack var1) {
      return (new NBTItem(var1)).getString("DIVINE_GEM_ID");
   }

   @EventHandler
   public void onInvClick(InventoryClickEvent var1) {
      if (var1.getWhoClicked() instanceof Player) {
         Player var2 = (Player)var1.getWhoClicked();
         ItemStack var3 = var1.getCursor();
         ItemStack var4 = var1.getCurrentItem();
         if (var3 != null && var4 != null) {
            if (var1.getInventory().getType() == InventoryType.CRAFTING) {
               if (var1.getSlotType() != org.bukkit.event.inventory.InventoryType.SlotType.CRAFTING) {
                  if (var1.getSlotType() != org.bukkit.event.inventory.InventoryType.SlotType.ARMOR && var1.getSlot() != 40) {
                     if (var3.hasItemMeta() && var3.getItemMeta().hasLore()) {
                        if (var4.hasItemMeta() && var4.getItemMeta().hasLore()) {
                           NBTItem var5 = new NBTItem(var3);
                           if (var5.hasKey("DIVINE_GEM_ID")) {
                              String var6 = var5.getString("DIVINE_GEM_ID");
                              if (this.getGemById(var6) == null) {
                                 var2.sendMessage(Lang.Prefix.toMsg() + Lang.Other_Internal.toMsg());
                              } else if (!this.settings.allowMultSameGems() && this.hasGem(var4, var6)) {
                                 var2.sendMessage(Lang.Prefix.toMsg() + Lang.Gems_Enchanting_MultipleNotAllowed.toMsg().replace("%gem%", var6));
                              } else {
                                 GemManager.Gem var7 = this.getGemById(var6);
                                 boolean var8 = false;
                                 Iterator var10 = var7.getItemTypes().iterator();

                                 String var9;
                                 while(var10.hasNext()) {
                                    var9 = (String)var10.next();
                                    if (ItemUtils.isValidItemType(var9, var4)) {
                                       var8 = true;
                                       break;
                                    }
                                 }

                                 if (!var8) {
                                    var2.sendMessage(Lang.Prefix.toMsg() + Lang.Gems_Enchanting_InvalidType.toMsg());
                                 } else if (var2.getInventory().firstEmpty() == -1) {
                                    var2.sendMessage(Lang.Prefix.toMsg() + Lang.Gems_Enchanting_FullInventory.toMsg());
                                 } else {
                                    var10 = var4.getItemMeta().getLore().iterator();

                                    while(var10.hasNext()) {
                                       var9 = (String)var10.next();
                                       String var11 = ChatColor.stripColor(var9);
                                       String var12 = ChatColor.stripColor(this.getSettings().getEmptySlot());
                                       if (var11.equalsIgnoreCase(var12)) {
                                          var1.setCursor((ItemStack)null);
                                          var2.getInventory().addItem(new ItemStack[]{var3});
                                          var1.setCancelled(true);
                                          this.openEnchantGUI(var2, var4, var3);
                                          return;
                                       }
                                    }

                                    var2.sendMessage(Lang.Prefix.toMsg() + Lang.Gems_Enchanting_NoSlots.toMsg());
                                 }
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
      }
   }

   @EventHandler
   public void onClick(InventoryClickEvent var1) {
      Player var2 = (Player)var1.getWhoClicked();
      if (this.plugin.getGUIManager().valid(var2, GUIType.ENCHANT_GEM)) {
         GUI var3 = this.plugin.getGUIManager().getPlayerGUI(var2, GUIType.ENCHANT_GEM);
         if (var3 != null && var1.getInventory().getTitle().equals(var3.getTitle())) {
            var1.setCancelled(true);
            ItemStack var4 = var1.getCurrentItem();
            if (var4 != null && var4.hasItemMeta()) {
               GUIItem var5 = (GUIItem)var3.getItems().get(ContentType.ACCEPT);
               int var6 = var1.getRawSlot();
               if (!var4.isSimilar(var5.getItem()) && !ArrayUtils.contains(var5.getSlots(), var6)) {
                  GUIItem var19 = (GUIItem)var3.getItems().get(ContentType.DECLINE);
                  if (var4.isSimilar(var19.getItem()) || ArrayUtils.contains(var19.getSlots(), var6)) {
                     var2.sendMessage(Lang.Prefix.toMsg() + Lang.Gems_Enchanting_Cancel.toMsg());
                     var2.closeInventory();
                     var2.updateInventory();
                     this.plugin.getGUIManager().reset(var2);
                  }

               } else {
                  ItemStack var7 = new ItemStack(((GUIItem)var3.getItems().get(ContentType.TARGET)).getItem());
                  ItemStack var8 = new ItemStack(((GUIItem)var3.getItems().get(ContentType.SOURCE)).getItem());
                  if (!var2.getInventory().contains(var7)) {
                     var2.sendMessage(Lang.Prefix.toMsg() + Lang.Gems_Enchanting_NoItem.toMsg());
                  } else {
                     int var9 = (new Random()).nextInt(100);
                     NBTItem var10 = new NBTItem(var8);
                     int var11 = var10.getInteger("DIVINE_CHANCE");
                     GemManager.GemSettings var12 = this.getSettings();
                     if (var11 >= var9) {
                        var2.getInventory().removeItem(new ItemStack[]{var7});
                        ItemStack var20 = this.insertGem(var8, var7);
                        var2.getInventory().addItem(new ItemStack[]{var20});
                        var2.getInventory().removeItem(new ItemStack[]{var8});
                        var8.setAmount(var8.getAmount() - 1);
                        var2.getInventory().addItem(new ItemStack[]{var8});
                        var2.sendMessage(Lang.Prefix.toMsg() + Lang.Gems_Enchanting_Success.toMsg());
                        var2.closeInventory();
                        if (var12.useSound()) {
                           var2.playSound(var2.getLocation(), var12.getSuccessSound(), 0.5F, 0.5F);
                        }

                        if (var12.useEffect()) {
                           Utils.playEffect(var12.getSuccessEffect(), 0.30000001192092896D, 0.0D, 0.30000001192092896D, 0.30000001192092896D, 15, var2.getLocation().add(0.0D, 0.5D, 0.0D));
                        }

                        var2.updateInventory();
                        this.plugin.getGUIManager().reset(var2);
                     } else {
                        switch($SWITCH_TABLE$su$nightexpress$divineitems$types$DestroyType()[var12.getDestroyType().ordinal()]) {
                        case 1:
                           var2.getInventory().removeItem(new ItemStack[]{var7});
                           var2.sendMessage(Lang.Prefix.toMsg() + Lang.Gems_Enchanting_Failure_Item.toMsg());
                           break;
                        case 2:
                           var2.getInventory().removeItem(new ItemStack[]{var8});
                           var8.setAmount(var8.getAmount() - 1);
                           var2.getInventory().addItem(new ItemStack[]{var8});
                           var2.sendMessage(Lang.Prefix.toMsg() + Lang.Gems_Enchanting_Failure_Source.toMsg());
                           break;
                        case 3:
                           var2.getInventory().removeItem(new ItemStack[]{var7});
                           var2.getInventory().removeItem(new ItemStack[]{var8});
                           var8.setAmount(var8.getAmount() - 1);
                           var2.getInventory().addItem(new ItemStack[]{var8});
                           ItemMeta var13 = var7.getItemMeta();
                           List var14 = var13.getLore();
                           ArrayList var15 = new ArrayList();
                           Iterator var17 = var14.iterator();

                           while(var17.hasNext()) {
                              String var16 = (String)var17.next();
                              if (var16.startsWith(var12.getFilledSlot())) {
                                 var15.add(var12.getEmptySlot());
                              } else {
                                 var15.add(var16);
                              }
                           }

                           var13.setLore(var15);
                           var7.setItemMeta(var13);
                           NBTItem var21 = new NBTItem(var7);
                           Iterator var18 = var21.getKeys().iterator();

                           while(var18.hasNext()) {
                              String var22 = (String)var18.next();
                              if (var22.startsWith("GEM_")) {
                                 var21.removeKey(var22);
                              }
                           }

                           var2.getInventory().addItem(new ItemStack[]{var21.getItem()});
                           var2.sendMessage(Lang.Prefix.toMsg() + Lang.Gems_Enchanting_Failure_Clear.toMsg());
                           break;
                        case 4:
                           var2.getInventory().removeItem(new ItemStack[]{var7});
                           var2.getInventory().removeItem(new ItemStack[]{var8});
                           var8.setAmount(var8.getAmount() - 1);
                           var2.getInventory().addItem(new ItemStack[]{var8});
                           var2.sendMessage(Lang.Prefix.toMsg() + Lang.Gems_Enchanting_Failure_Both.toMsg());
                        }

                        var2.closeInventory();
                        this.plugin.getGUIManager().reset(var2);
                        if (var12.useSound()) {
                           var2.playSound(var2.getLocation(), var12.getDestroySound(), 0.5F, 0.5F);
                        }

                        if (var12.useEffect()) {
                           Utils.playEffect(var12.getDestroyEffect(), 0.30000001192092896D, 0.0D, 0.30000001192092896D, 0.30000001192092896D, 15, var2.getLocation().add(0.0D, 0.5D, 0.0D));
                        }

                     }
                  }
               }
            }
         }
      }
   }

   private String replaceVars(String var1, HashMap<?, ?> var2) {
      String var6;
      String var7;
      for(Iterator var4 = var2.keySet().iterator(); var4.hasNext(); var1 = var1.replace(var6, var7)) {
         Object var3 = var4.next();
         String var5 = var3.toString();
         var6 = "%var_" + var5 + "%";
         var7 = var2.get(var3).toString();
      }

      return var1;
   }

   // $FF: synthetic method
   static int[] $SWITCH_TABLE$su$nightexpress$divineitems$types$DestroyType() {
      int[] var10000 = $SWITCH_TABLE$su$nightexpress$divineitems$types$DestroyType;
      if (var10000 != null) {
         return var10000;
      } else {
         int[] var0 = new int[DestroyType.values().length];

         try {
            var0[DestroyType.BOTH.ordinal()] = 4;
         } catch (NoSuchFieldError var4) {
         }

         try {
            var0[DestroyType.CLEAR.ordinal()] = 3;
         } catch (NoSuchFieldError var3) {
         }

         try {
            var0[DestroyType.ITEM.ordinal()] = 1;
         } catch (NoSuchFieldError var2) {
         }

         try {
            var0[DestroyType.SOURCE.ordinal()] = 2;
         } catch (NoSuchFieldError var1) {
         }

         $SWITCH_TABLE$su$nightexpress$divineitems$types$DestroyType = var0;
         return var0;
      }
   }

   public class Gem {
      private boolean enabled;
      private boolean enchant;
      private String id;
      private String material;
      private String name;
      private String ild;
      private List<String> desc;
      private HashMap<String, Double> vars;
      private HashMap<String, Double> vars_lvl;
      private HashMap<String, String> vars_att;
      private HashMap<String, Boolean> vars_perc;
      private int min_lvl;
      private int max_lvl;
      private List<String> item_types;

      public Gem(boolean var2, boolean var3, String var4, String var5, String var6, String var7, List<String> var8, HashMap<String, Double> var9, HashMap<String, Double> var10, HashMap<String, String> var11, HashMap<String, Boolean> var12, int var13, int var14, List<String> var15) {
         this.setEnabled(var2);
         this.setEnchanted(var3);
         this.setId(var4);
         this.setName(var6);
         this.setItemLoreDispaly(var7);
         this.setMaterial(var5);
         this.setDesc(var8);
         this.setVariables(var9);
         this.setVariablesLvl(var10);
         this.setVariablesAttributes(var11);
         this.setVariablesPercentage(var12);
         this.setMinLevel(var13);
         this.setMaxLevel(var14);
         this.setItemTypes(var15);
      }

      public boolean isEnabled() {
         return this.enabled;
      }

      public void setEnabled(boolean var1) {
         this.enabled = var1;
      }

      public boolean isEnchanted() {
         return this.enchant;
      }

      public void setEnchanted(boolean var1) {
         this.enchant = var1;
      }

      public String getId() {
         return this.id;
      }

      public void setId(String var1) {
         this.id = var1;
      }

      public String getMaterial() {
         return this.material;
      }

      public void setMaterial(String var1) {
         this.material = var1;
      }

      public String getName() {
         return this.name;
      }

      public void setName(String var1) {
         this.name = var1;
      }

      public String getItemLoreDisplay() {
         return this.ild;
      }

      public void setItemLoreDispaly(String var1) {
         this.ild = var1;
      }

      public List<String> getDesc() {
         return this.desc;
      }

      public void setDesc(List<String> var1) {
         this.desc = var1;
      }

      public HashMap<String, Double> getVariables() {
         return this.vars;
      }

      public void setVariables(HashMap<String, Double> var1) {
         this.vars = var1;
      }

      public HashMap<String, Double> getVariablesLvl() {
         return this.vars_lvl;
      }

      public void setVariablesLvl(HashMap<String, Double> var1) {
         this.vars_lvl = var1;
      }

      public HashMap<String, String> getVariablesAttributes() {
         return this.vars_att;
      }

      public void setVariablesAttributes(HashMap<String, String> var1) {
         this.vars_att = var1;
      }

      public HashMap<String, Boolean> getVariablesPercentage() {
         return this.vars_perc;
      }

      public void setVariablesPercentage(HashMap<String, Boolean> var1) {
         this.vars_perc = var1;
      }

      public int getMinLevel() {
         return this.min_lvl;
      }

      public void setMinLevel(int var1) {
         this.min_lvl = var1;
      }

      public int getMaxLevel() {
         return this.max_lvl;
      }

      public void setMaxLevel(int var1) {
         this.max_lvl = var1;
      }

      public List<String> getItemTypes() {
         return this.item_types;
      }

      public void setItemTypes(List<String> var1) {
         this.item_types = var1;
      }

      public ItemStack create(int var1) {
         if (!this.isEnabled()) {
            return new ItemStack(Material.AIR);
         } else {
            if (var1 == -1) {
               var1 = Utils.randInt(this.getMinLevel(), this.getMaxLevel());
            } else if (var1 > this.getMaxLevel()) {
               var1 = this.getMaxLevel();
            } else if (var1 < 1) {
               var1 = this.getMinLevel();
            }

            String[] var2 = this.getMaterial().split(":");
            ItemStack var3 = Utils.buildItem(var2, this.id);
            ItemMeta var4 = var3.getItemMeta();
            HashMap var5 = new HashMap(this.getVariables());
            String var7;
            if (var1 > 1) {
               int var6 = var1 - 1;
               Iterator var8 = this.getVariablesLvl().keySet().iterator();

               while(var8.hasNext()) {
                  var7 = (String)var8.next();
                  double var9 = Utils.round3((Double)this.getVariablesLvl().get(var7) * (double)var6);
                  if (var5.containsKey(var7)) {
                     double var11 = Utils.round3((Double)var5.get(var7) + var9);
                     var5.put(var7, var11);
                  }
               }
            }

            String var21 = GemManager.this.replaceVars(this.getName(), var5).replace("%level%", String.valueOf(var1)).replace("%rlevel%", Utils.IntegerToRomanNumeral(var1));
            var7 = GemManager.this.replaceVars(this.getItemLoreDisplay(), var5).replace("%level%", String.valueOf(var1)).replace("%rlevel%", Utils.IntegerToRomanNumeral(var1));
            String var22 = ChatColor.translateAlternateColorCodes('&', GemManager.this.getSettings().getDisplay().replace("%s", var21));
            ArrayList var23 = new ArrayList();
            Iterator var25 = this.getDesc().iterator();

            while(var25.hasNext()) {
               String var10 = (String)var25.next();
               var23.add(ChatColor.translateAlternateColorCodes('&', GemManager.this.replaceVars(var10, var5)));
            }

            int var24 = Utils.randInt(GemManager.this.getSettings().getMinChance(), GemManager.this.getSettings().getMaxChance());
            int var26 = 100 - var24;
            String var12 = "";
            String var13 = GemManager.this.plugin.getCM().getCFG().getStrClassColor();
            String var14 = GemManager.this.plugin.getCM().getCFG().getStrClassSeparator();

            String var17;
            for(Iterator var16 = this.getItemTypes().iterator(); var16.hasNext(); var12 = var12 + var13 + var17 + var14) {
               String var15 = (String)var16.next();
               var17 = var15.replace("*", "");
               if (Lang.hasPath("ItemTypes." + var17)) {
                  var17 = Lang.getCustom("ItemTypes." + var17);
               }
            }

            if (var12.length() > 3) {
               var12 = var12.substring(0, var12.length() - 3);
            }

            ArrayList var27 = new ArrayList();
            Iterator var30 = GemManager.this.getSettings().getLore().iterator();

            while(true) {
               while(var30.hasNext()) {
                  String var28 = (String)var30.next();
                  if (var28.equals("%desc%")) {
                     Iterator var19 = var23.iterator();

                     while(var19.hasNext()) {
                        String var18 = (String)var19.next();
                        var27.add(var18);
                     }
                  } else {
                     var27.add(ChatColor.translateAlternateColorCodes('&', var28.replace("%d%", String.valueOf(var26)).replace("%s%", String.valueOf(var24)).replace("%level%", String.valueOf(var1)).replace("%type%", var12).replace("%rlevel%", Utils.IntegerToRomanNumeral(var1))));
                  }
               }

               var4.setDisplayName(GemManager.this.replaceVars(var22, var5));
               var4.setLore(var27);
               var4.addItemFlags(ItemFlag.values());
               var4.spigot().setUnbreakable(true);
               var3.setItemMeta(var4);
               if (this.isEnchanted()) {
                  var3.addUnsafeEnchantment(Enchantment.ARROW_DAMAGE, 1);
               }

               NBTItem var29 = new NBTItem(var3);
               Iterator var31 = this.getVariablesAttributes().keySet().iterator();

               while(var31.hasNext()) {
                  var17 = (String)var31.next();
                  String var33 = (String)this.getVariablesAttributes().get(var17);
                  boolean var20 = (Boolean)this.getVariablesPercentage().get(var17);
                  var29.setString("DIVINE_VAR_ATT_" + var17, var33 + "@" + var20 + "@" + var5.get(var17));
               }

               var29.setString("DIVINE_GEM_ID", this.getId());
               var29.setInteger("DIVINE_CHANCE", var24);
               var29.setString("DIVINE_GEM_ILD", var7);
               ItemStack var32 = var29.getItem();
               return var32;
            }
         }
      }
   }

   public class GemSettings extends MainSettings {
      private boolean same;

      public GemSettings(boolean var2, String var3, List<String> var4, int var5, int var6, DestroyType var7, boolean var8, String var9, String var10, boolean var11, Sound var12, Sound var13, String var14, String var15, String var16) {
         super(var3, var4, var5, var6, var7, var8, var9, var10, var11, var12, var13, var14, var15, var16);
         this.setAllowMultSameGems(var2);
      }

      public boolean allowMultSameGems() {
         return this.same;
      }

      public void setAllowMultSameGems(boolean var1) {
         this.same = var1;
      }
   }
}
