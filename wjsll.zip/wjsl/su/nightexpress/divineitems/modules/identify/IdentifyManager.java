package su.nightexpress.divineitems.modules.identify;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.inventory.InventoryType.SlotType;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import su.nightexpress.divineitems.DivineItems;
import su.nightexpress.divineitems.DivineListener;
import su.nightexpress.divineitems.Module;
import su.nightexpress.divineitems.cmds.list.IdentifyCommand;
import su.nightexpress.divineitems.config.Lang;
import su.nightexpress.divineitems.config.MyConfig;
import su.nightexpress.divineitems.modules.tiers.TierManager;
import su.nightexpress.divineitems.nbt.NBTItem;
import su.nightexpress.divineitems.utils.Utils;

public class IdentifyManager extends DivineListener<DivineItems> implements Module {
   private DivineItems plugin;
   private boolean e;
   private Random r;
   private MyConfig settingsCfg;
   private MyConfig tomesCfg;
   private MyConfig itemsCfg;
   private HashMap<String, IdentifyManager.IdentifyTome> tomes;
   private HashMap<String, IdentifyManager.UnidentifiedItem> uis;
   private final String n = this.name().toLowerCase().replace(" ", "_");
   private final String label;
   private final String NBT_KEY_IT;
   private final String NBT_KEY_UI;

   public IdentifyManager(DivineItems var1) {
      super(var1);
      this.label = this.n.replace("_", "");
      this.NBT_KEY_IT = "DIVINE_TOME";
      this.NBT_KEY_UI = "DIVINE_UNIT";
      this.plugin = var1;
      this.e = this.plugin.getCM().getCFG().isModuleEnabled(this.name());
      this.r = new Random();
   }

   public void loadConfig() {
      this.tomes = new HashMap();
      this.uis = new HashMap();
      this.settingsCfg = new MyConfig(this.plugin, "/modules/" + this.n, "settings.yml");
      this.tomesCfg = new MyConfig(this.plugin, "/modules/" + this.n, "tomes.yml");
      this.itemsCfg = new MyConfig(this.plugin, "/modules/" + this.n, "items.yml");
      this.setup();
   }

   public boolean isActive() {
      return this.e;
   }

   public boolean isDropable() {
      return true;
   }

   public boolean isResolvable() {
      return false;
   }

   public String name() {
      return "Identify";
   }

   public String version() {
      return "1.0";
   }

   public void enable() {
      if (this.isActive()) {
         this.plugin.getCommander().registerCmd(this.label, new IdentifyCommand(this.plugin));
         this.loadConfig();
         this.registerListeners();
      }

   }

   public void unload() {
      if (this.isActive()) {
         this.plugin.getCommander().unregisterCmd(this.label);
         this.tomes.clear();
         this.uis.clear();
         this.e = false;
         this.unregisterListeners();
      }

   }

   public void reload() {
      this.unload();
      this.enable();
   }

   private void setup() {
      this.settingsCfg.save();
      this.setupTomes();
      this.setupItems();
   }

   private void setupTomes() {
      FileConfiguration var1 = this.tomesCfg.getConfig();
      if (var1.contains("IdentifyTomes")) {
         Iterator var3 = var1.getConfigurationSection("IdentifyTomes").getKeys(false).iterator();

         while(var3.hasNext()) {
            String var2 = (String)var3.next();
            String var4 = "IdentifyTomes." + var2.toString() + ".";
            String var5 = var2.toString().toLowerCase();
            String var6 = var1.getString(var4 + "Material");
            String var7 = ChatColor.translateAlternateColorCodes('&', var1.getString(var4 + "Display"));
            List var8 = var1.getStringList(var4 + "Lore");
            IdentifyManager.IdentifyTome var9 = new IdentifyManager.IdentifyTome(var5, var6, var7, var8);
            this.tomes.put(var5, var9);
         }
      }

   }

   private void setupItems() {
      FileConfiguration var1 = this.itemsCfg.getConfig();
      if (var1.contains("UnidentifiedItems")) {
         Iterator var3 = var1.getConfigurationSection("UnidentifiedItems").getKeys(false).iterator();

         while(var3.hasNext()) {
            String var2 = (String)var3.next();
            String var4 = "UnidentifiedItems." + var2.toString() + ".";
            String var5 = var2.toString().toLowerCase();
            String var6 = var1.getString(var4 + "Tier").toLowerCase();
            String var7 = var1.getString(var4 + "Tome").toLowerCase();
            String var8 = ChatColor.translateAlternateColorCodes('&', var1.getString(var4 + "Display"));
            List var9 = var1.getStringList(var4 + "Lore");
            IdentifyManager.UnidentifiedItem var10 = new IdentifyManager.UnidentifiedItem(var5, var6, var7, var8, var9);
            this.uis.put(var5, var10);
         }
      }

   }

   public boolean isTome(ItemStack var1) {
      return (new NBTItem(var1)).hasKey("DIVINE_TOME");
   }

   public boolean isUnidentified(ItemStack var1) {
      return (new NBTItem(var1)).hasKey("DIVINE_UNIT");
   }

   public boolean isValidTome(ItemStack var1, ItemStack var2) {
      NBTItem var3 = new NBTItem(var1);
      NBTItem var4 = new NBTItem(var2);
      String var5 = var4.getString("DIVINE_TOME");
      String[] var6 = var3.getString("DIVINE_UNIT").split(":");
      return var5.equalsIgnoreCase(var6[2]);
   }

   public Collection<IdentifyManager.IdentifyTome> getTomes() {
      return this.tomes.values();
   }

   public List<String> getTomeNames() {
      ArrayList var1 = new ArrayList();
      Iterator var3 = this.getTomes().iterator();

      while(var3.hasNext()) {
         IdentifyManager.IdentifyTome var2 = (IdentifyManager.IdentifyTome)var3.next();
         var1.add(var2.getId());
      }

      return var1;
   }

   public Collection<IdentifyManager.UnidentifiedItem> getItems() {
      return this.uis.values();
   }

   public List<String> getUINames() {
      ArrayList var1 = new ArrayList();
      Iterator var3 = this.getItems().iterator();

      while(var3.hasNext()) {
         IdentifyManager.UnidentifiedItem var2 = (IdentifyManager.UnidentifiedItem)var3.next();
         var1.add(var2.getId());
      }

      return var1;
   }

   public IdentifyManager.IdentifyTome getTomeById(String var1) {
      return var1.equalsIgnoreCase("random") ? (IdentifyManager.IdentifyTome)(new ArrayList(this.getTomes())).get(this.r.nextInt(this.getTomes().size())) : (IdentifyManager.IdentifyTome)this.tomes.get(var1.toLowerCase());
   }

   public IdentifyManager.UnidentifiedItem getItemById(String var1) {
      return var1.equalsIgnoreCase("random") ? (IdentifyManager.UnidentifiedItem)(new ArrayList(this.getItems())).get(this.r.nextInt(this.getItems().size())) : (IdentifyManager.UnidentifiedItem)this.uis.get(var1.toLowerCase());
   }

   @EventHandler
   public void onClick(InventoryClickEvent var1) {
      if (var1.getWhoClicked() instanceof Player) {
         Player var2 = (Player)var1.getWhoClicked();
         ItemStack var3 = var1.getCursor();
         ItemStack var4 = var1.getCurrentItem();
         if (var3 != null && var3.getType() != Material.AIR && var4 != null) {
            if (var1.getInventory().getType() == InventoryType.CRAFTING) {
               if (var1.getSlotType() != SlotType.CRAFTING) {
                  if (var1.getSlotType() != SlotType.ARMOR && var1.getSlot() != 40) {
                     if (var3.hasItemMeta() && var3.getItemMeta().hasLore()) {
                        if (var4.hasItemMeta() && var4.getItemMeta().hasLore()) {
                           NBTItem var5 = new NBTItem(var3);
                           if (var5.hasKey("DIVINE_TOME")) {
                              NBTItem var6 = new NBTItem(var4);
                              if (var6.hasKey("DIVINE_UNIT")) {
                                 String[] var7 = var6.getString("DIVINE_UNIT").split(":");
                                 String var8 = var7[1];
                                 int var9 = Integer.parseInt(var7[3]);
                                 if (!this.isValidTome(var4, var3)) {
                                    var2.sendMessage(Lang.Prefix.toMsg() + Lang.Identify_WrongTome.toMsg());
                                 } else {
                                    TierManager.Tier var10 = this.plugin.getMM().getTierManager().getTierById(var8);
                                    if (var10 == null) {
                                       var2.sendMessage(Lang.Prefix.toMsg() + Lang.Other_Internal.toMsg());
                                    } else {
                                       int var11 = 0;
                                       int var12 = 0;

                                       try {
                                          var11 = Integer.parseInt(var10.getLevels().split("-")[0]);
                                          var12 = Integer.parseInt(var10.getLevels().split("-")[1]);
                                       } catch (IllegalArgumentException var14) {
                                       }

                                       if (var9 < var11) {
                                          var9 = var11;
                                       } else if (var9 > var12) {
                                          var9 = var12;
                                       }

                                       var1.setCancelled(true);
                                       ItemStack var13 = var10.create(var9, var4.getType());
                                       var3.setAmount(var3.getAmount() - 1);
                                       if (var3.getAmount() <= 0) {
                                          var1.setCursor((ItemStack)null);
                                       } else {
                                          var1.setCursor(var3);
                                       }

                                       var1.setCurrentItem(var13);
                                    }
                                 }
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
      }
   }

   public ItemStack identify(ItemStack var1) {
      NBTItem var2 = new NBTItem(var1);
      if (!var2.hasKey("DIVINE_UNIT")) {
         return var1;
      } else {
         String[] var3 = var2.getString("DIVINE_UNIT").split(":");
         String var4 = var3[1];
         int var5 = Integer.parseInt(var3[3]);
         TierManager.Tier var6 = this.plugin.getMM().getTierManager().getTierById(var4);
         if (var6 == null) {
            return var1;
         } else {
            int var7 = Integer.parseInt(var6.getLevels().split("-")[0]);
            int var8 = Integer.parseInt(var6.getLevels().split("-")[1]);
            if (var5 < var7) {
               var5 = var7;
            } else if (var5 > var8) {
               var5 = var8;
            }

            ItemStack var9 = var6.create(var5, var1.getType());
            return var9;
         }
      }
   }

   public class IdentifyTome {
      private String id;
      private String material;
      private String display;
      private List<String> lore;

      public IdentifyTome(String var2, String var3, String var4, List<String> var5) {
         this.setId(var2);
         this.setMaterial(var3);
         this.setDisplay(var4);
         this.setLore(var5);
      }

      public String getId() {
         return this.id;
      }

      public void setId(String var1) {
         this.id = var1;
      }

      public String getMaterial() {
         return this.material;
      }

      public void setMaterial(String var1) {
         this.material = var1;
      }

      public String getDisplay() {
         return this.display;
      }

      public void setDisplay(String var1) {
         this.display = var1;
      }

      public List<String> getLore() {
         return this.lore;
      }

      public void setLore(List<String> var1) {
         this.lore = var1;
      }

      public ItemStack create() {
         String[] var1 = this.getMaterial().split(":");
         ItemStack var2 = Utils.buildItem(var1, this.id);
         ItemMeta var3 = var2.getItemMeta();
         ArrayList var4 = new ArrayList();
         var3.setDisplayName(this.getDisplay());
         Iterator var6 = this.getLore().iterator();

         while(var6.hasNext()) {
            String var5 = (String)var6.next();
            var4.add(ChatColor.translateAlternateColorCodes('&', var5));
         }

         var3.setLore(var4);
         var3.addItemFlags(ItemFlag.values());
         var3.spigot().setUnbreakable(true);
         var2.setItemMeta(var3);
         NBTItem var7 = new NBTItem(var2);
         var7.setString("DIVINE_TOME", this.getId());
         var2 = var7.getItem();
         return new ItemStack(var2);
      }
   }

   public class UnidentifiedItem {
      private String id;
      private String tier;
      private String tome;
      private String display;
      private List<String> lore;

      public UnidentifiedItem(String var2, String var3, String var4, String var5, List<String> var6) {
         this.setId(var2);
         this.setTier(var3);
         this.setTomeName(var4);
         this.setDisplay(var5);
         this.setLore(var6);
      }

      public String getId() {
         return this.id;
      }

      public void setId(String var1) {
         this.id = var1;
      }

      public String getTier() {
         return this.tier;
      }

      public void setTier(String var1) {
         this.tier = var1;
      }

      public String getTomeName() {
         return this.tome;
      }

      public void setTomeName(String var1) {
         this.tome = var1;
      }

      public String getDisplay() {
         return this.display;
      }

      public void setDisplay(String var1) {
         this.display = var1;
      }

      public List<String> getLore() {
         return this.lore;
      }

      public void setLore(List<String> var1) {
         this.lore = var1;
      }

      public ItemStack create(int var1) {
         TierManager.Tier var2 = IdentifyManager.this.plugin.getMM().getTierManager().getTierById(this.getTier());
         ItemStack var3 = new ItemStack(Material.AIR);
         if (var2 == null) {
            return var3;
         } else {
            if (var1 == -1) {
               int var4 = Integer.parseInt(var2.getLevels().split("-")[0]);
               int var5 = Integer.parseInt(var2.getLevels().split("-")[1]);
               var1 = Utils.randInt(var4, var5);
            }

            Random var10 = new Random();
            var3.setType((Material)var2.getMaterials().get(var10.nextInt(var2.getMaterials().size())));
            ItemMeta var11 = var3.getItemMeta();
            List var6 = var2.getDatas();
            if (var2.getDataSpecial().containsKey(var3.getType().name())) {
               var6 = (List)var2.getDataSpecial().get(var3.getType().name());
            }

            if (!var6.isEmpty()) {
               if (var2.isDataReversed()) {
                  var3.setDurability((short)(Integer)var6.get(var10.nextInt(var6.size())));
               } else {
                  int var7;
                  for(var7 = Utils.randInt(1, var3.getType().getMaxDurability()); var6.contains(var7); var7 = Utils.randInt(1, var3.getType().getMaxDurability())) {
                  }

                  var3.setDurability((short)var7);
               }
            }

            ArrayList var12 = new ArrayList();
            var11.setDisplayName(this.getDisplay());
            Iterator var9 = this.getLore().iterator();

            while(var9.hasNext()) {
               String var8 = (String)var9.next();
               var12.add(ChatColor.translateAlternateColorCodes('&', var8));
            }

            var11.setLore(var12);
            var11.addItemFlags(ItemFlag.values());
            var11.spigot().setUnbreakable(true);
            var3.setItemMeta(var11);
            NBTItem var13 = new NBTItem(var3);
            var13.setString("DIVINE_UNIT", this.getId() + ":" + var2.getId() + ":" + this.getTomeName() + ":" + var1);
            var3 = var13.getItem();
            return new ItemStack(var3);
         }
      }
   }
}
