package su.nightexpress.divineitems.modules.itemhints;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import org.bukkit.ChatColor;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Item;
import org.bukkit.event.EventHandler;
import org.bukkit.event.entity.ItemMergeEvent;
import org.bukkit.event.entity.ItemSpawnEvent;
import org.bukkit.inventory.ItemStack;
import su.nightexpress.divineitems.DivineItems;
import su.nightexpress.divineitems.DivineListener;
import su.nightexpress.divineitems.Module;
import su.nightexpress.divineitems.config.MyConfig;
import su.nightexpress.divineitems.libs.glowapi.GlowAPI;

public class ItemHintsManager extends DivineListener<DivineItems> implements Module {
   private DivineItems plugin;
   private MyConfig settingsCfg;
   private boolean e;
   private boolean s_forAll;
   private boolean s_glow;
   private String s_formatOne;
   private String s_formatMany;
   private HashMap<String, Boolean> s_for;
   private List<String> s_blackList;
   private List<String> s_gBlackList;
   private final String n = this.name().toLowerCase().replace(" ", "_");

   public ItemHintsManager(DivineItems var1) {
      super(var1);
      this.plugin = var1;
      this.e = this.plugin.getCM().getCFG().isModuleEnabled(this.name());
   }

   public void loadConfig() {
      this.settingsCfg = new MyConfig(this.plugin, "/modules/" + this.n, "settings.yml");
      this.s_for = new HashMap();
      this.s_blackList = new ArrayList();
      FileConfiguration var1 = this.settingsCfg.getConfig();
      this.s_forAll = var1.getBoolean("ForAllItems");
      this.s_glow = var1.getBoolean("Glow");
      this.s_formatOne = ChatColor.translateAlternateColorCodes('&', var1.getString("FormatOne"));
      this.s_formatMany = ChatColor.translateAlternateColorCodes('&', var1.getString("FormatMany"));
      Iterator var3 = this.plugin.getMM().getModules().iterator();

      while(var3.hasNext()) {
         Module var2 = (Module)var3.next();
         if (var2.isActive() && var2.isDropable()) {
            if (!var1.contains("EnabledFor." + var2.name())) {
               var1.set("EnabledFor." + var2.name(), true);
            }

            boolean var4 = var1.getBoolean("EnabledFor." + var2.name());
            this.s_for.put(var2.name(), var4);
         }
      }

      if (!var1.contains("ItemBlackList")) {
         var1.set("ItemBlackList", Arrays.asList("BEDROCK", "BARRIER"));
      }

      if (!var1.contains("ItemGlowBlackList")) {
         var1.set("ItemGlowBlackList", Arrays.asList("BEDROCK", "BARRIER"));
      }

      this.s_blackList = var1.getStringList("ItemBlackList");
      this.s_gBlackList = var1.getStringList("ItemGlowBlackList");
      this.settingsCfg.save();
   }

   public boolean isActive() {
      return this.e;
   }

   public boolean isDropable() {
      return false;
   }

   public boolean isResolvable() {
      return false;
   }

   public String name() {
      return "Item Hints";
   }

   public String version() {
      return "1.0.1";
   }

   public void enable() {
      if (this.isActive()) {
         this.loadConfig();
         this.registerListeners();
      }

   }

   public void unload() {
      if (this.isActive()) {
         this.e = false;
         this.unregisterListeners();
      }

   }

   public void reload() {
      this.unload();
      this.loadConfig();
      this.enable();
   }

   public boolean isForAll() {
      return this.s_forAll;
   }

   public boolean makeGlow() {
      return this.s_glow;
   }

   public String getNameFormatOne() {
      return this.s_formatOne;
   }

   public String getNameFormatMany() {
      return this.s_formatMany;
   }

   @EventHandler(
      ignoreCancelled = true
   )
   public void onItemSpawn(ItemSpawnEvent var1) {
      Item var2 = var1.getEntity();
      ItemStack var3 = var2.getItemStack();
      this.setItemHint(var2, var3, 0, this.getNameFormatOne());
   }

   @EventHandler
   public void onItemMerge(ItemMergeEvent var1) {
      Item var2 = var1.getEntity();
      Item var3 = var1.getTarget();
      this.setItemHint(var3, var3.getItemStack(), var2.getItemStack().getAmount(), this.getNameFormatMany());
   }

   private void setItemHint(Item var1, ItemStack var2, int var3, String var4) {
      Iterator var6 = this.s_for.keySet().iterator();

      String var5;
      boolean var7;
      label173:
      do {
         while(var6.hasNext()) {
            var5 = (String)var6.next();
            var7 = (Boolean)this.s_for.get(var5);
            switch(var5.hashCode()) {
            case -1850668115:
               if (var5.equals("Repair") && this.plugin.getMM().getRepairManager().isRepairGem(var2) && !var7) {
                  return;
               }
               break;
            case -947662255:
               if (var5.equals("Custom Items") && this.plugin.getMM().getCustomItemsManager().isCustomItem(var2) && !var7) {
                  return;
               }
               break;
            case -790637179:
               if (var5.equals("Magic Dust") && this.plugin.getMM().getMagicDustManager().isMagicDust(var2) && !var7) {
                  return;
               }
               break;
            case -703624410:
               if (var5.equals("Scrolls") && this.plugin.getMM().getScrollManager().isScroll(var2) && !var7) {
                  return;
               }
               break;
            case -632618200:
               if (var5.equals("Abilities") && this.plugin.getMM().getAbilityManager().isAbility(var2) && !var7) {
                  return;
               }
               break;
            case -71118036:
               if (var5.equals("Identify") && (this.plugin.getMM().getIdentifyManager().isTome(var2) || this.plugin.getMM().getIdentifyManager().isUnidentified(var2)) && !var7) {
                  return;
               }
               break;
            case 2215716:
               if (var5.equals("Gems") && this.plugin.getMM().getGemManager().isGem(var2) && !var7) {
                  return;
               }
               break;
            case 2573425:
               if (var5.equals("Sets") && this.plugin.getMM().getSetManager().isItemOfSet(var2) && !var7) {
                  return;
               }
               break;
            case 80804529:
               if (var5.equals("Tiers") && this.plugin.getMM().getTierManager().isTiered(var2) && !var7) {
                  return;
               }
               break;
            case 805312080:
               if (var5.equals("Consumables") && this.plugin.getMM().getConsumeManager().isConsume(var2) && !var7) {
                  return;
               }
               break;
            case 1769317210:
               if (var5.equals("Enchants") && this.plugin.getMM().getEnchantManager().isEnchant(var2) && !var7) {
                  return;
               }
               break;
            case 1809054010:
               if (var5.equals("Abyss Dust") && this.plugin.getMM().getAbyssDustManager().isAbyssDust(var2) && !var7) {
                  return;
               }
               break;
            case 1969682858:
               continue label173;
            }
         }

         String var13;
         if (!this.s_blackList.contains(var2.getType().name())) {
            int var12 = var2.getAmount() + var3;
            var13 = "";
            if (var2.hasItemMeta() && var2.getItemMeta().hasDisplayName()) {
               var13 = var2.getItemMeta().getDisplayName();
               if (var13.startsWith("***{")) {
                  return;
               }
            } else {
               if (!this.isForAll()) {
                  return;
               }

               var13 = this.plugin.getCM().getDefaultItemName(var2);
            }

            String var14 = var4.replace("%name%", var13).replace("%amount%", String.valueOf(var12));
            var1.setCustomName(var14);
            var1.setCustomNameVisible(true);
         }

         var5 = var1.getCustomName();
         if (!this.s_gBlackList.contains(var2.getType().name()) && this.makeGlow()) {
            var1.setGlowing(this.makeGlow());
            if (var5 != null && var5.length() > 2) {
               var13 = "f";
               if (var5.startsWith("§")) {
                  var13 = var5.substring(1, 2);
               }

               ChatColor var15 = ChatColor.getByChar(var13);
               GlowAPI.Color var8;
               if (var15 == null) {
                  var8 = GlowAPI.Color.WHITE;
               } else {
                  try {
                     var8 = GlowAPI.Color.valueOf(var15.name());
                  } catch (IllegalArgumentException var11) {
                     var8 = GlowAPI.Color.WHITE;
                  }
               }

               try {
                  GlowAPI.setGlowing((Entity)var1, var8, (Collection)this.plugin.getServer().getOnlinePlayers());
               } catch (Exception var10) {
               }
            }
         }

         return;
      } while(!var5.equals("Arrows") || !this.plugin.getMM().getArrowManager().isDivineArrow(var2) || var7);

   }
}
