package su.nightexpress.divineitems.modules.magicdust;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.inventory.InventoryType.SlotType;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import su.nightexpress.divineitems.DivineItems;
import su.nightexpress.divineitems.DivineListener;
import su.nightexpress.divineitems.Module;
import su.nightexpress.divineitems.cmds.list.MagicDustCommand;
import su.nightexpress.divineitems.config.Lang;
import su.nightexpress.divineitems.config.MyConfig;
import su.nightexpress.divineitems.nbt.NBTItem;
import su.nightexpress.divineitems.utils.ErrorLog;
import su.nightexpress.divineitems.utils.Utils;

public class MagicDustManager extends DivineListener<DivineItems> implements Module {
   private DivineItems plugin;
   private boolean e;
   private Random r;
   private MyConfig settingsCfg;
   private HashMap<String, MagicDustManager.MagicDust> mds;
   private final String n = this.name().toLowerCase().replace(" ", "_");
   private final String label;
   private final String NBT_KEY_DUST;
   // $FF: synthetic field
   private static int[] $SWITCH_TABLE$su$nightexpress$divineitems$modules$magicdust$MagicDustManager$DustType;

   public MagicDustManager(DivineItems var1) {
      super(var1);
      this.label = this.n.replace("_", "");
      this.NBT_KEY_DUST = "DIVINE_DUST_ID";
      this.plugin = var1;
      this.e = this.plugin.getCM().getCFG().isModuleEnabled(this.name());
      this.r = new Random();
   }

   public void loadConfig() {
      this.mds = new HashMap();
      this.settingsCfg = new MyConfig(this.plugin, "/modules/" + this.n, "settings.yml");
      this.setup();
   }

   public boolean isActive() {
      return this.e;
   }

   public boolean isDropable() {
      return true;
   }

   public boolean isResolvable() {
      return true;
   }

   public String name() {
      return "Magic Dust";
   }

   public String version() {
      return "1.0";
   }

   public void enable() {
      if (this.isActive()) {
         this.plugin.getCommander().registerCmd(this.label, new MagicDustCommand(this.plugin));
         this.loadConfig();
         this.registerListeners();
      }

   }

   public void unload() {
      if (this.isActive()) {
         this.plugin.getCommander().unregisterCmd(this.label);
         this.mds.clear();
         this.e = false;
         this.unregisterListeners();
      }

   }

   public void reload() {
      this.unload();
      this.enable();
   }

   public void setup() {
      FileConfiguration var1 = this.settingsCfg.getConfig();
      Iterator var3 = var1.getConfigurationSection("MagicDusts").getKeys(false).iterator();

      while(var3.hasNext()) {
         String var2 = (String)var3.next();
         String var4 = var2.toString().toLowerCase();
         String var5 = "MagicDusts." + var2.toString() + ".";
         String var6 = var1.getString(var5 + "Material");
         String var7 = ChatColor.translateAlternateColorCodes('&', var1.getString(var5 + "Display"));
         List var8 = var1.getStringList(var5 + "Lore");
         boolean var9 = var1.getBoolean(var5 + "Enchanted");
         int var10 = var1.getInt(var5 + "MaxLevel");
         double var11 = var1.getDouble(var5 + "MaxSuccess");
         MagicDustManager.DustType var13 = MagicDustManager.DustType.valueOf(var1.getString(var5 + "Type").toUpperCase());
         boolean var14 = var1.getBoolean(var5 + "Values.Random");
         String var15 = var1.getString(var5 + "Values.RandomRange");
         double var16 = var1.getDouble(var5 + "Values.Default");
         double var18 = var1.getDouble(var5 + "Values.PerLevel");
         String var20 = var1.getString(var5 + "OnUse.Effect");
         Sound var21 = Sound.ENTITY_EXPERIENCE_ORB_PICKUP;

         try {
            var21 = Sound.valueOf(var1.getString(var5 + "OnUse.Sound"));
         } catch (IllegalArgumentException var23) {
            ErrorLog.sendError(this, var5 + "OnUse.Sound", "Invalid Sound Type!", true);
            var1.set(var5 + "OnUse.Sound", "ENTITY_EXPERIENCE_ORB_PICKUP");
         }

         MagicDustManager.MagicDust var22 = new MagicDustManager.MagicDust(var4, var6, var7, var8, var9, var10, var11, var13, var14, var15, var16, var18, var21, var20);
         this.mds.put(var4, var22);
      }

      this.settingsCfg.save();
   }

   public Collection<MagicDustManager.MagicDust> getDusts() {
      return this.mds.values();
   }

   public List<String> getDustNames() {
      ArrayList var1 = new ArrayList();
      Iterator var3 = this.getDusts().iterator();

      while(var3.hasNext()) {
         MagicDustManager.MagicDust var2 = (MagicDustManager.MagicDust)var3.next();
         var1.add(var2.getId());
      }

      return var1;
   }

   public MagicDustManager.MagicDust getDustById(String var1) {
      return var1.equalsIgnoreCase("random") ? (MagicDustManager.MagicDust)(new ArrayList(this.getDusts())).get(this.r.nextInt(this.getDusts().size())) : (MagicDustManager.MagicDust)this.mds.get(var1.toLowerCase());
   }

   public boolean isMagicDust(ItemStack var1) {
      return (new NBTItem(var1)).hasKey("DIVINE_DUST_ID");
   }

   public String getDustId(ItemStack var1) {
      NBTItem var2 = new NBTItem(var1);
      String var3 = var2.getString("DIVINE_DUST_ID").split(":")[0];
      return var3;
   }

   public int getDustMod(ItemStack var1) {
      NBTItem var2 = new NBTItem(var1);
      int var3 = Integer.parseInt(var2.getString("DIVINE_DUST_ID").split(":")[1]);
      return var3;
   }

   private List<String> getTypeLore(MagicDustManager.DustType var1) {
      switch($SWITCH_TABLE$su$nightexpress$divineitems$modules$magicdust$MagicDustManager$DustType()[var1.ordinal()]) {
      case 1:
         return new ArrayList(this.plugin.getMM().getGemManager().getSettings().getLore());
      case 2:
         return new ArrayList(this.plugin.getMM().getEnchantManager().getSettings().getLore());
      case 3:
         return new ArrayList(this.plugin.getMM().getRuneManager().getSettings().getLore());
      case 4:
         return new ArrayList(this.plugin.getMM().getAbilityManager().getSettings().getLore());
      case 5:
         return new ArrayList();
      default:
         return new ArrayList();
      }
   }

   @EventHandler
   public void onClick(InventoryClickEvent var1) {
      if (var1.getWhoClicked() instanceof Player) {
         Player var2 = (Player)var1.getWhoClicked();
         ItemStack var3 = var1.getCursor();
         ItemStack var4 = var1.getCurrentItem();
         if (var3 != null && var4 != null) {
            if (var1.getInventory().getType() == InventoryType.CRAFTING) {
               if (var1.getSlotType() != SlotType.CRAFTING) {
                  if (var1.getSlotType() != SlotType.ARMOR && var1.getSlot() != 40) {
                     if (var3.hasItemMeta() && var3.getItemMeta().hasLore()) {
                        if (var4.hasItemMeta() && var4.getItemMeta().hasLore()) {
                           NBTItem var5 = new NBTItem(var3);
                           if (var5.hasKey("DIVINE_DUST_ID")) {
                              String[] var6 = var5.getString("DIVINE_DUST_ID").split(":");
                              String var7 = var6[0];
                              int var8 = Math.max(0, Integer.parseInt(var6[1]));
                              NBTItem var9 = new NBTItem(var4);
                              if (var9.hasKey("DIVINE_CHANCE")) {
                                 var1.setCancelled(true);
                                 int var10 = Math.max(0, var9.getInteger("DIVINE_CHANCE"));
                                 int var11 = 100 - var10;
                                 if (var10 >= 100) {
                                    var2.sendMessage(Lang.Prefix.toMsg() + Lang.MagicDust_Maximum.toMsg().replace("%s", String.valueOf(var10)));
                                 } else if (var4.getAmount() > 1) {
                                    var2.sendMessage(Lang.Prefix.toMsg() + Lang.MagicDust_NoStack.toMsg());
                                 } else {
                                    MagicDustManager.MagicDust var12 = this.getDustById(var7);
                                    MagicDustManager.DustType var13 = var12.getType();
                                    Object var14 = new ArrayList();
                                    if (this.plugin.getMM().getGemManager().isGem(var4)) {
                                       if (var13 != MagicDustManager.DustType.GEM && var13 != MagicDustManager.DustType.ANY) {
                                          var2.sendMessage(Lang.Prefix.toMsg() + Lang.MagicDust_WrongItem.toMsg());
                                          return;
                                       }

                                       var14 = this.getTypeLore(MagicDustManager.DustType.GEM);
                                    } else if (this.plugin.getMM().getEnchantManager().isEnchant(var4)) {
                                       if (var13 != MagicDustManager.DustType.ENCHANT && var13 != MagicDustManager.DustType.ANY) {
                                          var2.sendMessage(Lang.Prefix.toMsg() + Lang.MagicDust_WrongItem.toMsg());
                                          return;
                                       }

                                       var14 = this.getTypeLore(MagicDustManager.DustType.ENCHANT);
                                    } else if (this.plugin.getMM().getRuneManager().isRune(var4)) {
                                       if (var13 != MagicDustManager.DustType.RUNE && var13 != MagicDustManager.DustType.ANY) {
                                          var2.sendMessage(Lang.Prefix.toMsg() + Lang.MagicDust_WrongItem.toMsg());
                                          return;
                                       }

                                       var14 = this.getTypeLore(MagicDustManager.DustType.RUNE);
                                    } else if (this.plugin.getMM().getAbilityManager().isAbility(var4)) {
                                       if (var13 != MagicDustManager.DustType.ABILITY && var13 != MagicDustManager.DustType.ANY) {
                                          var2.sendMessage(Lang.Prefix.toMsg() + Lang.MagicDust_WrongItem.toMsg());
                                          return;
                                       }

                                       var14 = this.getTypeLore(MagicDustManager.DustType.ABILITY);
                                    }

                                    if ((double)var10 >= var12.getMaxSuccess()) {
                                       var2.sendMessage(Lang.Prefix.toMsg() + Lang.MagicDust_Maximum.toMsg().replace("%s", String.valueOf(var10)));
                                    } else {
                                       int var15 = 0;
                                       int var16 = 0;
                                       String var17 = "";
                                       String var18 = "";
                                       Iterator var20 = ((List)var14).iterator();

                                       while(var20.hasNext()) {
                                          String var19 = (String)var20.next();
                                          if (var19.contains("%s%")) {
                                             var17 = var19;
                                             var15 = ((List)var14).indexOf(var19);
                                          }

                                          if (var19.contains("%d%")) {
                                             var18 = var19;
                                             var16 = ((List)var14).indexOf(var19);
                                          }
                                       }

                                       int var24 = var10 + var8;
                                       int var25 = var11 - var8;
                                       ItemMeta var21 = var4.getItemMeta();
                                       ArrayList var22 = new ArrayList(var21.getLore());
                                       if (var15 == var16) {
                                          var22.remove(var15);
                                          var17 = ChatColor.translateAlternateColorCodes('&', var17.replace("%s%", String.valueOf(var24)).replace("%d%", String.valueOf(var25)));
                                          var22.add(var15, var17);
                                       } else {
                                          var22.remove(var15);
                                          var17 = ChatColor.translateAlternateColorCodes('&', var17.replace("%s%", String.valueOf(var24)));
                                          var22.add(var15, var17);
                                          var22.remove(var16);
                                          var18 = ChatColor.translateAlternateColorCodes('&', var18.replace("%d%", String.valueOf(var25)));
                                          var22.add(var16, var18);
                                       }

                                       var21.setLore(var22);
                                       var4.setItemMeta(var21);
                                       NBTItem var23 = new NBTItem(var4);
                                       var23.setInteger("DIVINE_CHANCE", var24);
                                       var2.getInventory().removeItem(new ItemStack[]{var4});
                                       var2.getInventory().addItem(new ItemStack[]{var23.getItem()});
                                       if (var3.getAmount() == 1) {
                                          var1.setCursor((ItemStack)null);
                                       } else {
                                          var3.setAmount(var3.getAmount() - 1);
                                          var1.setCursor(var3);
                                       }

                                       var2.sendMessage(Lang.Prefix.toMsg() + Lang.MagicDust_Done.toMsg());
                                       var2.playSound(var2.getLocation(), var12.getSound(), 0.5F, 0.5F);
                                       Utils.playEffect(var12.getEffect(), 0.30000001192092896D, 0.0D, 0.30000001192092896D, 0.0D, 5, var2.getLocation().add(0.0D, 0.85D, 0.0D));
                                       Utils.playEffect(var12.getEffect(), 0.30000001192092896D, 0.0D, 0.30000001192092896D, 0.0D, 5, var2.getLocation().add(0.0D, 0.65D, 0.0D));
                                       Utils.playEffect(var12.getEffect(), 0.30000001192092896D, 0.0D, 0.30000001192092896D, 0.0D, 5, var2.getLocation().add(0.0D, 0.25D, 0.0D));
                                    }
                                 }
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
      }
   }

   // $FF: synthetic method
   static int[] $SWITCH_TABLE$su$nightexpress$divineitems$modules$magicdust$MagicDustManager$DustType() {
      int[] var10000 = $SWITCH_TABLE$su$nightexpress$divineitems$modules$magicdust$MagicDustManager$DustType;
      if (var10000 != null) {
         return var10000;
      } else {
         int[] var0 = new int[MagicDustManager.DustType.values().length];

         try {
            var0[MagicDustManager.DustType.ABILITY.ordinal()] = 4;
         } catch (NoSuchFieldError var5) {
         }

         try {
            var0[MagicDustManager.DustType.ANY.ordinal()] = 5;
         } catch (NoSuchFieldError var4) {
         }

         try {
            var0[MagicDustManager.DustType.ENCHANT.ordinal()] = 2;
         } catch (NoSuchFieldError var3) {
         }

         try {
            var0[MagicDustManager.DustType.GEM.ordinal()] = 1;
         } catch (NoSuchFieldError var2) {
         }

         try {
            var0[MagicDustManager.DustType.RUNE.ordinal()] = 3;
         } catch (NoSuchFieldError var1) {
         }

         $SWITCH_TABLE$su$nightexpress$divineitems$modules$magicdust$MagicDustManager$DustType = var0;
         return var0;
      }
   }

   public static enum DustType {
      GEM,
      ENCHANT,
      RUNE,
      ABILITY,
      ANY;
   }

   public class MagicDust {
      private String id;
      private String mat;
      private String name;
      private List<String> lore;
      private boolean ench;
      private int max_lvl;
      private double max_suc;
      private MagicDustManager.DustType type;
      private boolean v_random;
      private String v_range;
      private double v_default;
      private double v_lvl;
      private Sound sound;
      private String effect;

      public MagicDust(String var2, String var3, String var4, List<String> var5, boolean var6, int var7, double var8, MagicDustManager.DustType var10, boolean var11, String var12, double var13, double var15, Sound var17, String var18) {
         this.setId(var2);
         this.setMaterial(var3);
         this.setDisplay(var4);
         this.setLore(var5);
         this.setEnchanted(var6);
         this.setMaxLevel(var7);
         this.setMaxSuccess(var8);
         this.setType(var10);
         this.setValuesRandom(var11);
         this.setValuesRandomRange(var12);
         this.setValuesDefault(var13);
         this.setValuesPerLevel(var15);
         this.setSound(var17);
         this.setEffect(var18);
      }

      public String getId() {
         return this.id;
      }

      public void setId(String var1) {
         this.id = var1;
      }

      public String getMaterial() {
         return this.mat;
      }

      public void setMaterial(String var1) {
         this.mat = var1;
      }

      public String getDisplay() {
         return this.name;
      }

      public void setDisplay(String var1) {
         this.name = var1;
      }

      public List<String> getLore() {
         return this.lore;
      }

      public void setLore(List<String> var1) {
         this.lore = var1;
      }

      public boolean isEnchanted() {
         return this.ench;
      }

      public void setEnchanted(boolean var1) {
         this.ench = var1;
      }

      public int getMaxLevel() {
         return this.max_lvl;
      }

      public void setMaxLevel(int var1) {
         this.max_lvl = var1;
      }

      public double getMaxSuccess() {
         return this.max_suc;
      }

      public void setMaxSuccess(double var1) {
         this.max_suc = var1;
      }

      public MagicDustManager.DustType getType() {
         return this.type;
      }

      public void setType(MagicDustManager.DustType var1) {
         this.type = var1;
      }

      public boolean isValuesRandom() {
         return this.v_random;
      }

      public void setValuesRandom(boolean var1) {
         this.v_random = var1;
      }

      public String getValuesRandomRange() {
         return this.v_range;
      }

      public void setValuesRandomRange(String var1) {
         this.v_range = var1;
      }

      public double getValuesDefault() {
         return this.v_default;
      }

      public void setValuesDefault(double var1) {
         this.v_default = var1;
      }

      public double getValuesPerLevel() {
         return this.v_lvl;
      }

      public void setValuesPerLevel(double var1) {
         this.v_lvl = var1;
      }

      public Sound getSound() {
         return this.sound;
      }

      public void setSound(Sound var1) {
         this.sound = var1;
      }

      public String getEffect() {
         return this.effect;
      }

      public void setEffect(String var1) {
         this.effect = var1;
      }

      public ItemStack create(int var1) {
         String[] var2 = this.getMaterial().split(":");
         ItemStack var3 = Utils.buildItem(var2, this.id);
         ItemMeta var4 = var3.getItemMeta();
         if (var1 == -1) {
            var1 = Utils.randInt(1, this.getMaxLevel());
         } else {
            if (var1 < 1 || var1 > 3999) {
               var1 = 1;
            }

            if (var1 > this.getMaxLevel()) {
               var1 = this.getMaxLevel();
            }
         }

         double var5 = 0.0D;
         String var7;
         if (this.isValuesRandom()) {
            var7 = this.getValuesRandomRange();
            double var8 = Double.parseDouble(var7.split(":")[0]);
            double var10 = Double.parseDouble(var7.split(":")[1]);
            var5 = Utils.getRandDouble(var8, var10);
         } else {
            var5 = this.getValuesDefault();
         }

         var5 += this.getValuesPerLevel() * (double)(var1 - 1);
         var7 = this.getDisplay().replace("%s", Utils.IntegerToRomanNumeral(var1));
         ArrayList var12 = new ArrayList();
         Iterator var14 = this.getLore().iterator();

         while(var14.hasNext()) {
            String var9 = (String)var14.next();
            var12.add(ChatColor.translateAlternateColorCodes('&', var9.replace("%level%", Utils.IntegerToRomanNumeral(var1)).replace("%value%", "" + (int)var5)));
         }

         var4.setDisplayName(var7);
         var4.setLore(var12);
         var4.spigot().setUnbreakable(true);
         var4.addItemFlags(ItemFlag.values());
         var3.setItemMeta(var4);
         if (this.isEnchanted()) {
            var3.addUnsafeEnchantment(Enchantment.ARROW_DAMAGE, 1);
         }

         NBTItem var13 = new NBTItem(var3);
         var13.setString("DIVINE_DUST_ID", this.getId() + ":" + (int)var5);
         return new ItemStack(var13.getItem());
      }
   }
}
