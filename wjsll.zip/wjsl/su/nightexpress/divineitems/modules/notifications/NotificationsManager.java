package su.nightexpress.divineitems.modules.notifications;

import java.util.HashMap;
import java.util.Iterator;
import net.md_5.bungee.api.ChatColor;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.inventory.ItemStack;
import su.nightexpress.divineitems.DivineItems;
import su.nightexpress.divineitems.DivineListener;
import su.nightexpress.divineitems.Module;
import su.nightexpress.divineitems.api.ItemAPI;
import su.nightexpress.divineitems.api.events.DivineItemDamageEvent;
import su.nightexpress.divineitems.config.MyConfig;
import su.nightexpress.divineitems.utils.ActionTitle;

public class NotificationsManager extends DivineListener<DivineItems> implements Module {
   private DivineItems plugin;
   private MyConfig config;
   private boolean e;
   private boolean note_dura_chat;
   private boolean note_dura_bar;
   private boolean note_dura_title;
   private HashMap<Double, String> note_dura_perc;
   private final String n = this.name().toLowerCase().replace(" ", "_");

   public NotificationsManager(DivineItems var1) {
      super(var1);
      this.plugin = var1;
      this.e = this.plugin.getCM().getCFG().isModuleEnabled(this.name());
   }

   public void loadConfig() {
      this.config = new MyConfig(this.plugin, "/modules/" + this.n, "settings.yml");
      FileConfiguration var1 = this.config.getConfig();
      this.note_dura_chat = var1.getBoolean("Durability.Chat");
      this.note_dura_bar = var1.getBoolean("Durability.ActionBar");
      this.note_dura_title = var1.getBoolean("Durability.Titles");
      this.note_dura_perc = new HashMap();
      if (var1.contains("Durability.Percentage")) {
         Iterator var3 = var1.getConfigurationSection("Durability.Percentage").getKeys(false).iterator();

         while(var3.hasNext()) {
            String var2 = (String)var3.next();
            double var4 = Double.parseDouble(var2.toString());
            String var6 = ChatColor.translateAlternateColorCodes('&', var1.getString("Durability.Percentage." + var2));
            this.note_dura_perc.put(var4, var6);
         }
      }

   }

   public boolean isActive() {
      return this.e;
   }

   public boolean isDropable() {
      return false;
   }

   public boolean isResolvable() {
      return false;
   }

   public String name() {
      return "Notifications";
   }

   public String version() {
      return "1.0";
   }

   public void enable() {
      if (this.isActive()) {
         this.loadConfig();
         this.registerListeners();
      }

   }

   public void unload() {
      if (this.isActive()) {
         this.note_dura_perc.clear();
         this.e = false;
         this.unregisterListeners();
      }

   }

   public void reload() {
      this.unload();
      this.enable();
   }

   public void notifyDurability(Player var1, ItemStack var2) {
      double var3 = (double)ItemAPI.getDurability(var2, 0) / (double)ItemAPI.getDurability(var2, 1) * 100.0D;
      if (this.note_dura_perc.containsKey(var3)) {
         String var5 = ((String)this.note_dura_perc.get(var3)).replace("%d1", String.valueOf(ItemAPI.getDurability(var2, 0) - 1)).replace("%d2", String.valueOf(ItemAPI.getDurability(var2, 1)));
         String var6 = var5;
         if (this.note_dura_chat) {
            if (var5.contains("/n")) {
               var6 = var5.replace("/n", "");
            }

            var1.sendMessage(var6);
         }

         if (this.note_dura_bar) {
            if (var5.contains("/n")) {
               var6 = var5.replace("/n", "");
            }

            ActionTitle.sendActionBar(var1, var6);
         }

         if (this.note_dura_title) {
            String var7 = "";
            if (var5.contains("/n")) {
               var7 = var5.split("/n")[1];
               var6 = var5.split("/n")[0];
            }

            ActionTitle.sendTitles(var1, var6, var7, 5, 30, 5);
         }
      }

   }

   @EventHandler
   public void onDmg(DivineItemDamageEvent var1) {
      Player var2 = var1.getPlayer();
      ItemStack var3 = var1.getItem();
      this.notifyDurability(var2, var3);
   }
}
