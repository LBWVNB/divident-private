package su.nightexpress.divineitems.modules.repair;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import net.md_5.bungee.api.ChatColor;
import org.apache.commons.lang.ArrayUtils;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.inventory.InventoryType.SlotType;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import su.nightexpress.divineitems.DivineItems;
import su.nightexpress.divineitems.DivineListener;
import su.nightexpress.divineitems.DivinePerms;
import su.nightexpress.divineitems.Module;
import su.nightexpress.divineitems.api.ItemAPI;
import su.nightexpress.divineitems.cmds.list.RepairCommand;
import su.nightexpress.divineitems.config.Lang;
import su.nightexpress.divineitems.config.MyConfig;
import su.nightexpress.divineitems.gui.ContentType;
import su.nightexpress.divineitems.gui.GUI;
import su.nightexpress.divineitems.gui.GUIItem;
import su.nightexpress.divineitems.gui.GUIType;
import su.nightexpress.divineitems.nbt.NBTItem;
import su.nightexpress.divineitems.utils.ParticleUtils;
import su.nightexpress.divineitems.utils.Utils;

public class RepairManager extends DivineListener<DivineItems> implements Module {
   private DivineItems plugin;
   private boolean e;
   private MyConfig settingsCfg;
   private RepairManager.RepairSettings rs;
   private RepairManager.RepairGem gem;
   private final String n = this.name().toLowerCase().replace(" ", "_");
   private final String label;
   private final String NBT_KEY_GEM;

   public RepairManager(DivineItems var1) {
      super(var1);
      this.label = this.n.replace("_", "");
      this.NBT_KEY_GEM = "DIVINE_RGEM";
      this.plugin = var1;
      this.e = this.plugin.getCM().getCFG().isModuleEnabled(this.name());
   }

   public void loadConfig() {
      this.settingsCfg = new MyConfig(this.plugin, "/modules/" + this.n, "settings.yml");
      this.setupSettings();
      this.setupGem();
   }

   public boolean isActive() {
      return this.e;
   }

   public boolean isDropable() {
      return true;
   }

   public boolean isResolvable() {
      return false;
   }

   public String name() {
      return "Repair";
   }

   public String version() {
      return "1.0";
   }

   public void enable() {
      if (this.isActive()) {
         this.plugin.getCommander().registerCmd(this.label, new RepairCommand(this.plugin));
         this.loadConfig();
         this.registerListeners();
      }

   }

   public void unload() {
      if (this.isActive()) {
         this.plugin.getCommander().unregisterCmd(this.label);
         this.rs = null;
         this.gem = null;
         this.e = false;
         this.unregisterListeners();
      }

   }

   public void reload() {
      this.unload();
      this.enable();
   }

   private void setupSettings() {
      FileConfiguration var1 = this.settingsCfg.getConfig();
      String var2 = "Anvil.";
      boolean var3 = var1.getBoolean(var2 + "Enabled");
      String var4 = var1.getString(var2 + "Action.Click").toUpperCase();
      boolean var5 = var1.getBoolean(var2 + "Action.isShiftOnly");
      HashMap var6 = new HashMap();
      Iterator var8 = var1.getConfigurationSection(var2 + "Currency").getKeys(false).iterator();

      while(var8.hasNext()) {
         String var7 = (String)var8.next();
         RepairManager.RepairType var9 = RepairManager.RepairType.valueOf(var7.toString().toUpperCase());
         boolean var10 = var1.getBoolean(var2 + "Currency." + var7);
         var6.put(var9, var10);
      }

      HashMap var14 = new HashMap();
      Iterator var17 = var1.getConfigurationSection(var2 + "RepairCost").getKeys(false).iterator();

      while(var17.hasNext()) {
         String var15 = (String)var17.next();
         RepairManager.RepairType var19 = RepairManager.RepairType.valueOf(var15.toString().toUpperCase());
         double var11 = var1.getDouble(var2 + "RepairCost." + var15);
         var14.put(var19, var11);
      }

      HashMap var16 = new HashMap();
      Iterator var20 = var1.getConfigurationSection(var2 + "MaterialsTable").getKeys(false).iterator();

      while(var20.hasNext()) {
         String var18 = (String)var20.next();
         String var21 = var2 + "MaterialsTable." + var18;
         Material var12 = Material.getMaterial(var18.toString().toUpperCase());
         if (var12 != null) {
            List var13 = var1.getStringList(var21);
            var16.put(var12, var13);
         }
      }

      this.rs = new RepairManager.RepairSettings(var3, var4, var5, var6, var14, var16);
   }

   private void setupGem() {
      FileConfiguration var1 = this.settingsCfg.getConfig();
      String var2 = "Item.";
      boolean var3 = var1.getBoolean(var2 + "Enabled");
      String var4 = var1.getString(var2 + "Material");
      String var5 = ChatColor.translateAlternateColorCodes('&', var1.getString(var2 + "Display"));
      List var6 = var1.getStringList(var2 + "Lore");
      List var7 = var1.getStringList(var2 + "ItemFlags");
      boolean var8 = var1.getBoolean(var2 + "SetUnbreakable");
      int var9 = var1.getInt(var2 + "RepairMode");
      HashMap var10 = new HashMap();
      Iterator var12 = var1.getConfigurationSection(var2 + "Levels").getKeys(false).iterator();

      while(var12.hasNext()) {
         String var11 = (String)var12.next();
         int var13 = Integer.parseInt(var11.toString());
         int var14 = var1.getInt(var2 + "Levels." + var11);
         var10.put(var13, var14);
      }

      this.gem = new RepairManager.RepairGem(var3, var4, var5, var6, var7, var8, var9, var10);
   }

   public RepairManager.RepairSettings getSettings() {
      return this.rs;
   }

   public RepairManager.RepairGem getGem() {
      return this.gem;
   }

   public boolean isRepairGem(ItemStack var1) {
      return (new NBTItem(var1)).hasKey("DIVINE_RGEM");
   }

   public void openGemGUI(Player var1, ItemStack var2, ItemStack var3, int var4) {
      GUI var5 = new GUI(this.plugin.getGUIManager().getGUIByType(GUIType.REPAIR_GEM));
      ((GUIItem)var5.getItems().get(ContentType.TARGET)).setItem(var2);
      ((GUIItem)var5.getItems().get(ContentType.SOURCE)).setItem(var3);
      ((GUIItem)var5.getItems().get(ContentType.RESULT)).setItem(this.getResult(new ItemStack(var2), var1, var4));
      this.plugin.getGUIManager().setGUI(var1, var5);
      var1.openInventory(var5.build());
   }

   public void openAnvilGUI(Player var1, ItemStack var2) {
      if (!var1.hasPermission(DivinePerms.REPAIR_ANVL.node())) {
         var1.sendMessage(Lang.Prefix.toMsg() + Lang.Other_NoPerm.toMsg());
      } else {
         GUI var3 = new GUI(this.plugin.getGUIManager().getGUIByType(GUIType.REPAIR_ANVIL));
         ((GUIItem)var3.getItems().get(ContentType.TARGET)).setItem(var2);
         RepairManager.RepairType[] var7;
         int var6 = (var7 = RepairManager.RepairType.values()).length;

         for(int var5 = 0; var5 < var6; ++var5) {
            RepairManager.RepairType var4 = var7[var5];
            GUIItem var8;
            ItemStack var9;
            if (!(Boolean)this.getSettings().getCurrency().get(var4)) {
               var8 = new GUIItem((GUIItem)var3.getItems().get(ContentType.valueOf(var4.name())));
               var9 = new ItemStack(Material.AIR);
               var8.setItem(var9);
               var3.getItems().put(ContentType.valueOf(var4.name()), var8);
            } else {
               var8 = new GUIItem((GUIItem)var3.getItems().get(ContentType.valueOf(var4.name())));
               var9 = new ItemStack(var8.getItem());
               ItemMeta var10 = var9.getItemMeta();
               List var11 = var10.getLore();
               ArrayList var12 = new ArrayList();
               Iterator var14 = var11.iterator();

               while(var14.hasNext()) {
                  String var13 = (String)var14.next();
                  String var15 = this.plugin.getCM().getDefaultItemName(new ItemStack(this.getCraftMaterial(var2.getType().name())));
                  var12.add(var13.replace("%material%", var15).replace("%d%", "" + this.getPlayerBalance(var1, var4, var2.getType())).replace("%s%", "" + this.calcCost(var2, var4)));
               }

               var10.setLore(var12);
               var9.setItemMeta(var10);
               var8.setItem(var9);
               var3.getItems().put(ContentType.valueOf(var4.name()), var8);
            }
         }

         this.plugin.getGUIManager().setGUI(var1, var3);
         var1.openInventory(var3.build());
      }
   }

   private ItemStack getResult(ItemStack var1, Player var2, int var3) {
      ItemStack var4 = ItemAPI.setDurability(var1, ItemAPI.getDurability(var1, 0) + var3, ItemAPI.getDurability(var1, 1));
      ItemMeta var5 = var4.getItemMeta();
      var5.setDisplayName(Lang.Repair_Result.toMsg());
      var4.setItemMeta(var5);
      return new ItemStack(var4);
   }

   private int calcCost(ItemStack var1, RepairManager.RepairType var2) {
      byte var3 = 0;
      if (var1 == null) {
         return var3;
      } else {
         int var4 = ItemAPI.getDurability(var1, 0);
         int var5 = ItemAPI.getDurability(var1, 1);
         double var6 = (Double)this.getSettings().getCosts().get(var2);
         double var8 = var6 * (double)(var5 - var4);
         int var10 = (int)var8;
         if (var10 <= 0) {
            var10 = 1;
         }

         return var10;
      }
   }

   private boolean payForRepair(Player var1, RepairManager.RepairType var2, ItemStack var3) {
      int var4 = this.calcCost(var3, var2);
      if (this.getPlayerBalance(var1, var2, var3.getType()) < var4) {
         return false;
      } else {
         if (var2 == RepairManager.RepairType.EXP) {
            var1.setLevel(var1.getLevel() - var4);
         } else if (var2 == RepairManager.RepairType.MATERIAL) {
            ItemStack[] var8;
            int var7 = (var8 = var1.getInventory().getContents()).length;

            for(int var6 = 0; var6 < var7; ++var6) {
               ItemStack var5 = var8[var6];
               if (var5 != null && var5.getType() == this.getCraftMaterial(var3.getType().name())) {
                  if (var5.getAmount() > var4) {
                     var1.getInventory().removeItem(new ItemStack[]{var5});
                     var5.setAmount(var5.getAmount() - var4);
                     var1.getInventory().addItem(new ItemStack[]{var5});
                     return true;
                  }

                  var1.getInventory().removeItem(new ItemStack[]{var5});
                  var4 -= var5.getAmount();
                  if (var4 <= 0) {
                     return true;
                  }
               }
            }
         } else if (var2 == RepairManager.RepairType.VAULT) {
            return this.plugin.getHM().getVault().take(var1, (double)var4);
         }

         return true;
      }
   }

   private int getPlayerBalance(Player var1, RepairManager.RepairType var2, Material var3) {
      int var4 = 0;
      if (var2 == RepairManager.RepairType.EXP) {
         return var1.getLevel();
      } else {
         if (var2 == RepairManager.RepairType.MATERIAL) {
            ItemStack[] var8;
            int var7 = (var8 = var1.getInventory().getContents()).length;

            for(int var6 = 0; var6 < var7; ++var6) {
               ItemStack var5 = var8[var6];
               if (var5 != null && var5.getType() == this.getCraftMaterial(var3.name())) {
                  var4 += var5.getAmount();
               }
            }
         } else if (var2 == RepairManager.RepairType.VAULT) {
            return (int)this.plugin.getHM().getVault().getBalans(var1);
         }

         return var4;
      }
   }

   private Material getCraftMaterial(String var1) {
      Iterator var3 = this.rs.getMaterials().keySet().iterator();

      while(var3.hasNext()) {
         Material var2 = (Material)var3.next();
         List var4 = (List)this.rs.getMaterials().get(var2);
         Iterator var6 = var4.iterator();

         while(var6.hasNext()) {
            String var5 = (String)var6.next();
            String var7;
            if (var5.endsWith("*")) {
               var7 = var5.replace("*", "");
               if (var1.startsWith(var7)) {
                  return var2;
               }
            } else if (var5.startsWith("*")) {
               var7 = var5.replace("*", "");
               if (var1.endsWith(var7)) {
                  return var2;
               }
            } else if (var1.equalsIgnoreCase(var5)) {
               return var2;
            }
         }
      }

      return Material.AIR;
   }

   @EventHandler
   public void onClickInventory(InventoryClickEvent var1) {
      if (var1.getWhoClicked() instanceof Player) {
         if (this.getGem().isEnabled()) {
            Player var2 = (Player)var1.getWhoClicked();
            ItemStack var3 = var1.getCursor();
            ItemStack var4 = var1.getCurrentItem();
            if (var3 != null && var4 != null) {
               if (ItemAPI.getDurability(var4, 0) >= 0) {
                  if (var1.getInventory().getType() == InventoryType.CRAFTING) {
                     if (var1.getSlotType() != SlotType.ARMOR && var1.getSlot() != 40) {
                        if (var3.hasItemMeta() && var3.getItemMeta().hasLore()) {
                           NBTItem var5 = new NBTItem(var3);
                           if (var5.hasKey("DIVINE_RGEM")) {
                              int var6 = var5.getInteger("DIVINE_RGEM");
                              int var7 = (Integer)this.getGem().getLevels().get(var6);
                              int var8 = ItemAPI.getDurability(var4, this.getGem().getMode());
                              double var9 = (double)var8 * ((double)var7 / 100.0D);
                              int var11 = (int)var9;
                              if (var2.getInventory().firstEmpty() == -1) {
                                 var2.sendMessage(Lang.Prefix.toMsg() + Lang.Repair_FullInventory.toMsg());
                              } else {
                                 var2.getInventory().addItem(new ItemStack[]{var3});
                                 var1.setCursor((ItemStack)null);
                                 var1.setCancelled(true);
                                 this.openGemGUI(var2, var4, var3, var11);
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
      }
   }

   @EventHandler
   public void onAnvil(PlayerInteractEvent var1) {
      if (this.getSettings().isAnvilEnabled()) {
         Player var2 = var1.getPlayer();
         ItemStack var3 = var2.getInventory().getItemInMainHand();
         if (var1.getHand() != EquipmentSlot.OFF_HAND) {
            if (var1.getAction().name().contains(this.getSettings().getAction())) {
               if (this.getSettings().isShift() && !var2.isSneaking()) {
                  return;
               }

               if (var1.getClickedBlock() != null && var1.getClickedBlock().getType() == Material.ANVIL) {
                  if (var3 == null) {
                     var2.sendMessage(Lang.Prefix.toMsg() + Lang.Repair_NoItem.toMsg());
                     return;
                  }

                  if (ItemAPI.getDurability(var3, 0) < 0) {
                     var2.sendMessage(Lang.Prefix.toMsg() + Lang.Repair_NoDurability.toMsg());
                     return;
                  }

                  if (ItemAPI.getDurability(var3, 0) == ItemAPI.getDurability(var3, 1)) {
                     return;
                  }

                  this.openAnvilGUI(var2, var3);
                  var1.setCancelled(true);
               }
            }

         }
      }
   }

   @EventHandler
   public void onClickGUI(InventoryClickEvent var1) {
      Player var2 = (Player)var1.getWhoClicked();
      if (this.plugin.getGUIManager().valid(var2, GUIType.REPAIR_GEM)) {
         GUI var3 = this.plugin.getGUIManager().getPlayerGUI(var2, GUIType.REPAIR_GEM);
         if (var3 != null && var1.getInventory().getTitle().equals(var3.getTitle())) {
            var1.setCancelled(true);
            ItemStack var4 = var1.getCurrentItem();
            if (var4 != null && var4.hasItemMeta()) {
               GUIItem var5 = (GUIItem)var3.getItems().get(ContentType.ACCEPT);
               int var6 = var1.getRawSlot();
               if (!var4.isSimilar(var5.getItem()) && !ArrayUtils.contains(var5.getSlots(), var6)) {
                  GUIItem var21 = (GUIItem)var3.getItems().get(ContentType.DECLINE);
                  if (var4.isSimilar(var21.getItem()) || ArrayUtils.contains(var21.getSlots(), var6)) {
                     var2.sendMessage(Lang.Prefix.toMsg() + Lang.Repair_Cancel.toMsg());
                     var2.closeInventory();
                     this.plugin.getGUIManager().reset(var2);
                  }

               } else {
                  ItemStack var7 = ((GUIItem)var3.getItems().get(ContentType.TARGET)).getItem();
                  ItemStack var8 = ((GUIItem)var3.getItems().get(ContentType.SOURCE)).getItem();
                  NBTItem var9 = new NBTItem(var8);
                  int var10 = var9.getInteger("DIVINE_RGEM");
                  int var11 = (Integer)this.getGem().getLevels().get(var10);
                  int var12 = ItemAPI.getDurability(var7, this.getGem().getMode());
                  double var13 = (double)var12 * ((double)var11 / 100.0D);
                  int var15 = (int)var13;
                  int var16 = 0;
                  ItemStack[] var20;
                  int var19 = (var20 = var2.getInventory().getContents()).length;

                  ItemStack var17;
                  for(int var18 = 0; var18 < var19; ++var18) {
                     var17 = var20[var18];
                     if (var17 != null && var17.equals(var7)) {
                        break;
                     }

                     ++var16;
                  }

                  var17 = new ItemStack(var8);
                  var17.setAmount(1);
                  var2.getInventory().removeItem(new ItemStack[]{var17});
                  var2.getInventory().removeItem(new ItemStack[]{var7});
                  ItemStack var22 = ItemAPI.setDurability(var7, ItemAPI.getDurability(var7, 0) + var15, ItemAPI.getDurability(var7, 1));
                  var2.getInventory().setItem(var16, var22);
                  var2.sendMessage(Lang.Prefix.toMsg() + Lang.Repair_Done.toMsg());
                  var2.closeInventory();
                  this.plugin.getGUIManager().reset(var2);
                  var2.playSound(var2.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 0.5F, 0.5F);
                  Utils.playEffect("VILLAGER_HAPPY", 0.30000001192092896D, 0.0D, 0.30000001192092896D, 0.30000001192092896D, 15, var2.getLocation().add(0.0D, 0.5D, 0.0D));
                  ParticleUtils.repairEffect(var2.getLocation());
               }
            }
         }
      }
   }

   @EventHandler
   public void onClick2(InventoryClickEvent var1) {
      Player var2 = (Player)var1.getWhoClicked();
      if (this.plugin.getGUIManager().valid(var2, GUIType.REPAIR_ANVIL)) {
         GUI var3 = this.plugin.getGUIManager().getPlayerGUI(var2, GUIType.REPAIR_ANVIL);
         if (var3 != null && var1.getInventory().getTitle().equals(var3.getTitle())) {
            var1.setCancelled(true);
            ItemStack var4 = var1.getCurrentItem();
            if (var4 != null && var4.hasItemMeta() && var4.getItemMeta().hasDisplayName()) {
               String var5 = var4.getItemMeta().getDisplayName();
               ItemStack var6 = ((GUIItem)var3.getItems().get(ContentType.TARGET)).getItem();
               RepairManager.RepairType var7 = null;
               if (((GUIItem)var3.getItems().get(ContentType.EXP)).getItem().getItemMeta() != null && var5.equals(((GUIItem)var3.getItems().get(ContentType.EXP)).getItem().getItemMeta().getDisplayName())) {
                  var7 = RepairManager.RepairType.EXP;
               } else if (((GUIItem)var3.getItems().get(ContentType.MATERIAL)).getItem().getItemMeta() != null && var5.equals(((GUIItem)var3.getItems().get(ContentType.MATERIAL)).getItem().getItemMeta().getDisplayName())) {
                  var7 = RepairManager.RepairType.MATERIAL;
               } else {
                  if (((GUIItem)var3.getItems().get(ContentType.VAULT)).getItem().getItemMeta() == null || !var5.equals(((GUIItem)var3.getItems().get(ContentType.VAULT)).getItem().getItemMeta().getDisplayName())) {
                     return;
                  }

                  var7 = RepairManager.RepairType.VAULT;
               }

               if (!this.payForRepair(var2, var7, var6)) {
                  var2.sendMessage(Lang.Prefix.toMsg() + Lang.Repair_CantAfford.toMsg());
                  var2.playSound(var2.getLocation(), Sound.BLOCK_ANVIL_BREAK, 0.5F, 0.5F);
               } else {
                  int var8 = 0;
                  ItemStack[] var12;
                  int var11 = (var12 = var2.getInventory().getContents()).length;

                  ItemStack var9;
                  for(int var10 = 0; var10 < var11; ++var10) {
                     var9 = var12[var10];
                     if (var9 != null && var9.equals(var6)) {
                        break;
                     }

                     ++var8;
                  }

                  var2.getInventory().removeItem(new ItemStack[]{var6});
                  var9 = ItemAPI.setDurability(var6, 1000000, ItemAPI.getDurability(var6, 1));
                  var2.getInventory().setItem(var8, var9);
                  var2.sendMessage(Lang.Prefix.toMsg() + Lang.Repair_Done.toMsg());
                  var2.closeInventory();
                  this.plugin.getGUIManager().reset(var2);
                  var2.playSound(var2.getLocation(), Sound.BLOCK_ANVIL_USE, 0.5F, 0.5F);
                  Utils.playEffect("VILLAGER_HAPPY", 0.30000001192092896D, 0.0D, 0.30000001192092896D, 0.30000001192092896D, 15, var2.getLocation().add(0.0D, 0.5D, 0.0D));
                  Block var13 = var2.getTargetBlock((Set)null, 100);
                  if (var13 != null && var13.getType() == Material.ANVIL) {
                     ParticleUtils.repairEffect(var13.getLocation());
                  }
               }
            }
         }
      }
   }

   public class RepairGem {
      private boolean enabled;
      private String material;
      private String display;
      private List<String> lore;
      private List<String> flags;
      private boolean unb;
      private int mode;
      private HashMap<Integer, Integer> levels;

      public RepairGem(boolean var2, String var3, String var4, List<String> var5, List<String> var6, boolean var7, int var8, HashMap<Integer, Integer> var9) {
         this.setEnabled(var2);
         this.setMaterial(var3);
         this.setDisplay(var4);
         this.setLore(var5);
         this.setFlags(var6);
         this.setUnbreak(var7);
         this.setMode(var8);
         this.setLevels(var9);
      }

      public boolean isEnabled() {
         return this.enabled;
      }

      public void setEnabled(boolean var1) {
         this.enabled = var1;
      }

      public String getMaterial() {
         return this.material;
      }

      public void setMaterial(String var1) {
         this.material = var1;
      }

      public String getDisplay() {
         return this.display;
      }

      public void setDisplay(String var1) {
         this.display = var1;
      }

      public List<String> getLore() {
         return this.lore;
      }

      public void setLore(List<String> var1) {
         this.lore = var1;
      }

      public List<String> getFlags() {
         return new ArrayList(this.flags);
      }

      public void setFlags(List<String> var1) {
         this.flags = var1;
      }

      public boolean setUnbreak() {
         return this.unb;
      }

      public void setUnbreak(boolean var1) {
         this.unb = var1;
      }

      public int getMode() {
         return this.mode;
      }

      public void setMode(int var1) {
         this.mode = var1;
      }

      public HashMap<Integer, Integer> getLevels() {
         return this.levels;
      }

      public void setLevels(HashMap<Integer, Integer> var1) {
         this.levels = var1;
      }

      public ItemStack getItemGem(int var1) {
         if (!this.isEnabled()) {
            return null;
         } else {
            if (!this.getLevels().containsKey(var1)) {
               var1 = 1;
            }

            String[] var2 = this.getMaterial().split(":");
            ItemStack var3 = Utils.buildItem(var2, "repair-gem-" + var1);
            ItemMeta var4 = var3.getItemMeta();
            var4.setDisplayName(this.getDisplay().replace("%s", Utils.IntegerToRomanNumeral(var1)));
            ArrayList var5 = new ArrayList();
            Iterator var7 = this.getLore().iterator();

            String var6;
            while(var7.hasNext()) {
               var6 = (String)var7.next();
               var5.add(ChatColor.translateAlternateColorCodes('&', var6.replace("%level%", Utils.IntegerToRomanNumeral(var1)).replace("%s%", "" + this.getLevels().get(var1))));
            }

            var4.setLore(var5);
            var7 = this.getFlags().iterator();

            while(var7.hasNext()) {
               var6 = (String)var7.next();
               var4.addItemFlags(new ItemFlag[]{ItemFlag.valueOf(var6)});
            }

            var4.spigot().setUnbreakable(this.setUnbreak());
            var3.setItemMeta(var4);
            NBTItem var8 = new NBTItem(var3);
            var8.setInteger("DIVINE_RGEM", var1);
            return var8.getItem();
         }
      }
   }

   public class RepairSettings {
      private boolean anvil_use;
      private String action;
      private boolean shift;
      private HashMap<RepairManager.RepairType, Boolean> anvil_currency;
      private HashMap<RepairManager.RepairType, Double> anvil_costs;
      private HashMap<Material, List<String>> mats;

      public RepairSettings(boolean var2, String var3, boolean var4, HashMap<RepairManager.RepairType, Boolean> var5, HashMap<RepairManager.RepairType, Double> var6, HashMap<Material, List<String>> var7) {
         this.setAnvilEnabled(var2);
         this.setAction(var3);
         this.setShift(var4);
         this.setCurrency(var5);
         this.setCosts(var6);
         this.setMaterials(var7);
      }

      public boolean isAnvilEnabled() {
         return this.anvil_use;
      }

      public void setAnvilEnabled(boolean var1) {
         this.anvil_use = var1;
      }

      public String getAction() {
         return this.action;
      }

      public void setAction(String var1) {
         this.action = var1;
      }

      public boolean isShift() {
         return this.shift;
      }

      public void setShift(boolean var1) {
         this.shift = var1;
      }

      public HashMap<RepairManager.RepairType, Boolean> getCurrency() {
         return this.anvil_currency;
      }

      public void setCurrency(HashMap<RepairManager.RepairType, Boolean> var1) {
         this.anvil_currency = var1;
      }

      public HashMap<RepairManager.RepairType, Double> getCosts() {
         return this.anvil_costs;
      }

      public void setCosts(HashMap<RepairManager.RepairType, Double> var1) {
         this.anvil_costs = var1;
      }

      public HashMap<Material, List<String>> getMaterials() {
         return this.mats;
      }

      public void setMaterials(HashMap<Material, List<String>> var1) {
         this.mats = var1;
      }
   }

   public static enum RepairType {
      EXP,
      MATERIAL,
      VAULT;
   }
}
