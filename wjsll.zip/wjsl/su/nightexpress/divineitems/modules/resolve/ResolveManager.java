package su.nightexpress.divineitems.modules.resolve;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import net.md_5.bungee.api.ChatColor;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.scheduler.BukkitRunnable;
import su.nightexpress.divineitems.DivineItems;
import su.nightexpress.divineitems.DivineListener;
import su.nightexpress.divineitems.Module;
import su.nightexpress.divineitems.cmds.list.ResolveMainCommand;
import su.nightexpress.divineitems.config.Lang;
import su.nightexpress.divineitems.config.MyConfig;
import su.nightexpress.divineitems.nbt.NBTItem;
import su.nightexpress.divineitems.utils.ErrorLog;
import su.nightexpress.divineitems.utils.Utils;

public class ResolveManager extends DivineListener<DivineItems> implements Module {
   private DivineItems plugin;
   private boolean e;
   private MyConfig settingsCfg;
   private ResolveManager.ResolveSettings ss;
   private HashMap<String, HashMap<String, ResolveManager.ResolveObject>> objects;
   private final String n = this.name().toLowerCase().replace(" ", "_");
   private final String label;
   private final String NBT_KEY_RES;

   public ResolveManager(DivineItems var1) {
      super(var1);
      this.label = this.n.replace("_", "");
      this.NBT_KEY_RES = "RESOLVE_2206";
      this.plugin = var1;
      this.e = this.plugin.getCM().getCFG().isModuleEnabled(this.name());
   }

   public void loadConfig() {
      this.settingsCfg = new MyConfig(this.plugin, "/modules/" + this.n, "settings.yml");
      this.setup();
   }

   public boolean isActive() {
      return this.e;
   }

   public boolean isDropable() {
      return false;
   }

   public boolean isResolvable() {
      return false;
   }

   public String name() {
      return "Resolve";
   }

   public String version() {
      return "1.0";
   }

   public void enable() {
      if (this.isActive()) {
         this.plugin.getCommander().registerCmd(this.label, new ResolveMainCommand(this.plugin));
         this.loadConfig();
         this.registerListeners();
      }

   }

   public void unload() {
      if (this.isActive()) {
         this.plugin.getCommander().unregisterCmd(this.label);
         this.ss = null;
         this.e = false;
         this.unregisterListeners();
      }

   }

   public void reload() {
      this.unload();
      this.enable();
   }

   public void setup() {
      this.setupSettings();
      this.setupObjects();
   }

   private void setupObjects() {
      this.objects = new HashMap();
      Iterator var2 = this.plugin.getMM().getModules().iterator();

      while(true) {
         String var3;
         File var4;
         YamlConfiguration var5;
         do {
            Module var1;
            do {
               do {
                  if (!var2.hasNext()) {
                     return;
                  }

                  var1 = (Module)var2.next();
               } while(!var1.isDropable());
            } while(!var1.isActive());

            var3 = var1.name().toLowerCase().replace(" ", "_");
            var4 = new File(this.plugin.getDataFolder() + "/modules/resolve/", var3 + ".yml");
            var5 = YamlConfiguration.loadConfiguration(var4);
         } while(!var4.exists());

         HashMap var6 = new HashMap();
         if (var5.contains("Objects")) {
            Iterator var8 = var5.getConfigurationSection("Objects").getKeys(false).iterator();

            while(true) {
               if (!var8.hasNext()) {
                  try {
                     var5.save(var4);
                  } catch (IOException var31) {
                     var31.printStackTrace();
                  }
                  break;
               }

               String var7 = (String)var8.next();
               String var9 = "Objects." + var7 + ".Out.";
               ArrayList var10 = new ArrayList();
               ArrayList var11 = new ArrayList();
               String var12;
               Iterator var13;
               String var14;
               double var15;
               Material var17;
               short var18;
               int var19;
               boolean var20;
               String var21;
               ArrayList var22;
               String var23;
               Iterator var24;
               if (var5.contains(var9 + "Items")) {
                  var13 = var5.getConfigurationSection(var9 + "Items").getKeys(false).iterator();

                  label126:
                  while(true) {
                     while(true) {
                        if (!var13.hasNext()) {
                           break label126;
                        }

                        var12 = (String)var13.next();
                        var14 = var9 + "Items." + var12 + ".";
                        if (!var5.contains(var14 + "Chance")) {
                           var5.set(var14 + "Chance", 100.0D);
                        }

                        var15 = var5.getDouble(var14 + "Chance");
                        var17 = Material.getMaterial(var5.getString(var14 + "Material").toUpperCase());
                        if (var17 == null) {
                           ErrorLog.sendError(this, var14 + "Material", "Invalid material!", false);
                        } else {
                           var18 = (short)var5.getInt(var14 + "Data");
                           var19 = var5.getInt(var14 + "Amount");
                           var20 = var5.getBoolean(var14 + "Meta.Enabled");
                           var21 = ChatColor.translateAlternateColorCodes('&', var5.getString(var14 + "Meta.Name"));
                           var22 = new ArrayList();
                           var24 = var5.getStringList(var14 + "Meta.Lore").iterator();

                           while(var24.hasNext()) {
                              var23 = (String)var24.next();
                              var22.add(ChatColor.translateAlternateColorCodes('&', var23));
                           }

                           List var34 = var5.getStringList(var14 + "Meta.Flags");
                           HashMap var36 = new HashMap();
                           if (var5.contains(var14 + "Meta.Enchants")) {
                              Iterator var26 = var5.getConfigurationSection(var14 + "Meta.Enchants").getKeys(false).iterator();

                              while(var26.hasNext()) {
                                 String var25 = (String)var26.next();
                                 Enchantment var27 = Enchantment.getByName(var25.toUpperCase());
                                 if (var27 == null) {
                                    ErrorLog.sendError(this, var14 + "Meta.Enchants", "Invalid enchantment!", false);
                                 } else {
                                    int var28 = var5.getInt(var14 + "Meta.Enchants." + var25);
                                    var36.put(var27, var28);
                                 }
                              }
                           }

                           boolean var38 = var5.getBoolean(var14 + "Meta.Unbreakable");
                           ItemStack var40 = new ItemStack(var17, var19, var18);
                           if (var20) {
                              ItemMeta var42 = var40.getItemMeta();
                              var42.setDisplayName(var21);
                              var42.setLore(var22);
                              Iterator var29 = var34.iterator();

                              while(var29.hasNext()) {
                                 String var44 = (String)var29.next();

                                 try {
                                    var42.addItemFlags(new ItemFlag[]{ItemFlag.valueOf(var44.toUpperCase())});
                                 } catch (IllegalArgumentException var32) {
                                    ErrorLog.sendError(this, var14 + "Meta.Flags." + var44, "Invalid item flag!", false);
                                 }
                              }

                              var42.spigot().setUnbreakable(var38);
                              var40.setItemMeta(var42);
                              var29 = var36.keySet().iterator();

                              while(var29.hasNext()) {
                                 Enchantment var45 = (Enchantment)var29.next();
                                 var40.addUnsafeEnchantment(var45, (Integer)var36.get(var45));
                              }
                           }

                           ResolveManager.ResolveItem var43 = new ResolveManager.ResolveItem(var12, var15, var40);
                           var10.add(var43);
                        }
                     }
                  }
               }

               if (var5.contains(var9 + "Commands")) {
                  var13 = var5.getConfigurationSection(var9 + "Commands").getKeys(false).iterator();

                  label146:
                  while(true) {
                     while(true) {
                        if (!var13.hasNext()) {
                           break label146;
                        }

                        var12 = (String)var13.next();
                        var14 = var9 + "Commands." + var12 + ".";
                        if (!var5.contains(var14 + "Chance")) {
                           var5.set(var14 + "Chance", 100.0D);
                        }

                        var15 = var5.getDouble(var14 + "Chance");
                        var17 = Material.getMaterial(var5.getString(var14 + "Display.Material").toUpperCase());
                        if (var17 == null) {
                           ErrorLog.sendError(this, var14 + "Display.Material", "Invalid material!", false);
                        } else {
                           var18 = (short)var5.getInt(var14 + "Display.Data");
                           var19 = var5.getInt(var14 + "Display.Amount");
                           var20 = var5.getBoolean(var14 + "Display.Enchanted");
                           var21 = ChatColor.translateAlternateColorCodes('&', var5.getString(var14 + "Display.Name"));
                           var22 = new ArrayList();
                           var24 = var5.getStringList(var14 + "Display.Lore").iterator();

                           while(var24.hasNext()) {
                              var23 = (String)var24.next();
                              var22.add(ChatColor.translateAlternateColorCodes('&', var23));
                           }

                           ItemStack var35 = new ItemStack(var17, var19, var18);
                           ItemMeta var37 = var35.getItemMeta();
                           var37.setDisplayName(var21);
                           var37.setLore(var22);
                           var37.addItemFlags(ItemFlag.values());
                           var37.spigot().setUnbreakable(true);
                           var35.setItemMeta(var37);
                           if (var20) {
                              var35.addUnsafeEnchantment(Enchantment.ARROW_FIRE, 1);
                           }

                           List var39 = var5.getStringList(var14 + "Commands");
                           ResolveManager.ResolveCommand var41 = new ResolveManager.ResolveCommand(var12, var15, var35, var39);
                           var11.add(var41);
                        }
                     }
                  }
               }

               ResolveManager.ResolveObject var33 = new ResolveManager.ResolveObject(var7.toLowerCase(), var10, var11);
               var6.put(var7.toLowerCase(), var33);
            }
         }

         this.objects.put(var3, var6);
      }
   }

   private void setupSettings() {
      FileConfiguration var1 = this.settingsCfg.getConfig();
      String var2 = org.bukkit.ChatColor.translateAlternateColorCodes('&', var1.getString("GUI.Title"));
      String var3 = "GUI.ResolveButton.Resolve.";
      Material var4 = Material.getMaterial(var1.getString(var3 + "Material").toUpperCase());
      short var5 = (short)var1.getInt(var3 + "Data");
      if (var4 == null) {
         var4 = Material.STAINED_GLASS_PANE;
         ErrorLog.sendError(this, var3 + "Resolve", "Invalid material!", true);
      }

      String var6 = ChatColor.translateAlternateColorCodes('&', var1.getString(var3 + "Name"));
      ArrayList var7 = new ArrayList();
      Iterator var9 = var1.getStringList(var3 + "Lore").iterator();

      while(var9.hasNext()) {
         String var8 = (String)var9.next();
         var7.add(ChatColor.translateAlternateColorCodes('&', var8));
      }

      boolean var14 = var1.getBoolean(var3 + "Enchanted");
      ItemStack var15 = new ItemStack(var4, 1, var5);
      ItemMeta var10 = var15.getItemMeta();
      var10.setDisplayName(var6);
      var10.setLore(var7);
      var10.addItemFlags(ItemFlag.values());
      var10.spigot().setUnbreakable(true);
      var15.setItemMeta(var10);
      if (var14) {
         var15.addUnsafeEnchantment(Enchantment.ARROW_DAMAGE, 1);
      }

      var3 = "GUI.ResolveButton.Unresolvable.";
      var4 = Material.getMaterial(var1.getString(var3 + "Material").toUpperCase());
      var5 = (short)var1.getInt(var3 + "Data");
      if (var4 == null) {
         var4 = Material.STAINED_GLASS_PANE;
         ErrorLog.sendError(this, var3 + "Resolve", "Invalid material!", true);
      }

      var6 = ChatColor.translateAlternateColorCodes('&', var1.getString(var3 + "Name"));
      var7 = new ArrayList();
      Iterator var12 = var1.getStringList(var3 + "Lore").iterator();

      while(var12.hasNext()) {
         String var11 = (String)var12.next();
         var7.add(ChatColor.translateAlternateColorCodes('&', var11));
      }

      var14 = var1.getBoolean(var3 + "Enchanted");
      ItemStack var16 = new ItemStack(var4, 1, var5);
      var10 = var16.getItemMeta();
      var10.setDisplayName(var6);
      var10.setLore(var7);
      var10.addItemFlags(ItemFlag.values());
      var10.spigot().setUnbreakable(true);
      var16.setItemMeta(var10);
      if (var14) {
         var16.addUnsafeEnchantment(Enchantment.ARROW_DAMAGE, 1);
      }

      var3 = "GUI.ResolveButton.Nothing.";
      var4 = Material.getMaterial(var1.getString(var3 + "Material").toUpperCase());
      var5 = (short)var1.getInt(var3 + "Data");
      if (var4 == null) {
         var4 = Material.STAINED_GLASS_PANE;
         ErrorLog.sendError(this, var3 + "Resolve", "Invalid material!", true);
      }

      var6 = ChatColor.translateAlternateColorCodes('&', var1.getString(var3 + "Name"));
      var7 = new ArrayList();
      Iterator var13 = var1.getStringList(var3 + "Lore").iterator();

      while(var13.hasNext()) {
         String var17 = (String)var13.next();
         var7.add(ChatColor.translateAlternateColorCodes('&', var17));
      }

      var14 = var1.getBoolean(var3 + "Enchanted");
      ItemStack var18 = new ItemStack(var4, 1, var5);
      var10 = var18.getItemMeta();
      var10.setDisplayName(var6);
      var10.setLore(var7);
      var10.addItemFlags(ItemFlag.values());
      var10.spigot().setUnbreakable(true);
      var18.setItemMeta(var10);
      if (var14) {
         var18.addUnsafeEnchantment(Enchantment.ARROW_DAMAGE, 1);
      }

      this.ss = new ResolveManager.ResolveSettings(false, var2, var15, var16, var18);
   }

   public void openResolveGUI(Player var1) {
      Inventory var2 = this.plugin.getServer().createInventory((InventoryHolder)null, 27, this.ss.getGUITitle());
      ItemStack var3 = new ItemStack(Material.STAINED_GLASS_PANE);
      var2.setItem(0, var3);
      var2.setItem(6, var3);
      var2.setItem(1, var3);
      var2.setItem(7, var3);
      var2.setItem(2, var3);
      var2.setItem(8, var3);
      var2.setItem(9, var3);
      var2.setItem(11, var3);
      var2.setItem(15, var3);
      var2.setItem(17, var3);
      var2.setItem(18, var3);
      var2.setItem(24, var3);
      var2.setItem(19, var3);
      var2.setItem(25, var3);
      var2.setItem(20, var3);
      var2.setItem(26, var3);
      int[] var4 = new int[]{3, 4, 5, 12, 13, 14, 21, 22, 23};
      ItemStack var5 = new ItemStack(Material.STAINED_GLASS_PANE, 1, (short)15);
      int[] var9 = var4;
      int var8 = var4.length;

      for(int var7 = 0; var7 < var8; ++var7) {
         int var6 = var9[var7];
         var2.setItem(var6, var5);
      }

      var2.setItem(16, this.ss.getButtonX());
      var1.openInventory(var2);
   }

   private void update(Inventory var1) {
      int[] var2 = new int[]{3, 4, 5, 12, 13, 14, 21, 22, 23};
      ItemStack var3 = new ItemStack(Material.STAINED_GLASS_PANE, 1, (short)15);
      int[] var7 = var2;
      int var6 = var2.length;

      for(int var5 = 0; var5 < var6; ++var5) {
         int var4 = var7[var5];
         var1.setItem(var4, var3);
      }

      ItemStack var12 = var1.getItem(10);
      if (var12 != null && var12.getType() != Material.AIR) {
         Object var13 = null;
         String var14 = "";
         if (this.plugin.getMM().getAbilityManager().isAbility(var12)) {
            var14 = this.plugin.getMM().getAbilityManager().getAbilityId(var12);
            var13 = this.plugin.getMM().getAbilityManager();
         } else if (this.plugin.getMM().getAbyssDustManager().isAbyssDust(var12)) {
            var14 = this.plugin.getMM().getAbyssDustManager().getDustId(var12);
            var13 = this.plugin.getMM().getAbyssDustManager();
         } else if (this.plugin.getMM().getArrowManager().isDivineArrow(var12)) {
            var14 = this.plugin.getMM().getArrowManager().getArrowId(var12);
            var13 = this.plugin.getMM().getArrowManager();
         } else if (this.plugin.getMM().getEnchantManager().isEnchant(var12)) {
            var14 = this.plugin.getMM().getEnchantManager().getEnchantBookId(var12);
            var13 = this.plugin.getMM().getEnchantManager();
         } else if (this.plugin.getMM().getGemManager().isGem(var12)) {
            var14 = this.plugin.getMM().getGemManager().getGemId(var12);
            var13 = this.plugin.getMM().getGemManager();
         } else if (this.plugin.getMM().getMagicDustManager().isMagicDust(var12)) {
            var14 = this.plugin.getMM().getMagicDustManager().getDustId(var12);
            var13 = this.plugin.getMM().getMagicDustManager();
         } else if (this.plugin.getMM().getRuneManager().isRune(var12)) {
            var14 = this.plugin.getMM().getRuneManager().getRuneId(var12);
            var13 = this.plugin.getMM().getRuneManager();
         } else if (this.plugin.getMM().getScrollManager().isScroll(var12)) {
            var14 = this.plugin.getMM().getScrollManager().getScrollId(var12);
            var13 = this.plugin.getMM().getScrollManager();
         } else if (this.plugin.getMM().getTierManager().isTiered(var12)) {
            var14 = this.plugin.getMM().getTierManager().getTierId(var12);
            var13 = this.plugin.getMM().getTierManager();
         }

         if (var13 != null && !var14.isEmpty()) {
            String var15 = ((Module)var13).name().toLowerCase().replace(" ", "_");
            ResolveManager.ResolveObject var8 = (ResolveManager.ResolveObject)((HashMap)this.objects.get(var15)).get(var14.toLowerCase());
            if (var8 == null) {
               var1.setItem(16, this.ss.getButtonNo());
            } else {
               int var9 = 0;

               Iterator var11;
               for(var11 = var8.getItems().iterator(); var11.hasNext(); ++var9) {
                  ResolveManager.ResolveItem var10 = (ResolveManager.ResolveItem)var11.next();
                  if (var9 >= 9) {
                     break;
                  }

                  var1.setItem(var2[var9], var10.getItem());
               }

               for(var11 = var8.getCommands().iterator(); var11.hasNext(); ++var9) {
                  ResolveManager.ResolveCommand var16 = (ResolveManager.ResolveCommand)var11.next();
                  if (var9 >= 9) {
                     break;
                  }

                  var1.setItem(var2[var9], var16.getDisplayItem());
               }

               ItemStack var17 = this.ss.getButtonYes();
               NBTItem var18 = new NBTItem(var17);
               var18.setString("RESOLVE_2206", var15 + ":" + var14.toLowerCase());
               var1.setItem(16, var18.getItem());
            }
         } else {
            var1.setItem(16, this.ss.getButtonNo());
         }
      } else {
         var1.setItem(16, this.ss.getButtonX());
      }
   }

   @EventHandler
   public void onClick(final InventoryClickEvent var1) {
      if (var1.getInventory().getTitle().equals(this.ss.getGUITitle())) {
         int var2 = var1.getRawSlot();
         if (var2 != 10 && var2 <= 26) {
            var1.setCancelled(true);
         } else {
            var1.setCancelled(false);
         }

         if (var2 > 26 && var1.isShiftClick()) {
            var1.setCancelled(true);
         }

         if (var2 != 16) {
            (new BukkitRunnable() {
               public void run() {
                  ResolveManager.this.update(var1.getInventory());
               }
            }).runTaskLater(this.plugin, 1L);
         } else {
            ItemStack var3 = var1.getCurrentItem();
            if (var3 != null && var3.getType() != Material.AIR) {
               NBTItem var4 = new NBTItem(var3);
               if (var4.hasKey("RESOLVE_2206")) {
                  Player var5 = (Player)var1.getWhoClicked();
                  String var6 = var4.getString("RESOLVE_2206").split(":")[0];
                  String var7 = var4.getString("RESOLVE_2206").split(":")[1];
                  ResolveManager.ResolveObject var8 = (ResolveManager.ResolveObject)((HashMap)this.objects.get(var6)).get(var7.toLowerCase());
                  Iterator var10;
                  double var11;
                  if (var8 != null && var8.getItems() != null) {
                     var10 = var8.getItems().iterator();

                     while(var10.hasNext()) {
                        ResolveManager.ResolveItem var9 = (ResolveManager.ResolveItem)var10.next();
                        var11 = Utils.getRandDouble(0.0D, 100.0D);
                        if (!(var11 > var9.getChance())) {
                           ItemStack var13 = var9.getItem();
                           if (var5.getInventory().firstEmpty() == -1) {
                              var5.getWorld().dropItemNaturally(var5.getLocation(), var13);
                           } else {
                              var5.getInventory().addItem(new ItemStack[]{var13});
                           }
                        }
                     }
                  }

                  if (var8 != null && var8.getCommands() != null) {
                     var10 = var8.getCommands().iterator();

                     label66:
                     while(true) {
                        ResolveManager.ResolveCommand var15;
                        do {
                           if (!var10.hasNext()) {
                              break label66;
                           }

                           var15 = (ResolveManager.ResolveCommand)var10.next();
                           var11 = Utils.getRandDouble(0.0D, 100.0D);
                        } while(var11 > var15.getChance());

                        Iterator var14 = var15.getCommands().iterator();

                        while(var14.hasNext()) {
                           String var18 = (String)var14.next();
                           this.plugin.getServer().dispatchCommand(this.plugin.getServer().getConsoleSender(), var18.replace("%p", var5.getName()));
                        }
                     }
                  }

                  ItemStack var16 = var1.getInventory().getItem(10);
                  String var17 = var16.getType().name();
                  if (var16.hasItemMeta() && var16.getItemMeta().hasDisplayName()) {
                     var17 = var16.getItemMeta().getDisplayName();
                  } else {
                     this.plugin.getCM().getDefaultItemName(var16);
                  }

                  this.plugin.getNMS().sendTitles(var5, Lang.Resolve_Title_Resolved.toMsg(), Lang.Resolve_SubTitle_Resolved.toMsg().replace("%item%", var17), 10, 40, 10);
                  var5.playSound(var5.getLocation(), Sound.BLOCK_ANVIL_DESTROY, 1.0F, 1.0F);
                  var1.getInventory().setItem(10, new ItemStack(Material.AIR));
                  var5.closeInventory();
               }
            }
         }
      }
   }

   @EventHandler
   public void onClose(InventoryCloseEvent var1) {
      if (var1.getInventory().getTitle().equals(this.ss.getGUITitle())) {
         Player var2 = (Player)var1.getPlayer();
         ItemStack var3 = var1.getInventory().getItem(10);
         if (var3 != null && var3.getType() != Material.AIR) {
            if (var2.getInventory().firstEmpty() == -1) {
               var2.getWorld().dropItemNaturally(var2.getLocation(), var3);
            } else {
               var2.getInventory().addItem(new ItemStack[]{var3});
            }

         }
      }
   }

   public class ResolveCommand {
      private String id;
      private double chance;
      private ItemStack item;
      private List<String> cmds;

      public ResolveCommand(String var2, double var3, ItemStack var5, List<String> var6) {
         this.setId(var2);
         this.setChance(var3);
         this.setDisplayItem(var5);
         this.setCommands(var6);
      }

      public String getId() {
         return this.id;
      }

      public void setId(String var1) {
         this.id = var1;
      }

      public double getChance() {
         return this.chance;
      }

      public void setChance(double var1) {
         this.chance = var1;
      }

      public ItemStack getDisplayItem() {
         return this.item.clone();
      }

      public void setDisplayItem(ItemStack var1) {
         this.item = var1.clone();
      }

      public List<String> getCommands() {
         return this.cmds;
      }

      public void setCommands(List<String> var1) {
         this.cmds = var1;
      }
   }

   public class ResolveItem {
      private String id;
      private double chance;
      private ItemStack item;

      public ResolveItem(String var2, double var3, ItemStack var5) {
         this.setId(var2);
         this.setChance(var3);
         this.setItem(var5);
      }

      public String getId() {
         return this.id;
      }

      public void setId(String var1) {
         this.id = var1;
      }

      public double getChance() {
         return this.chance;
      }

      public void setChance(double var1) {
         this.chance = var1;
      }

      public ItemStack getItem() {
         return this.item.clone();
      }

      public void setItem(ItemStack var1) {
         this.item = var1.clone();
      }
   }

   public class ResolveObject {
      private String id;
      private List<ResolveManager.ResolveItem> items;
      private List<ResolveManager.ResolveCommand> cmds;

      public ResolveObject(String var2, List<ResolveManager.ResolveItem> var3, List<ResolveManager.ResolveCommand> var4) {
         this.setId(var2);
         this.setItems(var3);
         this.setCommands(var4);
      }

      public String getId() {
         return this.id;
      }

      public void setId(String var1) {
         this.id = var1;
      }

      public List<ResolveManager.ResolveItem> getItems() {
         return this.items;
      }

      public void setItems(List<ResolveManager.ResolveItem> var1) {
         this.items = var1;
      }

      public List<ResolveManager.ResolveCommand> getCommands() {
         return this.cmds;
      }

      public void setCommands(List<ResolveManager.ResolveCommand> var1) {
         this.cmds = var1;
      }
   }

   public class ResolveSettings {
      private boolean g_autoFill;
      private String gui_title;
      private ItemStack button_yes;
      private ItemStack button_no;
      private ItemStack button_x;

      public ResolveSettings(boolean var2, String var3, ItemStack var4, ItemStack var5, ItemStack var6) {
         this.setAutoFill(var2);
         this.setGUITitle(var3);
         this.setButtonYes(var4);
         this.setButtonNo(var5);
         this.setButtonX(var6);
      }

      public boolean isAutoFill() {
         return this.g_autoFill;
      }

      public void setAutoFill(boolean var1) {
         this.g_autoFill = var1;
      }

      public String getGUITitle() {
         return this.gui_title;
      }

      public void setGUITitle(String var1) {
         this.gui_title = var1;
      }

      public ItemStack getButtonYes() {
         return this.button_yes.clone();
      }

      public void setButtonYes(ItemStack var1) {
         this.button_yes = var1.clone();
      }

      public ItemStack getButtonNo() {
         return this.button_no.clone();
      }

      public void setButtonNo(ItemStack var1) {
         this.button_no = var1.clone();
      }

      public ItemStack getButtonX() {
         return this.button_x.clone();
      }

      public void setButtonX(ItemStack var1) {
         this.button_x = var1.clone();
      }
   }
}
