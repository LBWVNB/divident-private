package su.nightexpress.divineitems.modules.runes;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import org.apache.commons.lang.ArrayUtils;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import su.nightexpress.divineitems.DivineItems;
import su.nightexpress.divineitems.DivineListener;
import su.nightexpress.divineitems.Module;
import su.nightexpress.divineitems.api.EntityAPI;
import su.nightexpress.divineitems.cmds.list.RunesCommand;
import su.nightexpress.divineitems.config.Lang;
import su.nightexpress.divineitems.config.MyConfig;
import su.nightexpress.divineitems.gui.ContentType;
import su.nightexpress.divineitems.gui.GUI;
import su.nightexpress.divineitems.gui.GUIItem;
import su.nightexpress.divineitems.gui.GUIType;
import su.nightexpress.divineitems.modules.MainSettings;
import su.nightexpress.divineitems.nbt.NBTItem;
import su.nightexpress.divineitems.types.DestroyType;
import su.nightexpress.divineitems.types.SlotType;
import su.nightexpress.divineitems.utils.ErrorLog;
import su.nightexpress.divineitems.utils.ItemUtils;
import su.nightexpress.divineitems.utils.Utils;

public class RuneManager extends DivineListener<DivineItems> implements Module {
   private DivineItems plugin;
   private MyConfig settingsCfg;
   private MyConfig runesCfg;
   private boolean e;
   private Random r;
   private int taskId;
   private RuneManager.RuneSettings rr;
   private HashMap<String, RuneManager.Rune> runes;
   private final String n = this.name().toLowerCase().replace(" ", "_");
   private final String label;
   private final String NBT_KEY_RUNE;
   private final String NBT_KEY_ITEM_RUNE;
   // $FF: synthetic field
   private static int[] $SWITCH_TABLE$su$nightexpress$divineitems$types$DestroyType;

   public RuneManager(DivineItems var1) {
      super(var1);
      this.label = this.n.replace("_", "");
      this.NBT_KEY_RUNE = "DIVINE_RUNE_ID";
      this.NBT_KEY_ITEM_RUNE = "RUNE_";
      this.plugin = var1;
      this.e = this.plugin.getCM().getCFG().isModuleEnabled(this.name());
      this.r = new Random();
   }

   public void loadConfig() {
      this.runes = new HashMap();
      this.settingsCfg = new MyConfig(this.plugin, "/modules/" + this.n, "settings.yml");
      this.runesCfg = new MyConfig(this.plugin, "/modules/" + this.n, "runes.yml");
      this.setupSettings();
      this.setupSlot();
      this.setupRunes();
   }

   public boolean isActive() {
      return this.e;
   }

   public boolean isDropable() {
      return true;
   }

   public boolean isResolvable() {
      return true;
   }

   public String name() {
      return "Runes";
   }

   public String version() {
      return "1.0";
   }

   public void enable() {
      if (this.isActive()) {
         this.plugin.getCommander().registerCmd(this.label, new RunesCommand(this.plugin));
         this.loadConfig();
         this.registerListeners();
         this.startTask();
      }

   }

   public void unload() {
      if (this.isActive()) {
         this.plugin.getCommander().unregisterCmd(this.label);
         this.stopTask();
         this.rr = null;
         this.runes.clear();
         this.e = false;
         this.unregisterListeners();
      }

   }

   public void reload() {
      this.unload();
      this.enable();
   }

   private void setupSlot() {
      SlotType var1 = SlotType.RUNE;
      var1.setModule(this);
      var1.setHeader(this.getSettings().getHeader());
      var1.setEmpty(this.getSettings().getEmptySlot());
      var1.setFilled(this.getSettings().getFilledSlot());
   }

   private void setupSettings() {
      FileConfiguration var1 = this.settingsCfg.getConfig();
      String var2 = "Item.";
      String var3 = ChatColor.translateAlternateColorCodes('&', var1.getString(var2 + "Display"));
      List var4 = var1.getStringList(var2 + "Lore");
      var2 = "Enchant.";
      int var5 = var1.getInt(var2 + "MinSuccessChance");
      int var6 = var1.getInt(var2 + "MaxSuccessChance");
      DestroyType var7 = DestroyType.CLEAR;

      try {
         var7 = DestroyType.valueOf(var1.getString(var2 + "DestroyType"));
      } catch (IllegalArgumentException var20) {
         ErrorLog.sendError(this, var2 + "DestroyType", "Invalid Destroy Type!", true);
         var1.set(var2 + "DestroyType", "CLEAR");
      }

      boolean var8 = var1.getBoolean(var2 + "StackLevels");
      var2 = "Effects.";
      boolean var9 = var1.getBoolean(var2 + "Enabled");
      String var10 = var1.getString(var2 + "Failure");
      String var11 = var1.getString(var2 + "Success");
      var2 = "Sounds.";
      boolean var12 = var1.getBoolean(var2 + "Enabled");
      Sound var13 = Sound.BLOCK_ANVIL_BREAK;

      try {
         var13 = Sound.valueOf(var1.getString(var2 + "Failure"));
      } catch (IllegalArgumentException var19) {
         ErrorLog.sendError(this, var2 + "Failure", "Invalid Sound Type!", true);
         var1.set(var2 + "Failure", "BLOCK_ANVIL_BREAK");
      }

      Sound var14 = Sound.ENTITY_EXPERIENCE_ORB_PICKUP;

      try {
         var14 = Sound.valueOf(var1.getString(var2 + "Success"));
      } catch (IllegalArgumentException var18) {
         ErrorLog.sendError(this, var2 + "Success", "Invalid Sound Type!", true);
         var1.set(var2 + "Success", "ENTITY_EXPERIENCE_ORB_PICKUP");
      }

      var2 = "Design.";
      String var15 = ChatColor.translateAlternateColorCodes('&', var1.getString(var2 + "Header"));
      String var16 = ChatColor.translateAlternateColorCodes('&', var1.getString(var2 + "EmptySlot"));
      String var17 = ChatColor.translateAlternateColorCodes('&', var1.getString(var2 + "FilledSlot"));
      this.rr = new RuneManager.RuneSettings(var3, var4, var5, var6, var7, var8, var9, var10, var11, var12, var13, var14, var15, var16, var17);
   }

   private void setupRunes() {
      FileConfiguration var1 = this.runesCfg.getConfig();
      Iterator var3 = var1.getConfigurationSection("Runes").getKeys(false).iterator();

      while(var3.hasNext()) {
         String var2 = (String)var3.next();
         String var4 = "Runes." + var2 + ".";
         String var5 = var2.toString().toLowerCase();
         boolean var6 = var1.getBoolean(var4 + "Enabled");
         if (var6) {
            String var7 = var1.getString(var4 + "Material");
            String var8 = ChatColor.translateAlternateColorCodes('&', var1.getString(var4 + "Name"));
            List var9 = var1.getStringList(var4 + "Desc");
            String var10 = var1.getString(var4 + "Effect");
            int var11 = var1.getInt(var4 + "LevelMin");
            int var12 = var1.getInt(var4 + "LevelMax");
            List var13 = var1.getStringList(var4 + "ItemTypes");
            RuneManager.Rune var14 = new RuneManager.Rune(var6, var5, var7, var8, var9, var10, var11, var12, var13);
            this.runes.put(var5, var14);
         }
      }

   }

   private void startTask() {
      this.taskId = this.plugin.getServer().getScheduler().scheduleSyncRepeatingTask(this.plugin, new Runnable() {
         public void run() {
            Iterator var2 = Bukkit.getOnlinePlayers().iterator();

            while(var2.hasNext()) {
               Player var1 = (Player)var2.next();
               RuneManager.this.setRuneEffects(var1);
            }

         }
      }, 10L, 60L);
   }

   private void stopTask() {
      this.plugin.getServer().getScheduler().cancelTask(this.taskId);
   }

   public void setRuneEffects(Player var1) {
      if (var1.getInventory().getArmorContents() != null) {
         HashMap var2 = new HashMap();
         ItemStack[] var6;
         int var5 = (var6 = EntityAPI.getEquipment(var1, false)).length;

         for(int var4 = 0; var4 < var5; ++var4) {
            ItemStack var3 = var6[var4];
            if (var3 != null && var3.hasItemMeta()) {
               NBTItem var7 = new NBTItem(var3);
               Iterator var9 = var7.getKeys().iterator();

               while(var9.hasNext()) {
                  String var8 = (String)var9.next();
                  if (var8.startsWith("RUNE_")) {
                     String[] var10 = var7.getString(var8).split(":");
                     PotionEffectType var11 = PotionEffectType.getByName(var10[2]);
                     if (var11 != null) {
                        int var12 = Integer.parseInt(var10[1]);
                        if (this.getSettings().isStackLevels() && var2.containsKey(var11)) {
                           var12 += (Integer)var2.get(var11);
                        }

                        var2.put(var11, var12);
                     }
                  }
               }
            }
         }

         if (!var2.isEmpty()) {
            Iterator var14 = var2.keySet().iterator();

            while(var14.hasNext()) {
               PotionEffectType var13 = (PotionEffectType)var14.next();
               var5 = (Integer)var2.get(var13);
               short var15 = 100;
               if (var13.getName().equalsIgnoreCase("NIGHT_VISION")) {
                  var15 = 1200;
               }

               PotionEffect var16 = new PotionEffect(var13, var15, var5 - 1);
               var1.removePotionEffect(var13);
               var1.addPotionEffect(var16);
            }

         }
      }
   }

   public boolean hasRune(String var1, ItemStack var2) {
      NBTItem var3 = new NBTItem(var2);
      Iterator var5 = var3.getKeys().iterator();

      while(var5.hasNext()) {
         String var4 = (String)var5.next();
         if (var4.startsWith("RUNE_")) {
            String[] var6 = var3.getString(var4).split(":");
            if (var6[0].equalsIgnoreCase(var1)) {
               return true;
            }
         }
      }

      return false;
   }

   public int getItemRuneLvl(ItemStack var1, String var2) {
      NBTItem var3 = new NBTItem(var1);
      Iterator var5 = var3.getKeys().iterator();

      while(var5.hasNext()) {
         String var4 = (String)var5.next();
         if (var4.startsWith("RUNE_")) {
            String[] var6 = var3.getString(var4).split(":");
            if (var6[0].equalsIgnoreCase(var2)) {
               return Integer.parseInt(var6[1]);
            }
         }
      }

      return 0;
   }

   public String getRuneId(ItemStack var1) {
      NBTItem var2 = new NBTItem(var1);
      String[] var3 = var2.getString("DIVINE_RUNE_ID").split(":");
      return var3[0];
   }

   public int getRuneLevel(ItemStack var1) {
      NBTItem var2 = new NBTItem(var1);
      String[] var3 = var2.getString("DIVINE_RUNE_ID").split(":");
      return Integer.parseInt(var3[1]);
   }

   private String getRuneEffect(ItemStack var1) {
      NBTItem var2 = new NBTItem(var1);
      String[] var3 = var2.getString("DIVINE_RUNE_ID").split(":");
      return var3[2];
   }

   public RuneManager.RuneSettings getSettings() {
      return this.rr;
   }

   public Collection<RuneManager.Rune> getRunes() {
      return this.runes.values();
   }

   public List<String> getRuneNames() {
      ArrayList var1 = new ArrayList();
      Iterator var3 = this.getRunes().iterator();

      while(var3.hasNext()) {
         RuneManager.Rune var2 = (RuneManager.Rune)var3.next();
         var1.add(var2.getId());
      }

      return var1;
   }

   public RuneManager.Rune getRuneById(String var1) {
      return var1.equalsIgnoreCase("random") ? (RuneManager.Rune)(new ArrayList(this.getRunes())).get(this.r.nextInt(this.getRunes().size())) : (RuneManager.Rune)this.runes.get(var1.toLowerCase());
   }

   public int getItemRunesAmount(ItemStack var1) {
      NBTItem var2 = new NBTItem(var1);
      int var3 = 0;
      Iterator var5 = var2.getKeys().iterator();

      while(var5.hasNext()) {
         String var4 = (String)var5.next();
         if (var4.startsWith("RUNE_")) {
            ++var3;
         }
      }

      return var3;
   }

   public ItemStack removeRune(ItemStack var1, String var2) {
      NBTItem var3 = new NBTItem(var1);
      Iterator var5 = var3.getKeys().iterator();

      while(var5.hasNext()) {
         String var4 = (String)var5.next();
         if (var4.startsWith("RUNE_")) {
            String[] var6 = var3.getString(var4).split(":");
            if (var6[0].equalsIgnoreCase(var2)) {
               var3.removeKey(var4);
               break;
            }
         }
      }

      return var3.getItem();
   }

   public ItemStack removeRune(ItemStack var1, int var2) {
      NBTItem var3 = new NBTItem(var1);
      int var4 = this.getItemRunesAmount(var1);
      int var5 = var2 - 1;
      int var6 = var4 - var5;
      int var7 = var6;
      if (var5 == 0) {
         var7 = var6 - 1;
      }

      var3.removeKey("RUNE_" + var7);
      var1 = new ItemStack(var3.getItem());
      ItemMeta var8 = var1.getItemMeta();
      ArrayList var9 = new ArrayList(var8.getLore());
      int var10 = 0;
      int var11 = 0;

      for(Iterator var13 = var8.getLore().iterator(); var13.hasNext(); ++var11) {
         String var12 = (String)var13.next();
         if (var12.startsWith(this.getSettings().getFilledSlot())) {
            ++var10;
         }

         if (var10 == var6) {
            var9.remove(var11);
            var9.add(var11, this.rr.getEmptySlot());
            break;
         }
      }

      var8.setLore(var9);
      var1.setItemMeta(var8);
      return var1;
   }

   private void openGUI(Player var1, ItemStack var2, ItemStack var3) {
      GUI var4 = new GUI(this.plugin.getGUIManager().getGUIByType(GUIType.ENCHANT_RUNE));
      ((GUIItem)var4.getItems().get(ContentType.TARGET)).setItem(var2);
      ((GUIItem)var4.getItems().get(ContentType.SOURCE)).setItem(var3);
      ((GUIItem)var4.getItems().get(ContentType.RESULT)).setItem(this.getResult(new ItemStack(var2), new ItemStack(var3)));
      this.plugin.getGUIManager().setGUI(var1, var4);
      var1.openInventory(var4.build());
   }

   private ItemStack insertRune(ItemStack var1, ItemStack var2) {
      String var3 = this.getRuneId(var2);
      int var4 = this.getRuneLevel(var2);
      String var5 = this.getRuneEffect(var2);
      RuneManager.Rune var6 = this.getRuneById(var3);
      String var7 = var6.getName().replace("%rlevel%", "").replace("%level%", "").trim();
      List var8 = var1.getItemMeta().getLore();
      String var9 = this.getSettings().getFilledSlot() + var6.getName().replace("%level%", String.valueOf(var4)).replace("%rlevel%", Utils.IntegerToRomanNumeral(var4));
      String var10;
      Iterator var11;
      if (this.hasRune(var3, var1)) {
         var11 = var8.iterator();

         while(var11.hasNext()) {
            var10 = (String)var11.next();
            if (var10.contains(var7)) {
               int var12 = var8.indexOf(var10);
               var8.remove(var12);
               var8.add(var12, var9);
               break;
            }
         }

         var1 = this.removeRune(var1, var3);
      } else {
         var11 = var8.iterator();

         while(var11.hasNext()) {
            var10 = (String)var11.next();
            String var17 = ChatColor.stripColor(var10);
            String var13 = ChatColor.stripColor(this.getSettings().getEmptySlot());
            if (var17.equals(var13)) {
               int var14 = var8.indexOf(var10);
               var8.remove(var14);
               var8.add(var14, var9);
               break;
            }
         }
      }

      ItemMeta var15 = var1.getItemMeta();
      var15.setLore(var8);
      var1.setItemMeta(var15);
      NBTItem var16 = new NBTItem(var1);
      var16.setString("RUNE_" + this.getItemRunesAmount(var1), var3 + ":" + var4 + ":" + var5);
      return var16.getItem();
   }

   private ItemStack getResult(ItemStack var1, ItemStack var2) {
      ItemStack var3 = this.insertRune(var1, var2);
      ItemMeta var4 = var3.getItemMeta();
      var4.setDisplayName(Lang.Runes_Enchanting_Result.toMsg());
      var3.setItemMeta(var4);
      return var3;
   }

   public boolean isRune(ItemStack var1) {
      NBTItem var2 = new NBTItem(var1);
      return var2.hasKey("DIVINE_RUNE_ID") && var2.getString("DIVINE_RUNE_ID").split(":").length == 3;
   }

   @EventHandler
   public void onClickInventory(InventoryClickEvent var1) {
      if (var1.getWhoClicked() instanceof Player) {
         Player var2 = (Player)var1.getWhoClicked();
         ItemStack var3 = var1.getCursor();
         ItemStack var4 = var1.getCurrentItem();
         if (var3 != null && var4 != null) {
            if (var3.hasItemMeta() && var3.getItemMeta().hasLore()) {
               if (var4.hasItemMeta() && var4.getItemMeta().hasLore()) {
                  if (var1.getInventory().getType() == InventoryType.CRAFTING) {
                     if (var1.getSlotType() != org.bukkit.event.inventory.InventoryType.SlotType.CRAFTING) {
                        if (var1.getSlotType() != org.bukkit.event.inventory.InventoryType.SlotType.ARMOR && var1.getSlot() != 40) {
                           if (this.isRune(var3)) {
                              String var5 = this.getRuneId(var3);
                              RuneManager.Rune var6 = this.getRuneById(var5);
                              if (var6 == null) {
                                 var2.sendMessage(Lang.Prefix.toMsg() + Lang.Other_Internal.toMsg());
                              } else {
                                 boolean var7 = false;
                                 Iterator var9 = var6.getItemTypes().iterator();

                                 while(var9.hasNext()) {
                                    String var8 = (String)var9.next();
                                    if (ItemUtils.isValidItemType(var8, var4)) {
                                       var7 = true;
                                       break;
                                    }
                                 }

                                 if (!var7) {
                                    var2.sendMessage(Lang.Prefix.toMsg() + Lang.Runes_Enchanting_InvalidType.toMsg());
                                 } else {
                                    int var13 = this.getRuneLevel(var3);
                                    if (this.hasRune(var5, var4) && this.getItemRuneLvl(var4, var5) >= var13) {
                                       var2.sendMessage(Lang.Prefix.toMsg() + Lang.Runes_Enchanting_AlreadyHave.toMsg());
                                    } else if (var2.getInventory().firstEmpty() == -1) {
                                       var2.sendMessage(Lang.Prefix.toMsg() + Lang.Runes_Enchanting_FullInventory.toMsg());
                                    } else {
                                       Iterator var10 = var4.getItemMeta().getLore().iterator();

                                       while(var10.hasNext()) {
                                          String var14 = (String)var10.next();
                                          String var11 = ChatColor.stripColor(var14);
                                          String var12 = ChatColor.stripColor(this.getSettings().getEmptySlot());
                                          if (var11.equalsIgnoreCase(var12)) {
                                             var1.setCursor((ItemStack)null);
                                             var2.getInventory().addItem(new ItemStack[]{var3});
                                             var1.setCancelled(true);
                                             this.openGUI(var2, var4, var3);
                                             return;
                                          }
                                       }

                                       var2.sendMessage(Lang.Prefix.toMsg() + Lang.Runes_Enchanting_NoSlots.toMsg());
                                    }
                                 }
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
      }
   }

   @EventHandler
   public void onClickGUI(InventoryClickEvent var1) {
      Player var2 = (Player)var1.getWhoClicked();
      if (this.plugin.getGUIManager().valid(var2, GUIType.ENCHANT_RUNE)) {
         GUI var3 = this.plugin.getGUIManager().getPlayerGUI(var2, GUIType.ENCHANT_RUNE);
         if (var3 != null && var1.getInventory().getTitle().equals(var3.getTitle())) {
            var1.setCancelled(true);
            ItemStack var4 = var1.getCurrentItem();
            if (var4 != null && var4.hasItemMeta()) {
               GUIItem var5 = (GUIItem)var3.getItems().get(ContentType.ACCEPT);
               int var6 = var1.getRawSlot();
               if (!var4.isSimilar(var5.getItem()) && !ArrayUtils.contains(var5.getSlots(), var6)) {
                  GUIItem var20 = (GUIItem)var3.getItems().get(ContentType.DECLINE);
                  if (var4.isSimilar(var20.getItem()) || ArrayUtils.contains(var20.getSlots(), var6)) {
                     var2.sendMessage(Lang.Prefix.toMsg() + Lang.Runes_Enchanting_Cancel.toMsg());
                     var2.closeInventory();
                     this.plugin.getGUIManager().reset(var2);
                  }

               } else {
                  ItemStack var7 = new ItemStack(((GUIItem)var3.getItems().get(ContentType.TARGET)).getItem());
                  ItemStack var8 = new ItemStack(((GUIItem)var3.getItems().get(ContentType.SOURCE)).getItem());
                  if (!var2.getInventory().contains(var7)) {
                     var2.sendMessage(Lang.Prefix.toMsg() + Lang.Runes_Enchanting_NoItem.toMsg());
                  } else {
                     int var9 = (new Random()).nextInt(100);
                     NBTItem var10 = new NBTItem(var8);
                     int var11 = var10.getInteger("DIVINE_CHANCE");
                     RuneManager.RuneSettings var12 = this.getSettings();
                     if (var11 >= var9) {
                        var2.getInventory().removeItem(new ItemStack[]{var7});
                        ItemStack var21 = this.insertRune(var7, var8);
                        var2.getInventory().addItem(new ItemStack[]{var21});
                        var2.getInventory().removeItem(new ItemStack[]{var8});
                        var8.setAmount(var8.getAmount() - 1);
                        var2.getInventory().addItem(new ItemStack[]{var8});
                        var2.sendMessage(Lang.Prefix.toMsg() + Lang.Runes_Enchanting_Success.toMsg());
                        var2.closeInventory();
                        if (var12.useSound()) {
                           var2.playSound(var2.getLocation(), var12.getSuccessSound(), 0.5F, 0.5F);
                        }

                        if (var12.useEffect()) {
                           Utils.playEffect(var12.getSuccessEffect(), 0.30000001192092896D, 0.0D, 0.30000001192092896D, 0.30000001192092896D, 15, var2.getLocation().add(0.0D, 0.5D, 0.0D));
                        }

                        var2.updateInventory();
                        this.plugin.getGUIManager().reset(var2);
                     } else {
                        DestroyType var13 = var12.getDestroyType();
                        switch($SWITCH_TABLE$su$nightexpress$divineitems$types$DestroyType()[var13.ordinal()]) {
                        case 1:
                           var2.getInventory().removeItem(new ItemStack[]{var7});
                           var2.sendMessage(Lang.Prefix.toMsg() + Lang.Runes_Enchanting_Failure_Item.toMsg());
                           break;
                        case 2:
                           var2.getInventory().removeItem(new ItemStack[]{var8});
                           var8.setAmount(var8.getAmount() - 1);
                           var2.getInventory().addItem(new ItemStack[]{var8});
                           var2.sendMessage(Lang.Prefix.toMsg() + Lang.Runes_Enchanting_Failure_Source.toMsg());
                           break;
                        case 3:
                           var2.getInventory().removeItem(new ItemStack[]{var7});
                           var2.getInventory().removeItem(new ItemStack[]{var8});
                           var8.setAmount(var8.getAmount() - 1);
                           var2.getInventory().addItem(new ItemStack[]{var8});
                           ItemMeta var14 = var7.getItemMeta();
                           List var15 = var14.getLore();
                           ArrayList var16 = new ArrayList();
                           Iterator var18 = var15.iterator();

                           while(var18.hasNext()) {
                              String var17 = (String)var18.next();
                              if (var17.startsWith(var12.getFilledSlot())) {
                                 var16.add(var12.getEmptySlot());
                              } else {
                                 var16.add(var17);
                              }
                           }

                           var14.setLore(var16);
                           var7.setItemMeta(var14);
                           NBTItem var22 = new NBTItem(var7);
                           Iterator var19 = var22.getKeys().iterator();

                           while(var19.hasNext()) {
                              String var23 = (String)var19.next();
                              if (var23.startsWith("RUNE_")) {
                                 var22.removeKey(var23);
                              }
                           }

                           var2.getInventory().addItem(new ItemStack[]{var22.getItem()});
                           var2.sendMessage(Lang.Prefix.toMsg() + Lang.Runes_Enchanting_Failure_Both.toMsg());
                           break;
                        case 4:
                           var2.getInventory().removeItem(new ItemStack[]{var7});
                           var2.getInventory().removeItem(new ItemStack[]{var8});
                           var8.setAmount(var8.getAmount() - 1);
                           var2.getInventory().addItem(new ItemStack[]{var8});
                           var2.sendMessage(Lang.Prefix.toMsg() + Lang.Runes_Enchanting_Failure_Both.toMsg());
                        }

                        var2.closeInventory();
                        if (var12.useSound()) {
                           var2.playSound(var2.getLocation(), var12.getDestroySound(), 0.5F, 0.5F);
                        }

                        if (var12.useEffect()) {
                           Utils.playEffect(var12.getDestroyEffect(), 0.30000001192092896D, 0.0D, 0.30000001192092896D, 0.30000001192092896D, 15, var2.getLocation().add(0.0D, 0.5D, 0.0D));
                        }

                     }
                  }
               }
            }
         }
      }
   }

   // $FF: synthetic method
   static int[] $SWITCH_TABLE$su$nightexpress$divineitems$types$DestroyType() {
      int[] var10000 = $SWITCH_TABLE$su$nightexpress$divineitems$types$DestroyType;
      if (var10000 != null) {
         return var10000;
      } else {
         int[] var0 = new int[DestroyType.values().length];

         try {
            var0[DestroyType.BOTH.ordinal()] = 4;
         } catch (NoSuchFieldError var4) {
         }

         try {
            var0[DestroyType.CLEAR.ordinal()] = 3;
         } catch (NoSuchFieldError var3) {
         }

         try {
            var0[DestroyType.ITEM.ordinal()] = 1;
         } catch (NoSuchFieldError var2) {
         }

         try {
            var0[DestroyType.SOURCE.ordinal()] = 2;
         } catch (NoSuchFieldError var1) {
         }

         $SWITCH_TABLE$su$nightexpress$divineitems$types$DestroyType = var0;
         return var0;
      }
   }

   public class Rune {
      private boolean enabled;
      private String id;
      private String material;
      private String name;
      private List<String> desc;
      private String effect;
      private int min_lvl;
      private int max_lvl;
      private List<String> item_types;

      public Rune(boolean var2, String var3, String var4, String var5, List<String> var6, String var7, int var8, int var9, List<String> var10) {
         this.setEnabled(var2);
         this.setId(var3);
         this.setMaterial(var4);
         this.setName(var5);
         this.setDesc(var6);
         this.setEffect(var7);
         this.setMinLevel(var8);
         this.setMaxLevel(var9);
         this.setItemTypes(var10);
      }

      public boolean isEnabled() {
         return this.enabled;
      }

      public void setEnabled(boolean var1) {
         this.enabled = var1;
      }

      public String getId() {
         return this.id;
      }

      public void setId(String var1) {
         this.id = var1;
      }

      public String getMaterial() {
         return this.material;
      }

      public void setMaterial(String var1) {
         this.material = var1;
      }

      public String getName() {
         return this.name;
      }

      public void setName(String var1) {
         this.name = var1;
      }

      public List<String> getDesc() {
         return this.desc;
      }

      public void setDesc(List<String> var1) {
         this.desc = var1;
      }

      public String getEffect() {
         return this.effect;
      }

      public void setEffect(String var1) {
         this.effect = var1;
      }

      public int getMinLevel() {
         return this.min_lvl;
      }

      public void setMinLevel(int var1) {
         this.min_lvl = var1;
      }

      public int getMaxLevel() {
         return this.max_lvl;
      }

      public void setMaxLevel(int var1) {
         this.max_lvl = var1;
      }

      public List<String> getItemTypes() {
         return this.item_types;
      }

      public void setItemTypes(List<String> var1) {
         this.item_types = var1;
      }

      public ItemStack create(int var1) {
         if (!this.isEnabled()) {
            return null;
         } else {
            if (var1 == -1) {
               var1 = Utils.randInt(this.getMinLevel(), this.getMaxLevel());
            } else if (var1 > this.getMaxLevel()) {
               var1 = this.getMaxLevel();
            } else if (var1 < 1) {
               var1 = this.getMinLevel();
            }

            String[] var2 = this.getMaterial().split(":");
            ItemStack var3 = Utils.buildItem(var2, this.id);
            ItemMeta var4 = var3.getItemMeta();
            String var5 = this.getName().replace("%level%", String.valueOf(var1)).replace("%rlevel%", Utils.IntegerToRomanNumeral(var1));
            String var6 = RuneManager.this.getSettings().getDisplay().replace("%s", var5);
            int var7 = Utils.randInt(RuneManager.this.getSettings().getMinChance(), RuneManager.this.getSettings().getMaxChance());
            int var8 = 100 - var7;
            String var9 = "";
            String var10 = RuneManager.this.plugin.getCM().getCFG().getStrClassColor();
            String var11 = RuneManager.this.plugin.getCM().getCFG().getStrClassSeparator();

            String var14;
            for(Iterator var13 = this.getItemTypes().iterator(); var13.hasNext(); var9 = var9 + var10 + var14 + var11) {
               String var12 = (String)var13.next();
               var14 = var12.replace("*", "");
               if (Lang.hasPath("ItemTypes." + var14)) {
                  var14 = Lang.getCustom("ItemTypes." + var14);
               }
            }

            if (var9.length() > 3) {
               var9 = var9.substring(0, var9.length() - 3);
            }

            List var18 = RuneManager.this.getSettings().getLore();
            ArrayList var19 = new ArrayList();
            Iterator var15 = var18.iterator();

            while(true) {
               while(var15.hasNext()) {
                  var14 = (String)var15.next();
                  if (var14.equals("%desc%")) {
                     Iterator var17 = this.getDesc().iterator();

                     while(var17.hasNext()) {
                        String var16 = (String)var17.next();
                        var19.add(ChatColor.translateAlternateColorCodes('&', var16.replace("%level%", String.valueOf(var1)).replace("%rlevel%", Utils.IntegerToRomanNumeral(var1))));
                     }
                  } else {
                     var19.add(ChatColor.translateAlternateColorCodes('&', var14.replace("%d%", String.valueOf(var8)).replace("%s%", String.valueOf(var7)).replace("%type%", var9).replace("%level%", String.valueOf(var1)).replace("%rlevel%", Utils.IntegerToRomanNumeral(var1))));
                  }
               }

               var4.setDisplayName(var6);
               var4.setLore(var19);
               var4.spigot().setUnbreakable(true);
               var4.addItemFlags(ItemFlag.values());
               var3.setItemMeta(var4);
               NBTItem var20 = new NBTItem(var3);
               var20.setString("DIVINE_RUNE_ID", this.getId().toLowerCase() + ":" + var1 + ":" + this.getEffect());
               var20.setInteger("DIVINE_CHANCE", var7);
               return var20.getItem();
            }
         }
      }
   }

   public class RuneSettings extends MainSettings {
      private boolean stack;

      public RuneSettings(String var2, List<String> var3, int var4, int var5, DestroyType var6, boolean var7, boolean var8, String var9, String var10, boolean var11, Sound var12, Sound var13, String var14, String var15, String var16) {
         super(var2, var3, var4, var5, var6, var8, var9, var10, var11, var12, var13, var14, var15, var16);
         this.setStackLevels(var7);
      }

      public boolean isStackLevels() {
         return this.stack;
      }

      public void setStackLevels(boolean var1) {
         this.stack = var1;
      }
   }
}
