package su.nightexpress.divineitems.modules.scrolls;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.Set;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.block.Action;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.scheduler.BukkitRunnable;
import su.nightexpress.divineitems.DivineItems;
import su.nightexpress.divineitems.DivineListener;
import su.nightexpress.divineitems.Module;
import su.nightexpress.divineitems.api.DivineItemsAPI;
import su.nightexpress.divineitems.api.ItemAPI;
import su.nightexpress.divineitems.cmds.list.ScrollsCommand;
import su.nightexpress.divineitems.config.Lang;
import su.nightexpress.divineitems.config.MyConfig;
import su.nightexpress.divineitems.nbt.NBTItem;
import su.nightexpress.divineitems.utils.ActionTitle;
import su.nightexpress.divineitems.utils.ErrorLog;
import su.nightexpress.divineitems.utils.Utils;

public class ScrollManager extends DivineListener<DivineItems> implements Module {
   private DivineItems plugin;
   private boolean e;
   private Random r;
   private MyConfig settingsCfg;
   private MyConfig scrollsCfg;
   private HashMap<String, ScrollManager.Scroll> scrolls;
   private HashMap<Player, Set<ScrollManager.ScrollCD>> scd;
   private HashMap<Player, ScrollManager.Cast> cast;
   private ScrollManager.ScrollSettings ss;
   private final String n = this.name().toLowerCase().replace(" ", "_");
   private final String label;
   private final String NBT_KEY_SCROLL;
   private final String NBT_KEY_USES;

   public ScrollManager(DivineItems var1) {
      super(var1);
      this.label = this.n.replace("_", "");
      this.NBT_KEY_SCROLL = "DIVINE_SCROLL_ID";
      this.NBT_KEY_USES = "DIVINE_SCROLL_USES";
      this.plugin = var1;
      this.e = this.plugin.getCM().getCFG().isModuleEnabled(this.name());
      this.r = new Random();
      this.scd = new HashMap();
      this.cast = new HashMap();
   }

   public void loadConfig() {
      this.scrolls = new HashMap();
      this.settingsCfg = new MyConfig(this.plugin, "/modules/" + this.n, "settings.yml");
      this.scrollsCfg = new MyConfig(this.plugin, "/modules/" + this.n, "scrolls.yml");
      this.setupSettings();
      this.setupScrolls();
   }

   public boolean isActive() {
      return this.e;
   }

   public boolean isDropable() {
      return true;
   }

   public boolean isResolvable() {
      return true;
   }

   public String name() {
      return "Scrolls";
   }

   public String version() {
      return "1.0";
   }

   public void enable() {
      if (this.isActive()) {
         this.plugin.getCommander().registerCmd(this.label, new ScrollsCommand(this.plugin));
         this.loadConfig();
         this.registerListeners();
      }

   }

   public void unload() {
      if (this.isActive()) {
         this.plugin.getCommander().unregisterCmd(this.label);
         Iterator var2 = this.cast.values().iterator();

         while(var2.hasNext()) {
            ScrollManager.Cast var1 = (ScrollManager.Cast)var2.next();
            var1.stap();
         }

         this.scd.clear();
         this.cast.clear();
         this.scd.clear();
         this.e = false;
         this.unregisterListeners();
      }

   }

   public void reload() {
      this.unload();
      this.enable();
   }

   private void setupSettings() {
      FileConfiguration var1 = this.settingsCfg.getConfig();
      String var2 = ChatColor.stripColor(var1.getString("Usage.Bar.Symbol"));
      String var3 = ChatColor.translateAlternateColorCodes('&', var1.getString("Usage.Bar.FirstColor"));
      String var4 = ChatColor.translateAlternateColorCodes('&', var1.getString("Usage.Bar.SecondColor"));
      boolean var5 = var1.getBoolean("Usage.Cancel.OnMove");
      boolean var6 = var1.getBoolean("Usage.Cancel.OnInteract");
      boolean var7 = var1.getBoolean("Usage.Cancel.OnDrop");
      boolean var8 = var1.getBoolean("Usage.Cancel.OnInventory");
      this.ss = new ScrollManager.ScrollSettings(var2, var3, var4, var5, var6, var7, var8);
   }

   private void setupScrolls() {
      FileConfiguration var1 = this.scrollsCfg.getConfig();
      Iterator var3 = var1.getConfigurationSection("Scrolls").getKeys(false).iterator();

      while(var3.hasNext()) {
         String var2 = (String)var3.next();
         String var4 = var2.toString();
         String var5 = "Scrolls." + var4 + ".";
         String[] var6 = var1.getString(var5 + "Material").split(":");
         short var7 = 0;
         Material var8 = Material.getMaterial(var6[0]);
         if (var8 == null) {
            var8 = Material.MAP;
            ErrorLog.sendError(this, var5 + "Material", "Invalid Material name!", true);
            var1.set(var5 + "Material", "MAP");
         }

         if (var6.length == 2) {
            var7 = (short)Integer.parseInt(var6[1]);
         }

         ItemStack var9 = new ItemStack(var8, 1, var7);
         String var10 = ChatColor.translateAlternateColorCodes('&', var1.getString(var5 + "Display"));
         List var11 = var1.getStringList(var5 + "Lore");
         ArrayList var12 = new ArrayList();
         Iterator var14 = var11.iterator();

         while(var14.hasNext()) {
            String var13 = (String)var14.next();
            var12.add(ChatColor.translateAlternateColorCodes('&', var13));
         }

         HashMap var22 = new HashMap();
         if (var1.contains(var5 + "Variables")) {
            Iterator var15 = var1.getConfigurationSection(var5 + "Variables").getKeys(false).iterator();

            while(var15.hasNext()) {
               String var23 = (String)var15.next();
               Object var16 = var1.get(var5 + "Variables." + var23);
               var22.put(var23, var16);
            }
         }

         HashMap var24 = new HashMap();
         if (var1.contains(var5 + "VariablesPerLvl")) {
            Iterator var27 = var1.getConfigurationSection(var5 + "VariablesPerLvl").getKeys(false).iterator();

            while(var27.hasNext()) {
               String var25 = (String)var27.next();
               Object var17 = var1.get(var5 + "VariablesPerLvl." + var25);
               var24.put(var25, var17);
            }
         }

         int var26 = var1.getInt(var5 + "MinLevel");
         int var28 = var1.getInt(var5 + "MaxLevel");
         List var29 = var1.getStringList(var5 + "Actions");
         int var18 = var1.getInt(var5 + "UseTime");
         int var19 = var1.getInt(var5 + "Cooldown");
         int var20 = var1.getInt(var5 + "Uses");
         ScrollManager.Scroll var21 = new ScrollManager.Scroll(var4.toLowerCase(), var9, var10, var12, var22, var24, var26, var28, var29, var18, var19, var20);
         this.scrolls.put(var4.toLowerCase(), var21);
      }

      this.scrollsCfg.save();
   }

   public boolean isScroll(ItemStack var1) {
      return (new NBTItem(var1)).hasKey("DIVINE_SCROLL_ID");
   }

   public String getScrollId(ItemStack var1) {
      return (new NBTItem(var1)).getString("DIVINE_SCROLL_ID").split(":")[0];
   }

   public int getScrollLvl(ItemStack var1) {
      return Integer.parseInt((new NBTItem(var1)).getString("DIVINE_SCROLL_ID").split(":")[1]);
   }

   public ItemStack takeUse(ItemStack var1) {
      NBTItem var2 = new NBTItem(var1);
      if (!var2.hasKey("DIVINE_SCROLL_USES")) {
         return var1;
      } else {
         int var3 = var2.getInteger("DIVINE_SCROLL_USES") - 1;
         if (var3 <= 0) {
            return new ItemStack(Material.AIR);
         } else {
            String[] var4 = var2.getString("DIVINE_SCROLL_ID").split(":");
            String var5 = var4[0];
            int var6 = Integer.parseInt(var4[1]);
            ScrollManager.Scroll var7 = new ScrollManager.Scroll(this.getScrollById(var5));
            ArrayList var8 = new ArrayList();
            var2.setInteger("DIVINE_SCROLL_USES", var3);
            var1 = var2.getItem();
            Iterator var10 = var7.getLore().iterator();

            while(var10.hasNext()) {
               String var9 = (String)var10.next();

               String var11;
               for(Iterator var12 = var7.getVariables().keySet().iterator(); var12.hasNext(); var9 = this.replaceVars(var9, var11, var7, var6)) {
                  var11 = (String)var12.next();
               }

               var8.add(ChatColor.translateAlternateColorCodes('&', var9.replace("%lvl%", String.valueOf(var6)).replace("%rlvl%", Utils.IntegerToRomanNumeral(var6)).replace("%uses%", String.valueOf(var3))));
            }

            ItemMeta var13 = var1.getItemMeta();
            var13.setLore(var8);
            var1.setItemMeta(var13);
            return var1;
         }
      }
   }

   public void setCD(Player var1, String var2) {
      var2 = var2.toLowerCase();
      if (this.scrolls.containsKey(var2) && !this.isOnCooldown(var1, var2)) {
         ScrollManager.Scroll var3 = (ScrollManager.Scroll)this.scrolls.get(var2);
         ScrollManager.ScrollCD var4 = new ScrollManager.ScrollCD(var2, System.currentTimeMillis() + (long)var3.getCD() * 1000L);
         Object var5 = new HashSet();
         if (this.scd.containsKey(var1)) {
            var5 = (Set)this.scd.get(var1);
         }

         ((Set)var5).add(var4);
         this.scd.put(var1, var5);
      }
   }

   public boolean isOnCooldown(Player var1, String var2) {
      if (!this.scd.containsKey(var1)) {
         return false;
      } else {
         Set var3 = (Set)this.scd.get(var1);
         Iterator var5 = var3.iterator();

         while(var5.hasNext()) {
            ScrollManager.ScrollCD var4 = (ScrollManager.ScrollCD)var5.next();
            if (var4.getScrollId().equalsIgnoreCase(var2)) {
               if (var4.getTimeEnd() > System.currentTimeMillis()) {
                  return true;
               }

               var3.remove(var4);
               break;
            }
         }

         if (var3.isEmpty()) {
            this.scd.remove(var1);
         }

         return false;
      }
   }

   public int getScrollCD(Player var1, String var2) {
      int var3 = 0;
      if (!this.isOnCooldown(var1, var2)) {
         return var3;
      } else {
         Set var4 = (Set)this.scd.get(var1);
         Iterator var6 = var4.iterator();

         while(var6.hasNext()) {
            ScrollManager.ScrollCD var5 = (ScrollManager.ScrollCD)var6.next();
            if (var5.getScrollId().equalsIgnoreCase(var2)) {
               var3 = (int)((var5.getTimeEnd() - System.currentTimeMillis()) / 1000L);
            }
         }

         return var3;
      }
   }

   public ScrollManager.Scroll getScrollById(String var1) {
      return var1.equalsIgnoreCase("random") ? (ScrollManager.Scroll)(new ArrayList(this.getScrolls())).get(this.r.nextInt(this.getScrolls().size())) : (ScrollManager.Scroll)this.scrolls.get(var1.toLowerCase());
   }

   public Collection<ScrollManager.Scroll> getScrolls() {
      return this.scrolls.values();
   }

   public List<String> getScrollNames() {
      ArrayList var1 = new ArrayList();
      Iterator var3 = this.getScrolls().iterator();

      while(var3.hasNext()) {
         ScrollManager.Scroll var2 = (ScrollManager.Scroll)var3.next();
         var1.add(var2.getId());
      }

      return var1;
   }

   public ScrollManager.ScrollSettings getSettings() {
      return this.ss;
   }

   private String replaceVars(String var1, String var2, ScrollManager.Scroll var3, int var4) {
      Object var5 = var3.getVariables().get(var2);
      String var6 = var5.toString();
      if (var3.getVariablesLvl().containsKey(var2)) {
         if (!(var5 instanceof Double) && !(var5 instanceof Integer)) {
            var6 = var3.getVariablesLvl().get(var2).toString();
         } else {
            double var7 = Double.parseDouble(var5.toString());
            var7 += (double)(var4 - 1) * Double.parseDouble(var3.getVariablesLvl().get(var2).toString());
            var6 = String.valueOf(Utils.round3(var7));
         }
      }

      return var1.replace("%var_" + var2 + "%", var6);
   }

   @EventHandler
   public void onUse(PlayerInteractEvent var1) {
      if (var1.getAction().name().contains("RIGHT") || var1.getAction() == Action.PHYSICAL) {
         if (var1.getItem() != null && var1.getItem().getType() != Material.AIR) {
            ItemStack var2 = new ItemStack(var1.getItem());
            NBTItem var3 = new NBTItem(var2);
            if (var3.hasKey("DIVINE_SCROLL_ID")) {
               Player var4 = var1.getPlayer();
               if (ItemAPI.canUse(var2, var4)) {
                  var1.setCancelled(true);
                  if (!this.cast.containsKey(var4)) {
                     String[] var5 = var3.getString("DIVINE_SCROLL_ID").split(":");
                     String var6 = var5[0];
                     int var7 = 1;
                     if (var5.length == 2) {
                        var7 = Integer.parseInt(var5[1]);
                     }

                     if (this.isOnCooldown(var4, var6)) {
                        var4.sendMessage(Lang.Prefix.toMsg() + Lang.Scrolls_Cooldown.toMsg().replace("%s", String.valueOf(this.getScrollCD(var4, var6))));
                     } else if (this.getScrollById(var6) == null) {
                        var4.sendMessage(Lang.Prefix.toMsg() + Lang.Other_Internal.toMsg());
                     } else {
                        ScrollManager.Scroll var8 = new ScrollManager.Scroll(this.getScrollById(var6));
                        ArrayList var9 = new ArrayList(var8.getActions());
                        ArrayList var10 = new ArrayList();
                        Iterator var12 = var9.iterator();

                        while(var12.hasNext()) {
                           String var11 = (String)var12.next();

                           String var13;
                           for(Iterator var14 = var8.getVariables().keySet().iterator(); var14.hasNext(); var11 = this.replaceVars(var11, var13, var8, var7)) {
                              var13 = (String)var14.next();
                           }

                           var10.add(var11);
                        }

                        var8.setActions(var10);
                        if (var1.getHand() == EquipmentSlot.OFF_HAND) {
                           var2.setAmount(var2.getAmount() - 1);
                           var4.getInventory().setItemInOffHand(var2);
                        } else {
                           var2.setAmount(1);
                           var4.getInventory().removeItem(new ItemStack[]{var2});
                        }

                        var2.setAmount(1);
                        if (var8.getUseTime() > 0) {
                           this.goCast(var4, var8, var2);
                        } else {
                           DivineItemsAPI.executeActions(var4, var10, var2);
                           this.setCD(var4, var6);
                           var4.getInventory().addItem(new ItemStack[]{this.takeUse(var2)});
                        }

                     }
                  }
               }
            }
         }
      }
   }

   public void goCast(Player var1, ScrollManager.Scroll var2, ItemStack var3) {
      double var4 = (double)(20 / var2.getUseTime());
      double var6 = 20.0D / var4;
      ScrollManager.Cast var8 = new ScrollManager.Cast(var1, var2, var3, (int)var6);
      var8.runTaskTimer(DivineItems.instance, 0L, (long)((int)var6));
      this.cast.put(var1, var8);
   }

   @EventHandler(
      ignoreCancelled = true
   )
   public void onTp(PlayerTeleportEvent var1) {
      if (this.getSettings().isCancelOnMove()) {
         Player var2 = var1.getPlayer();
         if (this.cast.containsKey(var2)) {
            ScrollManager.Cast var3 = (ScrollManager.Cast)this.cast.get(var2);
            var3.stap();
         }

      }
   }

   @EventHandler(
      ignoreCancelled = true
   )
   public void onDrop(PlayerDropItemEvent var1) {
      if (this.getSettings().isCancelOnDrop()) {
         Player var2 = var1.getPlayer();
         if (this.cast.containsKey(var2)) {
            ScrollManager.Cast var3 = (ScrollManager.Cast)this.cast.get(var2);
            var3.stap();
         }

      }
   }

   @EventHandler(
      ignoreCancelled = true
   )
   public void onMove(InventoryOpenEvent var1) {
      if (this.getSettings().isCancelOnInv()) {
         Player var2 = (Player)var1.getPlayer();
         if (this.cast.containsKey(var2)) {
            ScrollManager.Cast var3 = (ScrollManager.Cast)this.cast.get(var2);
            var3.stap();
         }

      }
   }

   @EventHandler(
      ignoreCancelled = true
   )
   public void onInt(PlayerInteractEvent var1) {
      if (this.getSettings().isCancelOnInteract()) {
         Player var2 = var1.getPlayer();
         if (this.cast.containsKey(var2)) {
            ScrollManager.Cast var3 = (ScrollManager.Cast)this.cast.get(var2);
            var3.stap();
         }

      }
   }

   public class Cast extends BukkitRunnable {
      DivineItems plugin;
      Player p;
      ScrollManager.Scroll scroll;
      int i;
      int j;
      String bar;
      Location start;
      ItemStack item;

      public Cast(Player var2, ScrollManager.Scroll var3, ItemStack var4, int var5) {
         this.plugin = DivineItems.instance;
         this.i = 0;
         this.j = var5;
         this.p = var2;
         this.start = var2.getLocation();
         this.scroll = var3;
         this.item = var4;
         String var6 = ScrollManager.this.getSettings().getBarSymbol();
         StringBuffer var7 = new StringBuffer();

         for(int var8 = 0; var8 < 20; ++var8) {
            var7.insert(var8, var6);
         }

         this.bar = var7.toString();
      }

      public void run() {
         if (ScrollManager.this.getSettings().isCancelOnMove() && (this.start.getX() != this.p.getLocation().getX() || this.start.getY() != this.p.getLocation().getY() || this.start.getZ() != this.p.getLocation().getZ())) {
            this.stap();
         }

         if (this.i == 20) {
            this.finish();
         }

         this.paintBar();
         ++this.i;
      }

      private void paintBar() {
         String var1 = this.bar;
         StringBuffer var2 = new StringBuffer(var1);
         String var3 = ScrollManager.this.getSettings().getBar1Color();
         String var4 = ScrollManager.this.getSettings().getBar2Color();
         var2.setLength(var2.length());
         var2.insert(0, var3);
         if (this.i < 20) {
            var2.insert(this.i + var4.length() + 1, var4);
         }

         var1 = var2.toString();
         ActionTitle.sendTitles(this.p, var1, Lang.Scrolls_Using.toMsg(), 0, this.j, 5);
      }

      public void stap() {
         this.cancel();
         ScrollManager.this.cast.remove(this.p);
         this.item.setAmount(1);
         this.p.getInventory().addItem(new ItemStack[]{this.item});
         (new BukkitRunnable() {
            public void run() {
               ActionTitle.sendTitles(Cast.this.p, Lang.Scrolls_Cancelled.toMsg(), "§r", 5, 30, 5);
            }
         }).runTaskLater(this.plugin, 1L);
      }

      public void finish() {
         ScrollManager.this.setCD(this.p, this.scroll.getId());
         ScrollManager.this.cast.remove(this.p);
         DivineItemsAPI.executeActions(this.p, this.scroll.getActions(), this.item);
         this.p.getInventory().addItem(new ItemStack[]{ScrollManager.this.takeUse(this.item)});
         this.cancel();
      }
   }

   public class Scroll {
      private String id;
      private ItemStack item;
      private String display;
      private List<String> lore;
      private HashMap<String, Object> vars;
      private HashMap<String, Object> vars_lvl;
      private int min_lvl;
      private int max_lvl;
      private List<String> actions;
      private int use;
      private int cd;
      private int uses;

      public Scroll(String var2, ItemStack var3, String var4, List<String> var5, HashMap<String, Object> var6, HashMap<String, Object> var7, int var8, int var9, List<String> var10, int var11, int var12, int var13) {
         this.setId(var2);
         this.setItem(var3);
         this.setDisplay(var4);
         this.setLore(var5);
         this.setVariables(var6);
         this.setVariablesLvl(var7);
         this.setMinLevel(var8);
         this.setMaxLevel(var9);
         this.setActions(var10);
         this.setUseTime(var11);
         this.setCD(var12);
         this.setUses(var13);
      }

      public Scroll(ScrollManager.Scroll var2) {
         this.setId(var2.getId());
         this.setItem(var2.getItem());
         this.setDisplay(var2.getDisplay());
         this.setLore(var2.getLore());
         this.setVariables(var2.getVariables());
         this.setVariablesLvl(var2.getVariablesLvl());
         this.setMinLevel(var2.getMinLevel());
         this.setMaxLevel(var2.getMaxLevel());
         this.setActions(var2.getActions());
         this.setUseTime(var2.getUseTime());
         this.setCD(var2.getCD());
         this.setUses(var2.getUses());
      }

      public String getId() {
         return this.id;
      }

      public void setId(String var1) {
         this.id = var1;
      }

      public ItemStack getItem() {
         return new ItemStack(this.item);
      }

      public void setItem(ItemStack var1) {
         this.item = new ItemStack(var1);
      }

      public String getDisplay() {
         return this.display;
      }

      public void setDisplay(String var1) {
         this.display = var1;
      }

      public List<String> getLore() {
         return this.lore;
      }

      public void setLore(List<String> var1) {
         this.lore = var1;
      }

      public HashMap<String, Object> getVariables() {
         return this.vars;
      }

      public void setVariables(HashMap<String, Object> var1) {
         this.vars = var1;
      }

      public HashMap<String, Object> getVariablesLvl() {
         return this.vars_lvl;
      }

      public void setVariablesLvl(HashMap<String, Object> var1) {
         this.vars_lvl = var1;
      }

      public int getMinLevel() {
         return this.min_lvl;
      }

      public void setMinLevel(int var1) {
         this.min_lvl = var1;
      }

      public int getMaxLevel() {
         return this.max_lvl;
      }

      public void setMaxLevel(int var1) {
         this.max_lvl = var1;
      }

      public List<String> getActions() {
         return this.actions;
      }

      public void setActions(List<String> var1) {
         this.actions = var1;
      }

      public int getUseTime() {
         return this.use;
      }

      public void setUseTime(int var1) {
         this.use = var1;
      }

      public int getCD() {
         return this.cd;
      }

      public void setCD(int var1) {
         this.cd = var1;
      }

      public int getUses() {
         return this.uses;
      }

      public void setUses(int var1) {
         this.uses = var1;
      }

      public ItemStack create(int var1) {
         if (var1 == -1) {
            var1 = Utils.randInt(this.getMinLevel(), this.getMaxLevel());
         } else if (var1 > this.getMaxLevel()) {
            var1 = this.getMaxLevel();
         } else if (var1 < 1) {
            var1 = this.getMinLevel();
         }

         ItemStack var2 = new ItemStack(this.getItem());
         ItemMeta var3 = var2.getItemMeta();
         String var4 = this.getDisplay().replace("%lvl%", String.valueOf(var1)).replace("%rlvl%", Utils.IntegerToRomanNumeral(var1));
         var3.setDisplayName(var4);
         ArrayList var5 = new ArrayList(this.getLore());
         ArrayList var6 = new ArrayList();
         Iterator var8 = var5.iterator();

         while(var8.hasNext()) {
            String var7 = (String)var8.next();

            String var9;
            for(Iterator var10 = this.getVariables().keySet().iterator(); var10.hasNext(); var7 = ScrollManager.this.replaceVars(var7, var9, this, var1)) {
               var9 = (String)var10.next();
            }

            var6.add(ChatColor.translateAlternateColorCodes('&', var7.replace("%lvl%", String.valueOf(var1)).replace("%rlvl%", Utils.IntegerToRomanNumeral(var1)).replace("%uses%", String.valueOf(this.getUses()))));
         }

         var3.setLore(var6);
         var3.spigot().setUnbreakable(true);
         var3.addItemFlags(ItemFlag.values());
         var2.setItemMeta(var3);
         NBTItem var11 = new NBTItem(var2);
         var11.setString("DIVINE_SCROLL_ID", this.id + ":" + var1);
         var11.setInteger("DIVINE_SCROLL_USES", this.getUses());
         return var11.getItem();
      }
   }

   public class ScrollCD {
      private String id;
      private long end;

      public ScrollCD(String var2, long var3) {
         this.setScrollId(var2);
         this.setTimeEnd(var3);
      }

      public String getScrollId() {
         return this.id;
      }

      public void setScrollId(String var1) {
         this.id = var1;
      }

      public long getTimeEnd() {
         return this.end;
      }

      public void setTimeEnd(long var1) {
         this.end = var1;
      }
   }

   public class ScrollSettings {
      private String bar_symbol;
      private String bar_c1;
      private String bar_c2;
      private boolean cancel_move;
      private boolean cancel_inter;
      private boolean cancel_drop;
      private boolean cancel_inv;

      public ScrollSettings(String var2, String var3, String var4, boolean var5, boolean var6, boolean var7, boolean var8) {
         this.setBarSymbol(var2);
         this.setBar1Color(var3);
         this.setBar2Color(var4);
         this.setCancelOnMove(var5);
         this.setCancelOnInteract(var6);
         this.setCancelOnDrop(var7);
         this.setCancelOnInv(var8);
      }

      public String getBarSymbol() {
         return this.bar_symbol;
      }

      public void setBarSymbol(String var1) {
         this.bar_symbol = var1;
      }

      public String getBar1Color() {
         return this.bar_c1;
      }

      public void setBar1Color(String var1) {
         this.bar_c1 = var1;
      }

      public String getBar2Color() {
         return this.bar_c2;
      }

      public void setBar2Color(String var1) {
         this.bar_c2 = var1;
      }

      public boolean isCancelOnMove() {
         return this.cancel_move;
      }

      public void setCancelOnMove(boolean var1) {
         this.cancel_move = var1;
      }

      public boolean isCancelOnInteract() {
         return this.cancel_inter;
      }

      public void setCancelOnInteract(boolean var1) {
         this.cancel_inter = var1;
      }

      public boolean isCancelOnDrop() {
         return this.cancel_drop;
      }

      public void setCancelOnDrop(boolean var1) {
         this.cancel_drop = var1;
      }

      public boolean isCancelOnInv() {
         return this.cancel_inv;
      }

      public void setCancelOnInv(boolean var1) {
         this.cancel_inv = var1;
      }
   }
}
