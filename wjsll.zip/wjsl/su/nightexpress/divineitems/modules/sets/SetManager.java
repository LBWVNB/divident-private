package su.nightexpress.divineitems.modules.sets;

import com.google.common.collect.Lists;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.TreeMap;
import net.md_5.bungee.api.ChatColor;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Item;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.entity.ItemSpawnEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.inventory.InventoryType.SlotType;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import su.nightexpress.divineitems.DivineItems;
import su.nightexpress.divineitems.DivineListener;
import su.nightexpress.divineitems.Module;
import su.nightexpress.divineitems.api.EntityAPI;
import su.nightexpress.divineitems.attributes.ItemStat;
import su.nightexpress.divineitems.cmds.list.SetsCommand;
import su.nightexpress.divineitems.config.MyConfig;
import su.nightexpress.divineitems.utils.ErrorLog;

public class SetManager extends DivineListener<DivineItems> implements Module {
   private DivineItems plugin;
   private MyConfig settingsCfg;
   private MyConfig setsCfg;
   private boolean e;
   private int taskId;
   private SetManager.SetSettings ss;
   private HashMap<String, SetManager.ItemSet> sets;
   private final String n = this.name().toLowerCase().replace(" ", "_");
   private final String label;

   public SetManager(DivineItems var1) {
      super(var1);
      this.label = this.n.replace("_", "");
      this.plugin = var1;
      this.e = this.plugin.getCM().getCFG().isModuleEnabled(this.name());
   }

   public void loadConfig() {
      this.sets = new HashMap();
      this.settingsCfg = new MyConfig(this.plugin, "/modules/" + this.n, "settings.yml");
      this.setsCfg = new MyConfig(this.plugin, "/modules/" + this.n, "sets.yml");
      this.setup();
   }

   public boolean isActive() {
      return this.e;
   }

   public boolean isDropable() {
      return true;
   }

   public boolean isResolvable() {
      return false;
   }

   public String name() {
      return "Sets";
   }

   public String version() {
      return "0.1";
   }

   public void enable() {
      if (this.isActive()) {
         this.plugin.getCommander().registerCmd(this.label, new SetsCommand(this.plugin));
         this.loadConfig();
         this.registerListeners();
         this.startTask();
      }

   }

   public void unload() {
      if (this.isActive()) {
         this.plugin.getCommander().unregisterCmd(this.label);
         this.stopTask();
         this.e = false;
         this.unregisterListeners();
      }

   }

   public void reload() {
      this.unload();
      this.enable();
   }

   public void setup() {
      this.setupSettings();
      this.setupSets();
   }

   private void setupSettings() {
      FileConfiguration var1 = this.settingsCfg.getConfig();
      boolean var2 = var1.getBoolean("DynamicLore");
      String var3 = ChatColor.translateAlternateColorCodes('&', var1.getString("ItemHave"));
      String var4 = ChatColor.translateAlternateColorCodes('&', var1.getString("ItemMiss"));
      String var5 = ChatColor.translateAlternateColorCodes('&', var1.getString("LoreHeader"));
      String var6 = ChatColor.translateAlternateColorCodes('&', var1.getString("LoreFooter"));
      ArrayList var7 = new ArrayList();
      Iterator var9 = var1.getStringList("Lore").iterator();

      while(var9.hasNext()) {
         String var8 = (String)var9.next();
         var7.add(ChatColor.translateAlternateColorCodes('&', var8));
      }

      this.ss = new SetManager.SetSettings(var2, var3, var4, var5, var6, var7);
   }

   private void setupSets() {
      FileConfiguration var1 = this.setsCfg.getConfig();
      if (var1.contains("ItemSets")) {
         Iterator var3 = var1.getConfigurationSection("ItemSets").getKeys(false).iterator();

         while(var3.hasNext()) {
            String var2 = (String)var3.next();
            String var4 = var2.toString().toLowerCase();
            String var5 = "ItemSets." + var2 + ".";
            String var6 = ChatColor.stripColor(ChatColor.translateAlternateColorCodes('&', var1.getString(var5 + "Name")));
            String var7 = ChatColor.translateAlternateColorCodes('&', var1.getString(var5 + "Prefix"));
            String var8 = ChatColor.translateAlternateColorCodes('&', var1.getString(var5 + "Suffix"));
            String var9 = ChatColor.translateAlternateColorCodes('&', var1.getString(var5 + "Color.Have"));
            String var10 = ChatColor.translateAlternateColorCodes('&', var1.getString(var5 + "Color.Miss"));
            HashMap var11 = new HashMap();
            Iterator var13 = var1.getConfigurationSection(var5 + "Parts").getKeys(false).iterator();

            String var16;
            String var18;
            while(var13.hasNext()) {
               String var12 = (String)var13.next();
               String var14 = var12.toString().toUpperCase();

               SetManager.PartType var15;
               try {
                  var15 = SetManager.PartType.valueOf(var14);
               } catch (IllegalArgumentException var28) {
                  ErrorLog.sendError(this, var5 + "Parts." + var14, "Invalid Part Type!", false);
                  continue;
               }

               var16 = var5 + "Parts." + var14 + ".";
               boolean var17 = var1.getBoolean(var16 + "Enabled");
               var18 = var1.getString(var16 + "Material");
               String var19 = ChatColor.translateAlternateColorCodes('&', var1.getString(var16 + "Name"));
               SetManager.SetPart var20 = new SetManager.SetPart(var17, var18, var19);
               var11.put(var15, var20);
            }

            TreeMap var31 = new TreeMap();
            Iterator var34 = var1.getConfigurationSection(var5 + "Effects.Parts").getKeys(false).iterator();

            while(var34.hasNext()) {
               String var32 = (String)var34.next();
               int var35 = Integer.parseInt(var32.toString());
               var16 = var5 + "Effects.Parts." + var35 + ".";
               ArrayList var36 = new ArrayList();
               Iterator var38 = var1.getStringList(var16 + "Lore").iterator();

               while(var38.hasNext()) {
                  var18 = (String)var38.next();
                  var36.add(ChatColor.translateAlternateColorCodes('&', var18));
               }

               List var37 = var1.getStringList(var16 + "Effects");
               ArrayList var39 = new ArrayList();
               Iterator var21 = var1.getConfigurationSection(var16 + "Attributes").getKeys(false).iterator();

               while(var21.hasNext()) {
                  String var40 = (String)var21.next();
                  String var22 = var40.toString();
                  String var23 = var16 + "Attributes." + var22 + ".";

                  ItemStat var24;
                  try {
                     var24 = ItemStat.valueOf(var22.toUpperCase());
                  } catch (IllegalArgumentException var30) {
                     ErrorLog.sendError(this, var23, "Invalid Attribute Type!", false);
                     continue;
                  }

                  SetManager.EffectAction var25;
                  try {
                     var25 = SetManager.EffectAction.valueOf(var1.getString(var23 + "Action"));
                  } catch (IllegalArgumentException var29) {
                     ErrorLog.sendError(this, var23, "Invalid Action Type!", false);
                     continue;
                  }

                  String var26 = var1.getString(var23 + "Value");
                  SetManager.EffectAttribute var27 = new SetManager.EffectAttribute(var24, var25, var26);
                  var39.add(var27);
               }

               SetManager.SetPartEffect var41 = new SetManager.SetPartEffect(var35, var36, var37, var39);
               var31.put(var35, var41);
            }

            SetManager.ItemSet var33 = new SetManager.ItemSet(var4, var6, var7, var8, var9, var10, var11, var31);
            this.sets.put(var4, var33);
         }

      }
   }

   private void startTask() {
      this.taskId = this.plugin.getServer().getScheduler().scheduleSyncRepeatingTask(this.plugin, new Runnable() {
         public void run() {
            Iterator var2 = SetManager.this.plugin.getServer().getOnlinePlayers().iterator();

            while(var2.hasNext()) {
               Player var1 = (Player)var2.next();
               SetManager.this.applySetPotions(var1);
            }

         }
      }, 10L, 80L);
   }

   private void stopTask() {
      this.plugin.getServer().getScheduler().cancelTask(this.taskId);
   }

   public void applySetPotions(Player var1) {
      Iterator var3 = this.getSets().iterator();

      label37:
      while(var3.hasNext()) {
         SetManager.ItemSet var2 = (SetManager.ItemSet)var3.next();
         Iterator var5 = var2.getPartsEffects().values().iterator();

         while(true) {
            SetManager.SetPartEffect var4;
            int var6;
            int var7;
            do {
               if (!var5.hasNext()) {
                  continue label37;
               }

               var4 = (SetManager.SetPartEffect)var5.next();
               var6 = var4.getPartsAmount();
               var7 = this.getPartsOf(var1, var2);
            } while(var7 < var6);

            Iterator var9 = var4.getEffects().iterator();

            while(var9.hasNext()) {
               String var8 = (String)var9.next();
               String[] var10 = var8.split(":");
               PotionEffectType var11 = PotionEffectType.getByName(var10[0].toUpperCase());
               if (var11 != null) {
                  if (var1.hasPotionEffect(var11)) {
                     var1.removePotionEffect(var11);
                  }

                  int var12 = Math.max(0, Integer.parseInt(var10[1]) - 1);
                  PotionEffect var13 = new PotionEffect(var11, 100, var12);
                  var1.addPotionEffect(var13);
               }
            }
         }
      }

   }

   public HashMap<ItemStat, Double> getSetAttributes(LivingEntity var1, SetManager.ItemSet var2, boolean var3) {
      HashMap var4 = new HashMap();
      Iterator var6 = var2.getPartsEffects().values().iterator();

      label55:
      while(true) {
         SetManager.SetPartEffect var5;
         int var7;
         int var8;
         do {
            do {
               if (!var6.hasNext()) {
                  return var4;
               }

               var5 = (SetManager.SetPartEffect)var6.next();
            } while(var5.getAttributes().isEmpty());

            var7 = var5.getPartsAmount();
            var8 = this.getPartsOf(var1, var2);
         } while(var8 < var7);

         Iterator var10 = var5.getAttributes().iterator();

         while(true) {
            SetManager.EffectAttribute var9;
            do {
               do {
                  if (!var10.hasNext()) {
                     continue label55;
                  }

                  var9 = (SetManager.EffectAttribute)var10.next();
               } while(var3 && !var9.getValue().endsWith("%"));
            } while(!var3 && var9.getValue().endsWith("%"));

            double var11 = Double.parseDouble(var9.getValue().replace("%", ""));
            if (var9.getAction() == SetManager.EffectAction.MINUS) {
               var11 = -var11;
            }

            if (var4.containsKey(var9.getType())) {
               var11 += (Double)var4.get(var9.getType());
            }

            var4.put(var9.getType(), var11);
         }
      }
   }

   public boolean isItemOfSet(ItemStack var1) {
      if (var1 != null && var1.hasItemMeta() && var1.getItemMeta().hasDisplayName() && var1.getItemMeta().hasLore()) {
         ItemMeta var2 = var1.getItemMeta();
         String var3 = var2.getDisplayName();
         SetManager.PartType var4 = this.getItemType(var1);
         Iterator var6 = this.getSets().iterator();

         while(var6.hasNext()) {
            SetManager.ItemSet var5 = (SetManager.ItemSet)var6.next();
            if (var5.getParts().containsKey(var4) && ((SetManager.SetPart)var5.getParts().get(var4)).isEnabled() && ((SetManager.SetPart)var5.getParts().get(var4)).getMaterial().equalsIgnoreCase(var1.getType().name())) {
               String var7 = var5.getPrefix();
               String var8 = var5.getSuffix();
               String var9 = ((SetManager.SetPart)var5.getParts().get(var4)).getName().replace("%suffix%", var8).replace("%prefix%", var7);
               var9.trim().replaceAll("\\s+", " ");
               if (var3.equalsIgnoreCase(var9)) {
                  return true;
               }
            }
         }

         return false;
      } else {
         return false;
      }
   }

   public SetManager.ItemSet getItemSet(ItemStack var1) {
      if (var1 != null && var1.hasItemMeta() && var1.getItemMeta().hasDisplayName() && var1.getItemMeta().hasLore()) {
         ItemMeta var2 = var1.getItemMeta();
         String var3 = var2.getDisplayName();
         Iterator var5 = this.getSets().iterator();

         SetManager.ItemSet var4;
         String var6;
         String var7;
         do {
            if (!var5.hasNext()) {
               return null;
            }

            var4 = (SetManager.ItemSet)var5.next();
            var6 = var4.getPrefix();
            var7 = var4.getSuffix();
         } while(!var3.startsWith(var6) || !var3.endsWith(var7));

         return var4;
      } else {
         return null;
      }
   }

   public ItemStack replaceLore(ItemStack var1) {
      if (var1 != null && var1.hasItemMeta() && var1.getItemMeta().hasDisplayName() && var1.getItemMeta().hasLore()) {
         ItemMeta var2 = var1.getItemMeta();
         ArrayList var3 = new ArrayList(var2.getLore());
         Iterator var5 = var2.getLore().iterator();

         while(var5.hasNext()) {
            String var4 = (String)var5.next();
            if (var4.contains("%SET%") && this.isItemOfSet(var1)) {
               SetManager.ItemSet var6 = this.getItemSet(var1);
               if (var6 == null) {
                  return var1;
               }

               int var7 = var2.getLore().indexOf(var4);
               var3.remove(var7);
               var3.add(var7, this.ss.getLoreFooter());
               List var8 = Lists.reverse(new ArrayList(this.ss.getLore()));
               Iterator var10 = var8.iterator();

               while(true) {
                  while(var10.hasNext()) {
                     String var9 = (String)var10.next();
                     String var14;
                     if (var9.contains("%parts%")) {
                        List var17 = Lists.reverse(new ArrayList(var6.getParts().values()));
                        Iterator var19 = var17.iterator();

                        while(var19.hasNext()) {
                           SetManager.SetPart var18 = (SetManager.SetPart)var19.next();
                           var14 = var18.getName().replace("%suffix%", var6.getSuffix()).replace("%prefix%", var6.getPrefix());
                           String var20 = ChatColor.stripColor(var14);
                           String var16 = this.getSettings().getItemMissStr().replace("%c%", var6.getColorMiss()).replace("%name%", var20);
                           var3.add(var7, var16);
                        }
                     } else if (!var9.contains("%effects%")) {
                        var3.add(var7, var9.replace("%set%", var6.getName()));
                     } else {
                        Iterator var12 = Lists.reverse(new ArrayList(var6.getPartsEffects().values())).iterator();

                        while(var12.hasNext()) {
                           SetManager.SetPartEffect var11 = (SetManager.SetPartEffect)var12.next();
                           List var13 = Lists.reverse(new ArrayList(var11.getLore()));
                           Iterator var15 = var13.iterator();

                           while(var15.hasNext()) {
                              var14 = (String)var15.next();
                              var3.add(var7, var14.replace("%c%", var6.getColorMiss()));
                           }
                        }
                     }
                  }

                  var3.add(var7, this.ss.getLoreHeader());
                  var2.setLore(var3);
                  var1.setItemMeta(var2);
                  return var1;
               }
            }
         }

         return var1;
      } else {
         return var1;
      }
   }

   public void updateSets(Player var1) {
      ItemStack[] var5;
      int var4 = (var5 = EntityAPI.getEquipment(var1, false)).length;

      for(int var3 = 0; var3 < var4; ++var3) {
         ItemStack var2 = var5[var3];
         this.updateLore(var1, var2);
      }

      var1.updateInventory();
   }

   public void updateLore(Player var1, ItemStack var2) {
      if (var2 != null && var2.hasItemMeta() && var2.getItemMeta().hasDisplayName() && var2.getItemMeta().hasLore()) {
         ItemMeta var3 = var2.getItemMeta();
         ArrayList var4 = new ArrayList(var3.getLore());
         if (var4.contains(this.ss.getLoreHeader())) {
            if (var4.contains(this.ss.getLoreFooter())) {
               if (this.isItemOfSet(var2)) {
                  SetManager.ItemSet var5 = this.getItemSet(var2);
                  int var6 = var4.indexOf(this.ss.getLoreHeader());
                  int var7 = var4.indexOf(this.ss.getLoreFooter());

                  for(int var8 = var7 - var6 + 1; var8 > 0; --var8) {
                     var4.remove(var6);
                  }

                  var4.add(var6, this.ss.getLoreFooter());
                  List var9 = Lists.reverse(new ArrayList(this.ss.getLore()));
                  Iterator var11 = var9.iterator();

                  while(true) {
                     while(var11.hasNext()) {
                        String var10 = (String)var11.next();
                        String var16;
                        String var18;
                        if (var10.contains("%parts%")) {
                           ArrayList var20 = new ArrayList(var5.getParts().values());
                           List var21 = Lists.reverse(var20);
                           Iterator var23 = var21.iterator();

                           while(var23.hasNext()) {
                              SetManager.SetPart var22 = (SetManager.SetPart)var23.next();
                              String var24 = var22.getName().replace("%suffix%", var5.getSuffix()).replace("%prefix%", var5.getPrefix());
                              String var25;
                              if (this.hasSetItem(var1, var24)) {
                                 var25 = this.ss.getItemHaveStr();
                                 var16 = var5.getColorHave();
                              } else {
                                 var25 = this.ss.getItemMissStr();
                                 var16 = var5.getColorMiss();
                              }

                              var18 = var25.replace("%c%", var16).replace("%name%", ChatColor.stripColor(var24));
                              var4.add(var6, var18);
                           }
                        } else if (!var10.contains("%effects%")) {
                           var4.add(var6, var10.replace("%set%", var5.getName()));
                        } else {
                           Iterator var13 = Lists.reverse(new ArrayList(var5.getPartsEffects().values())).iterator();

                           while(var13.hasNext()) {
                              SetManager.SetPartEffect var12 = (SetManager.SetPartEffect)var13.next();
                              int var14 = var12.getPartsAmount();
                              int var15 = this.getPartsOf(var1, var5);
                              if (var15 >= var14) {
                                 var16 = var5.getColorHave();
                              } else {
                                 var16 = var5.getColorMiss();
                              }

                              List var17 = Lists.reverse(new ArrayList(var12.getLore()));
                              Iterator var19 = var17.iterator();

                              while(var19.hasNext()) {
                                 var18 = (String)var19.next();
                                 var4.add(var6, var18.replace("%c%", var16));
                              }
                           }
                        }
                     }

                     var4.add(var6, this.ss.getLoreHeader());
                     var3.setLore(var4);
                     var2.setItemMeta(var3);
                     return;
                  }
               }
            }
         }
      }
   }

   public ItemStack resetSet(ItemStack var1) {
      if (var1 != null && var1.hasItemMeta() && var1.getItemMeta().hasDisplayName() && var1.getItemMeta().hasLore()) {
         ItemMeta var2 = var1.getItemMeta();
         ArrayList var3 = new ArrayList(var2.getLore());
         if (!var3.contains(this.ss.getLoreHeader())) {
            return var1;
         } else if (!var3.contains(this.ss.getLoreFooter())) {
            return var1;
         } else if (!this.isItemOfSet(var1)) {
            return var1;
         } else {
            SetManager.ItemSet var4 = this.getItemSet(var1);
            int var5 = var3.indexOf(this.ss.getLoreHeader());
            int var6 = var3.indexOf(this.ss.getLoreFooter());

            for(int var7 = var6 - var5 + 1; var7 > 0; --var7) {
               var3.remove(var5);
            }

            var3.add(var5, this.ss.getLoreFooter());
            List var8 = Lists.reverse(new ArrayList(this.ss.getLore()));
            Iterator var10 = var8.iterator();

            while(true) {
               while(var10.hasNext()) {
                  String var9 = (String)var10.next();
                  String var14;
                  if (var9.contains("%parts%")) {
                     List var18 = Lists.reverse(new ArrayList(var4.getParts().values()));
                     Iterator var20 = var18.iterator();

                     while(var20.hasNext()) {
                        SetManager.SetPart var19 = (SetManager.SetPart)var20.next();
                        var14 = var19.getName().replace("%suffix%", var4.getSuffix()).replace("%prefix%", var4.getPrefix());
                        String var21 = var4.getColorMiss();
                        String var16 = this.ss.getItemMissStr();
                        String var17 = var16.replace("%c%", var21).replace("%name%", ChatColor.stripColor(var14));
                        var3.add(var5, var17);
                     }
                  } else if (!var9.contains("%effects%")) {
                     var3.add(var5, var9.replace("%set%", var4.getName()));
                  } else {
                     Iterator var12 = Lists.reverse(new ArrayList(var4.getPartsEffects().values())).iterator();

                     while(var12.hasNext()) {
                        SetManager.SetPartEffect var11 = (SetManager.SetPartEffect)var12.next();
                        List var13 = Lists.reverse(new ArrayList(var11.getLore()));
                        Iterator var15 = var13.iterator();

                        while(var15.hasNext()) {
                           var14 = (String)var15.next();
                           var3.add(var5, var14.replace("%c%", var4.getColorMiss()));
                        }
                     }
                  }
               }

               var3.add(var5, this.ss.getLoreHeader());
               var2.setLore(var3);
               var1.setItemMeta(var2);
               return var1;
            }
         }
      } else {
         return var1;
      }
   }

   public int getPartsOf(LivingEntity var1, SetManager.ItemSet var2) {
      int var3 = 0;
      ItemStack[] var7;
      int var6 = (var7 = EntityAPI.getEquipment(var1, false)).length;

      for(int var5 = 0; var5 < var6; ++var5) {
         ItemStack var4 = var7[var5];
         if (this.isItemOfSet(var4)) {
            SetManager.ItemSet var8 = this.getItemSet(var4);
            if (var8 != null && var8.getId().equalsIgnoreCase(var2.getId())) {
               ++var3;
            }
         }
      }

      return var3;
   }

   public boolean hasSetItem(LivingEntity var1, String var2) {
      ItemStack[] var6;
      int var5 = (var6 = EntityAPI.getEquipment(var1, false)).length;

      for(int var4 = 0; var4 < var5; ++var4) {
         ItemStack var3 = var6[var4];
         if (var3 != null && var3.hasItemMeta() && var3.getItemMeta().hasDisplayName() && var3.getItemMeta().hasLore()) {
            ItemMeta var7 = var3.getItemMeta();
            if (var7.getDisplayName().equalsIgnoreCase(var2)) {
               return true;
            }
         }
      }

      return false;
   }

   public SetManager.PartType getItemType(ItemStack var1) {
      String var2 = var1.getType().name();
      if (!var2.endsWith("_CHESTPLATE") && !var2.equals("ELYTRA")) {
         if (var2.endsWith("_LEGGINGS")) {
            return SetManager.PartType.LEGGINGS;
         } else if (var2.endsWith("_BOOTS")) {
            return SetManager.PartType.BOOTS;
         } else if (!var2.endsWith("_HELMET") && !var2.equals("SKULL_ITEM")) {
            return var2.equals("SHIELD") ? SetManager.PartType.OFF_HAND : SetManager.PartType.MAIN_HAND;
         } else {
            return SetManager.PartType.HELMET;
         }
      } else {
         return SetManager.PartType.CHESTPLATE;
      }
   }

   public SetManager.SetSettings getSettings() {
      return this.ss;
   }

   public Collection<SetManager.ItemSet> getSets() {
      return (Collection)(!this.isActive() ? new ArrayList() : this.sets.values());
   }

   public SetManager.ItemSet getSetById(String var1) {
      return var1.equalsIgnoreCase("random") ? (SetManager.ItemSet)(new ArrayList(this.getSets())).get(this.getSets().size() - 1) : (SetManager.ItemSet)this.sets.get(var1.toLowerCase());
   }

   public List<String> getSetNames() {
      ArrayList var1 = new ArrayList();
      Iterator var3 = this.getSets().iterator();

      while(var3.hasNext()) {
         SetManager.ItemSet var2 = (SetManager.ItemSet)var3.next();
         var1.add(var2.getId());
      }

      return var1;
   }

   @EventHandler(
      ignoreCancelled = true
   )
   public void onClick(InventoryClickEvent var1) {
      if (var1.getWhoClicked() instanceof Player) {
         final Player var2 = (Player)var1.getWhoClicked();
         if (var2.getGameMode() != GameMode.CREATIVE) {
            ItemStack var3 = var1.getCurrentItem();
            if (var1.getInventory().getType() == InventoryType.CRAFTING) {
               if (var1.getSlotType() != SlotType.CRAFTING) {
                  if (var3 != null && var3.getType() != Material.AIR) {
                     var1.setCurrentItem(this.resetSet(var3));
                  }

                  (new BukkitRunnable() {
                     public void run() {
                        SetManager.this.updateSets(var2);
                     }
                  }).runTaskLater(this.plugin, 1L);
               }
            }
         }
      }
   }

   @EventHandler(
      ignoreCancelled = true
   )
   public void onSpawn(ItemSpawnEvent var1) {
      Item var2 = var1.getEntity();
      ItemStack var3 = var2.getItemStack();
      var3 = this.replaceLore(var3);
      var3 = this.resetSet(var3);
      var2.setItemStack(var3);
   }

   public static enum EffectAction {
      PLUS,
      MINUS,
      MULTIPLICATION,
      DIVISION;
   }

   public class EffectAttribute {
      private ItemStat type;
      private SetManager.EffectAction act;
      private String value;

      public EffectAttribute(ItemStat var2, SetManager.EffectAction var3, String var4) {
         this.setType(var2);
         this.setAction(var3);
         this.setValue(var4);
      }

      public ItemStat getType() {
         return this.type;
      }

      public void setType(ItemStat var1) {
         this.type = var1;
      }

      public SetManager.EffectAction getAction() {
         return this.act;
      }

      public void setAction(SetManager.EffectAction var1) {
         this.act = var1;
      }

      public String getValue() {
         return this.value;
      }

      public void setValue(String var1) {
         this.value = var1;
      }
   }

   public class ItemSet {
      private String id;
      private String name;
      private String prefix;
      private String suffix;
      private String color_have;
      private String color_miss;
      private HashMap<SetManager.PartType, SetManager.SetPart> parts;
      private TreeMap<Integer, SetManager.SetPartEffect> parts_eff;

      public ItemSet(String var2, String var3, String var4, String var5, String var6, String var7, HashMap<SetManager.PartType, SetManager.SetPart> var8, TreeMap<Integer, SetManager.SetPartEffect> var9) {
         this.setId(var2);
         this.setName(var3);
         this.setPrefix(var4);
         this.setSuffix(var5);
         this.setColorHave(var6);
         this.setColorMiss(var7);
         this.setParts(var8);
         this.setPartsEffects(var9);
      }

      public String getId() {
         return this.id;
      }

      public void setId(String var1) {
         this.id = var1;
      }

      public String getName() {
         return this.name;
      }

      public void setName(String var1) {
         this.name = var1;
      }

      public String getPrefix() {
         return this.prefix;
      }

      public void setPrefix(String var1) {
         this.prefix = var1;
      }

      public String getSuffix() {
         return this.suffix;
      }

      public void setSuffix(String var1) {
         this.suffix = var1;
      }

      public String getColorHave() {
         return this.color_have;
      }

      public void setColorHave(String var1) {
         this.color_have = var1;
      }

      public String getColorMiss() {
         return this.color_miss;
      }

      public void setColorMiss(String var1) {
         this.color_miss = var1;
      }

      public HashMap<SetManager.PartType, SetManager.SetPart> getParts() {
         return this.parts;
      }

      public void setParts(HashMap<SetManager.PartType, SetManager.SetPart> var1) {
         this.parts = var1;
      }

      public TreeMap<Integer, SetManager.SetPartEffect> getPartsEffects() {
         return this.parts_eff;
      }

      public void setPartsEffects(TreeMap<Integer, SetManager.SetPartEffect> var1) {
         this.parts_eff = var1;
      }

      public ItemStack create(String var1) {
         SetManager.PartType var3;
         if (var1.equalsIgnoreCase("random")) {
            ArrayList var4 = new ArrayList(this.getParts().keySet());
            var3 = (SetManager.PartType)var4.get((new Random()).nextInt(var4.size()));
         } else {
            var3 = SetManager.PartType.valueOf(var1.toUpperCase());
         }

         SetManager.SetPart var7 = (SetManager.SetPart)this.getParts().get(var3);
         ItemStack var2 = new ItemStack(Material.getMaterial(var7.getMaterial()));
         ItemMeta var5 = var2.getItemMeta();
         String var6 = var7.getName().replace("%suffix%", this.getSuffix()).replace("%prefix%", this.getPrefix());
         var6 = var6.trim().replaceAll("\\s+", " ");
         var5.setDisplayName(var6);
         var5.setLore(Arrays.asList("%SET%"));
         var2.setItemMeta(var5);
         var2 = SetManager.this.replaceLore(var2);
         return var2;
      }
   }

   public static enum PartType {
      HELMET,
      CHESTPLATE,
      LEGGINGS,
      BOOTS,
      MAIN_HAND,
      OFF_HAND;
   }

   public class SetPart {
      private boolean enabled;
      private String mat;
      private String name;

      public SetPart(boolean var2, String var3, String var4) {
         this.setEnabled(var2);
         this.setMaterial(var3);
         this.setName(var4);
      }

      public boolean isEnabled() {
         return this.enabled;
      }

      public void setEnabled(boolean var1) {
         this.enabled = var1;
      }

      public String getMaterial() {
         return this.mat;
      }

      public void setMaterial(String var1) {
         this.mat = var1;
      }

      public String getName() {
         return this.name;
      }

      public void setName(String var1) {
         this.name = var1;
      }
   }

   public class SetPartEffect {
      private int amount;
      private List<String> lore;
      private List<String> eff;
      private List<SetManager.EffectAttribute> att;

      public SetPartEffect(int var2, List<String> var3, List<String> var4, List<SetManager.EffectAttribute> var5) {
         this.setPartsAmount(var2);
         this.setLore(var3);
         this.setEffects(var4);
         this.setAttributes(var5);
      }

      public int getPartsAmount() {
         return this.amount;
      }

      public void setPartsAmount(int var1) {
         this.amount = var1;
      }

      public List<String> getLore() {
         return this.lore;
      }

      public void setLore(List<String> var1) {
         this.lore = var1;
      }

      public List<String> getEffects() {
         return this.eff;
      }

      public void setEffects(List<String> var1) {
         this.eff = var1;
      }

      public List<SetManager.EffectAttribute> getAttributes() {
         return this.att;
      }

      public void setAttributes(List<SetManager.EffectAttribute> var1) {
         this.att = var1;
      }
   }

   public class SetSettings {
      private boolean dynamic;
      private String i_have;
      private String i_miss;
      private String l_head;
      private String l_foot;
      private List<String> lore;

      public SetSettings(boolean var2, String var3, String var4, String var5, String var6, List<String> var7) {
         this.setDynamic(var2);
         this.setItemHaveStr(var3);
         this.setItemMissStr(var4);
         this.setLoreHeader(var5);
         this.setLoreFooter(var6);
         this.setLore(var7);
      }

      public boolean isDynamic() {
         return this.dynamic;
      }

      public void setDynamic(boolean var1) {
         this.dynamic = var1;
      }

      public String getItemHaveStr() {
         return this.i_have;
      }

      public void setItemHaveStr(String var1) {
         this.i_have = var1;
      }

      public String getItemMissStr() {
         return this.i_miss;
      }

      public void setItemMissStr(String var1) {
         this.i_miss = var1;
      }

      public String getLoreHeader() {
         return this.l_head;
      }

      public void setLoreHeader(String var1) {
         this.l_head = var1;
      }

      public String getLoreFooter() {
         return this.l_foot;
      }

      public void setLoreFooter(String var1) {
         this.l_foot = var1;
      }

      public List<String> getLore() {
         return this.lore;
      }

      public void setLore(List<String> var1) {
         this.lore = var1;
      }
   }
}
