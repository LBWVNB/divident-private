package su.nightexpress.divineitems.modules.soulbound;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;
import org.apache.commons.lang.ArrayUtils;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryPickupItemEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.inventory.InventoryType.SlotType;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerPickupItemEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import su.nightexpress.divineitems.DivineItems;
import su.nightexpress.divineitems.DivineListener;
import su.nightexpress.divineitems.Module;
import su.nightexpress.divineitems.api.ItemAPI;
import su.nightexpress.divineitems.cmds.list.SoulboundCommand;
import su.nightexpress.divineitems.config.Lang;
import su.nightexpress.divineitems.config.MyConfig;
import su.nightexpress.divineitems.gui.ContentType;
import su.nightexpress.divineitems.gui.GUI;
import su.nightexpress.divineitems.gui.GUIItem;
import su.nightexpress.divineitems.gui.GUIType;
import su.nightexpress.divineitems.nbt.NBTItem;

public class SoulboundManager extends DivineListener<DivineItems> implements Module {
   private DivineItems plugin;
   private boolean e;
   private MyConfig settingsCfg;
   private String untrade;
   private String soul;
   private String soulset;
   private List<String> cmds;
   private boolean b_drop;
   private boolean b_pick;
   private boolean b_click;
   private boolean b_use;
   private boolean i_pick;
   private boolean i_use;
   private boolean i_drop;
   private boolean i_death;
   private final String n = this.name().toLowerCase().replace(" ", "_");
   private final String label;
   private final String NBT_KEY_SOUL;

   public SoulboundManager(DivineItems var1) {
      super(var1);
      this.label = this.n.replace("_", "");
      this.NBT_KEY_SOUL = "Owner";
      this.plugin = var1;
      this.e = this.plugin.getCM().getCFG().isModuleEnabled(this.name());
   }

   public void loadConfig() {
      this.settingsCfg = new MyConfig(this.plugin, "/modules/" + this.n, "settings.yml");
      FileConfiguration var1 = this.settingsCfg.getConfig();
      if (!var1.contains("Interact.AllowDrop")) {
         var1.set("Interact.AllowDrop", true);
      }

      this.settingsCfg.save();
      this.untrade = ChatColor.translateAlternateColorCodes('&', var1.getString("Untradable"));
      this.soul = ChatColor.translateAlternateColorCodes('&', var1.getString("Soulbound"));
      this.soulset = ChatColor.translateAlternateColorCodes('&', var1.getString("SoulboundSet"));
      this.cmds = new ArrayList(var1.getStringList("CmdBlock"));
      this.b_drop = var1.getBoolean("BindToPlayer.OnItemDrop");
      this.b_pick = var1.getBoolean("BindToPlayer.OnItemPickup");
      this.b_click = var1.getBoolean("BindToPlayer.OnItemClick");
      this.b_use = var1.getBoolean("BindToPlayer.OnItemUse");
      this.i_pick = var1.getBoolean("Interact.AllowPickup");
      this.i_use = var1.getBoolean("Interact.AllowUse");
      this.i_drop = var1.getBoolean("Interact.AllowDrop");
      this.i_death = var1.getBoolean("Interact.DropOnDeath");
   }

   public boolean isActive() {
      return this.e;
   }

   public boolean isDropable() {
      return false;
   }

   public boolean isResolvable() {
      return false;
   }

   public String name() {
      return "Soulbound";
   }

   public String version() {
      return "1.0";
   }

   public void enable() {
      if (this.isActive()) {
         this.plugin.getCommander().registerCmd(this.label, new SoulboundCommand(this.plugin));
         this.loadConfig();
         this.registerListeners();
      }

   }

   public void unload() {
      if (this.isActive()) {
         this.plugin.getCommander().unregisterCmd(this.label);
         this.e = false;
         this.unregisterListeners();
      }

   }

   public void reload() {
      this.unload();
      this.enable();
   }

   public ItemStack removeSoulbound(ItemStack var1) {
      String[] var2 = this.getSoulSetString().split("%p");
      String var3 = "";
      if (var2[0] != null) {
         var3 = var2[0];
      } else {
         var3 = var2[1];
      }

      ItemMeta var4 = var1.getItemMeta();
      ArrayList var5 = new ArrayList(var4.getLore());
      boolean var6 = false;
      Iterator var8 = var5.iterator();

      while(var8.hasNext()) {
         String var7 = (String)var8.next();
         int var9;
         if (var7.contains(var3)) {
            var9 = var5.indexOf(var7);
            var5.remove(var9);
            var5.add(var9, this.getSoulString());
            break;
         }

         if (var7.contains(this.getUntradeString())) {
            var9 = var5.indexOf(var7);
            var5.remove(var9);
            break;
         }
      }

      var4.setLore(var5);
      var1.setItemMeta(var4);
      NBTItem var10 = new NBTItem(var1);
      var10.removeKey("Owner");
      return var10.getItem();
   }

   public boolean hasSoulbound(ItemStack var1) {
      return this.isSoulBinded(var1);
   }

   public boolean hasOwner(ItemStack var1) {
      if (var1 != null && var1.getType() != Material.AIR) {
         NBTItem var2 = new NBTItem(var1);
         return var2.hasKey("Owner");
      } else {
         return false;
      }
   }

   public boolean isOwner(ItemStack var1, Player var2) {
      return var2.getUniqueId().toString().equals(this.getOwner(var1)) || var2.getName().equalsIgnoreCase(this.getOwner(var1));
   }

   public String getOwner(ItemStack var1) {
      return (new NBTItem(var1)).getString("Owner");
   }

   public ItemStack setOwner(ItemStack var1, Player var2) {
      NBTItem var3 = new NBTItem(var1);
      var3.setString("Owner", var2.getUniqueId().toString());
      return var3.getItem();
   }

   public boolean isUntradeable(ItemStack var1) {
      if (var1 != null && var1.hasItemMeta() && var1.getItemMeta().hasLore()) {
         ItemMeta var2 = var1.getItemMeta();
         List var3 = var2.getLore();
         Iterator var5 = var3.iterator();

         while(var5.hasNext()) {
            String var4 = (String)var5.next();
            if (var4.contains(this.getUntradeString())) {
               return true;
            }
         }

         return false;
      } else {
         return false;
      }
   }

   public boolean isSoulboundRequired(ItemStack var1) {
      if (var1 != null && var1.hasItemMeta() && var1.getItemMeta().hasLore()) {
         ItemMeta var2 = var1.getItemMeta();
         List var3 = var2.getLore();
         Iterator var5 = var3.iterator();

         while(var5.hasNext()) {
            String var4 = (String)var5.next();
            if (var4.contains(this.getSoulString())) {
               return true;
            }
         }

         return false;
      } else {
         return false;
      }
   }

   public boolean isSoulBinded(ItemStack var1) {
      if (var1 != null && var1.hasItemMeta() && var1.getItemMeta().hasLore()) {
         if (!this.hasOwner(var1)) {
            return false;
         } else {
            ItemMeta var2 = var1.getItemMeta();
            List var3 = var2.getLore();
            String var4 = this.getOwner(var1);

            UUID var5;
            try {
               var5 = UUID.fromString(var4);
            } catch (IllegalArgumentException var9) {
               return false;
            }

            Player var7 = Bukkit.getPlayer(var5);
            String var6;
            if (var7 == null) {
               var6 = Bukkit.getOfflinePlayer(UUID.fromString(var4)).getName();
            } else {
               var6 = var7.getName();
            }

            if (this.getSoulSetString() == null) {
               return false;
            } else {
               String var8 = this.getSoulSetString().replace("%p", var6);
               return var3.contains(var8);
            }
         }
      } else {
         return false;
      }
   }

   public String getUntradeString() {
      return this.untrade;
   }

   public String getSoulString() {
      return this.soul;
   }

   public String getSoulSetString() {
      return this.soulset;
   }

   public List<String> getCmds() {
      return this.cmds;
   }

   public boolean bindOnDrop() {
      return this.b_drop;
   }

   public boolean bindOnPickup() {
      return this.b_pick;
   }

   public boolean bindOnClick() {
      return this.b_click;
   }

   public boolean bindOnUse() {
      return this.b_use;
   }

   public boolean allowPickup() {
      return this.i_pick;
   }

   public boolean allowUse() {
      return this.i_use;
   }

   public boolean allowDropDeath() {
      return this.i_death;
   }

   public void openGUI(Player var1, ItemStack var2) {
      GUI var3 = new GUI(this.plugin.getGUIManager().getGUIByType(GUIType.SOULBOUND));
      ((GUIItem)var3.getItems().get(ContentType.TARGET)).setItem(var2);
      this.plugin.getGUIManager().setGUI(var1, var3);
      var1.openInventory(var3.build());
   }

   @EventHandler
   public void onPickup(PlayerPickupItemEvent var1) {
      if (var1.getItem().hasMetadata("dont_pick_me")) {
         var1.setCancelled(true);
      } else {
         ItemStack var2 = var1.getItem().getItemStack();
         Player var3 = var1.getPlayer();
         if (ItemAPI.isSoulBinded(var2) && !ItemAPI.isOwner(var2, var3)) {
            var1.setCancelled(true);
         } else if (ItemAPI.hasOwner(var2) && !ItemAPI.isOwner(var2, var3)) {
            var1.setCancelled(true);
         } else {
            if (ItemAPI.isUntradeable(var2) && this.bindOnPickup()) {
               var1.getItem().setItemStack(ItemAPI.setOwner(var2, var3));
            }

         }
      }
   }

   @EventHandler(
      ignoreCancelled = true
   )
   public void onClick(InventoryClickEvent var1) {
      Player var2 = (Player)var1.getWhoClicked();
      ItemStack var3 = var1.getCurrentItem();
      if (var1.getInventory().getType() == InventoryType.CRAFTING && var1.getInventory().getHolder().equals(var2)) {
         if (var3 == null || !var3.hasItemMeta()) {
            return;
         }

         if (this.isSoulboundRequired(var3) && var1.isRightClick() && !var1.isShiftClick() && var1.getSlotType() != SlotType.CRAFTING) {
            if (var1.getSlotType() != SlotType.ARMOR && var1.getSlot() != 40) {
               var2.closeInventory();
               this.openGUI(var2, var3);
               var1.setCancelled(true);
               return;
            }

            return;
         }
      } else if ((this.isSoulBinded(var3) || this.hasOwner(var3)) && !this.isOwner(var3, var2) && !var2.hasPermission("divineitems.bypass.owner")) {
         var1.setCancelled(true);
         return;
      }

      if (this.isUntradeable(var3) && !this.hasOwner(var3) && this.bindOnClick()) {
         var3 = this.setOwner(var3, var2);
         var1.setCurrentItem(var3);
      }

   }

   @EventHandler(
      priority = EventPriority.LOW,
      ignoreCancelled = true
   )
   public void onInter(PlayerInteractEvent var1) {
      Player var2 = var1.getPlayer();
      ItemStack var3 = var1.getItem();
      if (var3 != null && var3.getItemMeta() != null && var3.getItemMeta().getLore() != null) {
         if (this.isUntradeable(var3) && !this.hasOwner(var3) && this.bindOnUse()) {
            if (var1.getHand() == EquipmentSlot.OFF_HAND) {
               var2.getInventory().setItemInOffHand(this.setOwner(var3, var2));
            } else {
               var2.getInventory().setItemInMainHand(this.setOwner(var3, var2));
            }
         }

      }
   }

   @EventHandler(
      priority = EventPriority.HIGHEST,
      ignoreCancelled = true
   )
   public void onItemDrop(PlayerDropItemEvent var1) {
      ItemStack var2 = var1.getItemDrop().getItemStack();
      if (this.i_drop || !this.isSoulBinded(var2) && !this.isUntradeable(var2)) {
         if (var2 != null) {
            if (this.isUntradeable(var2)) {
               if (!this.hasOwner(var2)) {
                  if (this.bindOnDrop()) {
                     Player var3 = var1.getPlayer();
                     if (this.isUntradeable(var2)) {
                        var1.getItemDrop().setItemStack(this.setOwner(var2, var3));
                     }

                  }
               }
            }
         }
      } else {
         var1.setCancelled(true);
      }
   }

   @EventHandler
   public void onPlayerCommandPreprocessEvent(PlayerCommandPreprocessEvent var1) {
      Player var2 = var1.getPlayer();
      String var3 = var1.getMessage();
      ItemStack var4 = var2.getInventory().getItemInMainHand();
      ItemStack var5 = var2.getInventory().getItemInOffHand();
      if (var4 != null || var5 != null) {
         Iterator var7 = this.getCmds().iterator();

         String var6;
         do {
            do {
               if (!var7.hasNext()) {
                  return;
               }

               var6 = (String)var7.next();
            } while(!var3.startsWith(var6));
         } while(!this.isUntradeable(var4) && !this.isSoulBinded(var4) && !this.isUntradeable(var5) && !this.isSoulBinded(var5));

         var1.setCancelled(true);
         var2.sendMessage(Lang.Prefix.toMsg() + Lang.Restrictions_NoCommands.toMsg());
      }
   }

   @EventHandler(
      ignoreCancelled = true
   )
   public void onHopper(InventoryPickupItemEvent var1) {
      ItemStack var2 = var1.getItem().getItemStack();
      if ((this.isUntradeable(var2) || this.isSoulBinded(var2)) && var1.getInventory().getType() == InventoryType.HOPPER) {
         var1.setCancelled(true);
      }

   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onDeath(PlayerDeathEvent var1) {
      if (!this.allowDropDeath()) {
         ArrayList var2 = new ArrayList(var1.getDrops());
         final ArrayList var3 = new ArrayList();
         Iterator var5 = var2.iterator();

         while(var5.hasNext()) {
            ItemStack var4 = (ItemStack)var5.next();
            if (this.hasOwner(var4)) {
               var1.getDrops().remove(var4);
               var3.add(var4);
            }
         }

         final Player var6 = var1.getEntity();
         this.plugin.getServer().getScheduler().scheduleSyncDelayedTask(this.plugin, new Runnable() {
            public void run() {
               Iterator var2 = var3.iterator();

               while(var2.hasNext()) {
                  ItemStack var1 = (ItemStack)var2.next();
                  var6.getInventory().addItem(new ItemStack[]{var1});
               }

            }
         });
      }
   }

   @EventHandler
   public void onClickGUI(InventoryClickEvent var1) {
      Player var2 = (Player)var1.getWhoClicked();
      if (this.plugin.getGUIManager().valid(var2, GUIType.SOULBOUND)) {
         GUI var3 = this.plugin.getGUIManager().getPlayerGUI(var2, GUIType.SOULBOUND);
         if (var3 != null && var1.getInventory().getTitle().equals(var3.getTitle())) {
            var1.setCancelled(true);
            ItemStack var4 = var1.getCurrentItem();
            if (var4 != null && var4.hasItemMeta()) {
               GUIItem var5 = (GUIItem)var3.getItems().get(ContentType.ACCEPT);
               int var6 = var1.getRawSlot();
               if (!var4.isSimilar(var5.getItem()) && !ArrayUtils.contains(var5.getSlots(), var6)) {
                  GUIItem var11 = (GUIItem)var3.getItems().get(ContentType.DECLINE);
                  if (var4.isSimilar(var11.getItem()) || ArrayUtils.contains(var11.getSlots(), var6)) {
                     var2.sendMessage(Lang.Prefix.toMsg() + Lang.Restrictions_SoulDecline.toMsg());
                     var2.closeInventory();
                     this.plugin.getGUIManager().reset(var2);
                  }

               } else {
                  ItemStack var7 = new ItemStack(((GUIItem)var3.getItems().get(ContentType.TARGET)).getItem());
                  var2.getInventory().removeItem(new ItemStack[]{var7});
                  boolean var8 = false;
                  ItemMeta var9 = var7.getItemMeta();
                  List var10 = var9.getLore();
                  int var12 = var10.indexOf(this.getSoulString());
                  var10.remove(var12);
                  var10.add(var12, this.getSoulSetString().replace("%p", var2.getName()));
                  var9.setLore(var10);
                  var7.setItemMeta(var9);
                  var7 = this.setOwner(var7, var2);
                  var2.getInventory().addItem(new ItemStack[]{var7});
                  var2.sendMessage(Lang.Prefix.toMsg() + Lang.Restrictions_SoulAccept.toMsg());
                  var2.closeInventory();
                  this.plugin.getGUIManager().reset(var2);
               }
            }
         }
      }
   }
}
