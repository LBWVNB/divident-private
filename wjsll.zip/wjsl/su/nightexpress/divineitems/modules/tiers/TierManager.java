package su.nightexpress.divineitems.modules.tiers;

import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import org.bukkit.ChatColor;
import org.bukkit.Color;
import org.bukkit.DyeColor;
import org.bukkit.Material;
import org.bukkit.block.Banner;
import org.bukkit.block.banner.Pattern;
import org.bukkit.block.banner.PatternType;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.BlockStateMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.LeatherArmorMeta;
import su.nightexpress.divineitems.DivineItems;
import su.nightexpress.divineitems.DivineListener;
import su.nightexpress.divineitems.Module;
import su.nightexpress.divineitems.api.ItemAPI;
import su.nightexpress.divineitems.attributes.ItemStat;
import su.nightexpress.divineitems.cmds.list.TiersCommand;
import su.nightexpress.divineitems.config.Lang;
import su.nightexpress.divineitems.hooks.Hook;
import su.nightexpress.divineitems.modules.tiers.resources.ResourceSubType;
import su.nightexpress.divineitems.modules.tiers.resources.ResourceType;
import su.nightexpress.divineitems.modules.tiers.resources.Resources;
import su.nightexpress.divineitems.nbt.NBTItem;
import su.nightexpress.divineitems.nms.NBTAttribute;
import su.nightexpress.divineitems.types.AmmoType;
import su.nightexpress.divineitems.types.ArmorType;
import su.nightexpress.divineitems.types.DamageType;
import su.nightexpress.divineitems.types.SlotType;
import su.nightexpress.divineitems.utils.ErrorLog;
import su.nightexpress.divineitems.utils.Files;
import su.nightexpress.divineitems.utils.ItemUtils;
import su.nightexpress.divineitems.utils.Utils;

public class TierManager extends DivineListener<DivineItems> implements Module {
   private DivineItems plugin;
   private boolean e;
   private Random r;
   private HashMap<String, TierManager.Tier> tiers;
   private final String n = this.name().toLowerCase().replace(" ", "_");
   private final String label;
   private final String NBT_KEY;

   public TierManager(DivineItems var1) {
      super(var1);
      this.label = this.n.replace("_", "");
      this.NBT_KEY = "TIER";
      this.plugin = var1;
      this.tiers = new HashMap();
      this.r = new Random();
      this.e = this.plugin.getCM().getCFG().isModuleEnabled(this.name());
   }

   public void loadConfig() {
      this.setupTiers();
   }

   public boolean isDropable() {
      return true;
   }

   public boolean isResolvable() {
      return true;
   }

   public boolean isActive() {
      return this.e;
   }

   public String name() {
      return "Tiers";
   }

   public String version() {
      return "1.0";
   }

   public void enable() {
      if (this.isActive()) {
         this.plugin.getCommander().registerCmd(this.label, new TiersCommand(this.plugin));
         this.loadConfig();
         this.registerListeners();
      }

   }

   public void unload() {
      if (this.isActive()) {
         this.plugin.getCommander().unregisterCmd(this.label);
         this.tiers.clear();
         this.e = false;
         this.unregisterListeners();
      }

   }

   public void reload() {
      this.unload();
      this.enable();
   }

   public void setupTiers() {
      Iterator var2 = Files.getFilesFolder("tiers").iterator();

      while(var2.hasNext()) {
         String var1 = (String)var2.next();
         TierManager.Tier var3 = this.loadFromConfig(var1);
         this.tiers.put(var3.getId(), var3);
      }

   }

   private TierManager.Tier loadFromConfig(String var1) {
      File var2 = new File(this.plugin.getDataFolder() + "/modules/tiers/", var1);
      new YamlConfiguration();
      YamlConfiguration var3 = YamlConfiguration.loadConfiguration(var2);
      String var4 = var1.replace(".yml", "").toLowerCase();
      String var5 = var3.getString("Display");
      String var6 = ChatColor.translateAlternateColorCodes('&', var3.getString("Color"));
      boolean var7 = var3.getBoolean("FindBroadcast");
      boolean var8 = var3.getBoolean("EquipOnEntity");
      String var9 = ChatColor.translateAlternateColorCodes('&', var3.getString("Item.Display"));
      List var10 = var3.getStringList("Item.Lore");
      ArrayList var11 = new ArrayList();
      Iterator var13 = var10.iterator();

      while(var13.hasNext()) {
         String var12 = (String)var13.next();
         var11.add(ChatColor.translateAlternateColorCodes('&', var12.replace("%c%", var6)));
      }

      boolean var62 = var3.getBoolean("Item.Color.Random");
      String[] var63 = var3.getString("Item.Color.Value").split(",");
      Color var14 = Color.fromRGB(Integer.parseInt(var63[0]), Integer.parseInt(var63[1]), Integer.parseInt(var63[2]));
      boolean var15 = var3.getBoolean("Item.Materials.Reverse");
      List var16 = var3.getStringList("Item.Materials.BlackList");
      HashSet var17 = new HashSet(Resources.getAllMaterials());
      ArrayList var18 = new ArrayList();
      if (!var15) {
         var18 = new ArrayList(var17);
      }

      Iterator var20 = var16.iterator();

      label131:
      while(var20.hasNext()) {
         String var19 = (String)var20.next();
         Iterator var22 = var17.iterator();

         while(true) {
            Material var21;
            do {
               if (!var22.hasNext()) {
                  continue label131;
               }

               var21 = (Material)var22.next();
            } while((!var19.contains("*") || !var21.name().startsWith(var19.replace("*", "")) && !var21.name().endsWith(var19.replace("*", ""))) && (var19.contains("*") || !var21.name().equalsIgnoreCase(var19)));

            if (var15) {
               var18.add(var21);
            } else {
               var18.remove(var21);
            }
         }
      }

      boolean var64 = var3.getBoolean("Item.MaterialData.Reverse");
      boolean var65 = var3.getBoolean("Item.MaterialData.SetUnbreakable");
      List var66 = var3.getIntegerList("Item.MaterialData.BlackList");
      HashMap var67 = new HashMap();
      Object[] var23 = var3.getConfigurationSection("Item.MaterialData.Special").getKeys(false).toArray();
      Object[] var27 = var23;
      int var26 = var23.length;

      int var25;
      String var28;
      for(var25 = 0; var25 < var26; ++var25) {
         Object var24 = var27[var25];
         var28 = var24.toString();
         List var29 = var3.getIntegerList("Item.MaterialData.Special." + var28);
         var67.put(var28, var29);
      }

      int var68 = var3.getInt("Item.Enchants.Min");
      var25 = var3.getInt("Item.Enchants.Max");
      boolean var69 = var3.getBoolean("Item.Enchants.SafeOnly");
      HashMap var70 = new HashMap();
      Iterator var72 = var3.getStringList("Item.Enchants.List").iterator();

      String var31;
      while(var72.hasNext()) {
         var28 = (String)var72.next();
         Enchantment var30 = Enchantment.getByName(var28.split(":")[0]);
         if (var30 != null) {
            var31 = var28.split(":")[1] + ":" + var28.split(":")[2];
            var70.put(var30, var31);
         }
      }

      List var71 = var3.getStringList("Item.Flags");
      ArrayList var73 = new ArrayList();
      Iterator var76 = var71.iterator();

      while(var76.hasNext()) {
         String var74 = (String)var76.next();

         try {
            var73.add(ItemFlag.valueOf(var74));
         } catch (IllegalArgumentException var61) {
            ErrorLog.sendError(this, "Item.Flags." + var74, "Invalid Item Flag!", false);
         }
      }

      HashMap var75 = new HashMap();
      Iterator var32 = var3.getConfigurationSection("Item.DamageTypes").getKeys(false).iterator();

      double var36;
      while(var32.hasNext()) {
         var31 = (String)var32.next();
         DamageType var33 = (DamageType)this.plugin.getCFG().getDamageTypes().get(var31.toLowerCase());
         if (var33 != null) {
            double var34 = var3.getDouble("Item.DamageTypes." + var31 + ".Chance");
            var36 = var3.getDouble("Item.DamageTypes." + var31 + ".Min");
            double var38 = var3.getDouble("Item.DamageTypes." + var31 + ".Max");
            String var40 = var34 + ":" + var36 + ":" + var38;
            var75.put(var33, var40);
         }
      }

      HashMap var77 = new HashMap();
      Iterator var80 = var3.getConfigurationSection("Item.ArmorTypes").getKeys(false).iterator();

      double var37;
      while(var80.hasNext()) {
         String var78 = (String)var80.next();
         ArmorType var83 = (ArmorType)this.plugin.getCFG().getArmorTypes().get(var78.toLowerCase());
         if (var83 != null) {
            double var35 = var3.getDouble("Item.ArmorTypes." + var78 + ".Chance");
            var37 = var3.getDouble("Item.ArmorTypes." + var78 + ".Min");
            double var39 = var3.getDouble("Item.ArmorTypes." + var78 + ".Max");
            String var41 = var35 + ":" + var37 + ":" + var39;
            var77.put(var83, var41);
         }
      }

      HashMap var79 = new HashMap();
      AmmoType[] var88;
      int var85 = (var88 = AmmoType.values()).length;

      for(int var84 = 0; var84 < var85; ++var84) {
         AmmoType var81 = var88[var84];
         if (var3.contains("Item.AmmoTypes." + var81.name())) {
            var37 = var3.getDouble("Item.AmmoTypes." + var81.name());
            var79.put(var81, var37);
         }
      }

      var79 = (HashMap)Utils.sortByValue(var79);
      boolean var82 = var3.getBoolean("Item.Restrictions.Soulbound");
      boolean var86 = var3.getBoolean("Item.Restrictions.Untradeable");
      String var87 = var3.getString("Item.Restrictions.Levels");
      var36 = var3.getDouble("Item.Restrictions.LevelScaleValues");
      List var89 = var3.getStringList("Item.Restrictions.LevelScaleBlackList");
      List var90 = var3.getStringList("Item.Restrictions.Classes");
      int var91 = var3.getInt("Item.Restrictions.MaxAttributes");
      int var92 = var3.getInt("Item.Restrictions.MaxBonuses");
      HashMap var42 = new HashMap();
      ItemStat[] var46;
      int var45 = (var46 = ItemStat.values()).length;

      for(int var44 = 0; var44 < var45; ++var44) {
         ItemStat var43 = var46[var44];
         String var47 = "Item.Attributes." + var43.name();
         if (var3.contains(var47)) {
            double var48 = var3.getDouble(var47 + ".Default.Chance");
            double var50 = var3.getDouble(var47 + ".Default.Min");
            double var52 = var3.getDouble(var47 + ".Default.Max");
            double var54 = var3.getDouble(var47 + ".Bonus.Chance");
            double var56 = var3.getDouble(var47 + ".Bonus.Min");
            double var58 = var3.getDouble(var47 + ".Bonus.Max");
            String var60 = var48 + ":" + var50 + ":" + var52 + "!" + var54 + ":" + var56 + ":" + var58;
            var42.put(var43, var60);
         }
      }

      HashMap var93 = new HashMap();
      SlotType[] var98;
      int var97 = (var98 = SlotType.values()).length;

      for(var45 = 0; var45 < var97; ++var45) {
         SlotType var94 = var98[var45];
         String var99 = "Item.Slots." + var94.name();
         if (var3.contains(var99)) {
            double var49 = var3.getDouble(var99 + ".Chance");
            int var51 = var3.getInt(var99 + ".Min");
            int var100 = var3.getInt(var99 + ".Max");
            String var53 = var49 + ":" + var51 + ":" + var100;
            var93.put(var94, var53);
         }
      }

      HashMap var95 = new HashMap();
      var95.put(ResourceType.PREFIX, Resources.getSource(ResourceType.PREFIX, ResourceSubType.TIER, var4));
      var95.put(ResourceType.SUFFIX, Resources.getSource(ResourceType.SUFFIX, ResourceSubType.TIER, var4));
      TierManager.Tier var96 = new TierManager.Tier(var4, var5, var6, var7, var8, var9, var11, var62, var14, var15, var18, var64, var65, var66, var67, var68, var25, var69, var70, var73, var75, var77, var79, var82, var86, var87, var36, var89, var90, var91, var92, var42, var93, var95);
      return var96;
   }

   public ItemStack replaceSet(ItemStack var1, TierManager.Tier var2) {
      if (this.plugin.getMM().getSetManager() != null && this.plugin.getMM().getSetManager().isActive()) {
         int var3 = var1.getItemMeta().getLore().indexOf("%SET%");
         if (var3 < 0) {
            return var1;
         } else {
            var1 = this.plugin.getMM().getSetManager().replaceLore(var1);
            return this.replaceLore(var1, "SET", "delz");
         }
      } else {
         return this.replaceLore(var1, "SET", "delz");
      }
   }

   public ItemStack replaceEnchants(ItemStack var1) {
      int var2 = var1.getItemMeta().getLore().indexOf("%ENCHANTS%");
      if (var2 < 0) {
         return var1;
      } else {
         if (var1.hasItemMeta() && var1.getItemMeta().hasEnchants()) {
            ItemMeta var3 = var1.getItemMeta();
            List var4 = var3.getLore();
            Iterator var6 = var3.getEnchants().keySet().iterator();

            while(var6.hasNext()) {
               Enchantment var5 = (Enchantment)var6.next();
               String var7 = this.plugin.getCM().getDefaultEnchantName(var5) + " " + Utils.IntegerToRomanNumeral(var3.getEnchantLevel(var5));
               var4.add(var2, var7);
            }

            var3.setLore(var4);
            var1.setItemMeta(var3);
         }

         var1 = this.replaceLore(var1, "ENCHANTS", "delz");
         return var1;
      }
   }

   public ItemStack replaceDamageTypes(ItemStack var1, TierManager.Tier var2, double var3) {
      int var5 = var1.getItemMeta().getLore().indexOf("%DAMAGE_TYPES%");
      if (var5 < 0) {
         return var1;
      } else if (ItemUtils.isWeapon(var1) && !var2.getDamageTypes().isEmpty()) {
         Iterator var7 = var2.getDamageTypes().keySet().iterator();

         while(var7.hasNext()) {
            DamageType var6 = (DamageType)var7.next();
            String var8 = (String)var2.getDamageTypes().get(var6);
            double var9 = Double.parseDouble(var8.split(":")[0]);
            if (Utils.getRandDouble(0.0D, 100.0D) <= var9) {
               if (var2.getLevelScaleBlack().contains(var6.getId())) {
                  var3 = 1.0D;
               }

               double var11 = Double.parseDouble(var8.split(":")[1]) * var3;
               double var13 = Double.parseDouble(var8.split(":")[2]) * var3;
               double var15 = Utils.round3(Utils.getRandDouble(var11, var13));
               double var17 = Utils.round3(Utils.getRandDouble(var11, var13));
               var1 = ItemAPI.addDamageType(var1, var6, var15, var17, var5);
            }
         }

         var1 = this.replaceLore(var1, "DAMAGE_TYPES", "delz");
         return var1;
      } else {
         return this.replaceLore(var1, "DAMAGE_TYPES", "delz");
      }
   }

   public ItemStack replaceArmorTypes(ItemStack var1, TierManager.Tier var2, double var3) {
      int var5 = var1.getItemMeta().getLore().indexOf("%ARMOR_TYPES%");
      if (var5 < 0) {
         this.replaceLore(var1, "ARMOR_TYPES", "delz");
      }

      if (ItemUtils.isArmor(var1) && !var2.getArmorTypes().isEmpty()) {
         Iterator var7 = var2.getArmorTypes().keySet().iterator();

         while(var7.hasNext()) {
            ArmorType var6 = (ArmorType)var7.next();
            String var8 = (String)var2.getArmorTypes().get(var6);
            double var9 = Double.parseDouble(var8.split(":")[0]);
            if (Utils.getRandDouble(0.0D, 100.0D) <= var9) {
               if (var2.getLevelScaleBlack().contains(var6.getId())) {
                  var3 = 1.0D;
               }

               double var11 = Double.parseDouble(var8.split(":")[1]) * var3;
               double var13 = Double.parseDouble(var8.split(":")[2]) * var3;
               double var15 = Utils.round3(Utils.getRandDouble(var11, var13));
               var1 = ItemAPI.addDefenseType(var1, var6, var15, var5);
            }
         }

         var1 = this.replaceLore(var1, "ARMOR_TYPES", "delz");
         return var1;
      } else {
         return this.replaceLore(var1, "ARMOR_TYPES", "delz");
      }
   }

   public ItemStack replaceAmmoTypes(ItemStack var1, TierManager.Tier var2) {
      int var3 = var1.getItemMeta().getLore().indexOf("%AMMO_TYPE%");
      if (var3 < 0) {
         return var1;
      } else if (var1.getType() == Material.BOW && !var2.getDamageTypes().isEmpty()) {
         AmmoType var4 = AmmoType.ARROW;
         Iterator var6 = var2.getAmmoTypes().keySet().iterator();

         while(var6.hasNext()) {
            AmmoType var5 = (AmmoType)var6.next();
            double var7 = (Double)var2.getAmmoTypes().get(var5);
            if (Utils.getRandDouble(0.0D, 100.0D) <= var7) {
               var4 = var5;
               break;
            }
         }

         var1 = ItemAPI.setAmmoType(var1, var4, var3);
         var1 = this.replaceLore(var1, "AMMO_TYPE", "delz");
         return var1;
      } else {
         return this.replaceLore(var1, "AMMO_TYPE", "delz");
      }
   }

   public ItemStack replaceClass(ItemStack var1, TierManager.Tier var2) {
      if (this.plugin.getHM().getClassPlugin() != Hook.NONE) {
         String var3 = "";
         String var4 = this.plugin.getCM().getCFG().getStrClassColor();
         String var5 = this.plugin.getCM().getCFG().getStrClassSeparator();

         String var6;
         for(Iterator var7 = var2.getClasses().iterator(); var7.hasNext(); var3 = var3 + var4 + var6 + var5) {
            var6 = (String)var7.next();
         }

         if (var3.length() > 3) {
            var3 = var3.substring(0, var3.length() - 3);
         }

         if (!var3.isEmpty()) {
            return this.replaceLore(var1, "CLASS", this.plugin.getCM().getCFG().getStrClass() + var3);
         }
      }

      return this.replaceLore(var1, "CLASS", "delz");
   }

   public ItemStack replaceLevel(ItemStack var1, int var2) {
      String var3 = this.plugin.getCM().getCFG().getStrLevel().replace("%n", String.valueOf(var2));
      return this.replaceLore(var1, "LEVEL", var3);
   }

   public ItemStack replaceSoul(ItemStack var1) {
      return this.replaceLore(var1, "SOULBOUND", this.plugin.getMM().getSoulboundManager().getSoulString());
   }

   public ItemStack replaceUntrade(ItemStack var1) {
      return this.replaceLore(var1, "SOULBOUND", this.plugin.getMM().getSoulboundManager().getUntradeString());
   }

   public ItemStack replaceSlots(ItemStack var1, TierManager.Tier var2) {
      Iterator var4 = var2.getSlots().keySet().iterator();

      while(true) {
         SlotType var3;
         int var8;
         int var10;
         String var12;
         do {
            if (!var4.hasNext()) {
               return var1;
            }

            var3 = (SlotType)var4.next();
            String var5 = (String)var2.getSlots().get(var3);
            double var6 = Double.parseDouble(var5.split(":")[0]);
            var8 = 0;
            if (Utils.getRandDouble(0.0D, 100.0D) <= var6) {
               int var9 = Integer.parseInt(var5.split(":")[1]);
               var10 = Integer.parseInt(var5.split(":")[2]);
               var8 = Utils.randInt(var9, var10);
            }

            var12 = "delz";
            if (var8 > 0 && var3.getModule() != null && var3.getModule().isActive()) {
               var12 = var3.getHeader();
            }

            var10 = var1.getItemMeta().getLore().indexOf("%" + var3.name() + "%") + 1;
         } while(var10 == -1);

         var1 = this.replaceLore(var1, var3.name(), var12);

         for(int var11 = 0; var11 < var8; ++var11) {
            var1 = ItemAPI.addDivineSlot(var1, var3, var10);
         }
      }
   }

   public ItemStack setMetaFlags(ItemStack var1, TierManager.Tier var2) {
      ItemMeta var3 = var1.getItemMeta();
      if (var3 == null) {
         return var1;
      } else {
         var3.addItemFlags((ItemFlag[])var2.getFlags().toArray(new ItemFlag[var2.getFlags().size()]));
         var1.setItemMeta(var3);
         return var1;
      }
   }

   public ItemStack replaceAttributes(ItemStack var1, TierManager.Tier var2, double var3) {
      HashSet var5 = new HashSet(var2.getAttributes().keySet());
      int var6 = 0;
      int var7 = 0;
      Iterator var9 = var5.iterator();

      ItemStat var8;
      while(var9.hasNext()) {
         var8 = (ItemStat)var9.next();
         boolean var10 = true;
         if (var8.getType() == ItemStat.ItemType.BOTH) {
            if (!Resources.getAllMaterials().contains(var1.getType())) {
               var1 = this.replaceLore(var1, var8.name(), "delz");
               var10 = false;
            }
         } else if (var8.getType() == ItemStat.ItemType.ARMOR) {
            if (!this.plugin.getCM().getCFG().getArmors().contains(var1.getType())) {
               var1 = this.replaceLore(var1, var8.name(), "delz");
               var10 = false;
            }
         } else if (var8.getType() == ItemStat.ItemType.WEAPON && !ItemUtils.isWeapon(var1)) {
            var1 = this.replaceLore(var1, var8.name(), "delz");
            var10 = false;
         }

         double var11 = var3;
         if (var2.getLevelScaleBlack().contains(var8.name())) {
            var11 = 1.0D;
         }

         String var13 = (String)var2.getAttributes().get(var8);
         double var17;
         double var19;
         double var21;
         double var23;
         if ((var2.getMaxAttributes() != 0 && var6 < var2.getMaxAttributes() || var2.getMaxAttributes() == -1) && var10 && !ItemAPI.hasAttribute(var1, var8)) {
            int var14 = var1.getItemMeta().getLore().indexOf("%" + var8.name() + "%");
            if (var14 < 0) {
               continue;
            }

            double var15 = Double.parseDouble(var13.split("!")[0].split(":")[0]);
            if (Utils.getRandDouble(0.0D, 100.0D) <= var15) {
               var17 = Double.parseDouble(var13.split("!")[0].split(":")[1]) * var11;
               var19 = Double.parseDouble(var13.split("!")[0].split(":")[2]) * var11;
               var21 = Utils.round3(Utils.getRandDouble(var17, var19));
               var23 = Utils.round3(Utils.getRandDouble(var17, var19));
               var1 = ItemAPI.addAttribute(var1, var8, false, String.valueOf(var21), String.valueOf(var23), var14);
               if (var2.getMaxAttributes() > 0) {
                  ++var6;
               }
            }
         }

         ItemStat var29 = null;
         if (ItemAPI.hasAttribute(var1, ItemStat.CRITICAL_DAMAGE) && !ItemAPI.hasAttribute(var1, ItemStat.CRITICAL_RATE)) {
            var29 = ItemStat.CRITICAL_RATE;
         } else if (ItemAPI.hasAttribute(var1, ItemStat.CRITICAL_RATE) && !ItemAPI.hasAttribute(var1, ItemStat.CRITICAL_DAMAGE)) {
            var29 = ItemStat.CRITICAL_DAMAGE;
         } else if (ItemAPI.hasAttribute(var1, ItemStat.BLOCK_DAMAGE) && !ItemAPI.hasAttribute(var1, ItemStat.BLOCK_RATE)) {
            var29 = ItemStat.BLOCK_RATE;
         } else if (ItemAPI.hasAttribute(var1, ItemStat.BLOCK_RATE) && !ItemAPI.hasAttribute(var1, ItemStat.BLOCK_DAMAGE)) {
            var29 = ItemStat.BLOCK_DAMAGE;
         }

         if (var29 != null) {
            String var30 = (String)var2.getAttributes().get(var29);
            int var16 = var1.getItemMeta().getLore().indexOf("%" + var29.name() + "%");
            var17 = Double.parseDouble(var30.split("!")[0].split(":")[1]) * var11;
            var19 = Double.parseDouble(var30.split("!")[0].split(":")[2]) * var11;
            var21 = Utils.round3(Utils.getRandDouble(var17, var19));
            var23 = Utils.round3(Utils.getRandDouble(var17, var19));
            var1 = ItemAPI.addAttribute(var1, var29, false, String.valueOf(var21), String.valueOf(var23), var16);
         }
      }

      for(var9 = var5.iterator(); var9.hasNext(); var1 = this.replaceLore(var1, var8.name(), "delz")) {
         var8 = (ItemStat)var9.next();
      }

      int var25 = var1.getItemMeta().getLore().indexOf("%BONUS_STATS%");
      Iterator var27 = var5.iterator();

      while(true) {
         ItemStat var26;
         do {
            if (!var27.hasNext()) {
               var1 = this.replaceLore(var1, "BONUS_STATS", "delz");
               return var1;
            }

            var26 = (ItemStat)var27.next();
         } while((var2.getMaxBonuses() == 0 || var7 >= var2.getMaxBonuses()) && var2.getMaxBonuses() != -1);

         if (var25 != -1) {
            String var28 = (String)var2.getAttributes().get(var26);
            double var12 = Double.parseDouble(var28.split("!")[1].split(":")[0]);
            if (Utils.getRandDouble(0.0D, 100.0D) <= var12) {
               double var31 = var3;
               if (var2.getLevelScaleBlack().contains(var26.name())) {
                  var31 = 1.0D;
               }

               double var32 = Double.parseDouble(var28.split("!")[1].split(":")[1]) * var31;
               double var18 = Double.parseDouble(var28.split("!")[1].split(":")[2]) * var31;
               double var20 = Utils.round3(Utils.getRandDoubleNega(var32, var18));
               double var22 = Utils.round3(Utils.getRandDoubleNega(var32, var18));
               var1 = ItemAPI.addAttribute(var1, var26, true, String.valueOf(var20), String.valueOf(var22), var25);
               if (var2.getMaxBonuses() > 0) {
                  ++var7;
               }
            }
         }
      }
   }

   public ItemStack replaceLore(ItemStack var1, String var2, String var3) {
      ItemMeta var4 = var1.getItemMeta();
      List var5 = var4.getLore();
      if (var5 == null) {
         return var1;
      } else {
         String var6 = "%" + var2.toUpperCase() + "%";
         boolean var7 = false;
         Iterator var9 = var5.iterator();

         while(var9.hasNext()) {
            String var8 = (String)var9.next();
            if (var8.contains(var6)) {
               int var10 = var5.indexOf(var8);
               var5.remove(var10);
               if (!var3.equals("delz") && !var3.equals("")) {
                  var5.add(var10, var8.replace(var6, var3));
               }
               break;
            }
         }

         var4.setLore(var5);
         var1.setItemMeta(var4);
         return var1;
      }
   }

   public Collection<TierManager.Tier> getTiers() {
      return this.tiers.values();
   }

   public List<String> getTierNames() {
      ArrayList var1 = new ArrayList();
      Iterator var3 = this.getTiers().iterator();

      while(var3.hasNext()) {
         TierManager.Tier var2 = (TierManager.Tier)var3.next();
         var1.add(var2.getId());
      }

      return var1;
   }

   public TierManager.Tier getTierById(String var1) {
      return var1.equalsIgnoreCase("random") ? (TierManager.Tier)(new ArrayList(this.getTiers())).get(this.r.nextInt(this.getTiers().size())) : (TierManager.Tier)this.tiers.get(var1.toLowerCase());
   }

   public boolean isTiered(ItemStack var1) {
      return (new NBTItem(var1)).hasKey("TIER");
   }

   public String getTierId(ItemStack var1) {
      return (new NBTItem(var1)).getString("TIER");
   }

   public class Tier {
      private String t_id;
      private String t_name;
      private String t_color;
      private boolean bc;
      private boolean equip;
      private String i_metaname;
      private List<String> i_lore;
      private boolean i_c_rand;
      private Color i_c_value;
      private boolean mat_reverse;
      private List<Material> mat_list;
      private boolean data_reverse;
      private boolean data_unbreak;
      private List<Integer> data_list;
      private HashMap<String, List<Integer>> data_spec;
      private int ench_min;
      private int ench_max;
      private boolean ench_safe;
      private HashMap<Enchantment, String> ench_list;
      private List<ItemFlag> flags;
      private HashMap<DamageType, String> dtypes;
      private HashMap<ArmorType, String> armtypes;
      private HashMap<AmmoType, Double> atypes;
      private boolean rest_soul;
      private boolean rest_untrade;
      private String rest_level;
      private double rest_level_scale;
      private List<String> rest_level_scale_black;
      private List<String> rest_class;
      private int max_att;
      private int max_bonus;
      private HashMap<ItemStat, String> att;
      private HashMap<SlotType, String> slots;
      private HashMap<ResourceType, List<String>> source;

      public Tier(String var2, String var3, String var4, boolean var5, boolean var6, String var7, List<String> var8, boolean var9, Color var10, boolean var11, List<Material> var12, boolean var13, boolean var14, List<Integer> var15, HashMap<String, List<Integer>> var16, int var17, int var18, boolean var19, HashMap<Enchantment, String> var20, List<ItemFlag> var21, HashMap<DamageType, String> var22, HashMap<ArmorType, String> var23, HashMap<AmmoType, Double> var24, boolean var25, boolean var26, String var27, double var28, List<String> var30, List<String> var31, int var32, int var33, HashMap<ItemStat, String> var34, HashMap<SlotType, String> var35, HashMap<ResourceType, List<String>> var36) {
         this.setId(var2);
         this.setName(var3);
         this.setColor(var4);
         this.setBroadcast(var5);
         this.setEquipOnEntity(var6);
         this.setMetaName(var7);
         this.setLore(var8);
         this.setRandomLeatherColor(var9);
         this.setLeatherColor(var10);
         this.setMaterialReversed(var11);
         this.setMaterials(var12);
         this.setDataReversed(var13);
         this.setDataUnbreak(var14);
         this.setDatas(var15);
         this.setDataSpecial(var16);
         this.setMinEnchantments(var17);
         this.setMaxEnchantments(var18);
         this.setSafeEnchant(var19);
         this.setEnchantments(var20);
         this.setFlags(var21);
         this.setDamageTypes(var22);
         this.setArmorTypes(var23);
         this.setAmmoTypes(var24);
         this.setNeedSoul(var25);
         this.setNonTrade(var26);
         this.setLevels(var27);
         this.setLevelScale(var28);
         this.setLevelScaleBlack(var30);
         this.setClasses(var31);
         this.setMaxAttributes(var32);
         this.setMaxBonuses(var33);
         this.setAttributes(var34);
         this.setSlots(var35);
         this.setSource(var36);
      }

      public String getId() {
         return this.t_id;
      }

      public void setId(String var1) {
         this.t_id = var1;
      }

      public String getName() {
         return this.t_name;
      }

      public void setName(String var1) {
         this.t_name = var1;
      }

      public String getColor() {
         return this.t_color;
      }

      public void setColor(String var1) {
         this.t_color = var1;
      }

      public boolean isBroadcast() {
         return this.bc;
      }

      public void setBroadcast(boolean var1) {
         this.bc = var1;
      }

      public boolean isEquipOnEntity() {
         return this.equip;
      }

      public void setEquipOnEntity(boolean var1) {
         this.equip = var1;
      }

      public String getMetaName() {
         return this.i_metaname;
      }

      public void setMetaName(String var1) {
         this.i_metaname = var1;
      }

      public List<String> getLore() {
         return this.i_lore;
      }

      public void setLore(List<String> var1) {
         this.i_lore = var1;
      }

      public boolean isRandomLeatherColor() {
         return this.i_c_rand;
      }

      public void setRandomLeatherColor(boolean var1) {
         this.i_c_rand = var1;
      }

      public Color getLeatherColor() {
         return this.i_c_value;
      }

      public void setLeatherColor(Color var1) {
         this.i_c_value = var1;
      }

      public boolean isMaterialReversed() {
         return this.mat_reverse;
      }

      public void setMaterialReversed(boolean var1) {
         this.mat_reverse = var1;
      }

      public List<Material> getMaterials() {
         return this.mat_list;
      }

      public void setMaterials(List<Material> var1) {
         this.mat_list = var1;
      }

      public boolean isDataReversed() {
         return this.data_reverse;
      }

      public void setDataReversed(boolean var1) {
         this.data_reverse = var1;
      }

      public boolean isDataUnbreak() {
         return this.data_unbreak;
      }

      public void setDataUnbreak(boolean var1) {
         this.data_unbreak = var1;
      }

      public List<Integer> getDatas() {
         return this.data_list;
      }

      public void setDatas(List<Integer> var1) {
         this.data_list = var1;
      }

      public HashMap<String, List<Integer>> getDataSpecial() {
         return this.data_spec;
      }

      public void setDataSpecial(HashMap<String, List<Integer>> var1) {
         this.data_spec = var1;
      }

      public int getMinEnchantments() {
         return this.ench_min;
      }

      public void setMinEnchantments(int var1) {
         this.ench_min = var1;
      }

      public int getMaxEnchantments() {
         return this.ench_max;
      }

      public void setMaxEnchantments(int var1) {
         this.ench_max = var1;
      }

      public boolean isSafeEnchant() {
         return this.ench_safe;
      }

      public void setSafeEnchant(boolean var1) {
         this.ench_safe = var1;
      }

      public HashMap<Enchantment, String> getEnchantments() {
         return this.ench_list;
      }

      public void setEnchantments(HashMap<Enchantment, String> var1) {
         this.ench_list = var1;
      }

      public List<ItemFlag> getFlags() {
         return this.flags;
      }

      public void setFlags(List<ItemFlag> var1) {
         this.flags = var1;
      }

      public HashMap<DamageType, String> getDamageTypes() {
         return this.dtypes;
      }

      public void setDamageTypes(HashMap<DamageType, String> var1) {
         this.dtypes = var1;
      }

      public HashMap<ArmorType, String> getArmorTypes() {
         return this.armtypes;
      }

      public void setArmorTypes(HashMap<ArmorType, String> var1) {
         this.armtypes = var1;
      }

      public HashMap<AmmoType, Double> getAmmoTypes() {
         return this.atypes;
      }

      public void setAmmoTypes(HashMap<AmmoType, Double> var1) {
         this.atypes = var1;
      }

      public boolean isNeedSoul() {
         return this.rest_soul;
      }

      public void setNeedSoul(boolean var1) {
         this.rest_soul = var1;
      }

      public boolean isNonTrade() {
         return this.rest_untrade;
      }

      public void setNonTrade(boolean var1) {
         this.rest_untrade = var1;
      }

      public String getLevels() {
         return this.rest_level;
      }

      public void setLevels(String var1) {
         this.rest_level = var1;
      }

      public double getLevelScale() {
         return this.rest_level_scale;
      }

      public void setLevelScale(double var1) {
         this.rest_level_scale = var1;
      }

      public List<String> getLevelScaleBlack() {
         return this.rest_level_scale_black;
      }

      public void setLevelScaleBlack(List<String> var1) {
         this.rest_level_scale_black = var1;
      }

      public List<String> getClasses() {
         return this.rest_class;
      }

      public void setClasses(List<String> var1) {
         this.rest_class = var1;
      }

      public int getMaxAttributes() {
         return this.max_att;
      }

      public void setMaxAttributes(int var1) {
         this.max_att = var1;
      }

      public int getMaxBonuses() {
         return this.max_bonus;
      }

      public void setMaxBonuses(int var1) {
         this.max_bonus = var1;
      }

      public HashMap<ItemStat, String> getAttributes() {
         return this.att;
      }

      public void setAttributes(HashMap<ItemStat, String> var1) {
         this.att = var1;
      }

      public HashMap<SlotType, String> getSlots() {
         return this.slots;
      }

      public void setSlots(HashMap<SlotType, String> var1) {
         this.slots = var1;
      }

      public HashMap<ResourceType, List<String>> getSource() {
         return this.source;
      }

      public void setSource(HashMap<ResourceType, List<String>> var1) {
         this.source = var1;
      }

      public ItemStack create(int var1, Material var2) {
         ItemStack var3 = new ItemStack(Material.STONE_SWORD);
         if (this.getMaterials().size() <= 0) {
            return var3;
         } else {
            if (var2 != null && this.getMaterials().contains(var2)) {
               var3.setType(var2);
            } else {
               var3.setType((Material)this.getMaterials().get(TierManager.this.r.nextInt(this.getMaterials().size())));
            }

            ItemMeta var4 = var3.getItemMeta();
            List var5 = this.getDatas();
            if (this.getDataSpecial().containsKey(var3.getType().name())) {
               var5 = (List)this.getDataSpecial().get(var3.getType().name());
            }

            if (!var5.isEmpty()) {
               if (this.isDataUnbreak()) {
                  var4.spigot().setUnbreakable(true);
               }

               if (this.isDataReversed()) {
                  var3.setDurability((short)(Integer)var5.get(TierManager.this.r.nextInt(var5.size())));
               } else {
                  int var6;
                  for(var6 = Utils.randInt(1, var3.getType().getMaxDurability()); var5.contains(var6); var6 = Utils.randInt(1, var3.getType().getMaxDurability())) {
                  }

                  var3.setDurability((short)var6);
               }
            }

            var4.setLore(this.getLore());
            String var38 = var3.getType().name();
            String var7 = "";
            String var8 = "";
            String var9 = "";
            String var10 = "";
            String var11 = "";
            String var12 = "";
            String var13 = "";
            List var14 = (List)this.getSource().get(ResourceType.PREFIX);
            if (!var14.isEmpty()) {
               var7 = (String)var14.get(TierManager.this.r.nextInt(var14.size()));
            }

            List var15 = (List)this.getSource().get(ResourceType.SUFFIX);
            if (!var15.isEmpty()) {
               var8 = (String)var15.get(TierManager.this.r.nextInt(var15.size()));
            }

            List var16 = Resources.getSourceByFullType(ResourceType.PREFIX, var38);
            List var17 = Resources.getSourceByFullType(ResourceType.SUFFIX, var38);
            if (var16.size() > 0) {
               var10 = (String)var16.get(TierManager.this.r.nextInt(var16.size()));
            }

            if (var17.size() > 0) {
               var11 = (String)var17.get(TierManager.this.r.nextInt(var17.size()));
            }

            List var18 = Resources.getSourceByHalfType(ResourceType.PREFIX, var38);
            List var19 = Resources.getSourceByHalfType(ResourceType.SUFFIX, var38);
            if (var18 != null && var18.size() > 0) {
               var12 = (String)var18.get(TierManager.this.r.nextInt(var18.size()));
            }

            if (var19 != null && var19.size() > 0) {
               var13 = (String)var19.get(TierManager.this.r.nextInt(var19.size()));
            }

            if (var38.split("_").length == 2) {
               var9 = Lang.getHalfType(var3.getType());
            } else {
               var9 = TierManager.this.plugin.getCM().getDefaultItemName(var3);
            }

            String var20 = this.getMetaName().replace("%itemtype%", var9).replace("%suffix_tier%", var8).replace("%prefix_tier%", var7).replace("%prefix_type%", var12).replace("%suffix_type%", var13).replace("%prefix_material%", var10).replace("%suffix_material%", var11).replace("%c%", "");
            var20 = var20.trim().replaceAll("\\s+", " ");
            var20 = this.getColor() + var20;
            var4.setDisplayName(var20);
            var3.setItemMeta(var4);
            if (var3.getType().name().startsWith("LEATHER_")) {
               LeatherArmorMeta var21 = (LeatherArmorMeta)var3.getItemMeta();
               if (this.isRandomLeatherColor()) {
                  var21.setColor(Color.fromRGB(TierManager.this.r.nextInt(255), TierManager.this.r.nextInt(255), TierManager.this.r.nextInt(255)));
               } else {
                  var21.setColor(this.getLeatherColor());
               }

               var3.setItemMeta(var21);
            } else if (var3.getType() == Material.SHIELD) {
               var4 = var3.getItemMeta();
               BlockStateMeta var39 = (BlockStateMeta)var4;
               if (var39 != null && var39.hasBlockState() && var39.getBlockState() != null) {
                  Banner var22 = (Banner)var39.getBlockState();
                  DyeColor[] var23 = DyeColor.values();
                  DyeColor var24 = var23[TierManager.this.r.nextInt(var23.length - 1)];
                  var22.setBaseColor(var24);
                  PatternType[] var25 = PatternType.values();
                  PatternType var26 = var25[TierManager.this.r.nextInt(var25.length - 1)];
                  DyeColor[] var27 = DyeColor.values();
                  DyeColor var28 = var27[TierManager.this.r.nextInt(var27.length - 1)];
                  var22.addPattern(new Pattern(var28, var26));
                  var22.update();
                  var39.setBlockState(var22);
                  var3.setItemMeta(var39);
               }
            }

            String[] var40 = this.getLevels().split("-");
            int var41 = 1;
            int var42 = 1;

            try {
               var41 = Integer.parseInt(var40[0]);
               var42 = Integer.parseInt(var40[1]);
            } catch (ArrayIndexOutOfBoundsException | NumberFormatException var37) {
            }

            if (var1 > 0 && var1 > var42) {
               var1 = var42;
            }

            if (var1 > 0 && var1 < var41) {
               var1 = var41;
            }

            if (var1 <= 0) {
               var1 = TierManager.this.r.nextInt(var42 - var41 + 1) + var41;
            }

            double var43 = (this.getLevelScale() * 100.0D - 100.0D) * (double)var1 / 100.0D + 1.0D;
            int var44 = this.getMinEnchantments();
            int var45 = this.getMaxEnchantments();
            if (var44 >= 0 && var45 >= 0) {
               int var46 = TierManager.this.r.nextInt(var45 - var44 + 1) + var44;
               ArrayList var29 = new ArrayList();
               Iterator var31 = this.getEnchantments().keySet().iterator();

               while(var31.hasNext()) {
                  Enchantment var30 = (Enchantment)var31.next();
                  var29.add(var30);
               }

               for(int var50 = 0; var50 < var46 && !var29.isEmpty(); ++var50) {
                  Enchantment var51 = (Enchantment)var29.get(TierManager.this.r.nextInt(var29.size()));
                  double var32 = (double)Math.max(1, Integer.parseInt(((String)this.getEnchantments().get(var51)).split(":")[0]));
                  double var34 = (double)Math.max(1, Integer.parseInt(((String)this.getEnchantments().get(var51)).split(":")[1]));
                  int var36 = Utils.randInt((int)var32, (int)var34) - 1;
                  if (this.isSafeEnchant()) {
                     if (var51.canEnchantItem(var3)) {
                        var3.addUnsafeEnchantment(var51, var36);
                     } else {
                        --var50;
                     }
                  } else {
                     var3.addUnsafeEnchantment(var51, var36);
                  }

                  var29.remove(var51);
               }
            }

            var3 = TierManager.this.replaceDamageTypes(var3, this, var43);
            var3 = TierManager.this.replaceArmorTypes(var3, this, var43);
            var3 = TierManager.this.replaceAmmoTypes(var3, this);
            var3 = TierManager.this.replaceLevel(var3, var1);
            var3 = TierManager.this.replaceClass(var3, this);
            var3 = TierManager.this.replaceEnchants(var3);
            if (TierManager.this.plugin.getMM().getSoulboundManager().isActive()) {
               boolean var47 = this.isNeedSoul();
               boolean var48 = this.isNonTrade();
               if (var47 && var48) {
                  var47 = false;
                  var48 = false;
               }

               if (var47) {
                  var3 = new ItemStack(TierManager.this.replaceSoul(var3));
               } else if (var48) {
                  var3 = new ItemStack(TierManager.this.replaceUntrade(var3));
               } else {
                  var3 = new ItemStack(TierManager.this.replaceLore(var3, "SOULBOUND", "delz"));
               }
            } else {
               var3 = new ItemStack(TierManager.this.replaceLore(var3, "SOULBOUND", "delz"));
            }

            var3 = new ItemStack(TierManager.this.setMetaFlags(var3, this));
            var3 = new ItemStack(TierManager.this.replaceAttributes(var3, this, var43));
            var3 = new ItemStack(TierManager.this.replaceSlots(var3, this));
            String var49;
            if (var3.getType().name().split("_").length == 2) {
               var49 = Lang.getHalfType(var3.getType());
            } else {
               var49 = TierManager.this.plugin.getCM().getDefaultItemName(var3);
            }

            var3 = TierManager.this.replaceSet(var3, this);
            var3 = TierManager.this.replaceLore(var3, "TYPE", var49);
            var3 = TierManager.this.replaceLore(var3, "TIER", this.getName());
            var3 = TierManager.this.replaceLore(var3, "DEFENSE", "delz");
            var3 = TierManager.this.replaceLore(var3, "DAMAGE", "delz");
            var3 = TierManager.this.replaceLore(var3, "POISON_DEFENSE", "delz");
            var3 = TierManager.this.replaceLore(var3, "MAGIC_DEFENSE", "delz");
            var3 = TierManager.this.replaceLore(var3, "FIRE_DEFENSE", "delz");
            var3 = TierManager.this.replaceLore(var3, "WATER_DEFENSE", "delz");
            var3 = TierManager.this.replaceLore(var3, "WIND_DEFENSE", "delz");
            var3 = ItemAPI.addNBTTag(var3, "TIER", this.getId());
            if (ItemUtils.isArmor(var3)) {
               var3 = TierManager.this.plugin.getNMS().setNBTAtt(var3, NBTAttribute.attackDamage, 0.0D);
               var3 = TierManager.this.plugin.getNMS().setNBTAtt(var3, NBTAttribute.armor, ItemAPI.getDefaultDefense(var3));
               var3 = TierManager.this.plugin.getNMS().setNBTAtt(var3, NBTAttribute.armorToughness, ItemAPI.getDefaultToughness(var3));
            }

            return var3;
         }
      }
   }
}
