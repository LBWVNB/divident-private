package su.nightexpress.divineitems.modules.tiers.resources;

import java.util.List;

public class Res {
   private String type;
   private List<String> prefix;
   private List<String> suffix;

   public Res(String var1, List<String> var2, List<String> var3) {
      this.setType(var1);
      this.setPrefixes(var2);
      this.setSuffixes(var3);
   }

   public String getType() {
      return this.type;
   }

   public void setType(String var1) {
      this.type = var1;
   }

   public List<String> getPrefixes() {
      return this.prefix;
   }

   public void setPrefixes(List<String> var1) {
      this.prefix = var1;
   }

   public List<String> getSuffixes() {
      return this.suffix;
   }

   public void setSuffixes(List<String> var1) {
      this.suffix = var1;
   }
}
