package su.nightexpress.divineitems.modules.tiers.resources;

public enum ResourceSubType {
   MATERIAL,
   TYPE,
   TIER;
}
