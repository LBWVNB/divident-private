package su.nightexpress.divineitems.modules.tiers.resources;

public enum ResourceType {
   PREFIX,
   SUFFIX;
}
