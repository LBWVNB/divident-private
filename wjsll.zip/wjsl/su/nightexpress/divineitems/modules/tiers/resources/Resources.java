package su.nightexpress.divineitems.modules.tiers.resources;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import org.bukkit.Material;
import su.nightexpress.divineitems.DivineItems;
import su.nightexpress.divineitems.utils.Files;

public class Resources {
   private static DivineItems plugin;
   private static HashMap<String, Res> res;
   private static HashMap<String, Res> res_half;
   private static Set<Material> mats;

   static {
      plugin = DivineItems.instance;
      res = new HashMap();
      res_half = new HashMap();
      mats = new HashSet();
   }

   public static void setup() {
      mats.addAll(plugin.getCM().getCFG().getWeapons());
      mats.addAll(plugin.getCM().getCFG().getArmors());
      mats.addAll(plugin.getCM().getCFG().getTools());
      setupMissingConfigs(ResourceType.PREFIX);
      setupMissingConfigs(ResourceType.SUFFIX);
      setupResourcesByTypes();
   }

   public static void setupMissingConfigs(ResourceType var0) {
      String var1 = var0.name().toLowerCase() + "es";
      Iterator var3 = Files.getFilesFolder("tiers").iterator();

      File var4;
      while(var3.hasNext()) {
         String var2 = (String)var3.next();
         var4 = new File(plugin.getDataFolder() + "/modules/tiers/resources/names/" + var1 + "/tiers/", var2.toLowerCase().replace(".yml", "") + ".txt");
         if (!var4.exists()) {
            if (plugin.getResource("modules/tiers/resources/names/" + var1 + "/tiers/" + var2.toLowerCase().replace(".yml", "") + ".txt") != null) {
               plugin.saveResource("modules/tiers/resources/names/" + var1 + "/tiers/" + var2.toLowerCase().replace(".yml", "") + ".txt", false);
            } else {
               Files.create(var4);
            }
         }
      }

      var3 = mats.iterator();

      while(var3.hasNext()) {
         Material var9 = (Material)var3.next();
         var4 = new File(plugin.getDataFolder() + "/modules/tiers/resources/names/" + var1 + "/materials/", var9.toString().toLowerCase() + ".txt");
         if (!var4.exists()) {
            if (plugin.getResource("modules/tiers/resources/names/" + var1 + "/materials/" + var9.toString().toLowerCase() + ".txt") != null) {
               plugin.saveResource("modules/tiers/resources/names/" + var1 + "/materials/" + var9.toString().toLowerCase() + ".txt", false);
            } else {
               Files.create(var4);
            }
         }
      }

      Object[] var10 = plugin.getCM().configLang.getConfig().getConfigurationSection("ItemTypes").getKeys(false).toArray();
      Object[] var6 = var10;
      int var5 = var10.length;

      for(int var12 = 0; var12 < var5; ++var12) {
         Object var11 = var6[var12];
         String var7 = var11.toString();
         File var8 = new File(plugin.getDataFolder() + "/modules/tiers/resources/names/" + var1 + "/types/", var7.toLowerCase() + ".txt");
         if (!var8.exists()) {
            Files.create(var8);
         }
      }

   }

   public static List<String> getSource(ResourceType var0, ResourceSubType var1, String var2) {
      ArrayList var3 = new ArrayList();
      String var4 = var0.name().toLowerCase() + "es";
      String var5 = var1.name().toLowerCase() + "s";
      String var6 = plugin.getDataFolder() + "/modules/tiers/resources/names/" + var4 + "/" + var5 + "/" + var2 + ".txt";

      try {
         Throwable var7 = null;
         Object var8 = null;

         try {
            BufferedReader var9 = new BufferedReader(new FileReader(var6));

            String var10;
            try {
               while((var10 = var9.readLine()) != null) {
                  var3.add(var10);
               }
            } finally {
               if (var9 != null) {
                  var9.close();
               }

            }
         } catch (Throwable var18) {
            if (var7 == null) {
               var7 = var18;
            } else if (var7 != var18) {
               var7.addSuppressed(var18);
            }

            throw var7;
         }
      } catch (IOException var19) {
         var19.printStackTrace();
      }

      return var3;
   }

   public static void setupResourcesByTypes() {
      Iterator var1 = mats.iterator();

      while(var1.hasNext()) {
         Material var0 = (Material)var1.next();
         String var2 = var0.name().toLowerCase();
         List var3 = getSource(ResourceType.PREFIX, ResourceSubType.MATERIAL, var2);
         List var4 = getSource(ResourceType.SUFFIX, ResourceSubType.MATERIAL, var2);
         Res var5 = new Res(var2, var3, var4);
         res.put(var2, var5);
      }

      Object[] var9 = plugin.getCM().configLang.getConfig().getConfigurationSection("ItemTypes").getKeys(false).toArray();
      Object[] var13 = var9;
      int var12 = var9.length;

      for(int var11 = 0; var11 < var12; ++var11) {
         Object var10 = var13[var11];
         String var14 = var10.toString().toLowerCase();
         List var6 = getSource(ResourceType.PREFIX, ResourceSubType.TYPE, var14);
         List var7 = getSource(ResourceType.SUFFIX, ResourceSubType.TYPE, var14);
         Res var8 = new Res(var14, var6, var7);
         res_half.put(var14, var8);
      }

   }

   public static List<String> getSourceByFullType(ResourceType var0, String var1) {
      ArrayList var2 = new ArrayList();
      var1 = var1.toLowerCase();
      if (res.containsKey(var1)) {
         return var0 == ResourceType.PREFIX ? ((Res)res.get(var1)).getPrefixes() : ((Res)res.get(var1)).getSuffixes();
      } else {
         return var2;
      }
   }

   public static List<String> getSourceByHalfType(ResourceType var0, String var1) {
      ArrayList var2 = new ArrayList();
      var1 = var1.toLowerCase();
      if (var1.split("_").length > 1) {
         var1 = var1.split("_")[1];
      }

      if (res_half.containsKey(var1)) {
         return var0 == ResourceType.PREFIX ? ((Res)res_half.get(var1)).getPrefixes() : ((Res)res_half.get(var1)).getSuffixes();
      } else {
         return var2;
      }
   }

   public static Set<Material> getAllMaterials() {
      return mats;
   }

   public static void clear() {
      res.clear();
      res_half.clear();
      mats.clear();
   }
}
