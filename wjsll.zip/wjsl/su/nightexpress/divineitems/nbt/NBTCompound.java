package su.nightexpress.divineitems.nbt;

import java.util.Iterator;
import java.util.Set;
import su.nightexpress.divineitems.nbt.utils.MinecraftVersion;

public class NBTCompound {
   private String compundName;
   private NBTCompound parent;

   protected NBTCompound(NBTCompound var1, String var2) {
      this.compundName = var2;
      this.parent = var1;
   }

   public String getName() {
      return this.compundName;
   }

   protected Object getCompound() {
      return this.parent.getCompound();
   }

   protected void setCompound(Object var1) {
      this.parent.setCompound(var1);
   }

   public NBTCompound getParent() {
      return this.parent;
   }

   public void mergeCompound(NBTCompound var1) {
      NBTReflectionUtil.addOtherNBTCompound(this, var1);
   }

   public void setString(String var1, String var2) {
      NBTReflectionUtil.setData(this, ReflectionMethod.COMPOUND_SET_STRING, var1, var2);
   }

   public String getString(String var1) {
      return (String)NBTReflectionUtil.getData(this, ReflectionMethod.COMPOUND_GET_STRING, var1);
   }

   protected String getContent(String var1) {
      return NBTReflectionUtil.getContent(this, var1);
   }

   public void setInteger(String var1, Integer var2) {
      NBTReflectionUtil.setData(this, ReflectionMethod.COMPOUND_SET_INT, var1, var2);
   }

   public Integer getInteger(String var1) {
      return (Integer)NBTReflectionUtil.getData(this, ReflectionMethod.COMPOUND_GET_INT, var1);
   }

   public void setDouble(String var1, Double var2) {
      NBTReflectionUtil.setData(this, ReflectionMethod.COMPOUND_SET_DOUBLE, var1, var2);
   }

   public Double getDouble(String var1) {
      return (Double)NBTReflectionUtil.getData(this, ReflectionMethod.COMPOUND_GET_DOUBLE, var1);
   }

   public void setByte(String var1, Byte var2) {
      NBTReflectionUtil.setData(this, ReflectionMethod.COMPOUND_SET_BYTE, var1, var2);
   }

   public Byte getByte(String var1) {
      return (Byte)NBTReflectionUtil.getData(this, ReflectionMethod.COMPOUND_GET_BYTE, var1);
   }

   public void setShort(String var1, Short var2) {
      NBTReflectionUtil.setData(this, ReflectionMethod.COMPOUND_SET_SHORT, var1, var2);
   }

   public Short getShort(String var1) {
      return (Short)NBTReflectionUtil.getData(this, ReflectionMethod.COMPOUND_GET_SHORT, var1);
   }

   public void setLong(String var1, Long var2) {
      NBTReflectionUtil.setData(this, ReflectionMethod.COMPOUND_SET_LONG, var1, var2);
   }

   public Long getLong(String var1) {
      return (Long)NBTReflectionUtil.getData(this, ReflectionMethod.COMPOUND_GET_LONG, var1);
   }

   public void setFloat(String var1, Float var2) {
      NBTReflectionUtil.setData(this, ReflectionMethod.COMPOUND_SET_FLOAT, var1, var2);
   }

   public Float getFloat(String var1) {
      return (Float)NBTReflectionUtil.getData(this, ReflectionMethod.COMPOUND_GET_FLOAT, var1);
   }

   public void setByteArray(String var1, byte[] var2) {
      NBTReflectionUtil.setData(this, ReflectionMethod.COMPOUND_SET_BYTEARRAY, var1, var2);
   }

   public byte[] getByteArray(String var1) {
      return (byte[])NBTReflectionUtil.getData(this, ReflectionMethod.COMPOUND_GET_BYTEARRAY, var1);
   }

   public void setIntArray(String var1, int[] var2) {
      NBTReflectionUtil.setData(this, ReflectionMethod.COMPOUND_SET_INTARRAY, var1, var2);
   }

   public int[] getIntArray(String var1) {
      return (int[])NBTReflectionUtil.getData(this, ReflectionMethod.COMPOUND_GET_INTARRAY, var1);
   }

   public void setBoolean(String var1, Boolean var2) {
      NBTReflectionUtil.setData(this, ReflectionMethod.COMPOUND_SET_BOOLEAN, var1, var2);
   }

   protected void set(String var1, Object var2) {
      NBTReflectionUtil.set(this, var1, var2);
   }

   public Boolean getBoolean(String var1) {
      return (Boolean)NBTReflectionUtil.getData(this, ReflectionMethod.COMPOUND_GET_BOOLEAN, var1);
   }

   public void setObject(String var1, Object var2) {
      NBTReflectionUtil.setObject(this, var1, var2);
   }

   public <T> T getObject(String var1, Class<T> var2) {
      return NBTReflectionUtil.getObject(this, var1, var2);
   }

   public Boolean hasKey(String var1) {
      return this.getKeys().isEmpty() ? false : (Boolean)NBTReflectionUtil.getData(this, ReflectionMethod.COMPOUND_HAS_KEY, var1);
   }

   public void removeKey(String var1) {
      NBTReflectionUtil.remove(this, var1);
   }

   public Set<String> getKeys() {
      return NBTReflectionUtil.getKeys(this);
   }

   public NBTCompound addCompound(String var1) {
      NBTReflectionUtil.addNBTTagCompound(this, var1);
      return this.getCompound(var1);
   }

   public NBTCompound getCompound(String var1) {
      NBTCompound var2 = new NBTCompound(this, var1);
      return NBTReflectionUtil.valideCompound(var2) ? var2 : null;
   }

   public NBTList getList(String var1, NBTType var2) {
      return NBTReflectionUtil.getList(this, var1, var2);
   }

   public NBTType getType(String var1) {
      return MinecraftVersion.getVersion() == MinecraftVersion.MC1_7_R4 ? NBTType.NBTTagEnd : NBTType.valueOf((Byte)NBTReflectionUtil.getData(this, ReflectionMethod.COMPOUND_GET_TYPE, var1));
   }

   public String toString() {
      StringBuilder var1 = new StringBuilder();
      Iterator var3 = this.getKeys().iterator();

      while(var3.hasNext()) {
         String var2 = (String)var3.next();
         var1.append(this.toString(var2));
      }

      return var1.toString();
   }

   public String toString(String var1) {
      StringBuilder var2 = new StringBuilder();

      for(NBTCompound var3 = this; var3.getParent() != null; var3 = var3.getParent()) {
         var2.append("   ");
      }

      return this.getType(var1) == NBTType.NBTTagCompound ? this.getCompound(var1).toString() : var2 + "-" + var1 + ": " + this.getContent(var1) + System.lineSeparator();
   }

   public String asNBTString() {
      return NBTReflectionUtil.gettoCompount(this.getCompound(), this).toString();
   }
}
