package su.nightexpress.divineitems.nbt;

public class NBTContainer extends NBTCompound {
   private Object nbt;

   public NBTContainer() {
      super((NBTCompound)null, (String)null);
      this.nbt = ObjectCreator.NMS_NBTTAGCOMPOUND.getInstance();
   }

   protected NBTContainer(Object var1) {
      super((NBTCompound)null, (String)null);
      this.nbt = var1;
   }

   public NBTContainer(String var1) {
      super((NBTCompound)null, (String)null);

      try {
         this.nbt = ReflectionMethod.PARSE_NBT.run((Object)null, var1);
      } catch (Exception var3) {
         var3.printStackTrace();
         throw new IllegalArgumentException("Malformed Json: " + var3.getMessage());
      }
   }

   protected Object getCompound() {
      return this.nbt;
   }

   protected void setCompound(Object var1) {
      this.nbt = var1;
   }
}
