package su.nightexpress.divineitems.nbt;

import org.bukkit.entity.Entity;

public class NBTEntity extends NBTCompound {
   private final Entity ent;

   public NBTEntity(Entity var1) {
      super((NBTCompound)null, (String)null);
      this.ent = var1;
   }

   protected Object getCompound() {
      return NBTReflectionUtil.getEntityNBTTagCompound(NBTReflectionUtil.getNMSEntity(this.ent));
   }

   protected void setCompound(Object var1) {
      NBTReflectionUtil.setEntityNBTTag(var1, NBTReflectionUtil.getNMSEntity(this.ent));
   }
}
