package su.nightexpress.divineitems.nbt;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

public class NBTFile extends NBTCompound {
   private final File file;
   private Object nbt;

   public NBTFile(File var1) {
      super((NBTCompound)null, (String)null);
      this.file = var1;
      if (var1.exists()) {
         FileInputStream var2 = new FileInputStream(var1);
         this.nbt = NBTReflectionUtil.readNBTFile(var2);
      } else {
         this.nbt = ObjectCreator.NMS_NBTTAGCOMPOUND.getInstance();
         this.save();
      }

   }

   public void save() {
      if (!this.file.exists()) {
         this.file.getParentFile().mkdirs();
         this.file.createNewFile();
      }

      FileOutputStream var1 = new FileOutputStream(this.file);
      NBTReflectionUtil.saveNBTFile(this.nbt, var1);
   }

   public File getFile() {
      return this.file;
   }

   protected Object getCompound() {
      return this.nbt;
   }

   protected void setCompound(Object var1) {
      this.nbt = var1;
   }
}
