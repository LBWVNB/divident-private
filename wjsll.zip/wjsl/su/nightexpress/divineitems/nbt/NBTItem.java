package su.nightexpress.divineitems.nbt;

import org.bukkit.inventory.ItemStack;

public class NBTItem extends NBTCompound {
   private ItemStack bukkitItem;

   public NBTItem(ItemStack var1) {
      super((NBTCompound)null, (String)null);
      if (var1 == null) {
         throw new NullPointerException("ItemStack can't be null!");
      } else {
         this.bukkitItem = var1.clone();
      }
   }

   protected Object getCompound() {
      return NBTReflectionUtil.getItemRootNBTTagCompound(ReflectionMethod.ITEMSTACK_NMSCOPY.run((Object)null, this.bukkitItem));
   }

   protected void setCompound(Object var1) {
      Object var2 = ReflectionMethod.ITEMSTACK_NMSCOPY.run((Object)null, this.bukkitItem);
      ReflectionMethod.ITEMSTACK_SET_TAG.run(var2, var1);
      this.bukkitItem = (ItemStack)ReflectionMethod.ITEMSTACK_BUKKITMIRROR.run((Object)null, var2);
   }

   public ItemStack getItem() {
      return this.bukkitItem;
   }

   protected void setItem(ItemStack var1) {
      this.bukkitItem = var1;
   }

   public boolean hasNBTData() {
      return this.getCompound() != null;
   }

   public static NBTContainer convertItemtoNBT(ItemStack var0) {
      return NBTReflectionUtil.convertNMSItemtoNBTCompound(ReflectionMethod.ITEMSTACK_NMSCOPY.run((Object)null, var0));
   }

   public static ItemStack convertNBTtoItem(NBTCompound var0) {
      return (ItemStack)ReflectionMethod.ITEMSTACK_BUKKITMIRROR.run((Object)null, NBTReflectionUtil.convertNBTCompoundtoNMSItem(var0));
   }
}
