package su.nightexpress.divineitems.nbt;

import java.lang.reflect.Method;
import su.nightexpress.divineitems.nbt.utils.MethodNames;

public class NBTList {
   private String listName;
   private NBTCompound parent;
   private NBTType type;
   private Object listObject;

   protected NBTList(NBTCompound var1, String var2, NBTType var3, Object var4) {
      this.parent = var1;
      this.listName = var2;
      this.type = var3;
      this.listObject = var4;
      if (var3 != NBTType.NBTTagString && var3 != NBTType.NBTTagCompound) {
         System.err.println("List types != String/Compound are currently not implemented!");
      }

   }

   protected void save() {
      this.parent.set(this.listName, this.listObject);
   }

   public NBTListCompound addCompound() {
      if (this.type != NBTType.NBTTagCompound) {
         (new Throwable("Using Compound method on a non Compound list!")).printStackTrace();
         return null;
      } else {
         try {
            Method var1 = this.listObject.getClass().getMethod("add", ClassWrapper.NMS_NBTBASE.getClazz());
            Object var2 = ClassWrapper.NMS_NBTTAGCOMPOUND.getClazz().newInstance();
            var1.invoke(this.listObject, var2);
            return new NBTListCompound(this, var2);
         } catch (Exception var3) {
            var3.printStackTrace();
            return null;
         }
      }
   }

   public NBTListCompound getCompound(int var1) {
      if (this.type != NBTType.NBTTagCompound) {
         (new Throwable("Using Compound method on a non Compound list!")).printStackTrace();
         return null;
      } else {
         try {
            Method var2 = this.listObject.getClass().getMethod("get", Integer.TYPE);
            Object var3 = var2.invoke(this.listObject, var1);
            return new NBTListCompound(this, var3);
         } catch (Exception var4) {
            var4.printStackTrace();
            return null;
         }
      }
   }

   public String getString(int var1) {
      if (this.type != NBTType.NBTTagString) {
         (new Throwable("Using String method on a non String list!")).printStackTrace();
         return null;
      } else {
         try {
            Method var2 = this.listObject.getClass().getMethod("getString", Integer.TYPE);
            return (String)var2.invoke(this.listObject, var1);
         } catch (Exception var3) {
            var3.printStackTrace();
            return null;
         }
      }
   }

   public void addString(String var1) {
      if (this.type != NBTType.NBTTagString) {
         (new Throwable("Using String method on a non String list!")).printStackTrace();
      } else {
         try {
            Method var2 = this.listObject.getClass().getMethod("add", ClassWrapper.NMS_NBTBASE.getClazz());
            var2.invoke(this.listObject, ClassWrapper.NMS_NBTTAGSTRING.getClazz().getConstructor(String.class).newInstance(var1));
            this.save();
         } catch (Exception var3) {
            var3.printStackTrace();
         }

      }
   }

   public void setString(int var1, String var2) {
      if (this.type != NBTType.NBTTagString) {
         (new Throwable("Using String method on a non String list!")).printStackTrace();
      } else {
         try {
            Method var3 = this.listObject.getClass().getMethod("a", Integer.TYPE, ClassWrapper.NMS_NBTBASE.getClazz());
            var3.invoke(this.listObject, var1, ClassWrapper.NMS_NBTTAGSTRING.getClazz().getConstructor(String.class).newInstance(var2));
            this.save();
         } catch (Exception var4) {
            var4.printStackTrace();
         }

      }
   }

   public void remove(int var1) {
      try {
         Method var2 = this.listObject.getClass().getMethod(MethodNames.getRemoveMethodName(), Integer.TYPE);
         var2.invoke(this.listObject, var1);
         this.save();
      } catch (Exception var3) {
         var3.printStackTrace();
      }

   }

   public int size() {
      try {
         Method var1 = this.listObject.getClass().getMethod("size");
         return (Integer)var1.invoke(this.listObject);
      } catch (Exception var2) {
         var2.printStackTrace();
         return -1;
      }
   }

   public NBTType getType() {
      return this.type;
   }
}
