package su.nightexpress.divineitems.nbt;

import java.util.HashSet;
import java.util.Set;

public class NBTListCompound {
   private NBTList owner;
   private Object compound;

   protected NBTListCompound(NBTList var1, Object var2) {
      this.owner = var1;
      this.compound = var2;
   }

   public void setString(String var1, String var2) {
      if (var2 == null) {
         this.remove(var1);
      } else {
         try {
            this.compound.getClass().getMethod("setString", String.class, String.class).invoke(this.compound, var1, var2);
            this.owner.save();
         } catch (Exception var4) {
            var4.printStackTrace();
         }

      }
   }

   public void setInteger(String var1, int var2) {
      try {
         this.compound.getClass().getMethod("setInt", String.class, Integer.TYPE).invoke(this.compound, var1, var2);
         this.owner.save();
      } catch (Exception var4) {
         var4.printStackTrace();
      }

   }

   public int getInteger(String var1) {
      try {
         return (Integer)this.compound.getClass().getMethod("getInt", String.class).invoke(this.compound, var1);
      } catch (Exception var3) {
         var3.printStackTrace();
         return 0;
      }
   }

   public void setDouble(String var1, double var2) {
      try {
         this.compound.getClass().getMethod("setDouble", String.class, Double.TYPE).invoke(this.compound, var1, var2);
         this.owner.save();
      } catch (Exception var5) {
         var5.printStackTrace();
      }

   }

   public double getDouble(String var1) {
      try {
         return (Double)this.compound.getClass().getMethod("getDouble", String.class).invoke(this.compound, var1);
      } catch (Exception var3) {
         var3.printStackTrace();
         return 0.0D;
      }
   }

   public String getString(String var1) {
      try {
         return (String)this.compound.getClass().getMethod("getString", String.class).invoke(this.compound, var1);
      } catch (Exception var3) {
         var3.printStackTrace();
         return "";
      }
   }

   public boolean hasKey(String var1) {
      try {
         return (Boolean)this.compound.getClass().getMethod("hasKey", String.class).invoke(this.compound, var1);
      } catch (Exception var3) {
         var3.printStackTrace();
         return false;
      }
   }

   public Set<String> getKeys() {
      try {
         return (Set)ReflectionMethod.LISTCOMPOUND_GET_KEYS.run(this.compound);
      } catch (Exception var2) {
         var2.printStackTrace();
         return new HashSet();
      }
   }

   public void remove(String var1) {
      try {
         this.compound.getClass().getMethod("remove", String.class).invoke(this.compound, var1);
      } catch (Exception var3) {
         var3.printStackTrace();
      }

   }
}
