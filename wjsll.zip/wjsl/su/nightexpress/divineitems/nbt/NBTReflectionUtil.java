package su.nightexpress.divineitems.nbt;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Method;
import java.util.Set;
import java.util.Stack;
import org.bukkit.block.BlockState;
import org.bukkit.entity.Entity;
import su.nightexpress.divineitems.nbt.utils.GsonWrapper;
import su.nightexpress.divineitems.nbt.utils.MethodNames;
import su.nightexpress.divineitems.nbt.utils.MinecraftVersion;

public class NBTReflectionUtil {
   public static Object getNMSEntity(Entity var0) {
      Class var1 = ClassWrapper.CRAFT_ENTITY.getClazz();

      try {
         Method var2 = var1.getMethod("getHandle");
         return var2.invoke(var1.cast(var0));
      } catch (Exception var3) {
         var3.printStackTrace();
         return null;
      }
   }

   public static Object readNBTFile(FileInputStream var0) {
      Class var1 = ClassWrapper.NMS_NBTCOMPRESSEDSTREAMTOOLS.getClazz();

      try {
         Method var2 = var1.getMethod("a", InputStream.class);
         return var2.invoke(var1, var0);
      } catch (Exception var3) {
         var3.printStackTrace();
         return null;
      }
   }

   public static Object saveNBTFile(Object var0, FileOutputStream var1) {
      Class var2 = ClassWrapper.NMS_NBTCOMPRESSEDSTREAMTOOLS.getClazz();

      try {
         Method var3 = var2.getMethod("a", ClassWrapper.NMS_NBTTAGCOMPOUND.getClazz(), OutputStream.class);
         return var3.invoke(var2, var0, var1);
      } catch (Exception var4) {
         var4.printStackTrace();
         return null;
      }
   }

   public static Object getItemRootNBTTagCompound(Object var0) {
      Class var1 = var0.getClass();

      try {
         Method var2 = var1.getMethod("getTag");
         Object var3 = var2.invoke(var0);
         return var3;
      } catch (Exception var4) {
         var4.printStackTrace();
         return null;
      }
   }

   public static Object convertNBTCompoundtoNMSItem(NBTCompound var0) {
      Class var1 = ClassWrapper.NMS_ITEMSTACK.getClazz();

      try {
         Object var2 = var1.getConstructor(ClassWrapper.NMS_NBTTAGCOMPOUND.getClazz()).newInstance(var0.getCompound());
         return var2;
      } catch (Exception var3) {
         var3.printStackTrace();
         return null;
      }
   }

   public static NBTContainer convertNMSItemtoNBTCompound(Object var0) {
      Class var1 = var0.getClass();

      try {
         Method var2 = var1.getMethod("save", ClassWrapper.NMS_NBTTAGCOMPOUND.getClazz());
         Object var3 = var2.invoke(var0, ObjectCreator.NMS_NBTTAGCOMPOUND.getInstance());
         return new NBTContainer(var3);
      } catch (Exception var4) {
         var4.printStackTrace();
         return null;
      }
   }

   public static Object getEntityNBTTagCompound(Object var0) {
      Class var1 = var0.getClass();

      try {
         Method var2 = var1.getMethod(MethodNames.getEntityNbtGetterMethodName(), ClassWrapper.NMS_NBTTAGCOMPOUND.getClazz());
         Object var3 = ClassWrapper.NMS_NBTTAGCOMPOUND.getClazz().newInstance();
         Object var4 = var2.invoke(var0, var3);
         if (var4 == null) {
            var4 = var3;
         }

         return var4;
      } catch (Exception var5) {
         var5.printStackTrace();
         return null;
      }
   }

   public static Object setEntityNBTTag(Object var0, Object var1) {
      try {
         Method var2 = var1.getClass().getMethod(MethodNames.getEntityNbtSetterMethodName(), ClassWrapper.NMS_NBTTAGCOMPOUND.getClazz());
         var2.invoke(var1, var0);
         return var1;
      } catch (Exception var3) {
         var3.printStackTrace();
         return null;
      }
   }

   public static Object getTileEntityNBTTagCompound(BlockState var0) {
      try {
         Object var1 = ObjectCreator.NMS_BLOCKPOSITION.getInstance(var0.getX(), var0.getY(), var0.getZ());
         Object var2 = ClassWrapper.CRAFT_WORLD.getClazz().cast(var0.getWorld());
         Object var3 = var2.getClass().getMethod("getHandle").invoke(var2);
         Object var4 = var3.getClass().getMethod("getTileEntity", var1.getClass()).invoke(var3, var1);
         Method var5 = ClassWrapper.NMS_TILEENTITY.getClazz().getMethod(MethodNames.getTileDataMethodName(), ClassWrapper.NMS_NBTTAGCOMPOUND.getClazz());
         Object var6 = ClassWrapper.NMS_NBTTAGCOMPOUND.getClazz().newInstance();
         Object var7 = var5.invoke(var4, var6);
         if (var7 == null) {
            var7 = var6;
         }

         return var7;
      } catch (Exception var8) {
         var8.printStackTrace();
         return null;
      }
   }

   public static void setTileEntityNBTTagCompound(BlockState var0, Object var1) {
      try {
         Object var2 = ObjectCreator.NMS_BLOCKPOSITION.getInstance(var0.getX(), var0.getY(), var0.getZ());
         Object var3 = ClassWrapper.CRAFT_WORLD.getClazz().cast(var0.getWorld());
         Object var4 = var3.getClass().getMethod("getHandle").invoke(var3);
         Object var5 = var4.getClass().getMethod("getTileEntity", var2.getClass()).invoke(var4, var2);
         Method var6 = ClassWrapper.NMS_TILEENTITY.getClazz().getMethod("a", ClassWrapper.NMS_NBTTAGCOMPOUND.getClazz());
         var6.invoke(var5, var1);
      } catch (Exception var7) {
         var7.printStackTrace();
      }

   }

   public static Object getSubNBTTagCompound(Object var0, String var1) {
      Class var2 = var0.getClass();

      try {
         Method var3 = var2.getMethod("getCompound", String.class);
         Object var4 = var3.invoke(var0, var1);
         return var4;
      } catch (Exception var5) {
         var5.printStackTrace();
         return null;
      }
   }

   public static void addNBTTagCompound(NBTCompound var0, String var1) {
      if (var1 == null) {
         remove(var0, var1);
      } else {
         Object var2 = var0.getCompound();
         if (var2 == null) {
            var2 = ObjectCreator.NMS_NBTTAGCOMPOUND.getInstance();
         }

         if (valideCompound(var0)) {
            Object var3 = gettoCompount(var2, var0);

            try {
               Method var4 = var3.getClass().getMethod("set", String.class, ClassWrapper.NMS_NBTBASE.getClazz());
               var4.invoke(var3, var1, ClassWrapper.NMS_NBTTAGCOMPOUND.getClazz().newInstance());
               var0.setCompound(var2);
            } catch (Exception var5) {
               var5.printStackTrace();
            }

         }
      }
   }

   public static Boolean valideCompound(NBTCompound var0) {
      Object var1 = var0.getCompound();
      if (var1 == null) {
         var1 = ObjectCreator.NMS_NBTTAGCOMPOUND.getInstance();
      }

      return gettoCompount(var1, var0) != null ? true : false;
   }

   static Object gettoCompount(Object var0, NBTCompound var1) {
      Stack var2;
      for(var2 = new Stack(); var1.getParent() != null; var1 = var1.getParent()) {
         var2.add(var1.getName());
      }

      while(!var2.isEmpty()) {
         var0 = getSubNBTTagCompound(var0, (String)var2.pop());
         if (var0 == null) {
            return null;
         }
      }

      return var0;
   }

   public static void addOtherNBTCompound(NBTCompound var0, NBTCompound var1) {
      Object var2 = var0.getCompound();
      if (var2 == null) {
         var2 = ObjectCreator.NMS_NBTTAGCOMPOUND.getInstance();
      }

      if (valideCompound(var0)) {
         Object var3 = gettoCompount(var2, var0);

         try {
            Method var4 = var3.getClass().getMethod("a", ClassWrapper.NMS_NBTTAGCOMPOUND.getClazz());
            var4.invoke(var3, var1.getCompound());
            var0.setCompound(var2);
         } catch (Exception var5) {
            var5.printStackTrace();
         }

      }
   }

   public static String getContent(NBTCompound var0, String var1) {
      Object var2 = var0.getCompound();
      if (var2 == null) {
         var2 = ObjectCreator.NMS_NBTTAGCOMPOUND.getInstance();
      }

      if (!valideCompound(var0)) {
         return null;
      } else {
         Object var3 = gettoCompount(var2, var0);

         try {
            Method var4 = var3.getClass().getMethod("get", String.class);
            return var4.invoke(var3, var1).toString();
         } catch (Exception var5) {
            var5.printStackTrace();
            return null;
         }
      }
   }

   public static void set(NBTCompound var0, String var1, Object var2) {
      if (var2 == null) {
         remove(var0, var1);
      } else {
         Object var3 = var0.getCompound();
         if (var3 == null) {
            var3 = ObjectCreator.NMS_NBTTAGCOMPOUND.getInstance();
         }

         if (!valideCompound(var0)) {
            (new Throwable("InvalideCompound")).printStackTrace();
         } else {
            Object var4 = gettoCompount(var3, var0);

            try {
               Method var5 = var4.getClass().getMethod("set", String.class, ClassWrapper.NMS_NBTBASE.getClazz());
               var5.invoke(var4, var1, var2);
               var0.setCompound(var3);
            } catch (Exception var6) {
               var6.printStackTrace();
            }

         }
      }
   }

   public static NBTList getList(NBTCompound var0, String var1, NBTType var2) {
      Object var3 = var0.getCompound();
      if (var3 == null) {
         var3 = ObjectCreator.NMS_NBTTAGCOMPOUND.getInstance();
      }

      if (!valideCompound(var0)) {
         return null;
      } else {
         Object var4 = gettoCompount(var3, var0);

         try {
            Method var5 = var4.getClass().getMethod("getList", String.class, Integer.TYPE);
            return new NBTList(var0, var1, var2, var5.invoke(var4, var1, var2.getId()));
         } catch (Exception var6) {
            var6.printStackTrace();
            return null;
         }
      }
   }

   public static void setObject(NBTCompound var0, String var1, Object var2) {
      if (MinecraftVersion.hasGsonSupport()) {
         try {
            String var3 = GsonWrapper.getString(var2);
            setData(var0, ReflectionMethod.COMPOUND_SET_STRING, var1, var3);
         } catch (Exception var4) {
            var4.printStackTrace();
         }

      }
   }

   public static <T> T getObject(NBTCompound var0, String var1, Class<T> var2) {
      if (!MinecraftVersion.hasGsonSupport()) {
         return null;
      } else {
         String var3 = (String)getData(var0, ReflectionMethod.COMPOUND_GET_STRING, var1);
         return var3 == null ? null : GsonWrapper.deserializeJson(var3, var2);
      }
   }

   public static void remove(NBTCompound var0, String var1) {
      Object var2 = var0.getCompound();
      if (var2 == null) {
         var2 = ObjectCreator.NMS_NBTTAGCOMPOUND.getInstance();
      }

      if (valideCompound(var0)) {
         Object var3 = gettoCompount(var2, var0);
         ReflectionMethod.COMPOUND_REMOVE_KEY.run(var3, var1);
         var0.setCompound(var2);
      }
   }

   public static Set<String> getKeys(NBTCompound var0) {
      Object var1 = var0.getCompound();
      if (var1 == null) {
         var1 = ObjectCreator.NMS_NBTTAGCOMPOUND.getInstance();
      }

      if (!valideCompound(var0)) {
         return null;
      } else {
         Object var2 = gettoCompount(var1, var0);
         return (Set)ReflectionMethod.COMPOUND_GET_KEYS.run(var2);
      }
   }

   public static void setData(NBTCompound var0, ReflectionMethod var1, String var2, Object var3) {
      if (var3 == null) {
         remove(var0, var2);
      } else {
         Object var4 = var0.getCompound();
         if (var4 == null) {
            var4 = ObjectCreator.NMS_NBTTAGCOMPOUND.getInstance();
         }

         if (valideCompound(var0)) {
            Object var5 = gettoCompount(var4, var0);
            var1.run(var5, var2, var3);
            var0.setCompound(var4);
         }
      }
   }

   public static Object getData(NBTCompound var0, ReflectionMethod var1, String var2) {
      Object var3 = var0.getCompound();
      if (var3 == null) {
         return null;
      } else if (!valideCompound(var0)) {
         return null;
      } else {
         Object var4 = gettoCompount(var3, var0);
         return var1.run(var4, var2);
      }
   }
}
