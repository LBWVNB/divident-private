package su.nightexpress.divineitems.nbt;

import org.bukkit.block.BlockState;

public class NBTTileEntity extends NBTCompound {
   private final BlockState tile;

   public NBTTileEntity(BlockState var1) {
      super((NBTCompound)null, (String)null);
      this.tile = var1;
   }

   protected Object getCompound() {
      return NBTReflectionUtil.getTileEntityNBTTagCompound(this.tile);
   }

   protected void setCompound(Object var1) {
      NBTReflectionUtil.setTileEntityNBTTagCompound(this.tile, var1);
   }
}
