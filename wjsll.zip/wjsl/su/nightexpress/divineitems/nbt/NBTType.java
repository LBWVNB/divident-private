package su.nightexpress.divineitems.nbt;

public enum NBTType {
   NBTTagEnd(0),
   NBTTagByte(1),
   NBTTagShort(2),
   NBTTagInt(3),
   NBTTagLong(4),
   NBTTagFloat(5),
   NBTTagDouble(6),
   NBTTagByteArray(7),
   NBTTagIntArray(11),
   NBTTagString(8),
   NBTTagList(9),
   NBTTagCompound(10);

   private final int id;

   private NBTType(int var3) {
      this.id = var3;
   }

   public int getId() {
      return this.id;
   }

   public static NBTType valueOf(int var0) {
      NBTType[] var4;
      int var3 = (var4 = values()).length;

      for(int var2 = 0; var2 < var3; ++var2) {
         NBTType var1 = var4[var2];
         if (var1.getId() == var0) {
            return var1;
         }
      }

      return NBTTagEnd;
   }
}
