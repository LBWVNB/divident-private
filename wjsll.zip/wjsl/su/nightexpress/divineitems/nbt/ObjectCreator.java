package su.nightexpress.divineitems.nbt;

import java.lang.reflect.Constructor;

public enum ObjectCreator {
   NMS_NBTTAGCOMPOUND(ClassWrapper.NMS_NBTTAGCOMPOUND.getClazz(), new Class[0]),
   NMS_BLOCKPOSITION(ClassWrapper.NMS_BLOCKPOSITION.getClazz(), new Class[]{Integer.TYPE, Integer.TYPE, Integer.TYPE});

   private Constructor<?> construct;

   private ObjectCreator(Class<?> var3, Class<?>[] var4) {
      try {
         this.construct = var3.getConstructor(var4);
      } catch (Exception var6) {
         var6.printStackTrace();
      }

   }

   public Object getInstance(Object... var1) {
      try {
         return this.construct.newInstance(var1);
      } catch (Exception var3) {
         var3.printStackTrace();
         return null;
      }
   }
}
