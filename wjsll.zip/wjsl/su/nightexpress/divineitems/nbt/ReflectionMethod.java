package su.nightexpress.divineitems.nbt;

import java.lang.reflect.Method;
import org.bukkit.inventory.ItemStack;
import su.nightexpress.divineitems.nbt.utils.MinecraftVersion;

public enum ReflectionMethod {
   COMPOUND_SET_FLOAT(ClassWrapper.NMS_NBTTAGCOMPOUND.getClazz(), new Class[]{String.class, Float.TYPE}, MinecraftVersion.MC1_7_R4, new ReflectionMethod.Since[]{new ReflectionMethod.Since(MinecraftVersion.MC1_7_R4, "setFloat")}),
   COMPOUND_SET_STRING(ClassWrapper.NMS_NBTTAGCOMPOUND.getClazz(), new Class[]{String.class, String.class}, MinecraftVersion.MC1_7_R4, new ReflectionMethod.Since[]{new ReflectionMethod.Since(MinecraftVersion.MC1_7_R4, "setString")}),
   COMPOUND_SET_INT(ClassWrapper.NMS_NBTTAGCOMPOUND.getClazz(), new Class[]{String.class, Integer.TYPE}, MinecraftVersion.MC1_7_R4, new ReflectionMethod.Since[]{new ReflectionMethod.Since(MinecraftVersion.MC1_7_R4, "setInt")}),
   COMPOUND_SET_BYTEARRAY(ClassWrapper.NMS_NBTTAGCOMPOUND.getClazz(), new Class[]{String.class, byte[].class}, MinecraftVersion.MC1_7_R4, new ReflectionMethod.Since[]{new ReflectionMethod.Since(MinecraftVersion.MC1_7_R4, "setByteArray")}),
   COMPOUND_SET_INTARRAY(ClassWrapper.NMS_NBTTAGCOMPOUND.getClazz(), new Class[]{String.class, int[].class}, MinecraftVersion.MC1_7_R4, new ReflectionMethod.Since[]{new ReflectionMethod.Since(MinecraftVersion.MC1_7_R4, "setIntArray")}),
   COMPOUND_SET_LONG(ClassWrapper.NMS_NBTTAGCOMPOUND.getClazz(), new Class[]{String.class, Long.TYPE}, MinecraftVersion.MC1_7_R4, new ReflectionMethod.Since[]{new ReflectionMethod.Since(MinecraftVersion.MC1_7_R4, "setLong")}),
   COMPOUND_SET_SHORT(ClassWrapper.NMS_NBTTAGCOMPOUND.getClazz(), new Class[]{String.class, Short.TYPE}, MinecraftVersion.MC1_7_R4, new ReflectionMethod.Since[]{new ReflectionMethod.Since(MinecraftVersion.MC1_7_R4, "setShort")}),
   COMPOUND_SET_BYTE(ClassWrapper.NMS_NBTTAGCOMPOUND.getClazz(), new Class[]{String.class, Byte.TYPE}, MinecraftVersion.MC1_7_R4, new ReflectionMethod.Since[]{new ReflectionMethod.Since(MinecraftVersion.MC1_7_R4, "setByte")}),
   COMPOUND_SET_DOUBLE(ClassWrapper.NMS_NBTTAGCOMPOUND.getClazz(), new Class[]{String.class, Double.TYPE}, MinecraftVersion.MC1_7_R4, new ReflectionMethod.Since[]{new ReflectionMethod.Since(MinecraftVersion.MC1_7_R4, "setDouble")}),
   COMPOUND_SET_BOOLEAN(ClassWrapper.NMS_NBTTAGCOMPOUND.getClazz(), new Class[]{String.class, Boolean.TYPE}, MinecraftVersion.MC1_7_R4, new ReflectionMethod.Since[]{new ReflectionMethod.Since(MinecraftVersion.MC1_7_R4, "setBoolean")}),
   COMPOUND_GET_FLOAT(ClassWrapper.NMS_NBTTAGCOMPOUND.getClazz(), new Class[]{String.class}, MinecraftVersion.MC1_7_R4, new ReflectionMethod.Since[]{new ReflectionMethod.Since(MinecraftVersion.MC1_7_R4, "getFloat")}),
   COMPOUND_GET_STRING(ClassWrapper.NMS_NBTTAGCOMPOUND.getClazz(), new Class[]{String.class}, MinecraftVersion.MC1_7_R4, new ReflectionMethod.Since[]{new ReflectionMethod.Since(MinecraftVersion.MC1_7_R4, "getString")}),
   COMPOUND_GET_INT(ClassWrapper.NMS_NBTTAGCOMPOUND.getClazz(), new Class[]{String.class}, MinecraftVersion.MC1_7_R4, new ReflectionMethod.Since[]{new ReflectionMethod.Since(MinecraftVersion.MC1_7_R4, "getInt")}),
   COMPOUND_GET_BYTEARRAY(ClassWrapper.NMS_NBTTAGCOMPOUND.getClazz(), new Class[]{String.class}, MinecraftVersion.MC1_7_R4, new ReflectionMethod.Since[]{new ReflectionMethod.Since(MinecraftVersion.MC1_7_R4, "getByteArray")}),
   COMPOUND_GET_INTARRAY(ClassWrapper.NMS_NBTTAGCOMPOUND.getClazz(), new Class[]{String.class}, MinecraftVersion.MC1_7_R4, new ReflectionMethod.Since[]{new ReflectionMethod.Since(MinecraftVersion.MC1_7_R4, "getIntArray")}),
   COMPOUND_GET_LONG(ClassWrapper.NMS_NBTTAGCOMPOUND.getClazz(), new Class[]{String.class}, MinecraftVersion.MC1_7_R4, new ReflectionMethod.Since[]{new ReflectionMethod.Since(MinecraftVersion.MC1_7_R4, "getLong")}),
   COMPOUND_GET_SHORT(ClassWrapper.NMS_NBTTAGCOMPOUND.getClazz(), new Class[]{String.class}, MinecraftVersion.MC1_7_R4, new ReflectionMethod.Since[]{new ReflectionMethod.Since(MinecraftVersion.MC1_7_R4, "getShort")}),
   COMPOUND_GET_BYTE(ClassWrapper.NMS_NBTTAGCOMPOUND.getClazz(), new Class[]{String.class}, MinecraftVersion.MC1_7_R4, new ReflectionMethod.Since[]{new ReflectionMethod.Since(MinecraftVersion.MC1_7_R4, "getByte")}),
   COMPOUND_GET_DOUBLE(ClassWrapper.NMS_NBTTAGCOMPOUND.getClazz(), new Class[]{String.class}, MinecraftVersion.MC1_7_R4, new ReflectionMethod.Since[]{new ReflectionMethod.Since(MinecraftVersion.MC1_7_R4, "getDouble")}),
   COMPOUND_GET_BOOLEAN(ClassWrapper.NMS_NBTTAGCOMPOUND.getClazz(), new Class[]{String.class}, MinecraftVersion.MC1_7_R4, new ReflectionMethod.Since[]{new ReflectionMethod.Since(MinecraftVersion.MC1_7_R4, "getBoolean")}),
   COMPOUND_REMOVE_KEY(ClassWrapper.NMS_NBTTAGCOMPOUND.getClazz(), new Class[]{String.class}, MinecraftVersion.MC1_7_R4, new ReflectionMethod.Since[]{new ReflectionMethod.Since(MinecraftVersion.MC1_7_R4, "remove")}),
   COMPOUND_HAS_KEY(ClassWrapper.NMS_NBTTAGCOMPOUND.getClazz(), new Class[]{String.class}, MinecraftVersion.MC1_7_R4, new ReflectionMethod.Since[]{new ReflectionMethod.Since(MinecraftVersion.MC1_7_R4, "hasKey")}),
   COMPOUND_GET_TYPE(ClassWrapper.NMS_NBTTAGCOMPOUND.getClazz(), new Class[]{String.class}, MinecraftVersion.MC1_8_R3, new ReflectionMethod.Since[]{new ReflectionMethod.Since(MinecraftVersion.MC1_8_R3, "b"), new ReflectionMethod.Since(MinecraftVersion.MC1_9_R1, "d")}),
   COMPOUND_GET_KEYS(ClassWrapper.NMS_NBTTAGCOMPOUND.getClazz(), new Class[0], MinecraftVersion.MC1_7_R4, new ReflectionMethod.Since[]{new ReflectionMethod.Since(MinecraftVersion.MC1_7_R4, "c"), new ReflectionMethod.Since(MinecraftVersion.MC1_13_R1, "getKeys")}),
   LISTCOMPOUND_GET_KEYS(ClassWrapper.NMS_NBTTAGCOMPOUND.getClazz(), new Class[0], MinecraftVersion.MC1_7_R4, new ReflectionMethod.Since[]{new ReflectionMethod.Since(MinecraftVersion.MC1_7_R4, "c"), new ReflectionMethod.Since(MinecraftVersion.MC1_13_R1, "getKeys")}),
   ITEMSTACK_SET_TAG(ClassWrapper.NMS_ITEMSTACK.getClazz(), new Class[]{ClassWrapper.NMS_NBTTAGCOMPOUND.getClazz()}, MinecraftVersion.MC1_7_R4, new ReflectionMethod.Since[]{new ReflectionMethod.Since(MinecraftVersion.MC1_7_R4, "setTag")}),
   ITEMSTACK_NMSCOPY(ClassWrapper.CRAFT_ITEMSTACK.getClazz(), new Class[]{ItemStack.class}, MinecraftVersion.MC1_7_R4, new ReflectionMethod.Since[]{new ReflectionMethod.Since(MinecraftVersion.MC1_7_R4, "asNMSCopy")}),
   ITEMSTACK_BUKKITMIRROR(ClassWrapper.CRAFT_ITEMSTACK.getClazz(), new Class[]{ClassWrapper.NMS_ITEMSTACK.getClazz()}, MinecraftVersion.MC1_7_R4, new ReflectionMethod.Since[]{new ReflectionMethod.Since(MinecraftVersion.MC1_7_R4, "asCraftMirror")}),
   PARSE_NBT(ClassWrapper.NMS_MOJANGSONPARSER.getClazz(), new Class[]{String.class}, MinecraftVersion.MC1_7_R4, new ReflectionMethod.Since[]{new ReflectionMethod.Since(MinecraftVersion.MC1_7_R4, "parse")});

   private ReflectionMethod.Since targetVersion;
   private Method method;
   private boolean loaded = false;
   private boolean compatible = false;

   private ReflectionMethod(Class<?> var3, Class<?>[] var4, MinecraftVersion var5, ReflectionMethod.Since[] var6) {
      MinecraftVersion var7 = MinecraftVersion.getVersion();
      if (var7.compareTo(var5) >= 0) {
         this.compatible = true;
         ReflectionMethod.Since var8 = var6[0];
         ReflectionMethod.Since[] var12 = var6;
         int var11 = var6.length;

         for(int var10 = 0; var10 < var11; ++var10) {
            ReflectionMethod.Since var9 = var12[var10];
            if (var9.version.getVersionId() <= var7.getVersionId() && var8.version.getVersionId() < var9.version.getVersionId()) {
               var8 = var9;
            }
         }

         this.targetVersion = var8;

         try {
            (this.method = var3.getMethod(this.targetVersion.name, var4)).setAccessible(true);
            this.loaded = true;
         } catch (NoSuchMethodException | SecurityException | NullPointerException var13) {
            var13.printStackTrace();
         }

      }
   }

   public Object run(Object var1, Object... var2) {
      try {
         return this.method.invoke(var1, var2);
      } catch (Exception var4) {
         var4.printStackTrace();
         return null;
      }
   }

   public boolean isLoaded() {
      return this.loaded;
   }

   public boolean isCompatible() {
      return this.compatible;
   }

   public static class Since {
      public final MinecraftVersion version;
      public final String name;

      public Since(MinecraftVersion var1, String var2) {
         this.version = var1;
         this.name = var2;
      }
   }
}
