package su.nightexpress.divineitems.nbt.utils;

import com.google.gson.Gson;

public class GsonWrapper {
   private static final Gson gson = new Gson();

   public static String getString(Object var0) {
      return gson.toJson(var0);
   }

   public static <T> T deserializeJson(String var0, Class<T> var1) {
      try {
         if (var0 == null) {
            return null;
         } else {
            Object var2 = gson.fromJson(var0, var1);
            return var1.cast(var2);
         }
      } catch (Exception var3) {
         var3.printStackTrace();
         return null;
      }
   }
}
