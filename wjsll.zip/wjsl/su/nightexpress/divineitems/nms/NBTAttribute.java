package su.nightexpress.divineitems.nms;

public enum NBTAttribute {
   armor("armor"),
   armorToughness("armorToughness"),
   attackDamage("attackDamage"),
   attackSpeed("attackSpeed"),
   movementSpeed("movementSpeed"),
   maxHealth("maxHealth"),
   knockbackResistance("knockbackResistance");

   private String s;

   private NBTAttribute(String var3) {
      this.s = var3;
   }

   public String att() {
      return this.s;
   }
}
