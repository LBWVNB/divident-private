package su.nightexpress.divineitems.nms;

import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public interface NMS {
   ItemStack setNBTAtt(ItemStack var1, NBTAttribute var2, double var3);

   void sendActionBar(Player var1, String var2);

   void sendTitles(Player var1, String var2, String var3, int var4, int var5, int var6);
}
