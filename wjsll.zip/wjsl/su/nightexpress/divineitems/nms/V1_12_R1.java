package su.nightexpress.divineitems.nms;

import net.minecraft.server.v1_12_R1.ChatMessageType;
import net.minecraft.server.v1_12_R1.IChatBaseComponent;
import net.minecraft.server.v1_12_R1.NBTTagCompound;
import net.minecraft.server.v1_12_R1.NBTTagDouble;
import net.minecraft.server.v1_12_R1.NBTTagInt;
import net.minecraft.server.v1_12_R1.NBTTagList;
import net.minecraft.server.v1_12_R1.NBTTagString;
import net.minecraft.server.v1_12_R1.PacketPlayOutChat;
import net.minecraft.server.v1_12_R1.PacketPlayOutTitle;
import net.minecraft.server.v1_12_R1.IChatBaseComponent.ChatSerializer;
import net.minecraft.server.v1_12_R1.PacketPlayOutTitle.EnumTitleAction;
import org.bukkit.ChatColor;
import org.bukkit.craftbukkit.v1_12_R1.entity.CraftPlayer;
import org.bukkit.craftbukkit.v1_12_R1.inventory.CraftItemStack;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import su.nightexpress.divineitems.api.ItemAPI;
import su.nightexpress.divineitems.utils.ItemUtils;
import su.nightexpress.divineitems.utils.Utils;

public class V1_12_R1 implements NMS {
   public ItemStack setNBTAtt(ItemStack var1, NBTAttribute var2, double var3) {
      net.minecraft.server.v1_12_R1.ItemStack var5 = CraftItemStack.asNMSCopy(var1);
      NBTTagCompound var6 = var5.hasTag() ? var5.getTag() : new NBTTagCompound();
      NBTTagList var7 = var6.getList("AttributeModifiers", 10);
      String[] var11;
      int var10 = (var11 = ItemUtils.getAllNBTSlots(var1)).length;

      for(int var9 = 0; var9 < var10; ++var9) {
         String var8 = var11[var9];
         NBTTagCompound var12 = new NBTTagCompound();

         int var13;
         for(var13 = 0; var13 < var7.size(); ++var13) {
            NBTTagCompound var14 = var7.get(var13);
            if (var14.hasKey("generic." + var2) && var14.getString("Slot").equalsIgnoreCase(var8)) {
               var12 = var7.get(var13);
               break;
            }
         }

         if (var2 == NBTAttribute.movementSpeed) {
            var3 = 0.1D * (1.0D + var3 / 100.0D) - 0.1D;
         } else if (var2 == NBTAttribute.attackSpeed) {
            double var15 = ItemAPI.getDefaultAttackSpeed(var1) * var3;
            var3 = -(ItemAPI.getDefaultAttackSpeed(var1) - var15);
         }

         var13 = Utils.randInt(1, 333);
         var12.set("AttributeName", new NBTTagString("generic." + var2.att()));
         var12.set("Name", new NBTTagString("generic." + var2.att()));
         var12.set("Amount", new NBTTagDouble(var3));
         var12.set("Operation", new NBTTagInt(0));
         var12.set("UUIDLeast", new NBTTagInt(var13));
         var12.set("UUIDMost", new NBTTagInt(var13));
         var12.set("Slot", new NBTTagString(var8));
         var7.add(var12);
      }

      var6.set("AttributeModifiers", var7);
      var5.setTag(var6);
      var1 = CraftItemStack.asBukkitCopy(var5);
      return var1;
   }

   public void sendActionBar(Player var1, String var2) {
      String var3 = ChatColor.translateAlternateColorCodes('&', var2);
      IChatBaseComponent var4 = ChatSerializer.a("{\"text\": \"" + var3 + "\"}");
      PacketPlayOutChat var5 = new PacketPlayOutChat(var4, ChatMessageType.GAME_INFO);
      ((CraftPlayer)var1).getHandle().playerConnection.sendPacket(var5);
   }

   public void sendTitles(Player var1, String var2, String var3, int var4, int var5, int var6) {
      IChatBaseComponent var7 = ChatSerializer.a("{\"text\": \"" + var2 + "\"}");
      IChatBaseComponent var8 = ChatSerializer.a("{\"text\": \"" + var3 + "\"}");
      PacketPlayOutTitle var9 = new PacketPlayOutTitle(EnumTitleAction.TITLE, var7);
      PacketPlayOutTitle var10 = new PacketPlayOutTitle(EnumTitleAction.SUBTITLE, var8);
      PacketPlayOutTitle var11 = new PacketPlayOutTitle(var4, var5, var6);
      ((CraftPlayer)var1).getHandle().playerConnection.sendPacket(var9);
      ((CraftPlayer)var1).getHandle().playerConnection.sendPacket(var10);
      ((CraftPlayer)var1).getHandle().playerConnection.sendPacket(var11);
   }
}
