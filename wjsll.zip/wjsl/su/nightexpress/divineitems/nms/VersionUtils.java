package su.nightexpress.divineitems.nms;

import org.bukkit.Bukkit;

public class VersionUtils {
   private VersionUtils.Version version = VersionUtils.Version.getCurrent();
   private NMS nms;

   public boolean setup() {
      if (this.setNMS()) {
         Bukkit.getConsoleSender().sendMessage("§7> §fServer version: §a" + this.getVersion().getVersion() + " / OK!");
         return true;
      } else {
         return false;
      }
   }

   public boolean setNMS() {
      String var1 = this.getVersion().getVersion();
      if (var1.equals("v1_9_R1")) {
         this.nms = new V1_9_R1();
      } else if (var1.equals("v1_9_R2")) {
         this.nms = new V1_9_R2();
      } else if (var1.equals("v1_10_R1")) {
         this.nms = new V1_9_R1();
      } else if (var1.equals("v1_11_R1")) {
         this.nms = new V1_11_R1();
      } else if (var1.equals("v1_12_R1")) {
         this.nms = new V1_12_R1();
      } else if (var1.equals("v1_13_R1")) {
         this.nms = new V1_13_R1();
      } else if (var1.equals("v1_13_R2")) {
         this.nms = new V1_13_R2();
      }

      return this.nms != null;
   }

   public NMS getNMS() {
      return this.nms;
   }

   public VersionUtils.Version getVersion() {
      return this.version;
   }

   public Class<?> getNmsClass(String var1) {
      return Class.forName("net.minecraft.server." + this.version.getVersion() + "." + var1);
   }

   public static enum Version {
      v1_9_R1("v1_9_R1", 10),
      v1_9_R2("v1_9_R2", 10),
      v1_10_R1("v1_10_R1", 11),
      v1_11_R1("v1_11_R1", 12),
      v1_12_R1("v1_12_R1", 13),
      v1_13_R1("v1_13_R1", 14),
      v1_13_R2("v1_13_R2", 15);

      private int n;
      private String s;

      private Version(String var3, int var4) {
         this.n = var4;
         this.s = var3;
      }

      public String getVersion() {
         return this.s;
      }

      public int getValue() {
         return this.n;
      }

      public static VersionUtils.Version getCurrent() {
         String[] var0 = Bukkit.getServer().getClass().getPackage().getName().split("\\.");
         String var1 = var0[var0.length - 1];
         VersionUtils.Version[] var2;
         int var3 = (var2 = values()).length;

         for(int var4 = 0; var4 < var3; ++var4) {
            VersionUtils.Version var5 = var2[var4];
            if (var5.name().equalsIgnoreCase(var1)) {
               return var5;
            }
         }

         return null;
      }

      public boolean isLower(VersionUtils.Version var1) {
         return this.getValue() < var1.getValue();
      }

      public boolean isHigher(VersionUtils.Version var1) {
         return this.getValue() > var1.getValue();
      }
   }
}
