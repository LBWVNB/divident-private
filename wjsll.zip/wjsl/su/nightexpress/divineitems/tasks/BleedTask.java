package su.nightexpress.divineitems.tasks;

import su.nightexpress.divineitems.DivineItems;

public class BleedTask {
   private DivineItems plugin;
   private int id;

   public BleedTask(DivineItems var1) {
      this.plugin = var1;
   }

   public void stop() {
      this.plugin.getServer().getScheduler().cancelTask(this.id);
   }

   public void start() {
      this.id = this.plugin.getServer().getScheduler().scheduleSyncRepeatingTask(this.plugin, new Runnable() {
         public void run() {
            BleedTask.this.plugin.getTM().processBleed();
         }
      }, 0L, 20L);
   }
}
