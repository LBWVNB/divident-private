package su.nightexpress.divineitems.tasks;

import java.util.HashMap;
import java.util.Iterator;
import org.bukkit.entity.LivingEntity;
import su.nightexpress.divineitems.DivineItems;
import su.nightexpress.divineitems.attributes.BleedEffect;
import su.nightexpress.divineitems.attributes.BleedRateSettings;
import su.nightexpress.divineitems.attributes.ItemStat;
import su.nightexpress.divineitems.utils.ItemUtils;
import su.nightexpress.divineitems.utils.Utils;

public class TaskManager {
   private DivineItems plugin;
   private BleedTask global;
   private HashMap<LivingEntity, BleedEffect> bleed;

   public TaskManager(DivineItems var1) {
      this.plugin = var1;
      this.global = new BleedTask(this.plugin);
      this.bleed = new HashMap();
   }

   public void start() {
      this.global.start();
   }

   public void stop() {
      this.global.stop();
      this.bleed.clear();
   }

   public void addBleedEffect(LivingEntity var1, double var2) {
      BleedRateSettings var4 = (BleedRateSettings)ItemStat.BLEED_RATE.getSettings();
      if (var4 != null && var4.getFormula() != null) {
         double var5 = ItemUtils.calc(var4.getFormula().replace("%dmg%", String.valueOf(var2)));
         BleedEffect var7 = new BleedEffect(var4.getTime(), var5);
         this.bleed.put(var1, var7);
      }
   }

   public void processBleed() {
      BleedRateSettings var1 = (BleedRateSettings)ItemStat.BLEED_RATE.getSettings();
      HashMap var2 = new HashMap(this.bleed);
      Iterator var4 = var2.keySet().iterator();

      while(true) {
         while(true) {
            LivingEntity var3;
            BleedEffect var5;
            do {
               if (!var4.hasNext()) {
                  return;
               }

               var3 = (LivingEntity)var4.next();
               var5 = (BleedEffect)var2.get(var3);
            } while(var5 == null);

            if (var3.isValid() && !var3.isDead() && var5.getTime() > 0) {
               var3.damage(var5.getDamage());
               Utils.playEffect(var1.getEffect(), 0.2D, 0.25D, 0.2D, 0.1D, 50, var3.getEyeLocation());
               var5.setTime(var5.getTime() - 1);
               this.bleed.put(var3, var5);
            } else {
               this.bleed.remove(var3);
            }
         }
      }
   }
}
