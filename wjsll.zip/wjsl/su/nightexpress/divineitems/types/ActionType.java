package su.nightexpress.divineitems.types;

public enum ActionType {
   BUFF,
   EFFECT,
   POTION,
   COMMAND,
   PLAYER_COMMAND,
   OP_COMMAND,
   TELEPORT,
   MESSAGE,
   ACTION_BAR,
   TITLES,
   SOUND,
   ARROW,
   FIREBALL,
   WITHER_SKULL,
   BLOCK,
   IGNITE,
   DELAY,
   LIGHTNING,
   FIREWORK,
   THROW,
   HOOK,
   PARTICLE_LINE,
   PARTICLE_PULSE,
   DAMAGE,
   SPELL;
}
