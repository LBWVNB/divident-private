package su.nightexpress.divineitems.types;

public enum AmmoType {
   ARROW(true, "&f➶", "Arrow"),
   SNOWBALL(true, "&9❆&f", "Snowball"),
   EGG(true, "&c⚫&f", "Egg"),
   FIREBALL(true, "&c☄&f", "Fireball"),
   WITHER_SKULL(true, "&8☢&f", "Wither Skull"),
   SHULKER_BULLET(true, "&d✦&f", "Shulker Bullet"),
   LLAMA_SPIT(true, "&e☔&f", "Llama Spit"),
   ENDER_PEARL(true, "&b◉", "Ender Peral"),
   EXP_POTION(true, "&e☘", "Exp Potion");

   private boolean enabled;
   private String prefix;
   private String name;

   private AmmoType(boolean var3, String var4, String var5) {
      this.setEnabled(var3);
      this.setPrefix(var4);
      this.setName(var5);
   }

   public String getPrefix() {
      return this.prefix;
   }

   public void setPrefix(String var1) {
      this.prefix = var1;
   }

   public String getName() {
      return this.name;
   }

   public void setName(String var1) {
      this.name = var1;
   }

   public boolean isEnabled() {
      return this.enabled;
   }

   public void setEnabled(boolean var1) {
      this.enabled = var1;
   }
}
