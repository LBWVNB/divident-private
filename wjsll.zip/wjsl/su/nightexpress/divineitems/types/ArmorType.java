package su.nightexpress.divineitems.types;

import java.util.List;

public class ArmorType {
   private String id;
   private String prefix;
   private String name;
   private String value;
   private boolean percent;
   private List<String> bds;
   private List<String> bdt;
   private String formula;

   public ArmorType(String var1, String var2, String var3, String var4, boolean var5, List<String> var6, List<String> var7, String var8) {
      this.setId(var1);
      this.setPrefix(var2);
      this.setName(var3);
      this.setValue(var4);
      this.setPercent(var5);
      this.setBlockDamageSources(var6);
      this.setBlockDamageTypes(var7);
      this.setFormula(var8);
   }

   public String getId() {
      return this.id;
   }

   public void setId(String var1) {
      this.id = var1.toLowerCase();
   }

   public String getPrefix() {
      return this.prefix;
   }

   public void setPrefix(String var1) {
      this.prefix = var1;
   }

   public String getName() {
      return this.name;
   }

   public void setName(String var1) {
      this.name = var1;
   }

   public String getValue() {
      return this.value;
   }

   public void setValue(String var1) {
      this.value = var1;
   }

   public boolean isPercent() {
      return this.percent;
   }

   public void setPercent(boolean var1) {
      this.percent = var1;
   }

   public List<String> getBlockDamageSources() {
      return this.bds;
   }

   public void setBlockDamageSources(List<String> var1) {
      this.bds = var1;
   }

   public List<String> getBlockDamageTypes() {
      return this.bdt;
   }

   public void setBlockDamageTypes(List<String> var1) {
      this.bdt = var1;
   }

   public String getFormula() {
      return this.formula;
   }

   public void setFormula(String var1) {
      this.formula = var1;
   }
}
