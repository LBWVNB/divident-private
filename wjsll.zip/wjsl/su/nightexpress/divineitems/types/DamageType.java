package su.nightexpress.divineitems.types;

import java.util.HashMap;
import java.util.List;

public class DamageType {
   private String id;
   private boolean def;
   private String prefix;
   private String name;
   private String value;
   private List<String> actions;
   private HashMap<String, Double> biome;

   public DamageType(String var1, boolean var2, String var3, String var4, String var5, List<String> var6, HashMap<String, Double> var7) {
      this.setId(var1);
      this.setDefault(var2);
      this.setPrefix(var3);
      this.setName(var4);
      this.setValue(var5);
      this.setActions(var6);
      this.setBiomeDamageModifiers(var7);
   }

   public String getId() {
      return this.id;
   }

   public void setId(String var1) {
      this.id = var1.toLowerCase();
   }

   public boolean isDefault() {
      return this.def;
   }

   public void setDefault(boolean var1) {
      this.def = var1;
   }

   public String getPrefix() {
      return this.prefix;
   }

   public void setPrefix(String var1) {
      this.prefix = var1;
   }

   public String getName() {
      return this.name;
   }

   public void setName(String var1) {
      this.name = var1;
   }

   public String getValue() {
      return this.value;
   }

   public void setValue(String var1) {
      this.value = var1;
   }

   public List<String> getActions() {
      return this.actions;
   }

   public void setActions(List<String> var1) {
      this.actions = var1;
   }

   public HashMap<String, Double> getBiomeDamageModifiers() {
      return this.biome;
   }

   public void setBiomeDamageModifiers(HashMap<String, Double> var1) {
      this.biome = var1;
   }

   public double getDamageModifierByBiome(String var1) {
      return this.biome.containsKey(var1.toUpperCase()) ? (Double)this.biome.get(var1.toUpperCase()) : 1.0D;
   }
}
