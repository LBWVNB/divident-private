package su.nightexpress.divineitems.types;

public enum DestroyType {
   ITEM,
   SOURCE,
   CLEAR,
   BOTH;
}
