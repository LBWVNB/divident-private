package su.nightexpress.divineitems.types;

public enum DivineType {
   aITEM,
   aGEM,
   aENCHANT,
   aRUNE,
   aABILITY,
   aABYSSGEM,
   aREPAIRGEM,
   aMAGICDUST,
   aSCROLL,
   aCUSTOM,
   aIDENTIFYTOME,
   aUNIDENTIFIED;
}
