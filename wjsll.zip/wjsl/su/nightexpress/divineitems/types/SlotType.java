package su.nightexpress.divineitems.types;

import su.nightexpress.divineitems.Module;

public enum SlotType {
   GEM((Module)null, "&2ᚐᚑᚒᚓᚔᚍᚎᚏ &a&lGems &2ᚏᚎᚍᚔᚓᚒᚑᚐ", "&a□ (Slot) Gem", "&a▣ Gem: &f"),
   RUNE((Module)null, "&3ᚐᚑᚒᚓᚔᚍᚎᚏ &b&lRunes &3ᚏᚎᚍᚔᚓᚒᚑᚐ", "&b◇ (Slot) Rune", "&b◈ Rune: &f"),
   ENCHANT((Module)null, "&4ᚐᚑᚒᚓᚔᚍᚎᚏ &c&lEnchants &4ᚏᚎᚍᚔᚓᚒᚑᚐ", "&c○ (Slot) Enchant", "&c◉ Enchant: &f"),
   ABILITY((Module)null, "&5ᚑᚒᚓᚔᚍᚎᚏ &d&lAbilities &5ᚏᚎᚍᚔᚓᚒᚑᚐ", "&d♯ (Slot) Ability", "&d⚡ Ability: &f");

   private Module m;
   private String head;
   private String empty;
   private String filled;

   private SlotType(Module var3, String var4, String var5, String var6) {
      this.setModule(var3);
      this.setHeader(var4);
      this.setEmpty(var5);
      this.setFilled(var6);
   }

   public Module getModule() {
      return this.m;
   }

   public void setModule(Module var1) {
      this.m = var1;
   }

   public String getHeader() {
      return this.head;
   }

   public void setHeader(String var1) {
      this.head = var1;
   }

   public String getEmpty() {
      return this.empty;
   }

   public void setEmpty(String var1) {
      this.empty = var1;
   }

   public String getFilled() {
      return this.filled;
   }

   public void setFilled(String var1) {
      this.filled = var1;
   }
}
