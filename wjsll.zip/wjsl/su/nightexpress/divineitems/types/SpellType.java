package su.nightexpress.divineitems.types;

public enum SpellType {
   ICE_SNAKE,
   METEOR,
   FIRE_STORM,
   ICE_STORM;
}
