package su.nightexpress.divineitems.types;

public enum TargetType {
   SELF,
   TARGET,
   RADIUS;
}
