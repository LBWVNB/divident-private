package su.nightexpress.divineitems.utils;

import org.bukkit.entity.Player;
import su.nightexpress.divineitems.DivineItems;

public class ActionTitle {
   private static DivineItems plugin;

   static {
      plugin = DivineItems.instance;
   }

   public static void sendActionBar(Player var0, String var1) {
      plugin.getNMS().sendActionBar(var0, var1);
   }

   public static void sendTitles(Player var0, String var1, String var2, int var3, int var4, int var5) {
      plugin.getNMS().sendTitles(var0, var1, var2, var3, var4, var5);
   }
}
