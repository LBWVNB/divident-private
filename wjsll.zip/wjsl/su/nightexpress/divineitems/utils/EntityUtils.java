package su.nightexpress.divineitems.utils;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import su.nightexpress.divineitems.DivineItems;
import su.nightexpress.divineitems.hooks.Hook;

public class EntityUtils {
   private static DivineItems plugin;
   private static Set<Entity> set;

   static {
      plugin = DivineItems.instance;
      set = new HashSet();
   }

   public static void add(Entity var0) {
      set.add(var0);
   }

   public static void remove(Entity var0) {
      set.remove(var0);
   }

   public static Set<Entity> getSaved() {
      return set;
   }

   public static List<LivingEntity> getEnemies(Entity var0, double var1, Player var3) {
      ArrayList var4 = new ArrayList();
      Iterator var6 = var0.getNearbyEntities(var1, var1, var1).iterator();

      while(true) {
         Entity var5;
         do {
            do {
               do {
                  do {
                     do {
                        if (!var6.hasNext()) {
                           return var4;
                        }

                        var5 = (Entity)var6.next();
                     } while(!(var5 instanceof LivingEntity));
                  } while(var5 instanceof ArmorStand);
               } while(Hook.CITIZENS.isEnabled() && plugin.getHM().getCitizens().isNPC(var5));
            } while(var3.equals(var5));
         } while(Hook.WORLD_GUARD.isEnabled() && !plugin.getHM().getWorldGuard().canFights(var5, var3));

         var4.add((LivingEntity)var5);
      }
   }
}
