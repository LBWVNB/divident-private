package su.nightexpress.divineitems.utils;

import org.bukkit.Bukkit;
import su.nightexpress.divineitems.Module;

public class ErrorLog {
   public static void sendError(Module var0, String var1, String var2, boolean var3) {
      Bukkit.getConsoleSender().sendMessage("§c-=-=-=-=-=-=-=-=-=-=-=-=-=-");
      Bukkit.getConsoleSender().sendMessage("[§cDivineItems§7] §c§lWARNING CONFIGURATION ERROR:");
      Bukkit.getConsoleSender().sendMessage("[§cDivineItems§7] §fModule: §c" + var0.name());
      Bukkit.getConsoleSender().sendMessage("[§cDivineItems§7] §fEntry: §c" + var1.replace(".", " -> "));
      Bukkit.getConsoleSender().sendMessage("[§cDivineItems§7] §fInfo: §c" + var2);
      if (var3) {
         Bukkit.getConsoleSender().sendMessage("[§aDivineItems§7] §aThis error has been fixed automatically!");
      } else {
         Bukkit.getConsoleSender().sendMessage("[§cDivineItems§7] §cThis error can not be fixed automatically.");
      }

      Bukkit.getConsoleSender().sendMessage("§c-=-=-=-=-=-=-=-=-=-=-=-=-=-");
      Bukkit.getConsoleSender().sendMessage("");
   }
}
