package su.nightexpress.divineitems.utils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import su.nightexpress.divineitems.DivineItems;

public class Files {
   public static void copy(InputStream var0, File var1) {
      try {
         FileOutputStream var2 = new FileOutputStream(var1);
         byte[] var3 = new byte[1024];

         int var4;
         while((var4 = var0.read(var3)) > 0) {
            var2.write(var3, 0, var4);
         }

         var2.close();
         var0.close();
      } catch (IOException var5) {
         var5.printStackTrace();
      }

   }

   public static void mkdir(File var0) {
      try {
         var0.mkdir();
      } catch (Exception var2) {
         var2.printStackTrace();
      }

   }

   public static void create(File var0) {
      var0.getParentFile().mkdirs();

      try {
         var0.createNewFile();
      } catch (IOException var2) {
         var2.printStackTrace();
      }

   }

   public static List<String> getFilesFolder(String var0) {
      ArrayList var1 = new ArrayList();
      File var2 = new File(DivineItems.instance.getDataFolder() + "/modules/" + var0 + "/");
      File[] var3 = var2.listFiles();
      if (var3 == null) {
         return var1;
      } else {
         for(int var4 = 0; var4 < var3.length; ++var4) {
            if (var3[var4].isFile()) {
               var1.add(var3[var4].getName());
            }
         }

         return var1;
      }
   }
}
