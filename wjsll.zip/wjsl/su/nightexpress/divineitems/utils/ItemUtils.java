package su.nightexpress.divineitems.utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Random;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;
import org.apache.commons.lang.WordUtils;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.inventory.ItemStack;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.metadata.MetadataValue;
import su.nightexpress.divineitems.DivineItems;
import su.nightexpress.divineitems.api.DivineItemsAPI;
import su.nightexpress.divineitems.api.EntityAPI;
import su.nightexpress.divineitems.api.ItemAPI;
import su.nightexpress.divineitems.attributes.ItemStat;
import su.nightexpress.divineitems.modules.arrows.ArrowManager;
import su.nightexpress.divineitems.types.ArmorType;
import su.nightexpress.divineitems.types.DamageType;

public class ItemUtils {
   private static DivineItems plugin;
   private static Random r;
   private static ScriptEngineManager mgr;
   private static ScriptEngine engine;
   // $FF: synthetic field
   private static int[] $SWITCH_TABLE$org$bukkit$entity$EntityType;

   static {
      plugin = DivineItems.instance;
      r = new Random();
      mgr = new ScriptEngineManager();
      engine = mgr.getEngineByName("JavaScript");
   }

   public static double dmgReducer(double var0, double var2, double var4) {
      if (var0 < var4) {
         double var6 = 1.0D - plugin.getCM().getCFG().getDamageCDReduce();
         var2 *= 1.0D - (1.0D - var0 / var4);
         var2 *= var6;
      } else {
         var2 += var0 - var4;
      }

      return var2;
   }

   public static String getSlotByItemType(ItemStack var0) {
      String var1 = var0.getType().name();
      if (!var1.contains("HELMET") && !var1.contains("SKULL_ITEM")) {
         if (!var1.contains("CHESTPLATE") && !var1.contains("ELYTRA")) {
            if (var1.contains("LEGGINGS")) {
               return "legs";
            } else if (var1.contains("BOOTS")) {
               return "feet";
            } else {
               return var1.contains("SHIELD") ? "offhand" : "mainhand";
            }
         } else {
            return "chest";
         }
      } else {
         return "head";
      }
   }

   public static String[] getAllNBTSlots(ItemStack var0) {
      return !isArmor(var0) && var0.getItemMeta().spigot().isUnbreakable() ? new String[]{"head", "chest", "legs", "feet", "offhand", "mainhand"} : new String[]{getSlotByItemType(var0)};
   }

   public static double calcDamageByFormula(LivingEntity var0, LivingEntity var1, double var2, ItemStack var4) {
      if (!plugin.getCM().getCFG().allowAttributesToMobs() && !(var1 instanceof Player)) {
         return var2;
      } else {
         HashMap var5 = new HashMap();
         double var10;
         if (var0.hasMetadata("DIVINE_ARROW_ID")) {
            String var6 = ((MetadataValue)var0.getMetadata("DIVINE_ARROW_ID").get(0)).asString();
            ArrowManager.DivineArrow var7 = plugin.getMM().getArrowManager().getArrowById(var6);

            ArrowManager.ArrowAttribute var8;
            for(Iterator var9 = var7.getAttributes().values().iterator(); var9.hasNext(); var5.put(var8.getAttribute(), var10)) {
               var8 = (ArrowManager.ArrowAttribute)var9.next();
               var10 = var8.getValue();
               if (var8.getAction() == ArrowManager.AttributeAction.MINUS) {
                  var10 = -var10;
               }
            }
         }

         ItemStat[] var48;
         int var46 = (var48 = ItemStat.values()).length;

         for(int var45 = 0; var45 < var46; ++var45) {
            ItemStat var43 = var48[var45];
            if (!var5.containsKey(var43)) {
               var5.put(var43, 0.0D);
            }
         }

         double var44 = 1.0D;
         if ((double)r.nextInt(100) <= EntityAPI.getItemStat(var1, ItemStat.CRITICAL_RATE) + (Double)var5.get(ItemStat.CRITICAL_RATE)) {
            var44 = EntityAPI.getItemStat(var1, ItemStat.CRITICAL_DAMAGE) + (Double)var5.get(ItemStat.CRITICAL_DAMAGE);
            if (var44 == 0.0D) {
               var44 = 1.0D;
            }

            if (plugin.getMM().getCombatLogManager().isActive()) {
               plugin.getMM().getCombatLogManager().setCritMeta(var0);
            }
         }

         if (var2 == 0.0D && var4 != null) {
            var2 = ItemAPI.getItemTotalDamage(var4);
            if (var2 == 0.0D) {
               var2 = ItemAPI.getDefaultDamage(var4);
            }
         }

         double var47 = dmgReducer(var2, ItemAPI.getItemTotalDamage(var4), ItemAPI.getDefaultDamage(var4));
         var10 = var47;
         ItemStat var12 = ItemStat.PVE_DEFENSE;
         ItemStat var13 = ItemStat.PVE_DAMAGE;
         if (var0 instanceof Player && var1 instanceof Player) {
            var12 = ItemStat.PVP_DEFENSE;
            var13 = ItemStat.PVP_DAMAGE;
         }

         double var14 = ItemAPI.getAttribute(var4, ItemStat.DIRECT_DAMAGE) / 100.0D;
         double var16 = 0.0D;
         double var18 = EntityAPI.getItemStat(var1, ItemStat.PENETRATION) + (Double)var5.get(ItemStat.PENETRATION);
         double var20 = EntityAPI.getItemStat(var0, var12) + (Double)var5.get(var12);
         double var22 = EntityAPI.getItemStat(var1, var13) + (Double)var5.get(var13);
         HashMap var24 = ItemAPI.getDamageTypes(var1);
         HashMap var25 = ItemAPI.getDefenseTypes(var0);
         DamageType var26;
         Iterator var27;
         if (var24.isEmpty()) {
            var27 = plugin.getCFG().getDamageTypes().values().iterator();

            while(var27.hasNext()) {
               var26 = (DamageType)var27.next();
               if (var26.isDefault()) {
                  String var28 = var1.getLocation().getBlock().getBiome().name();
                  var24.put(var26, var47 * var26.getDamageModifierByBiome(var28));
                  var10 = var47 * var26.getDamageModifierByBiome(var28);
                  break;
               }
            }
         }

         double var30;
         if (var25.isEmpty()) {
            var27 = var24.keySet().iterator();

            label156:
            while(true) {
               do {
                  if (!var27.hasNext()) {
                     break label156;
                  }

                  var26 = (DamageType)var27.next();
               } while(!var26.isDefault());

               Iterator var29 = plugin.getCFG().getArmorTypes().values().iterator();

               while(var29.hasNext()) {
                  ArmorType var52 = (ArmorType)var29.next();
                  if (var52.getBlockDamageTypes().contains(var26.getId())) {
                     var30 = ItemAPI.getDefaultDefense(var0);
                     var25.put(var52, var30);
                     break label156;
                  }
               }
            }
         }

         String var49 = "";
         Iterator var53 = var24.keySet().iterator();

         String var54;
         while(var53.hasNext()) {
            DamageType var50 = (DamageType)var53.next();
            var54 = "";
            var30 = (Double)var24.get(var50);
            if (!var50.isDefault() || var30 != var10) {
               var30 = dmgReducer(var2, var30, ItemAPI.getDefaultDamage(var4));
            }

            double var32 = var30 * var14;
            var30 = Math.max(0.0D, var30 - var32);
            var16 += var32;

            String var40;
            for(Iterator var35 = var25.keySet().iterator(); var35.hasNext(); var54 = var54 + "(" + var30 + " - " + var40 + ") + ") {
               ArmorType var34 = (ArmorType)var35.next();
               double var36 = 0.0D;
               if (var34.getBlockDamageTypes().contains(var50.getId())) {
                  var36 = (Double)var25.get(var34);
               }

               double var38 = Math.min(20.0D, EntityAPI.getEnchantedDefense(var1, var0));
               var30 *= 1.0D - var38 / 25.0D;
               var40 = var34.getFormula().replace("%crit%", String.valueOf(var44)).replace("%def%", String.valueOf(var36)).replace("%dmg%", String.valueOf(var30)).replace("%penetrate%", String.valueOf(var18));
            }

            if (var54.isEmpty()) {
               var54 = "0";
            }

            if (var54.length() > 3) {
               var54 = var54.substring(0, var54.length() - 2).trim();
            }

            var54 = var30 + " - (" + var54 + ")";
            double var56 = 0.0D;

            try {
               var56 = Math.max(0.0D, (Double)engine.eval(var54)) * var44;
            } catch (ScriptException var42) {
            }

            var49 = var49 + "(" + var56 + ") + ";
            if (plugin.getMM().getCombatLogManager().isActive()) {
               plugin.getMM().getCombatLogManager().setDTMeta(var0, var50.getId(), var56 + var32);
            }

            Iterator var37 = (new ArrayList(var50.getActions())).iterator();

            while(var37.hasNext()) {
               String var57 = (String)var37.next();
               if (var57.contains("[DAMAGE]")) {
                  var50.getActions().remove(var57);
               }
            }

            DivineItemsAPI.executeActions(var1, var50.getActions(), var4);
         }

         if (var49.length() > 3) {
            var49 = var49.substring(0, var49.length() - 2).trim();
         }

         double var51 = 0.0D;
         if (Utils.getRandDouble(0.0D, 100.0D) <= EntityAPI.getItemStat(var0, ItemStat.BLOCK_RATE) + (Double)var5.get(ItemStat.BLOCK_RATE)) {
            var51 = EntityAPI.getItemStat(var0, ItemStat.BLOCK_DAMAGE) + (Double)var5.get(ItemStat.BLOCK_DAMAGE);
            if (plugin.getMM().getCombatLogManager().isActive()) {
               plugin.getMM().getCombatLogManager().setBlockMeta(var0, var51);
            }
         }

         var54 = plugin.getCM().getCFG().getFormulaOther().replace("%pvpe_dmg%", String.valueOf(var22)).replace("%pvpe_def%", String.valueOf(var20)).replace("%crit%", String.valueOf(var44)).replace("%block%", String.valueOf(var51));
         String var55 = plugin.getCM().getCFG().getFormulaDamage().replace("%dmg%", var49).replace("%other%", var54).replace("%crit%", String.valueOf(var44)).replace("%block%", String.valueOf(var51));
         double var31 = 1.0D;

         try {
            var31 = var16 + Math.max(0.0D, (Double)engine.eval(var55));
         } catch (ScriptException var41) {
         }

         var0.removeMetadata("DIVINE_ARROW_ID", plugin);
         double var33 = EntityAPI.getItemStat(var1, ItemStat.BLEED_RATE);
         if (var33 > 0.0D && Utils.getRandDouble(0.0D, 100.0D) <= var33) {
            plugin.getTM().addBleedEffect(var0, var31);
         }

         return var31;
      }
   }

   public static void setProjectileData(Projectile var0, LivingEntity var1, ItemStack var2) {
      var0.setMetadata("DIItem", new FixedMetadataValue(plugin, var2));
      var0.setMetadata("dont_pick_me", new FixedMetadataValue(plugin, "yes"));
   }

   public static void setEntityData(Entity var0, LivingEntity var1, ItemStack var2) {
      var0.setMetadata("DIItem", new FixedMetadataValue(plugin, var2));
      var0.setMetadata("LauncherZ", new FixedMetadataValue(plugin, var1.getName()));
   }

   public static boolean isValidItemType(String var0, ItemStack var1) {
      String var2 = var1.getType().name();
      if (!var0.equalsIgnoreCase("*") && !var0.equalsIgnoreCase("ALL")) {
         if (var2.contains(var0)) {
            return true;
         } else if (var2.equalsIgnoreCase(var0)) {
            return true;
         } else if (var0.equalsIgnoreCase("WEAPON") && isWeapon(var1)) {
            return true;
         } else if (var0.equalsIgnoreCase("TOOL") && plugin.getCM().getCFG().getTools().contains(var1.getType())) {
            return true;
         } else if (var0.equalsIgnoreCase("ARMOR") && isArmor(var1)) {
            return true;
         } else if (var0.startsWith("*") && var2.endsWith(var0.replace("*", "")) && (plugin.getCM().getCFG().getWeapons().contains(var1.getType()) || plugin.getCM().getCFG().getArmors().contains(var1.getType()) || plugin.getCM().getCFG().getTools().contains(var1.getType()))) {
            return true;
         } else {
            return var0.endsWith("*") && var2.startsWith(var0.replace("*", "")) && (plugin.getCM().getCFG().getWeapons().contains(var1.getType()) || plugin.getCM().getCFG().getArmors().contains(var1.getType()) || plugin.getCM().getCFG().getTools().contains(var1.getType()));
         }
      } else {
         return true;
      }
   }

   public static String getValidSkullName(Entity var0) {
      EntityType var1 = var0.getType();
      switch($SWITCH_TABLE$org$bukkit$entity$EntityType()[var1.ordinal()]) {
      case 4:
         return "MHF_EGuardian";
      case 5:
         return "MHF_WSkeleton";
      case 58:
         return "MHF_LavaSlime";
      default:
         String var2 = var1.name().toLowerCase().replace("_", " ");
         return "MHF_" + WordUtils.capitalizeFully(var2.replace(" ", ""));
      }
   }

   public static boolean isWeapon(ItemStack var0) {
      return plugin.getCM().getCFG().getWeapons().contains(var0.getType()) || plugin.getCM().getCFG().getTools().contains(var0.getType());
   }

   public static boolean isArmor(ItemStack var0) {
      return plugin.getCM().getCFG().getArmors().contains(var0.getType());
   }

   public static double calc(String var0) {
      double var1 = 0.0D;

      try {
         var1 = Math.max(0.0D, Double.valueOf(engine.eval(var0).toString()));
      } catch (ScriptException var4) {
      }

      return var1;
   }

   // $FF: synthetic method
   static int[] $SWITCH_TABLE$org$bukkit$entity$EntityType() {
      int[] var10000 = $SWITCH_TABLE$org$bukkit$entity$EntityType;
      if (var10000 != null) {
         return var10000;
      } else {
         int[] var0 = new int[EntityType.values().length];

         try {
            var0[EntityType.AREA_EFFECT_CLOUD.ordinal()] = 3;
         } catch (NoSuchFieldError var91) {
         }

         try {
            var0[EntityType.ARMOR_STAND.ordinal()] = 30;
         } catch (NoSuchFieldError var90) {
         }

         try {
            var0[EntityType.ARROW.ordinal()] = 10;
         } catch (NoSuchFieldError var89) {
         }

         try {
            var0[EntityType.BAT.ordinal()] = 61;
         } catch (NoSuchFieldError var88) {
         }

         try {
            var0[EntityType.BLAZE.ordinal()] = 57;
         } catch (NoSuchFieldError var87) {
         }

         try {
            var0[EntityType.BOAT.ordinal()] = 39;
         } catch (NoSuchFieldError var86) {
         }

         try {
            var0[EntityType.CAVE_SPIDER.ordinal()] = 55;
         } catch (NoSuchFieldError var85) {
         }

         try {
            var0[EntityType.CHICKEN.ordinal()] = 69;
         } catch (NoSuchFieldError var84) {
         }

         try {
            var0[EntityType.COMPLEX_PART.ordinal()] = 89;
         } catch (NoSuchFieldError var83) {
         }

         try {
            var0[EntityType.COW.ordinal()] = 68;
         } catch (NoSuchFieldError var82) {
         }

         try {
            var0[EntityType.CREEPER.ordinal()] = 46;
         } catch (NoSuchFieldError var81) {
         }

         try {
            var0[EntityType.DONKEY.ordinal()] = 31;
         } catch (NoSuchFieldError var80) {
         }

         try {
            var0[EntityType.DRAGON_FIREBALL.ordinal()] = 26;
         } catch (NoSuchFieldError var79) {
         }

         try {
            var0[EntityType.DROPPED_ITEM.ordinal()] = 1;
         } catch (NoSuchFieldError var78) {
         }

         try {
            var0[EntityType.EGG.ordinal()] = 7;
         } catch (NoSuchFieldError var77) {
         }

         try {
            var0[EntityType.ELDER_GUARDIAN.ordinal()] = 4;
         } catch (NoSuchFieldError var76) {
         }

         try {
            var0[EntityType.ENDERMAN.ordinal()] = 54;
         } catch (NoSuchFieldError var75) {
         }

         try {
            var0[EntityType.ENDERMITE.ordinal()] = 63;
         } catch (NoSuchFieldError var74) {
         }

         try {
            var0[EntityType.ENDER_CRYSTAL.ordinal()] = 83;
         } catch (NoSuchFieldError var73) {
         }

         try {
            var0[EntityType.ENDER_DRAGON.ordinal()] = 59;
         } catch (NoSuchFieldError var72) {
         }

         try {
            var0[EntityType.ENDER_PEARL.ordinal()] = 14;
         } catch (NoSuchFieldError var71) {
         }

         try {
            var0[EntityType.ENDER_SIGNAL.ordinal()] = 15;
         } catch (NoSuchFieldError var70) {
         }

         try {
            var0[EntityType.EVOKER.ordinal()] = 34;
         } catch (NoSuchFieldError var69) {
         }

         try {
            var0[EntityType.EVOKER_FANGS.ordinal()] = 33;
         } catch (NoSuchFieldError var68) {
         }

         try {
            var0[EntityType.EXPERIENCE_ORB.ordinal()] = 2;
         } catch (NoSuchFieldError var67) {
         }

         try {
            var0[EntityType.FALLING_BLOCK.ordinal()] = 21;
         } catch (NoSuchFieldError var66) {
         }

         try {
            var0[EntityType.FIREBALL.ordinal()] = 12;
         } catch (NoSuchFieldError var65) {
         }

         try {
            var0[EntityType.FIREWORK.ordinal()] = 22;
         } catch (NoSuchFieldError var64) {
         }

         try {
            var0[EntityType.FISHING_HOOK.ordinal()] = 85;
         } catch (NoSuchFieldError var63) {
         }

         try {
            var0[EntityType.GHAST.ordinal()] = 52;
         } catch (NoSuchFieldError var62) {
         }

         try {
            var0[EntityType.GIANT.ordinal()] = 49;
         } catch (NoSuchFieldError var61) {
         }

         try {
            var0[EntityType.GUARDIAN.ordinal()] = 64;
         } catch (NoSuchFieldError var60) {
         }

         try {
            var0[EntityType.HORSE.ordinal()] = 76;
         } catch (NoSuchFieldError var59) {
         }

         try {
            var0[EntityType.HUSK.ordinal()] = 23;
         } catch (NoSuchFieldError var58) {
         }

         try {
            var0[EntityType.ILLUSIONER.ordinal()] = 37;
         } catch (NoSuchFieldError var57) {
         }

         try {
            var0[EntityType.IRON_GOLEM.ordinal()] = 75;
         } catch (NoSuchFieldError var56) {
         }

         try {
            var0[EntityType.ITEM_FRAME.ordinal()] = 18;
         } catch (NoSuchFieldError var55) {
         }

         try {
            var0[EntityType.LEASH_HITCH.ordinal()] = 8;
         } catch (NoSuchFieldError var54) {
         }

         try {
            var0[EntityType.LIGHTNING.ordinal()] = 86;
         } catch (NoSuchFieldError var53) {
         }

         try {
            var0[EntityType.LINGERING_POTION.ordinal()] = 84;
         } catch (NoSuchFieldError var52) {
         }

         try {
            var0[EntityType.LLAMA.ordinal()] = 79;
         } catch (NoSuchFieldError var51) {
         }

         try {
            var0[EntityType.LLAMA_SPIT.ordinal()] = 80;
         } catch (NoSuchFieldError var50) {
         }

         try {
            var0[EntityType.MAGMA_CUBE.ordinal()] = 58;
         } catch (NoSuchFieldError var49) {
         }

         try {
            var0[EntityType.MINECART.ordinal()] = 40;
         } catch (NoSuchFieldError var48) {
         }

         try {
            var0[EntityType.MINECART_CHEST.ordinal()] = 41;
         } catch (NoSuchFieldError var47) {
         }

         try {
            var0[EntityType.MINECART_COMMAND.ordinal()] = 38;
         } catch (NoSuchFieldError var46) {
         }

         try {
            var0[EntityType.MINECART_FURNACE.ordinal()] = 42;
         } catch (NoSuchFieldError var45) {
         }

         try {
            var0[EntityType.MINECART_HOPPER.ordinal()] = 44;
         } catch (NoSuchFieldError var44) {
         }

         try {
            var0[EntityType.MINECART_MOB_SPAWNER.ordinal()] = 45;
         } catch (NoSuchFieldError var43) {
         }

         try {
            var0[EntityType.MINECART_TNT.ordinal()] = 43;
         } catch (NoSuchFieldError var42) {
         }

         try {
            var0[EntityType.MULE.ordinal()] = 32;
         } catch (NoSuchFieldError var41) {
         }

         try {
            var0[EntityType.MUSHROOM_COW.ordinal()] = 72;
         } catch (NoSuchFieldError var40) {
         }

         try {
            var0[EntityType.OCELOT.ordinal()] = 74;
         } catch (NoSuchFieldError var39) {
         }

         try {
            var0[EntityType.PAINTING.ordinal()] = 9;
         } catch (NoSuchFieldError var38) {
         }

         try {
            var0[EntityType.PARROT.ordinal()] = 81;
         } catch (NoSuchFieldError var37) {
         }

         try {
            var0[EntityType.PIG.ordinal()] = 66;
         } catch (NoSuchFieldError var36) {
         }

         try {
            var0[EntityType.PIG_ZOMBIE.ordinal()] = 53;
         } catch (NoSuchFieldError var35) {
         }

         try {
            var0[EntityType.PLAYER.ordinal()] = 88;
         } catch (NoSuchFieldError var34) {
         }

         try {
            var0[EntityType.POLAR_BEAR.ordinal()] = 78;
         } catch (NoSuchFieldError var33) {
         }

         try {
            var0[EntityType.PRIMED_TNT.ordinal()] = 20;
         } catch (NoSuchFieldError var32) {
         }

         try {
            var0[EntityType.RABBIT.ordinal()] = 77;
         } catch (NoSuchFieldError var31) {
         }

         try {
            var0[EntityType.SHEEP.ordinal()] = 67;
         } catch (NoSuchFieldError var30) {
         }

         try {
            var0[EntityType.SHULKER.ordinal()] = 65;
         } catch (NoSuchFieldError var29) {
         }

         try {
            var0[EntityType.SHULKER_BULLET.ordinal()] = 25;
         } catch (NoSuchFieldError var28) {
         }

         try {
            var0[EntityType.SILVERFISH.ordinal()] = 56;
         } catch (NoSuchFieldError var27) {
         }

         try {
            var0[EntityType.SKELETON.ordinal()] = 47;
         } catch (NoSuchFieldError var26) {
         }

         try {
            var0[EntityType.SKELETON_HORSE.ordinal()] = 28;
         } catch (NoSuchFieldError var25) {
         }

         try {
            var0[EntityType.SLIME.ordinal()] = 51;
         } catch (NoSuchFieldError var24) {
         }

         try {
            var0[EntityType.SMALL_FIREBALL.ordinal()] = 13;
         } catch (NoSuchFieldError var23) {
         }

         try {
            var0[EntityType.SNOWBALL.ordinal()] = 11;
         } catch (NoSuchFieldError var22) {
         }

         try {
            var0[EntityType.SNOWMAN.ordinal()] = 73;
         } catch (NoSuchFieldError var21) {
         }

         try {
            var0[EntityType.SPECTRAL_ARROW.ordinal()] = 24;
         } catch (NoSuchFieldError var20) {
         }

         try {
            var0[EntityType.SPIDER.ordinal()] = 48;
         } catch (NoSuchFieldError var19) {
         }

         try {
            var0[EntityType.SPLASH_POTION.ordinal()] = 16;
         } catch (NoSuchFieldError var18) {
         }

         try {
            var0[EntityType.SQUID.ordinal()] = 70;
         } catch (NoSuchFieldError var17) {
         }

         try {
            var0[EntityType.STRAY.ordinal()] = 6;
         } catch (NoSuchFieldError var16) {
         }

         try {
            var0[EntityType.THROWN_EXP_BOTTLE.ordinal()] = 17;
         } catch (NoSuchFieldError var15) {
         }

         try {
            var0[EntityType.TIPPED_ARROW.ordinal()] = 90;
         } catch (NoSuchFieldError var14) {
         }

         try {
            var0[EntityType.UNKNOWN.ordinal()] = 91;
         } catch (NoSuchFieldError var13) {
         }

         try {
            var0[EntityType.VEX.ordinal()] = 35;
         } catch (NoSuchFieldError var12) {
         }

         try {
            var0[EntityType.VILLAGER.ordinal()] = 82;
         } catch (NoSuchFieldError var11) {
         }

         try {
            var0[EntityType.VINDICATOR.ordinal()] = 36;
         } catch (NoSuchFieldError var10) {
         }

         try {
            var0[EntityType.WEATHER.ordinal()] = 87;
         } catch (NoSuchFieldError var9) {
         }

         try {
            var0[EntityType.WITCH.ordinal()] = 62;
         } catch (NoSuchFieldError var8) {
         }

         try {
            var0[EntityType.WITHER.ordinal()] = 60;
         } catch (NoSuchFieldError var7) {
         }

         try {
            var0[EntityType.WITHER_SKELETON.ordinal()] = 5;
         } catch (NoSuchFieldError var6) {
         }

         try {
            var0[EntityType.WITHER_SKULL.ordinal()] = 19;
         } catch (NoSuchFieldError var5) {
         }

         try {
            var0[EntityType.WOLF.ordinal()] = 71;
         } catch (NoSuchFieldError var4) {
         }

         try {
            var0[EntityType.ZOMBIE.ordinal()] = 50;
         } catch (NoSuchFieldError var3) {
         }

         try {
            var0[EntityType.ZOMBIE_HORSE.ordinal()] = 29;
         } catch (NoSuchFieldError var2) {
         }

         try {
            var0[EntityType.ZOMBIE_VILLAGER.ordinal()] = 27;
         } catch (NoSuchFieldError var1) {
         }

         $SWITCH_TABLE$org$bukkit$entity$EntityType = var0;
         return var0;
      }
   }
}
