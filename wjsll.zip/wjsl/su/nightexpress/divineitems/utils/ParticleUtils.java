package su.nightexpress.divineitems.utils;

import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;
import su.nightexpress.divineitems.DivineItems;

public class ParticleUtils {
   private static DivineItems plugin;

   static {
      plugin = DivineItems.instance;
   }

   public static void wave(final Location var0) {
      (new BukkitRunnable() {
         int i = 0;

         public void run() {
            if (++this.i == 20) {
               this.cancel();
            }

            int var1 = this.i;
            double var2 = (0.5D + (double)var1 * 0.15D) % 3.0D;

            for(int var4 = 0; (double)var4 < var2 * 10.0D; ++var4) {
               double var5 = 6.283185307179586D / (var2 * 10.0D) * (double)var4;
               Utils.playEffect("REDSTONE", 0.10000000149011612D, 0.10000000149011612D, 0.10000000149011612D, 0.0D, 2, Utils.getPointOnCircle(var0, false, var5, var2, 1.0D));
               if (var1 < 15) {
                  Utils.playEffect("CRIT_MAGIC", 0.10000000149011612D, 0.10000000149011612D, 0.10000000149011612D, 0.0D, 1, Utils.getPointOnCircle(var0, false, var5, var2, 1.0D));
               }
            }

         }
      }).runTaskTimerAsynchronously(plugin, 0L, 1L);
   }

   public static void doParticle(Entity var0, final String var1, final String var2) {
      (new BukkitRunnable(var0) {
         int i = 1;
         int k = 0;
         World localWorld;
         double d3;
         double d5;
         double d7;

         {
            this.localWorld = var1x.getWorld();
            this.d3 = var1x.getLocation().getX();
            this.d5 = var1x.getLocation().getY();
            this.d7 = var1x.getLocation().getZ();
         }

         public void run() {
            if (this.k == 3) {
               this.cancel();
            }

            Utils.playEffect(var1, 0.0D, 0.0D, 0.0D, 0.0D, this.i, new Location(this.localWorld, this.d3, this.d5 + 1.8D, this.d7));
            Utils.playEffect(var1, 0.0D, 0.0D, 0.0D, 0.0D, this.i, new Location(this.localWorld, this.d3, this.d5 + 1.5D, this.d7));
            Utils.playEffect(var1, 0.0D, 0.0D, 0.0D, 0.0D, this.i, new Location(this.localWorld, this.d3 + 0.6D, this.d5 + 1.8D, this.d7));
            Utils.playEffect(var1, 0.0D, 0.0D, 0.0D, 0.0D, this.i, new Location(this.localWorld, this.d3 + 0.6D, this.d5 + 1.5D, this.d7));
            Utils.playEffect(var1, 0.0D, 0.0D, 0.0D, 0.0D, this.i, new Location(this.localWorld, this.d3 + 0.6D, this.d5 + 1.8D, this.d7 + 0.6D));
            Utils.playEffect(var1, 0.0D, 0.0D, 0.0D, 0.0D, this.i, new Location(this.localWorld, this.d3 + 0.6D, this.d5 + 1.5D, this.d7 + 0.6D));
            Utils.playEffect(var1, 0.0D, 0.0D, 0.0D, 0.0D, this.i, new Location(this.localWorld, this.d3 - 0.6D, this.d5 + 1.8D, this.d7));
            Utils.playEffect(var1, 0.0D, 0.0D, 0.0D, 0.0D, this.i, new Location(this.localWorld, this.d3 - 0.6D, this.d5 + 1.5D, this.d7));
            Utils.playEffect(var1, 0.0D, 0.0D, 0.0D, 0.0D, this.i, new Location(this.localWorld, this.d3 - 0.6D, this.d5 + 1.8D, this.d7 + 0.6D));
            Utils.playEffect(var1, 0.0D, 0.0D, 0.0D, 0.0D, this.i, new Location(this.localWorld, this.d3 - 0.6D, this.d5 + 1.5D, this.d7 + 0.6D));
            Utils.playEffect(var1, 0.0D, 0.0D, 0.0D, 0.0D, this.i, new Location(this.localWorld, this.d3, this.d5 + 1.8D, this.d7 + 0.6D));
            Utils.playEffect(var1, 0.0D, 0.0D, 0.0D, 0.0D, this.i, new Location(this.localWorld, this.d3 - 0.6D, this.d5 + 1.5D, this.d7 + 0.6D));
            Utils.playEffect(var1, 0.0D, 0.0D, 0.0D, 0.0D, this.i, new Location(this.localWorld, this.d3 + 0.6D, this.d5 + 1.8D, this.d7 - 0.6D));
            Utils.playEffect(var1, 0.0D, 0.0D, 0.0D, 0.0D, this.i, new Location(this.localWorld, this.d3 + 0.6D, this.d5 + 1.5D, this.d7 - 0.6D));
            Utils.playEffect(var1, 0.0D, 0.0D, 0.0D, 0.0D, this.i, new Location(this.localWorld, this.d3, this.d5 + 1.8D, this.d7 - 0.6D));
            Utils.playEffect(var1, 0.0D, 0.0D, 0.0D, 0.0D, this.i, new Location(this.localWorld, this.d3, this.d5 + 1.5D, this.d7 - 0.6D));
            Utils.playEffect(var1, 0.0D, 0.0D, 0.0D, 0.0D, this.i, new Location(this.localWorld, this.d3 - 0.6D, this.d5 + 1.8D, this.d7 - 0.6D));
            Utils.playEffect(var1, 0.0D, 0.0D, 0.0D, 0.0D, this.i, new Location(this.localWorld, this.d3 - 0.6D, this.d5 + 1.5D, this.d7 - 0.6D));
            Utils.playEffect(var2, 0.0D, 0.0D, 0.0D, 0.0D, 2, new Location(this.localWorld, this.d3, this.d5 + 1.0D, this.d7));
            ++this.k;
         }
      }).runTaskTimer(plugin, 0L, 5L);
   }

   public static void repairEffect(final Location var0) {
      (new BukkitRunnable() {
         int i = 0;

         public void run() {
            if (++this.i == 72) {
               this.cancel();
            }

            int var1 = this.i;
            double var2 = 0.3141592653589793D * (double)var1;
            double var4 = (double)var1 * 0.1D % 2.5D;
            double var6 = 0.45D;
            Location var8 = Utils.getPointOnCircle(Utils.getCenter(var0), true, var2, 0.45D, var4);
            Location var9 = Utils.getPointOnCircle(Utils.getCenter(var0), true, var2 - 3.141592653589793D, 0.45D, var4);
            Utils.playEffect("FLAME", 0.0D, 0.0D, 0.0D, 0.0D, 1, var8);
            Utils.playEffect("FLAME", 0.0D, 0.0D, 0.0D, 0.0D, 1, var9);
            Utils.playEffect("SPELL_WITCH", 0.20000000298023224D, 0.0D, 0.20000000298023224D, 0.0D, 5, Utils.getCenter(var0).add(0.0D, 0.5D, 0.0D));
         }
      }).runTaskTimerAsynchronously(plugin, 0L, 1L);
   }

   public static void drawParticleLine(LivingEntity var0, LivingEntity var1, String var2, float var3, int var4) {
      Location var5 = var1.getLocation();
      Location var6 = var0.getLocation();
      Vector var7 = (new Location(var5.getWorld(), var5.getX(), var5.getY(), var5.getZ())).toVector();
      var6.setDirection(var7.subtract(var6.toVector()));
      Vector var8 = var6.getDirection();

      for(int var9 = 0; (double)var9 < var0.getLocation().distance(var5); ++var9) {
         Location var10 = var6.add(var8);
         Utils.playEffect(var2, 0.0D, 0.0D, 0.0D, 0.0D, 5, var10);
      }

   }
}
