package su.nightexpress.divineitems.utils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Method;
import java.util.Enumeration;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import org.apache.commons.lang.Validate;
import org.bukkit.plugin.java.JavaPlugin;

public final class ResourceExtractor {
   protected final JavaPlugin plugin;
   protected final File extractfolder;
   protected final String folderpath;
   protected final String regex;

   public ResourceExtractor(JavaPlugin var1, File var2, String var3, String var4) {
      Validate.notNull(var1, "The plugin cannot be null!");
      Validate.notNull(var1, "The extract folder cannot be null!");
      Validate.notNull(var1, "The folder path cannot be null!");
      this.extractfolder = var2;
      this.folderpath = var3;
      this.plugin = var1;
      this.regex = var4;
   }

   public void extract() {
      this.extract(false, true);
   }

   public void extract(boolean var1) {
      this.extract(var1, true);
   }

   public void extract(boolean var1, boolean var2) {
      File var3 = null;

      try {
         Method var4 = JavaPlugin.class.getDeclaredMethod("getFile");
         var4.setAccessible(true);
         var3 = (File)var4.invoke(this.plugin);
      } catch (Exception var12) {
         throw new IOException(var12);
      }

      if (!this.extractfolder.exists()) {
         this.extractfolder.mkdirs();
      }

      JarFile var13 = new JarFile(var3);
      Enumeration var5 = var13.entries();

      while(true) {
         while(true) {
            JarEntry var6;
            String var7;
            do {
               if (!var5.hasMoreElements()) {
                  var13.close();
                  return;
               }

               var6 = (JarEntry)var5.nextElement();
               var7 = var6.getName();
            } while(!var7.startsWith(this.folderpath));

            File var8;
            if (var6.isDirectory()) {
               if (var2) {
                  var8 = new File(this.extractfolder, var6.getName().replaceFirst(this.folderpath, ""));
                  if (!var8.exists()) {
                     var8.mkdirs();
                  }
               }
            } else {
               if (var2) {
                  var8 = new File(this.extractfolder, var7.replaceFirst(this.folderpath, ""));
               } else {
                  var8 = new File(this.extractfolder, var7.substring(var7.indexOf(File.separatorChar), var7.length()));
               }

               String var9 = var8.getName();
               if (this.regex == null || var9.matches(this.regex)) {
                  if (var8.exists() && var1) {
                     var8.delete();
                  }

                  if (!var8.exists()) {
                     InputStream var10 = var13.getInputStream(var6);
                     FileOutputStream var11 = new FileOutputStream(var8);

                     while(var10.available() > 0) {
                        var11.write(var10.read());
                     }

                     var11.close();
                     var10.close();
                  }
               }
            }
         }
      }
   }
}
