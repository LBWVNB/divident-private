package su.nightexpress.divineitems.utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Random;
import java.util.Set;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Fireball;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.EulerAngle;
import org.bukkit.util.Vector;
import su.nightexpress.divineitems.DivineItems;
import su.nightexpress.divineitems.api.ItemAPI;

public class Spells {
   private static Random r = new Random();
   private static DivineItems plugin;
   private static HashMap<Player, HashSet<LivingEntity>> ice;
   private static HashMap<Projectile, String> pjef;

   static {
      plugin = DivineItems.instance;
      ice = new HashMap();
      pjef = new HashMap();
   }

   public static void skillIceSnake(final Player var0) {
      boolean var1 = true;
      final double var2 = ItemAPI.getItemTotalDamage(var0.getInventory().getItemInMainHand());
      final ArrayList var4 = new ArrayList();
      final Location var5 = var0.getEyeLocation().add(0.0D, -2.2D, 0.0D);
      final Vector var6 = var5.getDirection();
      (new BukkitRunnable() {
         int i = 0;

         public void run() {
            if (this.i == 20) {
               this.cancel();
            }

            Location var1 = var5.add(var6);
            if (this.i % 5 == 0) {
               if (Utils.getDirection(var0.getLocation().getYaw()) != "EAST" && Utils.getDirection(var0.getLocation().getYaw()) != "WEST") {
                  var1 = var1.add(0.33D, 0.0D, 0.0D);
               } else {
                  var1 = var1.add(0.0D, 0.0D, 0.33D);
               }
            }

            ArmorStand var2x = (ArmorStand)var0.getWorld().spawn(var1, ArmorStand.class);
            var2x.setVisible(false);
            var2x.setHelmet(new ItemStack(Material.ICE));
            var2x.setGravity(false);
            var2x.setInvulnerable(true);
            var2x.setSmall(false);
            Spells.setHeadPos(var2x);
            var4.add(var2x);
            EntityUtils.add(var2x);
            Utils.playEffect("BLOCK_CRACK:ICE", 0.30000001192092896D, 0.0D, 0.30000001192092896D, 0.30000001192092896D, 15, var1.clone().add(0.0D, 2.0D, 0.0D));
            Location var3 = var1.clone().add(Utils.getRandDoubleNega(-0.25D, 0.25D), Utils.getRandDouble(0.2D, 0.5D), Utils.getRandDoubleNega(-0.25D, 0.25D));
            ArmorStand var4x = (ArmorStand)var0.getWorld().spawn(var3, ArmorStand.class);
            var4x.setVisible(false);
            var4x.setHelmet(new ItemStack(Material.SNOW_BLOCK));
            var4x.setGravity(false);
            var4x.setInvulnerable(true);
            var4x.setSmall(true);
            Spells.setHeadPos(var4x);
            var4.add(var4x);
            EntityUtils.add(var4x);
            Utils.playEffect("BLOCK_CRACK:SNOW", 0.30000001192092896D, 0.0D, 0.30000001192092896D, 0.30000001192092896D, 15, var3.clone().add(0.0D, 0.75D, 0.0D));
            Iterator var6x = EntityUtils.getEnemies(var2x, 1.15D, var0).iterator();

            while(true) {
               LivingEntity var5x;
               do {
                  if (!var6x.hasNext()) {
                     if ((new Location(var1.getWorld(), var1.getX(), var1.getY() + 1.5D, var1.getZ())).getBlock().getType() != Material.AIR) {
                        this.cancel();
                     }

                     ++this.i;
                     return;
                  }

                  var5x = (LivingEntity)var6x.next();
               } while(Spells.ice.get(var0) != null && ((HashSet)Spells.ice.get(var0)).contains(var5x));

               var5x.damage(var2, var0);
               if (var5x.hasPotionEffect(PotionEffectType.SLOW)) {
                  var5x.removePotionEffect(PotionEffectType.SLOW);
               }

               var5x.addPotionEffect(new PotionEffect(PotionEffectType.SLOW, 100, 0));
               if (Spells.ice.get(var0) == null) {
                  HashSet var7 = new HashSet();
                  var7.add(var5x);
                  Spells.ice.put(var0, var7);
               } else {
                  ((HashSet)Spells.ice.get(var0)).add(var5x);
               }
            }
         }
      }).runTaskTimer(plugin, 0L, 1L);
      (new BukkitRunnable() {
         public void run() {
            Iterator var2 = var4.iterator();

            while(var2.hasNext()) {
               ArmorStand var1 = (ArmorStand)var2.next();
               Utils.playEffect("FIREWORKS_SPARK", 0.0D, 0.0D, 0.0D, 0.20000000298023224D, 5, var1.getLocation().add(0.0D, 2.0D, 0.0D));
               var1.remove();
               EntityUtils.remove(var1);
            }

         }
      }).runTaskLater(plugin, 50L);
      if (ice.get(var0) != null) {
         ((HashSet)ice.get(var0)).clear();
         ice.remove(var0);
      }

      var0.playSound(var0.getLocation(), Sound.ENTITY_BLAZE_SHOOT, 0.7F, 0.7F);
   }

   private static void setHeadPos(ArmorStand var0) {
      double var1 = Utils.getRandDouble(0.0D, 15.0D);
      double var3 = Utils.getRandDouble(0.0D, 15.0D);
      EulerAngle var5 = new EulerAngle(var1, 0.0D, var3);
      var0.setHeadPose(var5);
   }

   public static void skillMeteor(final Player var0) {
      byte var1 = 50;
      Block var2 = var0.getTargetBlock((Set)null, var1);
      final Location var3 = var2.getLocation();
      final Location var4 = new Location(var3.getWorld(), var3.getX(), var3.getY() + 20.0D, var3.getZ());
      Location var5 = var2.getLocation();
      Vector var6 = (new Location(var3.getWorld(), var3.getX(), var3.getY() + 20.0D, var3.getZ())).toVector();
      var5.setDirection(var6.subtract(var5.toVector()));
      Vector var7 = var5.getDirection();

      for(int var8 = 0; (double)var8 < var4.distance(var3); ++var8) {
         Location var9 = var5.add(var7);
         Utils.playEffect("FLAME", 0.0D, 0.0D, 0.0D, 0.0D, 25, var9);
      }

      (new BukkitRunnable() {
         public void run() {
            Location var1 = new Location(var4.getWorld(), var4.getX() + (double)Spells.r.nextInt(10), var4.getY(), var4.getZ() + (double)Spells.r.nextInt(10));
            Vector var2 = (new Location(var3.getWorld(), var3.getX(), var3.getY(), var3.getZ())).toVector();
            var1.setDirection(var2.subtract(var1.toVector()));
            Vector var3x = var1.getDirection();
            Fireball var4x = (Fireball)var1.getWorld().spawn(var1, Fireball.class);
            var4x.setShooter(var0);
            var4x.setDirection(var3x);
            var4x.setVelocity(var3x.normalize());
            Spells.pjef.put(var4x, "SMOKE_LARGE");
         }
      }).runTaskLater(plugin, 30L);
      var0.playSound(var0.getLocation(), Sound.ENTITY_BLAZE_AMBIENT, 0.7F, 0.7F);
   }

   public static void startPjEfTask() {
      plugin.getServer().getScheduler().scheduleSyncRepeatingTask(plugin, new Runnable() {
         public void run() {
            HashMap var1 = new HashMap(Spells.pjef);
            Iterator var3 = var1.keySet().iterator();

            while(true) {
               while(var3.hasNext()) {
                  Projectile var2 = (Projectile)var3.next();
                  if (!var2.isOnGround() && var2.isValid()) {
                     String var4 = (String)var1.get(var2);
                     Utils.playEffect(var4, 0.0D, 0.0D, 0.0D, 0.0D, 25, var2.getLocation());
                  } else {
                     Spells.pjef.remove(var2);
                  }
               }

               return;
            }
         }
      }, 0L, 1L);
   }

   public static void skillIceFireStorm(final Player var0, final int var1) {
      byte var2 = 50;
      Block var3 = var0.getTargetBlock((Set)null, var2);
      final Location var4 = var3.getLocation();
      final Location var5 = var4.clone().add(0.0D, 20.0D, 0.0D);
      final ItemStack var6;
      final String var7;
      final String var8;
      if (var1 == 0) {
         var6 = new ItemStack(Material.ICE);
         var7 = "CLOUD";
         var8 = "FIREWORKS_SPARK";
      } else {
         var6 = new ItemStack(Material.NETHERRACK);
         var7 = "LAVA";
         var8 = "FLAME";
      }

      (new BukkitRunnable() {
         public void run() {
            (new BukkitRunnable() {
               int i = 0;

               public void run() {
                  if (this.i == 8) {
                     this.cancel();
                  } else {
                     final double var1x = ItemAPI.getItemTotalDamage(var0.getInventory().getItemInMainHand());
                     final Location var3 = var5.clone().add((double)Spells.r.nextInt(10), 0.0D, (double)Spells.r.nextInt(10));
                     Vector var4x = var4.clone().add((double)Spells.r.nextInt(5), 0.0D, (double)Spells.r.nextInt(5)).toVector();
                     var3.setDirection(var4x.subtract(var3.toVector()));
                     final Vector var5x = var3.getDirection();
                     final ArmorStand var6x = (ArmorStand)var0.getWorld().spawn(var3, ArmorStand.class);
                     var6x.setVisible(false);
                     var6x.setHelmet(var6);
                     var6x.setGravity(false);
                     var6x.setInvulnerable(true);
                     var6x.setSmall(true);
                     Spells.setHeadPos(var6x);
                     (new BukkitRunnable() {
                        public void run() {
                           Location var1xx = var3.add(var5x);
                           var6x.teleport(var1xx);
                           Location var2 = var6x.getEyeLocation().clone().add(0.0D, 1.3D, 0.0D);
                           if (var2.getBlock() != null && var2.getBlock().getType() != Material.AIR) {
                              Utils.playEffect(var7, 1.25D, 0.20000000298023224D, 1.25D, 0.10000000149011612D, 100, var2);
                              Iterator var4x = EntityUtils.getEnemies(var6x, 2.0D, var0).iterator();

                              while(var4x.hasNext()) {
                                 LivingEntity var3x = (LivingEntity)var4x.next();
                                 var3x.damage(var1x, var0);
                                 if (var1 == 0) {
                                    if (var3x.hasPotionEffect(PotionEffectType.SLOW)) {
                                       var3x.removePotionEffect(PotionEffectType.SLOW);
                                    }

                                    var3x.addPotionEffect(new PotionEffect(PotionEffectType.SLOW, 100, 0));
                                 } else {
                                    var3x.setFireTicks(100);
                                 }
                              }

                              var2.getWorld().playSound(var2, Sound.ENTITY_GENERIC_EXPLODE, 1.0F, 1.0F);
                              var6x.remove();
                              this.cancel();
                           } else {
                              var2.getWorld().playSound(var2, Sound.ENTITY_GENERIC_EXPLODE, 1.0F, 1.0F);
                              Utils.playEffect(var8, 0.0D, 0.0D, 0.0D, 0.25D, 15, var6x.getEyeLocation().clone().add(0.2D, 1.0D, 0.2D));
                              Utils.playEffect("BLOCK_CRACK:" + var6.getType().name(), 0.0D, 0.0D, 0.0D, 0.30000001192092896D, 15, var6x.getEyeLocation().clone().add(0.2D, 1.0D, 0.2D));
                           }
                        }
                     }).runTaskTimer(Spells.plugin, 0L, 1L);
                     ++this.i;
                  }
               }
            }).runTaskTimer(Spells.plugin, 0L, 15L);
         }
      }).runTaskLater(plugin, 30L);
   }
}
