package su.nightexpress.divineitems.utils;

import com.mojang.authlib.GameProfile;
import com.mojang.authlib.properties.Property;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import java.util.Map.Entry;
import net.md_5.bungee.api.chat.BaseComponent;
import net.md_5.bungee.api.chat.ClickEvent;
import net.md_5.bungee.api.chat.ComponentBuilder;
import net.md_5.bungee.api.chat.HoverEvent;
import net.md_5.bungee.api.chat.ComponentBuilder.FormatRetention;
import net.md_5.bungee.api.chat.HoverEvent.Action;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.FireworkEffect;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.World;
import org.bukkit.FireworkEffect.Type;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Firework;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.FireworkMeta;
import org.bukkit.inventory.meta.SkullMeta;
import su.nightexpress.divineitems.DivineItems;
import su.nightexpress.divineitems.config.Lang;
import su.nightexpress.divineitems.nms.VersionUtils;

public class Utils {
   private static DivineItems plugin = DivineItems.getInstance();
   private static Random r = new Random();

   public static ItemStack buildItem(String[] var0, String var1) {
      Material var2 = Material.getMaterial(var0[0]);
      if (var2 == null) {
         return null;
      } else {
         int var3 = 0;
         if (var0.length >= 2) {
            var3 = Integer.parseInt(var0[1]);
         }

         ItemStack var4 = new ItemStack(var2, 1, (short)var3);
         if (var0.length == 3) {
            UUID var5 = plugin.getCM().getItemHash(var1);
            var4 = getHashed(var4, var0[2], var5);
         }

         return var4.clone();
      }
   }

   public static double round3(double var0) {
      int var2 = (int)(var0 * 100.0D);
      double var3 = var0 * 100.0D;
      if (var3 - (double)var2 >= 0.5D) {
         ++var2;
      }

      var3 = (double)var2;
      return var3 / 100.0D;
   }

   public static int randInt(int var0, int var1) {
      int var2 = var0;
      var0 = Math.min(var0, var1);
      var1 = Math.max(var2, var1);
      return r.nextInt(var1 - var0 + 1) + var0;
   }

   public static String getEntityName(Entity var0) {
      String var1 = ((Entity)var0).getType().name();
      if (var0 instanceof Projectile) {
         Projectile var2 = (Projectile)var0;
         if (var2.getShooter() != null && var2.getShooter() instanceof LivingEntity) {
            var0 = (LivingEntity)var2.getShooter();
         }
      }

      if (var0 instanceof Player) {
         var1 = ((Entity)var0).getName();
      } else if (var0 instanceof LivingEntity) {
         if (((Entity)var0).getCustomName() != null) {
            var1 = ((Entity)var0).getCustomName();
         } else {
            var1 = Lang.getCustom("EntityNames." + ((Entity)var0).getType().name());
         }
      } else {
         var1 = "Unknown Object";
      }

      return var1;
   }

   public static <K, V extends Comparable<? super V>> Map<K, V> sortByValue(Map<K, V> var0) {
      LinkedList var1 = new LinkedList(var0.entrySet());
      Collections.sort(var1, new Comparator<Entry<K, V>>() {
         public int compare(Entry<K, V> var1, Entry<K, V> var2) {
            return ((Comparable)var1.getValue()).compareTo(var2.getValue());
         }
      });
      LinkedHashMap var2 = new LinkedHashMap();
      Iterator var4 = var1.iterator();

      while(var4.hasNext()) {
         Entry var3 = (Entry)var4.next();
         var2.put(var3.getKey(), (Comparable)var3.getValue());
      }

      return var2;
   }

   public static <T> List<List<T>> split(List<T> var0, int var1) {
      ArrayList var2 = new ArrayList();

      for(int var3 = 0; var3 < var0.size(); var3 += var1) {
         var2.add(var0.subList(var3, Math.min(var3 + var1, var0.size())));
      }

      return var2;
   }

   public static String IntegerToRomanNumeral(int var0) {
      if (var0 >= 1 && var0 <= 3999) {
         String var1;
         for(var1 = ""; var0 >= 1000; var0 -= 1000) {
            var1 = var1 + "M";
         }

         while(var0 >= 900) {
            var1 = var1 + "CM";
            var0 -= 900;
         }

         while(var0 >= 500) {
            var1 = var1 + "D";
            var0 -= 500;
         }

         while(var0 >= 400) {
            var1 = var1 + "CD";
            var0 -= 400;
         }

         while(var0 >= 100) {
            var1 = var1 + "C";
            var0 -= 100;
         }

         while(var0 >= 90) {
            var1 = var1 + "XC";
            var0 -= 90;
         }

         while(var0 >= 50) {
            var1 = var1 + "L";
            var0 -= 50;
         }

         while(var0 >= 40) {
            var1 = var1 + "XL";
            var0 -= 40;
         }

         while(var0 >= 10) {
            var1 = var1 + "X";
            var0 -= 10;
         }

         while(var0 >= 9) {
            var1 = var1 + "IX";
            var0 -= 9;
         }

         while(var0 >= 5) {
            var1 = var1 + "V";
            var0 -= 5;
         }

         while(var0 >= 4) {
            var1 = var1 + "IV";
            var0 -= 4;
         }

         while(var0 >= 1) {
            var1 = var1 + "I";
            --var0;
         }

         return var1;
      } else {
         return "Invalid Roman Number Value";
      }
   }

   public static int romanToDecimal(String var0) {
      int var1 = 0;
      short var2 = 0;
      String var3 = var0.toUpperCase();

      for(int var4 = var3.length() - 1; var4 >= 0; --var4) {
         char var5 = var3.charAt(var4);
         switch(var5) {
         case 'C':
            var1 = processDecimal(100, var2, var1);
            var2 = 100;
            break;
         case 'D':
            var1 = processDecimal(500, var2, var1);
            var2 = 500;
            break;
         case 'I':
            var1 = processDecimal(1, var2, var1);
            var2 = 1;
            break;
         case 'L':
            var1 = processDecimal(50, var2, var1);
            var2 = 50;
            break;
         case 'M':
            var1 = processDecimal(1000, var2, var1);
            var2 = 1000;
            break;
         case 'V':
            var1 = processDecimal(5, var2, var1);
            var2 = 5;
            break;
         case 'X':
            var1 = processDecimal(10, var2, var1);
            var2 = 10;
         }
      }

      return var1;
   }

   public static String getEnums(Class<?> var0, String var1, String var2) {
      String var3 = "";
      if (var0.isEnum()) {
         Object[] var7;
         int var6 = (var7 = var0.getEnumConstants()).length;

         for(int var5 = 0; var5 < var6; ++var5) {
            Object var4 = var7[var5];
            var3 = var3 + var1 + var4.toString() + var2 + ", ";
         }

         if (var3.length() > 4) {
            var3 = var3.substring(0, var3.length() - 4);
         }
      }

      return var3;
   }

   public static List<String> getEnumsList(Class<?> var0) {
      ArrayList var1 = new ArrayList();
      if (var0.isEnum()) {
         Object[] var5;
         int var4 = (var5 = var0.getEnumConstants()).length;

         for(int var3 = 0; var3 < var4; ++var3) {
            Object var2 = var5[var3];
            var1.add(var2.toString());
         }
      }

      return var1;
   }

   public static List<String> getWorldNames() {
      ArrayList var0 = new ArrayList();
      Iterator var2 = Bukkit.getWorlds().iterator();

      while(var2.hasNext()) {
         World var1 = (World)var2.next();
         var0.add(var1.getName());
      }

      return var0;
   }

   public static int processDecimal(int var0, int var1, int var2) {
      return var1 > var0 ? var2 - var0 : var2 + var0;
   }

   public static double getRandDouble(double var0, double var2) {
      return var0 + (var2 - var0) * r.nextDouble();
   }

   public static double getRandDoubleNega(double var0, double var2) {
      double var4 = var2 - var0;
      double var6 = r.nextDouble() * var4;
      double var8 = var6 + var0;
      return var8;
   }

   public static ArrayList<Player> getNearbyEntities(double var0, Location var2) {
      ArrayList var3 = new ArrayList();
      Iterator var5 = Bukkit.getOnlinePlayers().iterator();

      while(var5.hasNext()) {
         Player var4 = (Player)var5.next();
         if (var2.getWorld().equals(var4.getLocation().getWorld()) && var2.distance(var4.getLocation()) < var0) {
            var3.add(var4);
         }
      }

      return var3;
   }

   public static boolean check(Location var0) {
      return !getNearbyEntities(50.0D, var0).isEmpty();
   }

   public static Location getPointOnCircle(Location var0, boolean var1, double var2, double var4, double var6) {
      return (var1 ? var0.clone() : var0).add(Math.cos(var2) * var4, var6, Math.sin(var2) * var4);
   }

   public static Location getPointOnCircle(Location var0, double var1, double var3, double var5) {
      return getPointOnCircle(var0, true, var1, var3, var5);
   }

   public static Location getCenter(Location var0) {
      return new Location(var0.getWorld(), getRelativeCoord(var0.getBlockX()), getRelativeCoord(var0.getBlockY()), getRelativeCoord(var0.getBlockZ()));
   }

   private static double getRelativeCoord(int var0) {
      double var1 = (double)var0;
      var1 = var1 < 0.0D ? var1 - 0.5D : var1 + 0.5D;
      return var1;
   }

   public static double getClose(double var0, List<Double> var2) {
      if (var2.isEmpty()) {
         return -1.0D;
      } else {
         double var3 = Math.abs((Double)var2.get(0) - var0);
         int var5 = 0;

         for(int var6 = 1; var6 < var2.size(); ++var6) {
            double var7 = Math.abs((Double)var2.get(var6) - var0);
            if (var7 < var3) {
               var5 = var6;
               var3 = var7;
            }
         }

         return (Double)var2.get(var5);
      }
   }

   public static BaseComponent[] myHoverText(String var0) {
      ComponentBuilder var1 = new ComponentBuilder("");
      var1.append(var0);
      return var1.create();
   }

   public static Firework spawnRandomFirework(Location var0) {
      Firework var1 = (Firework)var0.getWorld().spawnEntity(var0, EntityType.FIREWORK);
      FireworkMeta var2 = var1.getFireworkMeta();
      int var3 = r.nextInt(4) + 1;
      Type var4 = Type.BALL;
      if (var3 == 1) {
         var4 = Type.BALL;
      }

      if (var3 == 2) {
         var4 = Type.BALL_LARGE;
      }

      if (var3 == 3) {
         var4 = Type.BURST;
      }

      if (var3 == 4) {
         var4 = Type.CREEPER;
      }

      if (var3 == 5) {
         var4 = Type.STAR;
      }

      int var5 = r.nextInt(250) + 1;
      int var6 = r.nextInt(250) + 1;
      Color var7 = Color.fromBGR(var5, var6, var5);
      Color var8 = Color.fromBGR(var6, var5, var6);
      FireworkEffect var9 = FireworkEffect.builder().flicker(r.nextBoolean()).withColor(var7).withFade(var8).with(var4).trail(r.nextBoolean()).build();
      var2.addEffect(var9);
      int var10 = r.nextInt(2) + 1;
      var2.setPower(var10);
      var1.setFireworkMeta(var2);
      return var1;
   }

   public static ItemStack getHashed(ItemStack var0, String var1, UUID var2) {
      if (var0.getType() == Material.SKULL_ITEM) {
         SkullMeta var3 = (SkullMeta)var0.getItemMeta();
         GameProfile var4 = new GameProfile(var2, (String)null);
         var4.getProperties().put("textures", new Property("textures", new String(var1)));
         Field var5 = null;

         try {
            var5 = var3.getClass().getDeclaredField("profile");
            var5.setAccessible(true);
            var5.set(var3, var4);
         } catch (IllegalArgumentException | IllegalAccessException | NoSuchFieldException var7) {
            var7.printStackTrace();
         }

         var0.setItemMeta(var3);
      }

      return var0;
   }

   public static int transSec(long var0) {
      return (int)((var0 - System.currentTimeMillis()) / 1000L);
   }

   public static void interactiveList(CommandSender var0, int var1, List<String> var2, String var3, String var4) {
      ArrayList var5 = new ArrayList(var2);
      int var6 = split(var5, 10).size();
      if (var1 > var6) {
         var1 = var6;
      }

      Object var14;
      if (var6 < 1) {
         var14 = new ArrayList();
      } else {
         var14 = (List)split(var5, 10).get(var1 - 1);
      }

      String var7 = var3.toLowerCase().replace(" ", "").replace("_", " ");
      var0.sendMessage("§6§m--------§e " + var3 + " List §6§m---------");
      int var8 = 10 * (var1 - 1) + 1;

      for(Iterator var10 = ((List)var14).iterator(); var10.hasNext(); ++var8) {
         String var9 = (String)var10.next();
         BaseComponent[] var11 = null;
         ComponentBuilder var12 = new ComponentBuilder("");
         var12.append("§c" + var8 + ". §7", FormatRetention.NONE);
         var12.append(var9);
         var12.append("   ", FormatRetention.NONE);
         var12.append("§a[Get Item]");
         var12.event(new HoverEvent(Action.SHOW_TEXT, myHoverText("§fGive the item into your inventory")));
         var12.event(new ClickEvent(net.md_5.bungee.api.chat.ClickEvent.Action.RUN_COMMAND, "/di " + var7 + " get " + var9 + " " + var4));
         var12.append("  ", FormatRetention.NONE);
         var11 = var12.create();
         if (var0 instanceof Player) {
            Player var13 = (Player)var0;
            var13.spigot().sendMessage(var11);
         } else {
            var0.sendMessage("§c" + var8 + ". §7" + var9);
         }
      }

      var0.sendMessage("");
      if (var1 < var6) {
         var0.sendMessage("§eType §6/di " + var7 + " list " + (var1 + 1) + " §eto next page.");
      }

      var0.sendMessage("§6§m------ §e Page §7" + var1 + "§e of §7" + var6 + " §6§m------");
   }

   public static String getDirection(Float var0) {
      var0 = var0 / 90.0F;
      var0 = (float)Math.round(var0);
      if (var0 != -4.0F && var0 != 0.0F && var0 != 4.0F) {
         if (var0 != -1.0F && var0 != 3.0F) {
            if (var0 != -2.0F && var0 != 2.0F) {
               return var0 != -3.0F && var0 != 1.0F ? "" : "WEST";
            } else {
               return "NORTH";
            }
         } else {
            return "EAST";
         }
      } else {
         return "SOUTH";
      }
   }

   public static String getCardinalDirection(Player var0) {
      double var1 = (double)((var0.getLocation().getYaw() - 90.0F) % 360.0F);
      if (var1 < 0.0D) {
         var1 += 360.0D;
      }

      if (0.0D <= var1 && var1 < 22.5D) {
         return "N";
      } else if (22.5D <= var1 && var1 < 67.5D) {
         return "NE";
      } else if (67.5D <= var1 && var1 < 112.5D) {
         return "E";
      } else if (112.5D <= var1 && var1 < 157.5D) {
         return "SE";
      } else if (157.5D <= var1 && var1 < 202.5D) {
         return "S";
      } else if (202.5D <= var1 && var1 < 247.5D) {
         return "SW";
      } else if (247.5D <= var1 && var1 < 292.5D) {
         return "W";
      } else if (292.5D <= var1 && var1 < 337.5D) {
         return "NW";
      } else {
         return 337.5D <= var1 && var1 < 360.0D ? "N" : null;
      }
   }

   public static Color getColorOfChar(String var0) {
      Color var1 = Color.WHITE;
      switch(var0.hashCode()) {
      case 48:
         if (var0.equals("0")) {
            var1 = Color.BLACK;
         }
         break;
      case 49:
         if (var0.equals("1")) {
            var1 = Color.NAVY;
         }
         break;
      case 50:
         if (var0.equals("2")) {
            var1 = Color.GREEN;
         }
         break;
      case 51:
         if (var0.equals("3")) {
            var1 = Color.TEAL;
         }
         break;
      case 52:
         if (var0.equals("4")) {
            var1 = Color.MAROON;
         }
         break;
      case 53:
         if (var0.equals("5")) {
            var1 = Color.OLIVE;
         }
         break;
      case 54:
         if (var0.equals("6")) {
            var1 = Color.ORANGE;
         }
         break;
      case 55:
         if (var0.equals("7")) {
            var1 = Color.SILVER;
         }
         break;
      case 56:
         if (var0.equals("8")) {
            var1 = Color.GRAY;
         }
         break;
      case 57:
         if (var0.equals("9")) {
            var1 = Color.BLUE;
         }
         break;
      case 97:
         if (var0.equals("a")) {
            var1 = Color.LIME;
         }
         break;
      case 98:
         if (var0.equals("b")) {
            var1 = Color.AQUA;
         }
         break;
      case 99:
         if (var0.equals("c")) {
            var1 = Color.RED;
         }
         break;
      case 100:
         if (var0.equals("d")) {
            var1 = Color.PURPLE;
         }
         break;
      case 101:
         if (var0.equals("e")) {
            var1 = Color.YELLOW;
         }
         break;
      case 102:
         if (var0.equals("f")) {
            var1 = Color.WHITE;
         }
      }

      return var1;
   }

   public static Color getColorByName(String var0) {
      Color var1 = Color.WHITE;
      var0 = var0.toUpperCase();
      switch(var0.hashCode()) {
      case -2027972496:
         if (var0.equals("MAROON")) {
            var1 = Color.MAROON;
         }
         break;
      case -1955522002:
         if (var0.equals("ORANGE")) {
            var1 = Color.ORANGE;
         }
         break;
      case -1923613764:
         if (var0.equals("PURPLE")) {
            var1 = Color.PURPLE;
         }
         break;
      case -1848981747:
         if (var0.equals("SILVER")) {
            var1 = Color.SILVER;
         }
         break;
      case -1680910220:
         if (var0.equals("YELLOW")) {
            var1 = Color.YELLOW;
         }
         break;
      case 81009:
         if (var0.equals("RED")) {
            var1 = Color.RED;
         }
         break;
      case 2016956:
         if (var0.equals("AQUA")) {
            var1 = Color.AQUA;
         }
         break;
      case 2041946:
         if (var0.equals("BLUE")) {
            var1 = Color.BLUE;
         }
         break;
      case 2196067:
         if (var0.equals("GRAY")) {
            var1 = Color.GRAY;
         }
         break;
      case 2336725:
         if (var0.equals("LIME")) {
            var1 = Color.LIME;
         }
         break;
      case 2388918:
         if (var0.equals("NAVY")) {
            var1 = Color.NAVY;
         }
         break;
      case 2570844:
         if (var0.equals("TEAL")) {
            var1 = Color.TEAL;
         }
         break;
      case 63281119:
         if (var0.equals("BLACK")) {
            var1 = Color.BLACK;
         }
         break;
      case 68081379:
         if (var0.equals("GREEN")) {
            var1 = Color.GREEN;
         }
         break;
      case 75295163:
         if (var0.equals("OLIVE")) {
            var1 = Color.OLIVE;
         }
         break;
      case 82564105:
         if (var0.equals("WHITE")) {
            var1 = Color.WHITE;
         }
      }

      return var1;
   }

   public static void playEffect(String var0, double var1, double var3, double var5, double var7, int var9, Location var10) {
      Particle var11;
      if (var0.split(":").length == 2) {
         var11 = Particle.valueOf(var0.split(":")[0].toUpperCase());
      } else {
         try {
            var11 = Particle.valueOf(var0.toUpperCase());
         } catch (IllegalArgumentException var18) {
            var11 = Particle.CLOUD;
         }
      }

      if (var11 == Particle.REDSTONE) {
         if (VersionUtils.Version.getCurrent().isHigher(VersionUtils.Version.v1_12_R1)) {
            return;
         }

         Color var12 = Color.RED;
         if (var0.split(":").length == 2) {
            String var13 = var0.split(":")[1];
            if (var13.split(",").length == 3) {
               String[] var14 = var13.split(",");
               int var15 = Integer.parseInt(var14[0]);
               int var16 = Integer.parseInt(var14[1]);
               int var17 = Integer.parseInt(var14[2]);
               Color.fromRGB(var15, var16, var17);
            } else {
               var12 = getColorByName(var13);
            }
         }

         var10.getWorld().spawnParticle(var11, var10, var9, var1, var3, var5, 1.0D);
      } else {
         Material var19;
         if (var11 == Particle.BLOCK_CRACK) {
            if (VersionUtils.Version.getCurrent().isHigher(VersionUtils.Version.v1_12_R1)) {
               return;
            }

            var19 = null;
            if (var0.split(":").length == 2) {
               var19 = Material.getMaterial(var0.split(":")[1].toUpperCase());
            }

            if (var19 == null) {
               var19 = Material.STONE;
            }

            if (VersionUtils.Version.getCurrent().isLower(VersionUtils.Version.v1_13_R1)) {
               var10.getWorld().spawnParticle(var11, var10, var9, var1, var3, var5, var7);
            } else {
               var10.getWorld().spawnParticle(var11, var10, var9, var1, var3, var5, var7, var19.getData());
            }
         } else if (var11 == Particle.ITEM_CRACK) {
            var19 = null;
            if (var0.split(":").length == 2) {
               var19 = Material.getMaterial(var0.split(":")[1].toUpperCase());
            }

            if (var19 == null) {
               var19 = Material.STONE;
            }

            var10.getWorld().spawnParticle(var11, var10, var9, var1, var3, var5, var7, new ItemStack(var19));
         } else {
            if (VersionUtils.Version.getCurrent().isHigher(VersionUtils.Version.v1_12_R1)) {
               return;
            }

            var10.getWorld().spawnParticle(var11, var10, var9, var1, var3, var5, var7);
         }
      }

   }
}
